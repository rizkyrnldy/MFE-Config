import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginPage } from './login';
import { CalendarModule } from 'ion2-calendar';


@NgModule({
  declarations: [
    LoginPage
  ],
  imports: [
    IonicPageModule.forChild(LoginPage),
    CalendarModule
  ],
  entryComponents: [
    LoginPage
  ]
})
export class LoginPageModule { }
