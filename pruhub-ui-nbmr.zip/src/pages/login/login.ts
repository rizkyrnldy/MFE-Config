import { Component } from '@angular/core';
import { NavController, AlertController, LoadingController, Loading, IonicPage, ModalController, NavParams } from 'ionic-angular';
import { UserProvider, TaskProvider, ComplianceProvider } from '../../providers/providers';
import { MainMenuProvider } from '../../providers/providers';
import { Storage } from '@ionic/storage';
import { User } from '../../providers/user/user';
import { WhatsappAgentUserLoginProvider } from '../../providers/whatsapp-agent/user-login-provider';

@IonicPage()

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})

export class LoginPage {
  loading: Loading;
  registerCredentials = { username: '', password: '', channel: 'user' };
  rioleDistributionList: any[] = [];
  dummyLogin: boolean = false;
  constructor(private task:TaskProvider, private nav: NavController, private auth: UserProvider, private alertCtrl: AlertController, private loadingCtrl: LoadingController, public mainMenu: MainMenuProvider, private storage: Storage, public whatsappAgentUserLoginProvider: WhatsappAgentUserLoginProvider, private compProv: ComplianceProvider) { 
    this.mainMenu.activePage = 'Login';
    this.mainMenu.activeChildPage = '';
  }

  public createAccount() {
    this.nav.push('RegisterPage');
  }
 

  public login() {
    this.showLoading()
    this.auth.login(this.registerCredentials).subscribe(allowed => {
      if (allowed) {  
        this.storage.set('Authorization', "Bearer-"+allowed.access_token);   
        this.storage.set('username', allowed.username);
        this.storage.set('password', this.registerCredentials.password);
        this.storage.set('roles', allowed.roles);
        this.storage.set('access_token', allowed.access_token);
        this.mainMenu.username = allowed.username;
        this.auth.encrypt(allowed.username, this.registerCredentials.password, "Bearer-"+allowed.access_token)
          .subscribe(encrypted => {
            this.auth.listRoleDistributionUserByUsername(allowed.username, "Bearer-"+allowed.access_token) 
            .subscribe(result => { 
              this.auth.roleDistributionList = result; 
              this.storage.set('roleDistributionList', result);
              this.storage.set('encrypted', encrypted);
              this.storage.set('isLoggedin', true);
              this.storage.set('createdTime', Date.now());
              this.auth._isLoggedin = true;
              this.auth.currentUser = {name: allowed.username, email:''};
              this.mainMenu.mainMenuInit();
              this.loadMenu("Bearer-"+allowed.access_token);
              this.mainMenu.openMenu(true);
              // this.createUserLogin(allowed.username);
            }, 
            error => { 
              this.showError(error); 
            }); 
          },
          (error:any) => {
            this.showError(error);
          });
      } else {
        this.showError("Access Denied");
      }
    },
      (error:any) => {
        if(error.slice(error.length - 16, error.length) == "401 Unauthorized"){
          this.showError("Username or Password is Incorect");
        }else{
        this.showError(error);
        }
      });
  }


  isClaimUser(listRoleDistributionUser:any[]){
    let claimRoles:string[] = [
      "CLM_ADMINISTRATOR","CLM_AV_MAJOR","CLM_AV_MINOR","CLM_CA_HIGH",
      "CLMNGR10","CLM_CA_LOW","CLM_CA_CLMNGRP3","CLMNGRP3","CLM_CA_CLMNGRP4",
      "CLM_CA_CLMNGRP5","CLM_CA_CLMNGR10","CLMNGRP1","CLMNGRP2","CLMNGRP4",
      "CLMNGRP5","CLM_HANDLER_DUP_WF","CLM_HANDLER_LM","CLM_HANDLER_COI",
      "CLM_HANDLER_DUP_CLIENT","CLM_HANDLER_INCOMING","CLM_JET_APPROVE",
      "CLM_JET_DECLINE","CLM_RE-UNDERWRITING","CLM_LEGAL&COMPLIENCE",
      "CLM_BILLING","CLM_INVESTIGATOR_CALL","CLM_MINOR_CMO","CLM_INVESTIGATOR_APS",
      "CLM_AML","CLM_INVESTIGATOR_1","CLM_INVESTIGATOR_2","CLM_INVESTIGATOR_3",
      "CLM_RISK","CLM_PHS","CLM_OSC","CLM_CC","CLM_MINOR_SUPERVISOR","CLM_LETTER_ADMIN",
      "CLM_HD","CLM_TPA_ADMIN","CLM_MINOR_WO&FCR"];
    for(let userData of listRoleDistributionUser){
      for(let claimRole of claimRoles){  
        if(userData.id.roleDistribution == claimRole){
          return true;
        }
      }
    };
    
    return false;
  }

  findComplianceByStateMenu(menuChildren, objCompliance) {
    for (let item of menuChildren ) {
      if (item.state == 'ComplianceAssessmentPage') objCompliance.isComplience = true;
      if (item.state == 'PICAssessmentPage') objCompliance.isDeptPIC = true;
      if (item.state == 'ComplianceHodApprovalPage') objCompliance.isHOD = true;

      if (objCompliance.isHOD || objCompliance.isComplience) return objCompliance;
      objCompliance = this.findComplianceByStateMenu(item.children, objCompliance);
    }
    return objCompliance;
  }

  async getComplianceUser(userMenu) {
    let isComplianceUser: boolean = false;
    let userRole: string = null;
    let  objCompliance = {isComplience: false, isDeptPIC: false, isHOD: false }

    objCompliance = this.findComplianceByStateMenu(userMenu.content, objCompliance);
    if (objCompliance.isHOD) {
      userRole = "REGULATORY_COMPLIANCE_HOD";
      isComplianceUser = true;
    } else if (objCompliance.isComplience) {
      userRole = "REGULATORY_COMPLIANCE";
      isComplianceUser = true;
    } else if (objCompliance.isDeptPIC) {
      userRole = "REGULATORY_COMPLIANCE_PIC";
      isComplianceUser = true;
    }
    console.log('complianceUser', objCompliance, userRole);
    if (isComplianceUser) {
      let complianceUser: any = {}
      const username = await this.storage.get('username');
      const Authorization = await this.storage.get('Authorization');
      const resEmployee = await this.compProv.getEmployeeDetail(username, Authorization).toPromise();
      if (resEmployee.body && resEmployee.body.data && resEmployee.body.data.list && resEmployee.body.data.list.length>0 ) {
        complianceUser = resEmployee.body.data.list[0].map;
        complianceUser.role = userRole;
        
        const resNotif = await this.compProv.showNotification(username, Authorization, complianceUser.EmployeeId).toPromise();
        let unreadNotif = 0;
        if (resNotif.body && resNotif.body.data && resNotif.body.data.length>0 ) {
          unreadNotif = resNotif.body.data.filter((item) => { return item.opened == 'F'} ).length;
        }
        complianceUser.unreadNotif = unreadNotif;

        const resApproval = await this.compProv.checkApprovalByHod(username, Authorization, complianceUser.EmployeeId).toPromise();
        let approvalCount = 0;
        if (resApproval.body && resApproval.body.data) {
          approvalCount = resApproval.body.data;
        }

        complianceUser.approvalCount = approvalCount;
        this.auth.complianceUser = complianceUser;
      }
    }
  }
 
  loadMenu(Authorization){
    if (this.dummyLogin == true) {
      this.auth.role ='All';
      this.auth.getMenu(Authorization)
        .subscribe((result) => {
            for(let key in result.content){
              var item = {};
              item = result.content[key];
              this.mainMenu.mainNav[this.mainMenu.userActionIndex].children.push(item);
            }

            if(this.registerCredentials.username == "rifkii"){
              let menuClaim = this.mainMenu.searchMenu(this.mainMenu.mainNav, "Claim");
              if(menuClaim != undefined && menuClaim != null){
                menuClaim.children[menuClaim.children.length] = {
                  "children": [{
                    "children": [],
                    "id": 67627,
                    "mobileFlag": false,
                    "name": "Bank Account Handler",
                    "parentId": null,
                    "parentName": null,
                    "priority": 2.0,
                    "state": "PaymentOutClaimPage",
                    "type": "link",
                    "url": []
                  }, {
                    "children": [],
                    "id": 67634,
                    "mobileFlag": false,
                    "name": "Payment Handler",
                    "parentId": null,
                    "parentName": null,
                    "priority": 5.0,
                    "state": "PaymentOutClaimPage",
                    "type": "link",
                    "url": []
                  }, {
                    "children": [],
                    "id": 67631,
                    "mobileFlag": false,
                    "name": "AML Handler",
                    "parentId": null,
                    "parentName": null,
                    "priority": 15.0,
                    "state": "PaymentOutClaimPage",
                    "type": "link",
                    "url": []
                  },{
                    "children": [],
                    "id": 67631,
                    "mobileFlag": false,
                    "name": "Release Reject Handler",
                    "parentId": null,
                    "parentName": null,
                    "priority": 15.0,
                    "state": "PaymentOutClaimPage",
                    "type": "link",
                    "url": []
                  },{
                    "children": [],
                    "id": 67631,
                    "mobileFlag": false,
                    "name": "Case Summary",
                    "parentId": null,
                    "parentName": null,
                    "priority": 15.0,
                    "state": "PaymentOutTabs-Case Summary",
                    "type": "link",
                    "url": []
                  },{
                    "children": [],
                    "id": 67631,
                    "mobileFlag": false,
                    "name": "Reserve Amount",
                    "parentId": null,
                    "parentName": null,
                    "priority": 15.0,
                    "state": "PaymentOutTabs-Reserve Amount",
                    "type": "link",
                    "url": []
                  }
                  ],
                  "id": 67626,
                  "mobileFlag": false,
                  "name": "Payment Out Claim",
                  "parentId": null,
                  "parentName": null,
                  "priority": 1.0,
                  "state": "PaymentOutClaimPage",
                  "type": "dropdown",
                  "url": []
                }
              }
            }

            this.nav.setRoot('HomePage');
        }, (error) => {
          console.log('error: ', error);
        });

    }else{
      this.auth.role ='All';
      this.auth.getMenu(Authorization)
        .subscribe((result) => {
            for(let key in result.content){
              var item = {};
              item = result.content[key];
              this.mainMenu.mainNav[this.mainMenu.userActionIndex].children.push(item);
            }
            this.getComplianceUser(result);

            this.nav.setRoot('HomePage');
        }, (error) => {
          console.log('error: ', error);
        });
    }
  }

  createUserLogin(username) {
    let userLoginEnt = ({
      userlogin: username
    });
    this.storage.get('Authorization').then((Authorization) => {
      this.whatsappAgentUserLoginProvider.createUserLogin(userLoginEnt, Authorization)
        .subscribe(data => {

        }, error => {

          return;
        });
    });
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
  }
 
  showError(text) {
    this.loading.dismiss();
    let alert = this.alertCtrl.create({
      title: 'Login Failed',
      subTitle: text,
      buttons: ['OK']
    });
    alert.present(prompt);
  }
}