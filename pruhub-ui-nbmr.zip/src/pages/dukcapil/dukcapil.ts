import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams} from 'ionic-angular';
import { DukcapilProvider } from '../../providers/providers';
import { AlertController } from 'ionic-angular/components/alert/alert-controller';
import { Storage } from '@ionic/storage';


/**
 * Generated class for the DukcapilPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-dukcapil',
  templateUrl: 'dukcapil.html',
})
export class DukcapilPage {

	
nik :any;
searchkey: any;
noKK: any;
fullName: any;
kabupatenName: any;
religion: any;
rwNumber: any;
kecamatanName: any;
occupationType: any;
rtNumber: any;
kelurahanNumber: any;
address: any;
kecamatanNumber: any;
birthPlace: any;
lastEducation: any;
marriedStatus: any;
relationFamilyStatus: any;
provinceNumber: any;
motherFullName: any;
provinceName: any;
kabupatenNumber: any;
kelurahanName: any;
gender: any;
birthDate: any;
errorMessage : any;

  
  constructor(private storage: Storage,public navCtrl: NavController, public navParams: NavParams,
  	public dukcapilService: DukcapilProvider, private alertCtrl: AlertController) {
  //this.nik="coba";
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DukcapilPage');
  }

  ionViewWillEnter(){
    this.storage.get('isLoggedin').then((val) => {
      if (!val) {
        this.navCtrl.setRoot('LoginPage');
      }
    });
  }

  search() {
  	console.log(this.searchkey);
  	console.log("test");
  	//this.nik=this.searchkey;
this.storage.get('Authorization').then((Authorization) => {
  	 this.dukcapilService.getDataByNik(this.searchkey,Authorization).subscribe(rs => {
  		console.log(rs);
  		if(rs.responseCode == '00'){
  		this.nik= rs.nik;
this.noKK= rs.noKK;
this.fullName= rs.fullName;
this.kabupatenName= rs.kabupatenName;
this.religion= rs.religion;
this.rwNumber= rs.rwNumber;
this.kecamatanName= rs.kecamatanName;
this.occupationType= rs.occupationType;
this.rtNumber= rs.rtNumber;
this.kelurahanNumber= rs.kelurahanNumber;
this.address= rs.address;
this.kecamatanNumber= rs.kecamatanNumber;
this.birthPlace= rs.birthPlace;
this.lastEducation= rs.lastEducation;
this.marriedStatus= rs.marriedStatus;
this.relationFamilyStatus= rs.relationFamilyStatus;
this.provinceNumber= rs.provinceNumber;
this.motherFullName= rs.motherFullName;
this.provinceName= rs.provinceName;
this.kelurahanName= rs.kelurahanName;
this.gender= rs.gender;
this.birthDate= rs.birthDate;
this.kabupatenNumber= rs.kabupatenNumber;}
else{
	//errorHandler(rs.responseCode);
	
	if(rs.responseCode == "01"){
		this.errorMessage="GAGAL LOGIN";
	}else if(rs.responseCode == "02"){
		this.errorMessage="DATA TIDAK DITEMUKAN";
	}else if(rs.responseCode == "03"){
		this.errorMessage="IP ADDRESS TIDAK DITEMUKAN";
	}else if(rs.responseCode == "04"){
		this.errorMessage="IP ADDRESS TIDAK TERDAFTAR";
	}else if(rs.responseCode == "05"){
		this.errorMessage="DATA NULL";
	}else if(rs.responseCode == "06"){
		this.errorMessage="NIK TIDAK BOLEH BERUPA ALFANUMERIK";
	}else if(rs.responseCode == "07"){
		this.errorMessage="NIK DIMULAI DENGAN ANGKA 0";
	}else if(rs.responseCode == "08"){
		this.errorMessage="NIK DIAKHIRI 4 ANGKA 0";
	}else if(rs.responseCode == "09"){
		this.errorMessage="NIK HARUS TERDIRI DARI 16 CHARACTER";
	}else if(rs.responseCode == "10"){
		this.errorMessage="NIK HARUS TERDIRI DARI 16 CHARACTER";
	}else if(rs.responseCode == "11"){
    this.errorMessage="API TIDAK DAPAT DI AKSES";
  }else if(rs.responseCode == "12"){
    this.errorMessage="QUOTA MAXIMAL HARIAN TELAH TERCAPAI";
  }else if(rs.responseCode == "13"){
    this.errorMessage="USER TIDAK MEMILIKI AKSES KE API";
  }else if(rs.responseCode == "99"){
    this.errorMessage="API TIDAK DAPAT DI AKSES";
  }else{
    this.errorMessage="KESALAHAN SISTEM, MOHON KONTAK ADIMINISTRATOR";
  }

	this.msgHandler("error",this.errorMessage);
}



  	});
	  });
  

    //return this.nik;
  } 

   errorHandler(error){
    const alert = this
    .alertCtrl
    .create({title: 'Error Message', message: error, buttons: ['Ok']});
    alert.present();
  }

  msgHandler(title: string, message: string){
    const alert = this
    .alertCtrl
    .create({title: title, message: message, buttons: ['Ok']});
    alert.present();
  }


}
