import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-pdf-viewer-modal',
  templateUrl: 'pdf-viewer-modal.html',
})
export class PdfViewerModalPage {
	document: any = {};
  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl : ViewController) {
	  this.document = navParams.get('data');
  }

  public closeModal(){
    this.viewCtrl.dismiss();
	}
}
