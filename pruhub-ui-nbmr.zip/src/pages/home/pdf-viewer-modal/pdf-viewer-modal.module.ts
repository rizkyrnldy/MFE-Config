import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PdfViewerModalPage } from './pdf-viewer-modal';
import { PdfViewerModule } from 'ng2-pdf-viewer';

@NgModule({
  declarations: [
    PdfViewerModalPage,
  ],
  imports: [
    IonicPageModule.forChild(PdfViewerModalPage),
    PdfViewerModule
  ],
})
export class PdfViewerModalPageModule {}
