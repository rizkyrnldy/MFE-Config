import { Component, ViewChild  } from '@angular/core';
import { IonicPage, NavController, NavParams, Slides, ModalController  } from 'ionic-angular';
import { MainMenuProvider, UserProvider, DashboardProvider} from './../../providers/providers';
import { Storage } from '@ionic/storage';

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  @ViewChild(Slides) slides: Slides;
  @ViewChild('slide2') slide2: Slides;
  tabs: Array<{id: number, active: number}>;
  dashboardTeam : any;
  dashboardIndividual: any = {};
  currentIndex: number = 0;
  updates: any[] = [];
  calendars: any[] = [];
  documents: any[] = [];

  tabsNews:any = [
    {id: 0, active: 0, name: 'bookmark'},
    {id: 1, active: 0, name: 'SCHEDULE'},
    {id: 2, active: 0, name: 'sign up'}
  ]

  widgetMobile:any = [
    {id: 0, active: 0, name: 'CORPORATE CALENDER'},
    {id: 1, active: 0, name: 'Prudata & Library'},
    {id: 2, active: 0, name: 'CORPORATE UPDATES'}
  ]

  activeDashboardIndividual: number = 0;

  goToSlide() {
    this.slide2.slideTo(1, 500);
  }

  slideChanged(e) {
    console.log(e);
    this.currentIndex = this.slide2.getActiveIndex();
  }

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    public mainMenu: MainMenuProvider, 
    private auth: UserProvider, 
    private dashboard: DashboardProvider, 
    public storage: Storage,
    public modalCtrl: ModalController) {

    mainMenu.activePage = 'User Action';
    mainMenu.activeChildPage = 'Home';

    this.tabs = [
      {id:0, active: 0},
      {id:1, active: 0},
      {id:2, active: 0},
      {id:3, active: null},
      {id:4, active: 0},
      {id:5, active: 0}
    ]
    
    this.loadData();
  }

  actTab(tabs, a, e){
    if (tabs == this.tabs[3]) {
      if (tabs.active == a) {
        tabs.active = null;
        return false;
      }
    }
    tabs.active = a;
    if (this.tabs[1].active == 3){
    }
    if (this.tabs[2].active == 15){
    }
  }

  loadData(){
    this.storage.get('Authorization').then((Authorization) => {
      this.storage.get('encrypted').then((val) => {
        this.dashboard.dashboardindividual(val, Authorization)
          .subscribe((dashboard_individual: any) => {
            if (dashboard_individual.userName != undefined) {
              this.dashboardIndividual = dashboard_individual;            
            }
          }, (error) => {
            console.warn(error); 
          });

        this.dashboard.dashboarddocuments(val, Authorization)
          .subscribe((dashboard_documents: any) => {
            if (dashboard_documents) {
              this.documents = dashboard_documents.msDocumentsData;  
              this.calendars = dashboard_documents.msCalendarsData;  
              this.updates = dashboard_documents.msUpdatesData;
            }
          }, (error) => {
            console.warn(error); 
          });
      });
    });
  }

  openDropdownHome(e){
    let element = e.currentTarget.nextElementSibling;
    let height = element.children[0].offsetHeight;
    let parentAcc = element.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement;
    let parentAccHeight = parentAcc.offsetHeight;
    let head = element.previousElementSibling;

    // if (parentAcc != null) {
    if (parentAcc.className != 'wf-body-dropdown'){
      let element = e.target;
      while((element = element.parentElement) && !element.classList.contains('wf-body-dropdown')) {
        parentAcc = element.parentElement;
      }
      if (parentAcc != null) {
        parentAccHeight = parentAcc.offsetHeight;
      }
    }

    e.stopPropagation();

    if (height > 1000){
      element.setAttribute("transition-duration", "1000");
    }else{
      element.setAttribute("transition-duration", "300");
    }

    if (element.hasAttribute('style')){
      element.removeAttribute("style");

      if (parentAcc) {
        parentAcc.setAttribute("style", "height:auto");
      }
      head.classList.add("wf-icon-add");
      head.classList.add("line-black");
      head.classList.remove("wf-icon-danger");
    } else if (element.classList.contains("wf-drop-open")) {
      element.classList.remove("wf-drop-open");
      head.classList.add("wf-icon-add");
      head.classList.add("line-black");
      head.classList.remove("wf-icon-danger");
    } else{
      element.setAttribute("style", "height: auto");
      if (parentAcc) {
        parentAcc.setAttribute("style", "height:auto");
      }
      head.classList.remove("wf-icon-add");
      head.classList.remove("line-black");
      head.classList.add("wf-icon-danger");
      
    }
  }

  ionViewDidLoad() {
  }

  ionViewWillEnter(){ 
    if(this.auth.loggedIn()){
      return true
    }else{
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
  } 

  toLowerCase(val){
    return val.toLowerCase();
  }

  presentPDFViewer(document_data) {
    let PDFModal = this.modalCtrl.create('PdfViewerModalPage', {data:document_data}, {showBackdrop:true});
    PDFModal.present();
  }

  removeTabs(tabs, a) {
    if (tabs.active != a) {
      tabs.active = null;
    }
  }

  public newsBanner = false;

  ngOnInit(){
    //show box msg
    this.newsBanner = true;
    //wait 3 Seconds and hide
    setTimeout(() => {
     this.newsBanner = false;
     // console.log(this.newsBanner);
    }, 30000);
  }

  gotoComplianceHODApproval() {
    this.navCtrl.setRoot('ComplianceHodApprovalPage');
  }

}
