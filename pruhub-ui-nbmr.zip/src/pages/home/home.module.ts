import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { HomePage } from './home';
import { MutDatatableV2Component } from '../../app/shared/datatable-v2/mut-datatable-v2';

@NgModule({
  declarations: [
    HomePage,
    MutDatatableV2Component
  ],
  exports:    [ MutDatatableV2Component ],
  imports: [
    IonicPageModule.forChild(HomePage),
  ],
})
export class HomePageModule {}