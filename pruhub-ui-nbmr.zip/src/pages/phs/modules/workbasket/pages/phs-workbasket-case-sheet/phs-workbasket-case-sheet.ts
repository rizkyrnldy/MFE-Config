import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { caseSheetProvider } from '../../../../../../providers/phs/workbasket/caseSheet';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { Storage } from '@ionic/storage';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';

/**
 * Generated class for the PhsWorkbasketCaseSheetPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketcasesheet",
  segment: "PHS/workbasket/case_sheet/:id"
})
@Component({
  selector: 'page-phs-workbasket-case-sheet',
  templateUrl: 'phs-workbasket-case-sheet.html',
})
export class PhsWorkbasketCaseSheetPage {
  dataCaseSheet: any = [];
  start: number = 0;
  end: number = 10;
  activePage: number = 1;
  totalPage: number = 1;
  datatext: string;
  ionTitle: any;
  constructor(
    public navCtrl: NavController,
    public caseSheetProvider: caseSheetProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    public storage: Storage,
    private phsToastService: phsToastService,
    public navParams: NavParams,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider
  ) {
  }
  async getInitial() {
    this.caseSheetProvider.getcasesheet({ genId: await this.phsHelperStorageService.getStorageNoStringify('genId') }).subscribe(p1 => {
      // this.caseSheetProvider.getcasesheet({ genId: 'PHS_201903131846301' }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (response) {
          this.dataCaseSheet = response;
          this.totalPage = Math.ceil(response.length / 10)
          console.log("this.totalPage", this.totalPage)
          this.phsSupportProvider.dismissLoading();
        }
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  filterData(page) {
    console.log("page", page)
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  async saveData(data) {
    var param = {
      "genId": await this.phsHelperStorageService.getStorageNoStringify('genId'),
      // "genId": 'PHS_201903131846301',
      "notes": data,
      "user": await this.storage.get('username'),
      "activityName": await this.phsHelperStorageService.getStorageNoStringify('activityName')

    }
    this.caseSheetProvider.savecasesheet(param).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (!response.error) {
          this.getInitial()
          this.showToast("Save Successful");
          this.datatext = ''
        }
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getStorage();
    this.getInitial();
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }
}
