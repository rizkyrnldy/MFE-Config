import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketCaseSheetPage } from './phs-workbasket-case-sheet';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';
@NgModule({
  declarations: [
    PhsWorkbasketCaseSheetPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketCaseSheetPage),  
    PhsDirectivesModule,
    ComponentsModule
  ],
})
export class PhsWorkbasketCaseSheetPageModule {}
