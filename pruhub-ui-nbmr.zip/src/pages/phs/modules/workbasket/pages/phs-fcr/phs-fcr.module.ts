import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsFCR } from './phs-fcr';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsFCR,
  ],
  imports: [
    IonicPageModule.forChild(PhsFCR),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsFCRModule {}
