import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { IonicPage, NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { HttpClient } from '@angular/common/http';
import { UserProvider } from '../../../../../../providers/providers';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import env from '../../../../../../environments/env';
import moment from 'moment';

@IonicPage({
  name: "phsworkbasketfcr",
  segment: "PHS/workbasket/phsfcr"
})
@Component({
  selector: 'page-phs-fcr',
  templateUrl: 'phs-fcr.html',
})
export class PhsFCR {  
  form: FormGroup;
  title: string;
  accessToken: string;
  policyNo: string;
  data: Array<any>;
  loading: Loading;

  constructor(
    public formBuilder: FormBuilder,
    public navCtrl: NavController,
    public navParams: NavParams,
    public storage: Storage,
    private auth: UserProvider,
    private phsToastService: phsToastService,
    private http: HttpClient,
    private loadingCtrl: LoadingController
  ) {
    this.form = this.formBuilder.group({
      policyNo:  new FormControl({value: '', disabled: true}, Validators.required),
      suppressBilling: new FormControl("N", Validators.required),
      suppressDate: new FormControl(""),
    })
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.checkTitle();
    this.setPolicyNumber();
    this.getAccessToken();
  }

  async checkTitle() {
    this.title = await this.storage.get('ionTitle') as string;
    if (!this.title) {
      this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      return;
    }
  }
  async setPolicyNumber() {
    this.policyNo = await this.storage.get('policyNumber') as string;
    if (this.policyNo) {
      this.form.get('policyNo').setValue(this.policyNo);
    }
  }

  async getAccessToken() {
    let accessToken: string = await this.storage.get('Authorization');
    accessToken = accessToken.replace('Bearer-', "");
    this.accessToken = accessToken;
  }

  async onSubmit() {
    if(this.form.valid) {
      const { value } = this.form;
      const body = {
        body: {
          accessToken: this.accessToken,
          operation: "listFcr",
          jsonRequest: {
            CHDRSEL: this.policyNo,
            SUPFLAG: value.suppressBilling,
            SUPPTO: value.suppressDate
          }
        }
      }
      this.showLoading();
      this.http.post(env.fcr_wrapperPaymentService, body)
      .subscribe((response: any)=>{
        this.loading.dismiss();
        this.data = response.body;
        if (this.data && Array.isArray(this.data) && this.data.length > 0) {
          this.data = this.data.map((item: any) =>{
            item.date = moment(item.EFFDATE, "YYYYMMDD").format("DD/MM/YYYY")
            return item;
          })
        }
      }, (err)=> {
        this.loading.dismiss();
        this.showToast(err.message || 'Something went wrong');
      });
    }
  }

  onProcess(item) {
    const { value } = this.form;
    const body = {
      body: {
        accessToken: this.accessToken,
        operation: "fcr",
        jsonRequest: {
          CHDRSEL: this.policyNo,
          SUPFLAG: value.suppressBilling,
          SUPPTO: value.suppressDate,
          TRANNO: item.TRANNO,
          TRCODE: item.TRCODE
        }
      }
    }
    this.showLoading();
    this.http.post(env.fcr_wrapperPaymentService, body)
    .subscribe(res=> {
      this.showToast('Success');
      this.loading.dismiss();
    }, (err)=>{
      this.loading.dismiss();
      this.showToast(err.message || 'Something went wrong');
    });
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }


  showToast(text) {
    this.phsToastService.showToast(text);
  }
}
