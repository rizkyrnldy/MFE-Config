import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { clientDetailProvider } from '../../../../../../providers/phs/workbasket/clientDetail';
import { ModalProvider } from '../../../../../../providers/phs/modal/modal';
import { UserProvider} from '../../../../../../providers/providers';
import { ModalClientSearchPage } from '../phs-workbasket-modal/modal-client-search/modal-client-search';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the PhsWorkbasketClientDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketclientdetailqa",
  segment: "PHS/workbasket/client-detail-qa/:id"
})
@Component({
  selector: 'page-phs-workbasket-client-detail-qa',
  templateUrl: 'phs-workbasket-client-detail-qa.html',
})
export class PhsWorkbasketClientDetailQaPage {

  polis: any = [];
  data: any = [];
  iconDelete = false;
  iconTrash = false;
  disabled = false;
  mainlife: string;
  ionTitle: any;
  role: string;
  newclient: any;
  public addColor: string;
  public text: string;
  disableButton: boolean = true;
  showsegment: boolean = true;
  EnableAdd: boolean = false;
  NextTap: boolean;
  selectedSegment: any;
  dataLeft: any;
  dataQuotation: any;
  dataAdditional: any;
  dataSearch: boolean;
  getMasterSex: Object[];
  getMasterCountry: Object[];
  getMasterMaritalStatus: Object[];
  datamasterreasoninsurance: Object[];
  dataPolicyNumber: Object[];
  getMasterSourceOfIncome: Object[];
  getMasterIncome: Object[];
  getMasterCountryCodes: Object[];
  getMasterSalutation: Object[];
  getMasterOccupation: Object[];
  getListSearchAs: any = [];
  dataPolicyHolder: Object;
  dataLifeAssured: Object;
  dataBoneClientPolicy: any;
  dataBoneNewClient: any;
  dataBoneClientAssure: any;
  getMasterProvince: Object[]
  home_phone: any = { country_phone: "", number: "", type: "Home" }; office_phone: any = { country_phone: "", number: "", type: "Office" }; mobile_phone1: any = { country_phone: "", number: "", type: "GSM1" }; mobile_phone2: any = { country_phone: "", number: "", type: "GSM2" }; cdma: any = { country_phone: "", number: "", type: "CDMA" }
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    public clientDetailProvider: clientDetailProvider,
    private modalCtrl: ModalProvider,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private auth: UserProvider,
    public alertCtrl: AlertController) {
    this.addColor = "buttonNonActiveClass";
    this.polis = "userPolis";
    this.text = 'Errased Life Assured';
    // this.data = [
    //   {
    //     id: 1,
    //     name: 'Main Life Assured',
    //     value: 'mainLifeAssured'
    //   }
    // ]

  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  async mergeAddClient() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.brmsverification.additional_new_client.forEach(element => {
      let number: any
      console.log("element.role", element.role)
      if (!isNaN(element.role)) {
        number = parseInt(element.role)
        this.data.splice(number - 1,0,{
          clntnum: null,
          name: parseInt(element.role) == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + (number-1),
          role: '0'+number,
          value: 'formAssured' + (number-1),
          // newclient: true
        });
      }
    });

    this.getDataBoneNewClient(this.data[0].clntnum, this.data[0].role, this.data[0].newclient, null)
    this.mainlife = this.data[0].value
  }

  SearchAs(params) {
    params.forEach(element => {
      console.log(element.clrrrole + element.life)
      switch (element.clrrrole + element.life) {
        case "OW":
          element.name = 'Policy Holder'; element.value = 'policyholder'; element.desc = 'Policy Holder'
          this.getListSearchAs.push(element)
          break;
        case "PY":
          element.name = 'Payor'; element.value = 'payor'; element.desc = 'Payor'
          this.getListSearchAs.push(element)
          break;
        case "LF01":
          element.name = 'Main Life Assured'; element.value = 'mainlifeassured'; element.desc = 'Main Life Assured'
          this.getListSearchAs.push(element)
          this.data.push(element)
          break;
        case "LF02":
          element.name = 'Additional Life Assured 1'; element.value = 'additionallifeassured1'; element.desc = 'Additional Life Assured 1'
          this.getListSearchAs.push(element)
          this.data.push(element)
          break;
        case "LF03":
          element.name = 'Additional Life Assured 2'; element.value = 'additionallifeassured2'; element.desc = 'Additional Life Assured 2'
          this.getListSearchAs.push(element)
          this.data.push(element)
          break;
        case "LF04":
          element.name = 'Additional Life Assured 3'; element.value = 'additionallifeassured3'; element.desc = 'Additional Life Assured 3'
          this.getListSearchAs.push(element)
          this.data.push(element)
          break;
        case "LF05":
          element.name = 'Additional Life Assured 4'; element.value = 'additionallifeassured4'; element.desc = 'Additional Life Assured 4'
          this.getListSearchAs.push(element)
          this.data.push(element)
          break;
      }
    });
    this.mergeAddClient();
  }

  getPolicy(data) {
    console.log("data", data)
    this.clientDetailProvider.getPolicy({ objid: "PHCPOLRTV", clntnum: data.clntnum, clrrrole: data.clrrrole }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataPolicyNumber = response;
        console.log("this.dataPolicyNumber", this.dataPolicyNumber)
      })
    })
  }

  getClientDetail(data) {
    this.clientDetailProvider.getClientDetail({ chdrnum: data }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataPolicyHolder = response.policyDetailList[0];
      })
    })
  }

  searchLifeAssured(id) {
    this.clientDetailProvider.getClientDetail({ chdrnum: id }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataLifeAssured = response.policyDetailList[0]
      })
    })
  }

  async newLifeAssure(role, newClient, index) {
    let getRole: boolean
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    this.role = role;
    this.newclient = { status: newClient, index: index }
    jsonR.jsonRequest.payload.client.lifeAss.forEach(async element => {
      if (element.role == role) {
        getRole = true
        this.dataLeft = element
        console.log("this.dataLeft", this.dataLeft)
        this.dataLeft.phone.forEach(element => {
          if (element.type) {
            switch (element.type) {
              case 'Home':
                this.home_phone = element
                break
              case 'Office':
                this.office_phone = element
                break
              case 'GSM1':
                this.mobile_phone1 = element
                break
              case 'GSM2':
                this.mobile_phone2 = element
                break
              case 'CDMA':
                this.cdma = element
                break
            }
          }
        })
        this.getDataBoneNewClient(this.dataLeft.client_no, 'clientSearch', null, null);
      }
    })
    if (!getRole) { this.createDataLeft(); }
    this.getInitial()
  }

  async getDataBoneNewClient(clientNumber, role, newclient, index) {
    this.NextTap = true
    if (!isNaN(role) && role) { this.getMasterSex = null, this.getMasterSalutation = null, this.getMasterMaritalStatus = null, this.getMasterCountry = null, this.getMasterOccupation = null, this.getMasterCountry = null, this.getMasterProvince = null, this.getMasterCountryCodes = null, this.getMasterIncome = null; this.newLifeAssure(role, newclient, index) }
    else {
      this.clientDetailProvider.getBoneNewClient({ clntnum: clientNumber ? clientNumber : await this.phsHelperStorageService.getStorageNoStringify('clientNumber') }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          if (role == 'payor') { this.dataBoneClientPolicy = response }
          else if (role == 'clientSearch') { 
            this.dataSearch =  response.clientNo ? true: false;
            this.dataBoneNewClient = response }
          else if (clientNumber && !role) {            
            this.dataBoneNewClient = response
            this.dataSearch =  response.clientNo ? true: false;
            this.dataLeft = null;
          }
          console.log("this.dataBoneNewClient",this.dataBoneNewClient)
        })
      })
    }
  }

  async getClientRole() {
    this.clientDetailProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber') }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.SearchAs(response)
      })
    })
  }

  async getInitial() {
    this.clientDetailProvider.getMasterSex().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSex = response
      })
    })

    this.clientDetailProvider.datamasterreasoninsurance().subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (this.dataLeft.buy_ins.length) {
          // response.forEach(elementRes => {
          //   this.dataLeft.buy_ins.forEach(elementStorage => {
          //     if (elementRes.id == elementStorage.id) {
          //       elementRes.isChecked = true
          //     }
          //   });
          // });          
          // this.dataLeft.buy_ins = response
        }
        else { this.dataLeft.buy_ins = response }
      })
    })

    this.clientDetailProvider.getMasterSourceOfIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.filterSource_Income(response)
      })
    })

    this.clientDetailProvider.getMasterIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterIncome = response
      })
    })

    this.clientDetailProvider.getMasterCountry().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountry = response
      })
    })

    this.clientDetailProvider.getMasterOccupation().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterOccupation = response;
        console.log("getMasterOccupation", this.getMasterOccupation)
      })
    })

    this.clientDetailProvider.getMasterMaritalStatus().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterMaritalStatus = response
      })
    })

    this.clientDetailProvider.getMasterCountryCodes().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountryCodes = response
      })
    })

    this.clientDetailProvider.getMasterSalutation().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSalutation = response
      })
    })

    this.clientDetailProvider.getMasterProvince().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterProvince = response
      })
    })
  }

  searchModal() {
    // this.showModal = true;
    let modalInstance = this.modalCtrl.Modal(ModalClientSearchPage, {});
    modalInstance.onDidDismiss(data => {
      if (data) {
        this.dataLeft.client_no = data
        this.getDataBoneNewClient(data, 'clientSearch', null, null)
      }
    })
  }

  filterBuyingInsurance(response) {
    response.forEach(elementRes => {
      this.dataBoneClientPolicy.reasonForBuyingInsurance.forEach(elementStorage => {
        if (elementRes.description.trim() == elementStorage.reasonForBuyingInsurance.trim()) {
          elementRes.isChecked = true
        }
      });
    })
    this.dataBoneClientPolicy.reasonForBuyingInsurance = response;
  }

  filterSource(response) {
    return new Promise((resolve) => {
      response.forEach(elementRes => {
        this.dataLeft.income.forEach(elementStorage => {
          if (elementRes.id == elementStorage.source) {
            elementRes.isChecked = true
          }
        });
      });
      resolve(response)
    })
  }

  async filterSource_Income(response) {
    let amount = this.dataLeft.income.length ? this.dataLeft.income[0].amount : this.dataLeft.income.amount
    let source = this.dataLeft.income.length ? await this.filterSource(response) : this.dataLeft.income.source
    this.dataLeft.income = {
      amount: amount,
      source: source
    }
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getStorage()
    this.getClientRole()
    this.getDataBoneNewClient(null, 'payor', null, null)
  }

  showConfirm() {
    const confirm = this.alertCtrl.create({
      title: 'Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page',
      cssClass: 'showConfrim',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            this.navCtrl.setRoot('phsworkbasketlist', {})
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        }
      ]
    });
    confirm.present();
  }

  addSegment() {
    var i;
    let enableAdd: boolean = false
    for (i = 1; i < 6; i++) {
      enableAdd = false
      this.data.forEach(element => {
        console.log("loopingan",i +' '+ parseInt(element.role) +' '+ parseInt(element.life))
        if (i === parseInt(element.role) || i === parseInt(element.life)) {
          console.log("tidak di add" ,i +' '+parseInt(element.role) +' '+ parseInt(element.life) )
          enableAdd = true
        }
      });
      if (!enableAdd) {
        console.log("index add",i)
        this.data.splice(i - 1,0,{          
          clntnum: null,
          name: i  == 1 ? 'Main Life Assured ' : 'Add Life Assured ' + (i - 1),
          // desc: this.data.length == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + this.data.length,
          value: 'formAssured' + (i - 1),
          // role: '0' + (this.data.length + 1),
          role: '0'+ i,
          newclient: true
        })
        // this.data.push({          
        //   clntnum: null,
        //   name: i  == 1 ? 'Main Life Assured ' : 'Add Life Assured ' + (i - 1),
        //   // desc: this.data.length == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + this.data.length,
        //   value: 'formAssured' + (i - 1),
        //   // role: '0' + (this.data.length + 1),
        //   role: '0'+ i,
        //   newclient: true
        // });
        console.log("this.data",this.data)
        break;
      }
    }
    this.EnableAdd = true;
    this.showsegment = false;
    this.disableButton = false;
    setTimeout(() => { this.showsegment = true; }, 100)
  }


  showDeleteIcon() {
    this.iconDelete = !this.iconDelete;
    if (this.text === 'Cancel') {
      this.text = 'Erased Life Assured'
    } else {
      this.text = 'Cancel'
    };
    this.iconTrash = !this.iconTrash;
    this.disabled = !this.disabled;
  }

  filterReasonInsurance() {
    return new Promise((resolve) => {
      let arraySelected = []
      this.dataLeft.buy_ins.forEach((element, key) => {
        if (element.isChecked) { delete element.isChecked; arraySelected.push(element) }
      });
      resolve(arraySelected)
    })
  }

  async saveData() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.payload.client.lifeAss.forEach(async (element, key) => {
      if (element.role == this.role) {
        jsonR.jsonRequest.payload.client.lifeAss[key] = this.dataLeft
        // jsonR.jsonRequest.payload.client.lifeAss[key].buy_ins        
      }
    })

    jsonR.jsonRequest.payload.quotation.lifeAss.forEach(async element => {
      if (element.role == this.role) {
        // element.income = this.dataLeft.income
        element.sex = this.dataLeft.sex
        element.dob = this.dataLeft.dob
        element.name = this.dataLeft.name
        element.occp = this.dataLeft.occp
        element.client_no = this.dataLeft.client_no
      }
    })


    if (this.newclient.status) {
      this.dataLeft.role = this.role
      this.dataQuotation.sex = this.dataLeft.sex;
      this.dataQuotation.dob = this.dataLeft.dob;
      this.dataQuotation.name = this.dataLeft.name;
      this.dataQuotation.occp = this.dataLeft.occp;
      this.dataQuotation.client_no = this.dataLeft.client_no;
      this.dataQuotation.role = this.role;
      this.dataAdditional.role = this.role;
      this.dataAdditional.documentName = this.role == '01' ? 'Main Life Assured' : 'Life Assured';
      jsonR.jsonRequest.payload.client.lifeAss.push(this.dataLeft);
      jsonR.jsonRequest.payload.quotation.lifeAss.push(this.dataQuotation)
      jsonR.jsonRequest.brmsverification.additional_new_client.push(this.dataAdditional)
    }

    console.log("JsonR", jsonR)
    let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
    if (result) {
      this.EnableAdd = false
      delete this.data[this.newclient.index].newclient
      this.showToast("Save Successful");
      this.newclient = { status: null, index: null }
    }
  }

  async confirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) this.saveData();
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async deleteItem(i, role, newclient) {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want delete this form ?');
    if (confirm) {
      this.data.splice(i, 1);
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      jsonR.jsonRequest.brmsverification.additional_new_client.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.brmsverification.additional_new_client.splice(key, 1);
      });
      jsonR.jsonRequest.payload.client.lifeAss.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.payload.client.lifeAss.splice(key, 1);
      });
      jsonR.jsonRequest.payload.quotation.lifeAss.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.payload.quotation.lifeAss.splice(key, 1);
      });
      this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
      this.dataLeft = null; this.dataSearch = false
      if (newclient) { this.EnableAdd = false }
    }
  }

  createDataLeft() {
    this.dataLeft = {
      income: [{ amount: '', source: '' }],
      pob: "",
      role: "",
      auto_dedup: "",
      mailing_method: "",
      fax: "",
      email: "",
      id_number: "",
      us_tax: "",
      id_exp: "",
      address: [
        {
          zip: "",
          country: "",
          province: "",
          city: "",
          kecamatan: "",
          type: "",
          line3: "",
          line2: "",
          line1: "",
          kelurahan: ""
        }
      ],
      sex: "",
      npwp: "",
      xIns_flag: "",
      buy_ins: [],
      religion: "",
      marital_status: "",
      natlty: "",
      occp: "",
      foreign_tax: "",
      client_no: "",
      phone: [
      ],
      dob: "",
      cob: "",
      edu: "",
      name: "",
      occp_company: "",
      salution: ""
    }
    this.dataQuotation = {
      income: "",
      role: "",
      next_bday: "",
      smoking_status: "",
      occp_class: "",
      jabatan: "",
      sex: "",
      batang_rokok: "",
      occp: "",
      component: [
        {
          product_desc: "",
          cover_age: "",
          product_code: "",
          coi: "",
          sum_ass: "",
          unit_prumed: ""
        }
      ],
      client_no: "",
      dob: "",
      new_client: "Y",
      name: "",
      usaha: "",
      instansi: ""
    }
    this.dataAdditional = {
      role: "",
      clientNo: "",
      documentName: ""
    }
  }

  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }

}
