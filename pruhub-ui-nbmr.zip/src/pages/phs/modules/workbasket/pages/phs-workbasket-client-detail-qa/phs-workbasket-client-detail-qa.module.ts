import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketClientDetailQaPage } from './phs-workbasket-client-detail-qa';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
@NgModule({
  declarations: [
    PhsWorkbasketClientDetailQaPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketClientDetailQaPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsWorkbasketClientDetailQaPageModule {}
