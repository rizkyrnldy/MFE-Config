import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { ModalComparingDocumentPage } from './modal-comparing-document';
import { ComponentsModule } from '../../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    ModalComparingDocumentPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalComparingDocumentPage),
    IonicModule,
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class ModalComparingDocumentPageModule {}
