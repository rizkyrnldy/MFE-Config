import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ModalProvider } from '../../../../../../providers/phs/modal/modal';
import { ModalComparingDocumentPage } from './modal-comparing-document/modal-comparing-document'
import { ModalViewDocumentPage } from './modal-view-document/modal-view-document';
import { UserProvider } from './../../../../../../providers/providers';
import { DocumentProvider } from '../../../../../../providers/phs/workbasket/document';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
/**
 * Generated class for the PhsWorkbasketDocumentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: 'phsworkbasketdocument',
  segment: 'PHS/workbasket/documentpage/:id'
})

@Component({
  selector: 'page-phs-workbasket-document',
  templateUrl: 'phs-workbasket-document.html',
})
export class PhsWorkbasketDocumentPage {
  ionTitle: any;
  SearchAs: any = [];
  policyNumber: any;
  policyNumberData: any[];
  dataSearch: string = '';
  chooseClient: string;
  dataDoc: any;
  dataCompare: any = [];
  ClientNumberSearch: any = [];
  start: number = 0;
  end: number = 10;
  activePage: number = 1;
  totalPage: number = 1;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private modalCtrl: ModalProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    public documentProvider: DocumentProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService,
    private phsAlertService: phsAlertService,
  ) {
  }

  openModal() {
    // this.showModal = true;
    let modalInstance = this.modalCtrl.Modal(ModalComparingDocumentPage, { 'dataCompare': this.dataCompare, 'dataDoc': this.dataDoc }, {
      cssClass: "docPhs-modal"
    });
    modalInstance.onDidDismiss(data => {
      // do something
    })
  }

  openTabelView(data) {
    let modalInstance = this.modalCtrl.Modal(ModalViewDocumentPage, { 'dataCurrent': data, 'dataDoc': this.dataDoc }, {
      cssClass: "docPhs-modal"
    });
    modalInstance.onDidDismiss(data => {
      // do something
    })
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  mergeData(response) {
    console.log(response, "response")
    let data = []
    response.forEach(element => {

      data.push({ policyNo: element.policyNo, rolePolicy: element.rolePolicy == "LF" ? element.rolePolicy + ' ' + element.lifeRole : element.rolePolicy })
    });
    if (data.length) {
      var result = data.reduce(function (r, a) {
        r[a.rolePolicy] = r[a.rolePolicy] || [];
        r[a.rolePolicy].push(a);
        return r;
      }, Object.create(null));
      this.policyNumberData = result;
      let keyNames = Object.keys(result);
      this.SearchAs = keyNames
      console.log(this.SearchAs, "SearchAs")
    }
  }

  challenge(data, i) {
    if (data.isChecked) {
      console.log("first", this.dataCompare.length)
      if (this.dataCompare.length < 2) {
        this.dataCompare.push(data)
        console.log("second", this.dataCompare.length)
      }
    }
    else {
      this.dataCompare.forEach((element, index) => {
        if (element.itemId == data.itemId) {
          this.dataCompare.splice(index, 1);
        }
      });
    }
  }

  async getInitial() {
    this.documentProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum: await this.phsHelperStorageService.getStorageNoStringify("policyNumber") }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (!response.error) {
          this.addClientNumberCode(response)
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }
  
  getpolicyrole(data) {
    this.documentProvider.getpolicyrole({ clntnum: data.clntnum }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.mergeData(response)
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }


  SEARCH() {
    this.documentProvider.getCmDocByParam([{ param: "PS_POLDOCTEMP", type: "Policy_Number", value: this.chooseClient }]).subscribe(p1 => {
      p1.subscribe((response: any) => {
        console.log(response);
        this.dataDoc = response
        this.totalPage = Math.ceil(response.length / 10)
        this.dataCompare = []
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  filterData(page) {
    console.log("page", page)
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  convertCode(item) {
    switch (item) {
      case "LF 01":
        return "Main Life Assured"
      case "LF 02":
        return "Add Life Assured 01"
      case "LF 03":
        return "Add Life Assured 02"
      case "LF 04":
        return "Add Life Assured 03"
      case "LF 05":
        return "Add Life Assured 04"
      case "OW":
        return "Policy Holder"
      case "PY":
        return "Payor"
    }
  }

  addClientNumberCode(items) {
    if (items) {
      items.forEach(element => {
        let search = element.life ? element.clrrrole + ' ' + element.life : element.clrrrole;
        console.log("search", search)
        switch (search) {
          case "LF 01":
            this.ClientNumberSearch.push({ description: 'Main Life Assured' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 02":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 01' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 03":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 02' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 04":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 03' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 05":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 04' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "OW":
            this.ClientNumberSearch.push({ description: 'Policy Holder' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "PY":
            this.ClientNumberSearch.push({ description: 'Payor' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
        }
      });
      this.mergeAddClient();
    }
  }

  async mergeAddClient() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.brmsverification.additional_new_client.forEach(element => {
      let number: any
      if (!isNaN(element.role)) {
        switch (element.role) {
          case "01":
            this.ClientNumberSearch.push({ description: 'Main Life Assured' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "02":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 01' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "03":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 02' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "04":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 03' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "05":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 04' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
        }
      }
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhsWorkbasketDocumentPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getInitial();
    this.getStorage();
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page ?');
    if (confirm) {
      let _activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
      if(_activityName === "Processor") {
        this.navCtrl.setRoot('phsworkbasketlist', {});
      } else {
        this.navCtrl.setRoot('phsworkbasketlist', {});
      }
    } 
  }
}
