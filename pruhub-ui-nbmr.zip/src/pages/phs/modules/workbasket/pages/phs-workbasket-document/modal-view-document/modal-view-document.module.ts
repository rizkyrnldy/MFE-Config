import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { ModalViewDocumentPage } from './modal-view-document';
import { ComponentsModule } from '../../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    ModalViewDocumentPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalViewDocumentPage),
    IonicModule,
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class ModalViewDocumentPageModule {}
