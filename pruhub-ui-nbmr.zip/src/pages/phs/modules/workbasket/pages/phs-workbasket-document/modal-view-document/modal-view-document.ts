import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { DocumentProvider } from '../../../../../../../providers/phs/workbasket/document';
import { PhsSupportProvider } from '../../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the ModalViewDocumentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal-view-document',
  templateUrl: 'modal-view-document.html',
})
export class ModalViewDocumentPage {
  pdfSrc: any;
  mime: any;
  // dataCurrent: any;
  // dataDoc: any;
  DocumentSelected: string[];
  DateStamp: any;
  dataSelected:string;
  itemId:string;
  imageOnlyOne: string = "image-only-one"
  linkImage: string;
  constructor(public navCtrl: NavController,
     public navParams: NavParams, 
     private viewCtrl: ViewController,
     private documentProvider : DocumentProvider,
     private phsSupportProvider: PhsSupportProvider,
     private phsToastService: phsToastService
     ) {
    
    this.dataSelected = this.navParams.get('dataCurrent').subDoc;
    this.itemId = this.navParams.get('dataCurrent').itemId;
    let data  = this.navParams.get('dataDoc');

    var result = data.reduce(function (r, a) {
      r[a.subDoc] = r[a.subDoc] || [];
      r[a.subDoc].push(a);
      return r;
    }, Object.create(null));
    this.DateStamp = result;
    console.log("DateStamp", this.DateStamp )
    this.DocumentSelected = Object.keys(result);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ModalViewDocumentPage');
  }
  
  closeModal() {
    this.viewCtrl.dismiss();
  }

 async getInitial(){
  this.documentProvider.getDetailCmByItemId({ itemId :this.navParams.get('dataDoc')[0].itemId}).subscribe(p1 => {
    p1.subscribe((response:any) => {            
      this.pdfSrc = 'data:' + response.mimeType + ';base64,' + response.byteDoc;
      this.linkImage =  'getfileByItem/' + this.navParams.get('dataDoc')[0].itemId;
      this.mime = response.mimeType;
      this.phsSupportProvider.dismissLoading()
    }, err => {
        this.showToast(err);
      this.phsSupportProvider.dismissLoading()
    })
  })
 }
 
 showToast(text) {
  this.phsToastService.showToast(text);
}

 checkImage(id){
  this.documentProvider.getDetailCmByItemId({ itemId : id}).subscribe(p1 => {
    p1.subscribe((response:any) => {            
      this.pdfSrc = 'data:' + response.mimeType + ';base64,' + response.byteDoc
      this.mime = response.mimeType;
      this.phsSupportProvider.dismissLoading()
    }, err => {
        this.showToast(err);
      this.phsSupportProvider.dismissLoading()
    })
  })
 }

  ionViewWillEnter(){
    this.getInitial()
  }
}
