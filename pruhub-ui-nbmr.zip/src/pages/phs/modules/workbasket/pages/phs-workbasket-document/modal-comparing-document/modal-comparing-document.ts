import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { DocumentProvider } from '../../../../../../../providers/phs/workbasket/document';
import { PhsSupportProvider } from '../../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the ModalComparingDocumentPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal-comparing-document',
  templateUrl: 'modal-comparing-document.html',
})
export class ModalComparingDocumentPage {
  dataSelected1: any;
  dataSelected2: any;
  DateStamp: any;
  DocumentSelected: string[];
  itemId1: any;
  itemId2: any;
  pdfSrc1: string;
  mime1: any;
  pdfSrc2: string;
  mime2: any;
  imageLeft:string = "image-left"
  imageRight:string = "image-right"
  linkImage1: string;
  linkImage2: string;

  constructor(public navCtrl: NavController,
    private documentProvider: DocumentProvider,
    public navParams: NavParams,
    private viewCtrl: ViewController,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService
    ) {

    console.log('dataCompare', this.navParams.get('dataCompare'))
    console.log('dataDoc', this.navParams.get('dataDoc'))
    let data = this.navParams.get('dataDoc');
    this.dataSelected1 = this.navParams.get('dataCompare')[0].subDoc
    this.dataSelected2 = this.navParams.get('dataCompare')[1].subDoc
    this.itemId1 = this.navParams.get('dataCompare')[0].itemId;
    this.itemId2 = this.navParams.get('dataCompare')[1].itemId;

    var result = data.reduce(function (r, a) {
      r[a.subDoc] = r[a.subDoc] || [];
      r[a.subDoc].push(a);
      return r;
    }, Object.create(null));
    this.DateStamp = result;
    console.log("DateStamp", this.DateStamp)
    this.DocumentSelected = Object.keys(result);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ModalComparingDocumentPage');
  }

  closeModal() {
    // this.showModal = false;
    this.viewCtrl.dismiss();
  }

  async getInitial(){
    this.documentProvider.getDetailCmByItemId({ itemId :this.navParams.get('dataCompare')[0].itemId}).subscribe(p1 => {
      p1.subscribe((response:any) => {            
        this.pdfSrc1 = 'data:' + response.mimeType + ';base64,' + response.byteDoc
        this.linkImage1 =  'getfileByItem/' + this.navParams.get('dataCompare')[0].itemId;
        this.mime1 = response.mimeType;
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
    
    this.documentProvider.getDetailCmByItemId({ itemId :this.navParams.get('dataCompare')[1].itemId}).subscribe(p1 => {
      p1.subscribe((response:any) => {            
        this.pdfSrc2 = 'data:' + response.mimeType + ';base64,' + response.byteDoc
        this.linkImage2 =  'getfileByItem/' + this.navParams.get('dataCompare')[1].itemId;
        this.mime2 = response.mimeType;
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
   }

  checkImage(id, toDo) {
    this.documentProvider.getDetailCmByItemId({ itemId: id }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (toDo == 'Item1') {
          this.pdfSrc1 = 'data:' + response.mimeType + ';base64,' + response.byteDoc
          this.mime1 = response.mimeType;
        }
        else {
          this.pdfSrc2 = 'data:' + response.mimeType + ';base64,' + response.byteDoc
          this.mime2 = response.mimeType;
        }
      })
      this.phsSupportProvider.dismissLoading()
    }, err => {
        this.showToast(err);
      this.phsSupportProvider.dismissLoading()
    })
  }
  
  showToast(text) {
    this.phsToastService.showToast(text);
  }

  ionViewWillEnter(){
    this.getInitial()
  }
}
