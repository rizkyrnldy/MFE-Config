import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketDetailPage } from './phs-workbasket-detail';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';

@NgModule({
  declarations: [
    PhsWorkbasketDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketDetailPage),
    PhsDirectivesModule
  ],
})
export class PhsWorkbasketDetailPageModule {}
