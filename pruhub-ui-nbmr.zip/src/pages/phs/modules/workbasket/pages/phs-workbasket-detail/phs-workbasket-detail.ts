import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams, Content } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { DetailProvider } from '../../../../../../providers/phs/workbasket/detail';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { PhsWorkbasketKesehatanMagnumPage } from '../phs-workbasket-kesehatan-magnum/phs-workbasket-kesehatan-magnum';
import { PhsWorkbasketRevivalMagnumPage } from '../phs-workbasket-revival-magnum/phs-workbasket-revival-magnum';

@IonicPage({
  name: "phsworkbasketdetail",
  segment: "PHS/workbasket/detail/:genId"
})
@Component({
  selector: 'page-phs-workbasket-detail',
  templateUrl: 'phs-workbasket-detail.html',
})

export class PhsWorkbasketDetailPage {
  @ViewChild(Content) content: Content;
  result: any = [];
  data: any = [];
  jsonRequest: any = [];
  ionTitle: any;
  generalData: any;
  validation: boolean
  constructor(
    private phsSupportProvider: PhsSupportProvider,
    public navCtrl: NavController,
    public navParams: NavParams,
    public storage: Storage,
    public phsHelperStorageService: PhsHelperStorageService,
    private detailProvider: DetailProvider,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private auth: UserProvider
  ) {
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle')
    this.generalData = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
    console.log(this.generalData);
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getStorage();
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }


  dataNotOk(i, document_name) {
    this.detailProvider.getSignatureFlagByDocumentName({ "documentName": document_name }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.generalData.jsonRequest.brmsverification.signature_flags[i].detailFlag = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  async confirm() {
    this.validation = true
    if (this.generalData.jsonRequest.brmsverification.signature_flags) {
      console.log("this.generalData.jsonRequest.brmsverification.signature_flags",this.generalData.jsonRequest.brmsverification.signature_flags)
      for (let i = 0; i < this.generalData.jsonRequest.brmsverification.signature_flags.length; i++) {
        console.log("signature_flags",!this.generalData.jsonRequest.brmsverification.signature_flags[i].statusFlag)
        if (!this.generalData.jsonRequest.brmsverification.signature_flags[i].statusFlag) {
          this.validation = false
          break;
        }
      }
    }
    if (this.validation) {
      let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
      if (confirm) this.saveData();
    }
    else {
      this.phsAlertService.basicAlert({ title: 'Unsuccessful', subTitle: 'Please input signature flag before saving!' })
      let y = document.getElementById('signatureFlag');
      this.content.scrollTo(0, y.offsetTop);
    }
  }

  async saveData() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.brmsverification.signature_flags = this.generalData.jsonRequest.brmsverification.signature_flags

    let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
    if (result) {
      this.showToast("Save Successful");
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async  goCheck(data) {
    const NeedMagnum = await this.phsHelperStorageService.getStorageNoStringify('needMagnum')
    this.detailProvider.getPruhubScreenByDocId(data.id).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (response) {  
          if (response.data.length) {
            switch (response.data[0].type) {
              case "HD":
                if (NeedMagnum) {
                  this.navCtrl.setRoot(PhsWorkbasketKesehatanMagnumPage);
                }else{
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                }
                break;
              case "REVIVAL":
                if(response.data[0].pruhub_screen == "phsworkbasketrevivalcorporatebulk"){
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                }else{
                  if (NeedMagnum) {
                    this.navCtrl.setRoot(PhsWorkbasketRevivalMagnumPage);
                  }else{
                    this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                  }
                }
                break;
              case "MAJOR":
                    this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                break;
              case "SPAJT":
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                break;
              case "QUOTATION":
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                break;
              case "PAYOR":
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true })
                break;
              case "CUTI PREMI":
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true, link:'phsworkbasketsubmittedform' })
                break;
              case "REFUND":
                  this.navCtrl.setRoot(response.data[0].pruhub_screen, { docId: data.id, dataSub : true, link:'phsworkbasketsubmittedform' })
                break;
            }
          }
          this.phsSupportProvider.dismissLoading()
        }
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }
}


