import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { caseSheetProvider } from '../../../../../../providers/phs/workbasket/caseSheet';
import { UserProvider } from '../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';

@IonicPage({
  name: "phscasehistory",
  segment: "PHS/case_history/:id"
})
@Component({
  selector: 'page-phs-case-history',
  templateUrl: 'phs-case-history.html',
})
export class PhsCaseHistoryPage {
  ionTitle: string = 'Case Tracking';
  dataCaseSheet: any = []
  start: number = 0
  end: number = 10
  activePage: number = 1;
  totalPage: number = 1;
  search: any;
  listOfdataGenIds:any = [];
  caseStatus: string;
  constructor(public navCtrl: NavController,
    private phsSupportProvider: PhsSupportProvider,
    public caseSheetProvider: caseSheetProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    public navParams: NavParams,
    private auth: UserProvider,
    private phsToastService: phsToastService
  ) {

    this.search = {policy_no:'',gen_id:'',temp_model_plantype:{code:'',description:''}};
  }

  searchComboDataInMemory(code){
    var me = this;
    setTimeout(function(){
      me.listOfdataGenIds  = me.listOfdataGenIds.filter(s =>s.description.indexOf(code)>-1 );
    },300);
  }

  listGenIdTransactions(policy_num:String,search:String){
    this.caseSheetProvider.mdengine2(policy_num).subscribe(p1=>{
      p1.subscribe((response:any)=>{
        this.listOfdataGenIds = [];
        for(let i=0; i<response.data.length; i++){
          let item = response.data[i];
          this.listOfdataGenIds.push({code:item.gen_id,description:item.gen_id +"_"+item.transaction_type+"_"+item.alter_number, status_process: item.status_process});
        }

        if(search!='') this.searchComboDataInMemory(search);

        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      });
    });
  
  }

  searchEvent(event,product_code){
    this.listGenIdTransactions(product_code,event.text);
  }

  onSelectEvent(data){
    const { code } = data;
    this.caseStatus = data.status_process;

    /** Get Case Sheet History */
    var me = this;
    me.filterData(1);
    
    if(me.dataCaseSheet.length>0){
      me.dataCaseSheet=[];
    }

    this.caseSheetProvider.getcasehistory({ genId: code }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (response) {          

          for(let i=response.length; i>=0; i--){
            let raw = response[i];
            if(raw!=undefined){

              /**
                completeDate: 1566299183090
                decision: ""
                status: "COMPLETED"
                taskName: "Sub Alter Type"
                trxIn: 1566299183110
                user
              */
              me.dataCaseSheet.push(raw);
            }
          }

          me.totalPage = Math.ceil(response.length / 10)
          me.phsSupportProvider.dismissLoading()

        }
      }, err => {
        me.showToast(err);
        me.phsSupportProvider.dismissLoading()
      })
    });

  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  filterData(page) {
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  searchPolNoOnChange(policy_no){
    var me = this;
    if(policy_no!='' && policy_no.length>=8){
      setTimeout(function(){
        me.listGenIdTransactions(policy_no,'');
      },2000);
    }
  }

}


