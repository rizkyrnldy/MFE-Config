import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsCaseHistoryPage } from './phs-case-history';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';
import { IonicSelectableModule } from 'ionic-selectable';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsCaseHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsCaseHistoryPage),
    PhsDirectivesModule,
    ComponentsModule,
    IonicSelectableModule,
    PipesModule,
  ],
})
export class PhsCaseHistoryPageModule {}
