import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { UserProvider } from '../../../../../../providers/providers';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { ReportPhsProvider } from '../../../../../../providers/phs/workbasket/reportphs';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { Storage } from '@ionic/storage';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { saveAs } from "file-saver";

/**
 * Generated class for the PhsWorkbasketManageTask page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsreport",
  segment: "PHS/workbasket/phsreport/:id"
})
@Component({
  selector: 'page-phs-report',
  templateUrl: 'phs-report.html',
})
export class PhsReport {  
  FormModel:any =  { report_name:'',startDate:'',endDate:'' };
  listOfReportName:any;
  searchData: boolean = false;
  searchInput: Object = { clientNo: '', userName: '', department: '', policyNo: '', roleDistribution: '', role: '' };
  data: any = [];
  searchBody: any = [];
  activePage: number = 1;
  // page: number = 1;
  limit: number = 10;
  totalPage: number = 1;
  dataManagetask: any;
  dataSearch: any;
  dataInitial: any;
  searchbar: string;
  getItems: any;
  action: string;
  ChooseDecision: any;
  SelectedDecision: any;
  activityName: any;
  constructor(
    public storage: Storage,
    public navCtrl: NavController,
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    public phsHelperStorageService: PhsHelperStorageService,
    private ReportPhsProvider: ReportPhsProvider,
    private auth: UserProvider,
    public phsToastService: phsToastService,
    public PhsSupportProvider: PhsSupportProvider,
  ) {
  }
  async getSearch(searchInput) {
   
    //console.log('TODO load Download Report',this.FormModel);

   
    this.searchData = true;
    this.ReportPhsProvider.downloadReport(this.FormModel).subscribe(response => {

      //console.log(response);
      saveAs(response, this.FormModel.report_name+'_'+this.FormModel.startDate+'_'+this.FormModel.endDate+'.csv');
      this.PhsSupportProvider.dismissLoading()

    }, err => {
      this.showToast(err);
        this.PhsSupportProvider.dismissLoading()
    }
    );
    
  }

  

  submitForm(frm:any) {
    this.activePage = 1;
    console.log('debug',this.FormModel);
    this.getSearch(this.FormModel);
  }

  

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhsWorkbasketManageTask');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getInitial()
  }

  loadDropDownReportName(){

    this.listOfReportName = [];
    this.ReportPhsProvider.listReportName().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.listOfReportName = response.data;
      })
      this.PhsSupportProvider.dismissLoading()
    }, err => {
        this.showToast(err);
      this.PhsSupportProvider.dismissLoading()
    });
  }

  getInitial() {

    
    this.loadDropDownReportName();    
  }

  

  showToast(text) {
    this.phsToastService.showToast(text);
  }
}
