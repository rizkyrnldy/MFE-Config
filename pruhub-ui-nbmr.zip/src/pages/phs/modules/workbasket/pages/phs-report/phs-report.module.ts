import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsReport } from './phs-report';
import { ComponentsModule } from '../../../../../../components/components.module';
// import { CustomSelectComponent } from '../../../../../../components/shared/forms/custom-select/custom-select';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsReport,
    // CustomSelectComponent
  ],
  imports: [
    IonicPageModule.forChild(PhsReport),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsReportModule {}
