import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAddAlterationPage } from './phs-workbasket-add-alteration';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';

@NgModule({
  declarations: [
    PhsWorkbasketAddAlterationPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAddAlterationPage),
    ComponentsModule,
    PhsDirectivesModule
  ],
})
export class PhsWorkbasketAddAlterationPageModule {}
