import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { UserProvider } from '../../../../../../providers/providers';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';

/**
 * Generated class for the PhsWorkbasketAddalterationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketaddalteration",
  segment: "PHS/workbasket/add-alteration/:id"
})
@Component({
  selector: 'page-phs-workbasket-add-alteration',
  templateUrl: 'phs-workbasket-add-alteration.html',
})
export class PhsWorkbasketAddAlterationPage {
  summAdd: any;
  ionTitle: any;
  add: any;
  validation: any;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    public phsHelperStorageService: PhsHelperStorageService,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    private phsToastService: phsToastService,
    private phsSupportProvider: PhsSupportProvider,
    private auth: UserProvider
  ) {
    this.add = {
      type: '',
      description: '',
      status: ''
    }
  }

  async getData() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.add = this.navParams.get('addData');
  }

  async saveData() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async addAlter() {
    this.validation = await this.phsSupportProvider.checkDataGetSaved({ type: this.add.type, description: this.add.description, status: this.add.status })
    if (this.validation) {
      this.alterationFollowUpProvider.phrtvaltfl({
        OBJID: "PHUPDALTFL",
        CHDRSEL: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        ZALTNUMSEL: "",
        ZALTSTASEL: this.add.status,
        ZALTTYPSEL: this.add.type,
        ZALTDESC: this.add.description,
        ZLASTRCVDT: "",
        ZCOMPLDT: "",
        YNFLAG: ""
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          let resMessage = JSON.parse(response.message);
          if (resMessage.headerMsg.errlvl == '1') {
            this.showToast(resMessage.headerMsg.app_remaining_msg);
          }
          else {
            this.showToast("Succses Add");
            this.navCtrl.setRoot('phsworkbasketalterationfollowup');
          }
          this.phsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.phsSupportProvider.dismissLoading()
        })
      })
    }
  }

  gotoNextField(nextElement) {
    nextElement.setFocus();
  }

  actionEnter(item, nextElement) {
    this.alterationFollowUpProvider.phrtvt5661({
      FUPCDE: item,
      OBJID: "PHRTVT5661"
    }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.phsSupportProvider.dismissLoading();
        let message = JSON.parse(response.message);
        if (response.code === "200" && response.error === false) {
          if (message.headerRespMsg.errlvl == '1') {
            this.showToast(message.headerRespMsg.app_remaining_msg);
          }
          else {
            this.add.description = message.phrtvt5661.longdesc;
          }
        };
        nextElement.setFocus();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  ionViewDidLoad() {
    this.getData();
    console.log('ionViewDidLoad PhsWorkbasketAddAlterationPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }
}
