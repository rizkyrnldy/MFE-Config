import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketBackToWorkbasketPage } from './phs-workbasket-backtoworkbasket';
import { ComponentsModule } from '../../../../../../components/components.module';

@NgModule({
  declarations: [
    PhsWorkbasketBackToWorkbasketPage,    
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketBackToWorkbasketPage),
    ComponentsModule
  ],
  exports: [  
  ]
})
export class PhsWorkbasketBackToWorkbasketPageModule {}
