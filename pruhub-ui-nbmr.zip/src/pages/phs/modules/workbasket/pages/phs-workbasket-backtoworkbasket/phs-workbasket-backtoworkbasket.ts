import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Content } from 'ionic-angular';
import { UserProvider } from './../../../../../../providers/providers';

@IonicPage({
  name: "phsworkbasketbacktoworkbasket",
  segment: "PHS/workbasket/backtoworkbasket"
})
@Component({
  selector: 'page-phs-workbasket-backtoworkbasket',
  templateUrl: 'phs-workbasket-backtoworkbasket.html',
})
export class PhsWorkbasketBackToWorkbasketPage {
  pdfSrc: string;
  @ViewChild(Content)
  content: Content;
  mime: string;
  isSticky: boolean = false;
  constructor(public navCtrl: NavController, public navParams: NavParams,
    private auth: UserProvider
  
    ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhsWorkbasketBackToWorkbasketPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    } 
  }
}
