import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketKesehatanNonSyariahPage } from './phs-workbasket-kesehatan-non-syariah';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    PhsWorkbasketKesehatanNonSyariahPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketKesehatanNonSyariahPage),
    ComponentsModule,
    PipesModule,
    IonicSelectableModule
  ],
  exports: [
    
  ],
})
export class PhsWorkbasketKesehatanNonSyariahPageModule {}
