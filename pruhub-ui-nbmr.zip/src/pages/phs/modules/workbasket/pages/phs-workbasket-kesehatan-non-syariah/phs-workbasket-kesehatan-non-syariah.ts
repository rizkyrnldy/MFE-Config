import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Content } from 'ionic-angular';
// import { StickyContainerComponent } from '../../../../../../components/shared/sticky-container/sticky-container';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { kesehatanNonSyariahProvider } from '../../../../../../providers/phs/workbasket/kesehatanNonSyariah';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';

@IonicPage({
  name: "phsworkbasketkesehatannonsyariah",
  segment: "PHS/workbasket/kesehatan_non_syariah/:id"
})
@Component({
  selector: 'page-phs-workbasket-kesehatan-non-syariah',
  templateUrl: 'phs-workbasket-kesehatan-non-syariah.html',
})
export class PhsWorkbasketKesehatanNonSyariahPage {
  pdfSrc: string;
  // @ViewChild(StickyContainerComponent) stickyContainer: StickyContainerComponent;
  @ViewChild(Content)
  content: Content;
  mime: string;
  isSticky: boolean = false;
  pembayarPremi: any = [];
  payload: any;
  ionTitle: any;
  jobsMethod: any;
  major: boolean = false; revival: boolean = false;
  validation: {};
  imageDocument: string = "imageDocBRMS"
  documentFixed: string;
  linkImage: string;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    private kesehatanNonSyariahProvider: kesehatanNonSyariahProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
  ) {

  }



  async getImage() {
    let genId = await this.phsHelperStorageService.getStorageNoStringify('genId');
    this.kesehatanNonSyariahProvider.getContentCMByItemId({
      "genId": genId,
      "docId": this.navParams.get('docId')
    }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.pdfSrc = 'data:' + response.mime + ';base64,' + response.byteDoc;
        this.linkImage =  'getfile/'+genId +'/'+ this.navParams.get('docId');
        this.mime = response.mime;
        setTimeout(() => {
          this.documentFixed = "document-fixed"
          this.phsSupportProvider.dismissLoading();
        }, 100);
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  async getStorage() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
    if (jsonR) {
      this.payload = jsonR.jsonRequest.payload;
      this.payload.hd.lifeAss.forEach(async element => {
        element.model1 = await this.checkName('occupation', element.occp)
        if(element.client_role==="") {

          element.client_role = '01';
          element.data = [
            { no: "01", answer: "" },
            { no: "02", answer: "" },
            { no: "03", answer: "" },
            { no: "04", answer: "" },
            { no: "05", answer: "" },
            { no: "06", answer: "" },
            { no: "07", answer: "" },
            { no: "08", answer: "" },
            { no: "09", answer: "" },
            { no: "10", answer: "" },
            { no: "11", answer: "" },
            { no: "12", answer: "" },
          ]
  
        }
      });
      if (jsonR.jsonRequest.payload) {
        // this.major = jsonR.jsonRequest.payload.hd.submission_criteria.toLocaleUpperCase() == "major" ? true : false
        // this.revival = jsonR.jsonRequest.payload.hd.submission_criteria.toLowerCase() == "revival" ? true : false
        let dataarray: any = jsonR.jsonRequest.payload.hd.submission_criteria.split(",");
        if (dataarray)
          dataarray.forEach((element, key) => {
            if (element.toLocaleUpperCase() == "MAJ")
              this.major = true
            else if (element.toLocaleUpperCase() == "REV") {
              this.revival = true
            }
          });
      }
      this.payload.hd.tgl_ttd = this.payload.hd.tgl_ttd.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.payload.hd.tgl_ttd) : this.payload.hd.tgl_ttd;
      this.payload.hd.lifeAss.forEach(async  element => {
        element.dob = element.dob.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(element.dob) : element.dob;
      });
      this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
      console.log("this.payload", this.payload)
    }
  }

  async saveData() {
    this.validation = await this.phsSupportProvider.checkDataEmpty({ pol_no: this.payload.policy.pol_no, kriteria_pengajuan: this.major ? this.major : this.revival })
    if (this.validation) {
      let major = this.major ? 'MAJ' : ''
      let revival = this.revival ? 'REV' : ''
      let coma = major && revival ? ',' : ''
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      let activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
      this.payload.hd.submission_criteria = major + coma + revival;
      // this.payload.major.tgl_quotation = await this.phsHelperDateTimeService.resetDateFormat(this.payload.major.tgl_quotation,"-")
      jsonR.jsonRequest.payload = this.payload;
      let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet');
      console.log("GGG",activityName,this.navParams.get('dataSub'))
      if (result) {
        this.showToast("Save Successful");
        if(activityName === "Processor") {
          this.navCtrl.setRoot(this.phsSupportProvider.goToSubmitForm(activityName.toString(),this.navParams.get('dataSub')), {})
        } else {
          this.navCtrl.setRoot('phsworkbasketdetail', {})
        }
      }
    }
  }

  searchOccupation(event) {
    this.kesehatanNonSyariahProvider.mdengine({ md_name: "occupation", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.jobsMethod = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  async confirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) this.saveData();
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) {
      let _activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
      if(_activityName === "Processor") {
        this.navCtrl.setRoot('phsworkbasketlist', {});
      } else {
        this.navCtrl.setRoot(this.navParams.get('dataSub') ? 'phsworkbasketsubmittedform' : 'phsworkbasketdetail', {})
      }
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  getInitial() {
  }

  ionViewDidLoad() {
    this.getStorage()
    this.getImage()
    this.getInitial()
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  checkName(name, code) {
    return new Promise((resolve) => {
      let result = ""
      if (code) {
        this.kesehatanNonSyariahProvider.mdengine({ md_name: name, search: code }).subscribe(p1 => {
          p1.subscribe((response: any) => {
            if (response.data.length) {
              result = response.data[0]
              resolve(result)
            }
            else {
              resolve(result)
            }
            this.phsSupportProvider.dismissLoading();
          }, err => {
            this.showToast(err);
            this.phsSupportProvider.dismissLoading();
          })
        })
      }
      else {
        resolve(result)
      }
    })
  }
  
  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }

  removeLifeAss(index:number) {
    this.payload.hd.lifeAss.splice(index,1)
  }

  addLifeAss() {
    const lifeAssLen = (this.payload.hd.lifeAss.length+1);
    const defLifeAss = {
      client_role: "0" + lifeAssLen,
      data: [
        {no: "01", answer: ""},
        {no: "02", answer: ""},
        {no: "03", answer: ""},
        {no: "04", answer: ""},
        {no: "05", answer: ""},
        {no: "06", answer: ""},
        {no: "07", answer: ""},
        {no: "08", answer: ""},
        {no: "09", answer: ""},
        {no: "10", answer: ""},
        {no: "11", answer: ""},
        {no: "12", answer: ""}
      ],
      dob: "",
      height: "",
      jml_rokok: "",
      model1: "",
      name: "",
      occp: "",
      weight: ""
    }

    this.payload.hd.lifeAss.push(defLifeAss);
  }

}
