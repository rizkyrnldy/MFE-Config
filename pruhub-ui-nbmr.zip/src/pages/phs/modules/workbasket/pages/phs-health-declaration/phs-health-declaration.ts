import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsWorkbasketKesehatanMagnumPage } from '../phs-workbasket-kesehatan-magnum/phs-workbasket-kesehatan-magnum';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';

@IonicPage({
  name: "HealthDeclaration",
  segment: "PHS/workbasket/health-declaration/:id"
})
@Component({
  selector: 'page-phs-health-declaration',
  templateUrl: 'phs-health-declaration.html',
})
export class PhsHealthDeclaration {  
  generalData: any;
  constructor(
    public navCtrl: NavController,
    private phsHelperStorageService: PhsHelperStorageService,
  ) {
    this.validate();
  }


  async validate() {
    this.generalData = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
    const { documents } = this.generalData.jsonRequest.brmsverification
    const healthDec = documents.filter(item=>item.document_name == 'Form Health Declaration' || item.document_name == 'HD')
    const NeedMagnum = await this.phsHelperStorageService.getStorageNoStringify('needMagnum')
    if (NeedMagnum) {
      this.navCtrl.setRoot(PhsWorkbasketKesehatanMagnumPage);
    }
    else if(healthDec.length > 0){
      const {id, data_completeness, document_checklist } = healthDec[0]
      if(id && document_checklist || data_completeness) this.navCtrl.setRoot('phsworkbasketkesehatannonsyariah', { docId: id })
    }
    else {
      return
    }
  }
  
}
