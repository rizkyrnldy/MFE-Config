import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsHealthDeclaration } from './phs-health-declaration';

@NgModule({
  declarations: [
    PhsHealthDeclaration,
  ],
  imports: [
    IonicPageModule.forChild(PhsHealthDeclaration),
  ],
})
export class PhsHealthDeclarationModule {}
