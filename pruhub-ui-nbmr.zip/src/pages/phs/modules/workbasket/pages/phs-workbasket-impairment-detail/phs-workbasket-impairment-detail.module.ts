import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketImpairmentDetailPage } from './phs-workbasket-impairment-detail';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { SelectSearchableModule } from 'ionic-select-searchable';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    PhsWorkbasketImpairmentDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketImpairmentDetailPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    SelectSearchableModule,
    IonicSelectableModule
  ],
})
export class PhsWorkbasketImpairmentDetailPageModule {}
