import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport'
import { IonicSelectableComponent } from 'ionic-selectable';
/**
 * Generated class for the PhsWorkbasketImpairmentDetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketimpairmentdetail",
  segment: "PHS/workbasket/impairmentdetail/:id"
})
@Component({
  selector: 'page-phs-workbasket-impairment-detail',
  templateUrl: 'phs-workbasket-impairment-detail.html',
})
export class PhsWorkbasketImpairmentDetailPage {
  ionTitle: any;
  params: any;
  followUp: any;
  update: boolean = false;
  zaltnum: string;
  exclusion: string;
  dataFollowUp: any;
  dataImpairment: any;
  dataImpairmentClient: any;
  riderCodeTable: any;
  getMasterRiderDetails: any[];
  indexOfImpairment: any;
  grouping: any;
  dataExclusion: any;
  emptyRider: any = [];
  emptyClientNo: any;
  totalLength: any;
  Reason: any;
  saved: boolean = true;
  savedAdd: boolean = false;
  getMasterMICDCode: any[];
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperDateTimeService: PhsHelperDateTimeService,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    public PhsSupportProvider: PhsSupportProvider,
    private auth: UserProvider
  ) {
    this.emptyRider = [{
      riderCode: '',
      load: '',
      icdDesc: '',
      icdsDesc: '',
      needEmptySave: false,
      isChecked: false
    }]
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  async getInitial() {
    this.dataExclusion = this.navParams.get('dataExclusion');
    this.params = this.navParams.get('params');
    this.followUp = this.navParams.get('followUp');
    this.dataImpairmentClient = this.navParams.get('item');
    this.riderCodeTable = this.navParams.get('group');
    this.grouping = this.navParams.get('grouping');
    this.Reason = this.navParams.get('Reason');
    console.log(this.params, 'params');
    console.log(this.riderCodeTable, 'riderCodeTable');
    console.log(this.followUp, 'followup');
    console.log(this.dataImpairmentClient, 'item');
    console.log(this.navParams.get('Reason'), 'Reason');
    this.indexOfImpairment = this.navParams.get('index');
    this.totalLength = this.navParams.get('totalLength');
    console.log('this.indexOfImpairment', this.indexOfImpairment);
    if (this.dataImpairmentClient && this.riderCodeTable) {
      this.riderCodeTable[this.dataImpairmentClient].forEach(async element => {
        console.log(element.load)
        element.load = element.load == '00000' ? '' : parseInt(element.load) / 100;
        element.endDate = element.endDate == "00000000" && "99999999" ? '' : await this.phsHelperDateTimeService.toFormatDate_v2(element.endDate);
      });
    }
  }

  async backMenu() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) this.navCtrl.setRoot('phsworkbasketalterationfollowupexclusion', { 'data': this.params, 'dataFollowUp': this.followUp })
  }

  async add() {
    console.log("add")
    this.riderCodeTable[this.dataImpairmentClient].push({
      riderCode: '',
      load: '',
      icdDesc: '',
      icdsDesc: '',
      needSave: true,
      new: true
    })
    this.saved = false;
    console.log(this.riderCodeTable[this.dataImpairmentClient], 'tambah')
  }

  async addEmpty() {
    console.log("addEmpty")
    this.emptyRider.push({
      riderCode: '',
      load: '',
      icdDesc: '',
      icdsDesc: '',
      needEmptySave: false,
      isChecked: false,
      new: true
    })
    this.savedAdd = false;
  }

  selectAll() {
    if (this.emptyRider.length) {
      this.emptyRider.forEach(element => {
        element.isChecked = !element.isChecked
      });
    }
    if (this.dataImpairmentClient && this.riderCodeTable) {
      this.riderCodeTable[this.dataImpairmentClient].forEach(element => {
        element.isChecked = !element.isChecked
      });
    }
  }

  async submitAdd() {
    let next = false;
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) {
      this.grouping.forEach(element => {
        if (this.emptyClientNo == element) {
          this.showToast("Your id client have existed");
          next = true
        }
      });
      if (!next) {
        let body = {
          objid: "PHUPDIMP",
          chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
          zaltnum: this.navParams.get('followUp').zaltnum,
          fupno: this.params.fupno,
          fupcde: this.params.fupcde,
          clntnum1: this.emptyClientNo,
          dataImpairmentClient: this.emptyRider,
          riderCodeTable: this.riderCodeTable,
          indexOfImpairment: this.totalLength,
          grouping: this.grouping,
          Reason: this.Reason
        }
        let params = await this.PhsSupportProvider.reqNote(body)
        this.alterationFollowUpProvider.impairmentDetail(params).subscribe(p1 => {
          p1.subscribe((response: any) => {
            response = JSON.parse(response.message);
            if (response.headerRespMsg.errlvl == '1') {
              this.showToast(response.headerRespMsg.app_remaining_msg);
            }
            else {
              this.showToast("Saved Success");
            }
            this.PhsSupportProvider.dismissLoading()
          }, err => {
            this.showToast(err);
            this.PhsSupportProvider.dismissLoading()
          })
        })
      }
    }
  }

  async submit() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) {
      console.log(this.riderCodeTable[this.dataImpairmentClient])
      let body = {
        objid: "PHUPDIMP",
        chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        zaltnum: this.navParams.get('followUp').zaltnum,
        fupno: this.params.fupno,
        fupcde: this.params.fupcde,
        clntnum1: this.dataImpairmentClient,
        dataImpairmentClient: this.riderCodeTable[this.dataImpairmentClient],
        riderCodeTable: this.riderCodeTable,
        indexOfImpairment: this.indexOfImpairment + 1,
        grouping: this.grouping,
        Reason: this.Reason
      }
      let params = await this.PhsSupportProvider.reqNote(body)
      this.alterationFollowUpProvider.impairmentDetail(params
        // { objid : "PHUPDIMP",
        // chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        // zaltnum : this.navParams.get('followUp').zaltnum,
        // fupno : this.params.fupno,
        // fupcde: this.params.fupcde,
        // clntnum1: this.dataImpairmentClient,
        // crtable11: this.riderCodeTable[this.dataImpairmentClient].riderCode,
        // oppc11: this.riderCodeTable[this.dataImpairmentClient].load,
        // icdcd11: this.riderCodeTable[this.dataImpairmentClient].icdDesc,
        // }
      ).subscribe(p1 => {
        p1.subscribe((response: any) => {
          response = JSON.parse(response.message);
          if (response.headerRespMsg.errlvl == '1') {
            this.showToast(response.headerRespMsg.app_remaining_msg);
          }
          else {
            this.showToast("Saved Success");
          }
          this.PhsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.PhsSupportProvider.dismissLoading()
        })
      })
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async deleteEmptyRider() {
    let SavedAdd: boolean = true
    if (this.emptyRider.length) {
      let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to delete this data ?');
      if (confirm) {
        var i
        for (i = this.emptyRider.length - 1; i >= 0; i--) {
          if (this.emptyRider[i].isChecked) {
            this.emptyRider.splice(i, 1)
          }
        }
        this.EnableSavedAdd()
      }
    }
  }

  EnableSavedAdd() {
    if (this.emptyRider.filter(data => data.new == true).length) {
      this.savedAdd = false;
    }
    else {
      this.savedAdd = true
    }
  }

  async deleteriderCodeTable() {
    var i
    if (this.riderCodeTable[this.dataImpairmentClient]) {
      let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to delete this data ?');
      if (confirm) {
        for (i = this.riderCodeTable[this.dataImpairmentClient].length - 1; i >= 0; i--) {
          if (this.riderCodeTable[this.dataImpairmentClient][i].isChecked) {
            this.riderCodeTable[this.dataImpairmentClient].splice(i, 1)
          }
        }
        this.EnableSaved()
      }
    }
  }

  EnableSaved() {
    if (this.riderCodeTable[this.dataImpairmentClient].filter(data => data.new == true).length) {
      this.saved = false;
    }
    else {
      this.saved = true
    }
  }

  onSelect(event) {
    console.log(event)
  }

  searchRider(event) {
    console.log(event)
    this.alterationFollowUpProvider.mdengine({ md_name: "rider_detail", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterRiderDetails = response.data
        this.PhsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.PhsSupportProvider.dismissLoading()
      })
    })
  }

  searchICDCode(event) {
    this.alterationFollowUpProvider.mdengine({ md_name: "icd_code", search: event.text }
    ).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterMICDCode = response.data
        console.log("this.getMasterMdengine", this.getMasterMICDCode)
        this.PhsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.PhsSupportProvider.dismissLoading()
      })
    })
  }

  ionViewDidLoad() {
    this.getStorage()
    this.getInitial();
    console.log('ionViewDidLoad PhsWorkbasketImpairmentDetailPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }
  
  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }
}
