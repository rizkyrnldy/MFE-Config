import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { PhsWorkbasketFinancialReviewPage } from './phs-workbasket-financial-review';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsWorkbasketFinancialReviewPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketFinancialReviewPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    IonicModule
  ],
})
export class PhsWorkbasketFinancialReviewPageModule {}
