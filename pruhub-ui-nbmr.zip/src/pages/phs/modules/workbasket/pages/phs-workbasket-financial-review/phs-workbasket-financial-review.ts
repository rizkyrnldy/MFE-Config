import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { FinancialReviewProvider } from '../../../../../../providers/phs/workbasket/financialReview';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the PhsWorkbasketFinancialReviewPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketfinancialreview",
  segment: "PHS/workbasket/financial-review/:id"
})
@Component({
  selector: 'page-phs-workbasket-financial-review',
  templateUrl: 'phs-workbasket-financial-review.html',
})
export class PhsWorkbasketFinancialReviewPage {
  ionTitle: any;
  financial: any;
  activePageUp: number = 1;
  activePageDown: number = 1;
  TotalPageUp: number = 1;
  TotalPageDown: number = 1;
  start: number;
  end: number;
  activePage: number = 1;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    public phsHelperStorageService: PhsHelperStorageService,
    private FinancialReviewProvider : FinancialReviewProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService
    ) {
    
  }

  async revalidate(){
    this.phsAlertService.ConfirmAlert('Are you sure want to revalidate this data ?');
  }

  async getStorage(){
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.FinancialReviewProvider.getFinancialReview({ genId : await this.phsHelperStorageService.getStorageNoStringify('genId')}).subscribe(p1 => {
      p1.subscribe((response:any) => {
        if (response) {  
          console.log("FINANCIAL : ",response)        
          this.financial = response;
          if (response.kycp)
          this.TotalPageDown = Math.ceil(response.kycp.tabelList.length / 10);
          // this.TotalPageUp = response.kycp.tabelList.length;
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  filterData(page) {
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePageDown = page;
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  ionViewDidLoad() {
    
    console.log('ionViewDidLoad PhsWorkbasketFinancialReviewPage');
  }

  ionViewWillEnter() {
    this.getStorage();
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
   this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result){
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })  
  }
}
