import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketManageTask } from './phs-workbasket-managetask';
import { ComponentsModule } from '../../../../../../components/components.module';
// import { CustomSelectComponent } from '../../../../../../components/shared/forms/custom-select/custom-select';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsWorkbasketManageTask,
    // CustomSelectComponent
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketManageTask),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsWorkbasketManageTaskModule {}
