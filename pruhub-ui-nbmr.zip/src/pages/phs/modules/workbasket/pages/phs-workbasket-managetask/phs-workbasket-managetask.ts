import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, Loading } from 'ionic-angular';
import { UserProvider } from '../../../../../../providers/providers';
import { ManageTaskProvider } from '../../../../../../providers/phs/workbasket/managetask';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { Storage } from '@ionic/storage';

@IonicPage({
  name: "phsworkbasketmanagetask",
  segment: "PHS/workbasket/managetask/:id"
})
@Component({
  selector: 'page-phs-workbasket-managetask',
  templateUrl: 'phs-workbasket-managetask.html',
})
export class PhsWorkbasketManageTask {
  loading: Loading;
  searchData: boolean = false;
  searchInput: Object = { clientNo: '', userName: '', department: '', policyNo: '', roleDistribution: '', role: '', status: '' };
  data: any = [];
  searchBody: any = [];
  activePage: number = 1;
  totalPage: number = 1;
  dataManagetask: any;
  dataSearch: any;
  dataInitial: any;
  searchbar: string;
  getItems: any;
  action: string;
  ChooseDecision: any;
  SelectedDecision: any;
  username: any;
  statuses: any[] = [
    { label: '-', value: '' },
    { label: 'Open', value: 'OPEN' },
    { label: 'Claimed', value: 'CLAIMED' },
    { label: 'Suspend', value: 'SUSPEND' },
    { label: 'Wait For', value: 'WAIT FOR' }
  ];
  actions = [
    { label: 'Transfer to Pool', value: 'TransferPool' },
    { label: 'Transfer to User', value: 'TransferUser' },
    { label: 'Release Suspend', value: 'SUSPEND' },
    { label: 'Retry Failed Case', value: 'RETRY' },
    { label: 'Release Wait For', value: 'WAIT FOR' },
    { label: 'Terminate', value: 'TERMINATE' },
    { label: 'Close', value: 'CLOSE' },
  ]
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private storage: Storage,
    private ManageTaskProvider: ManageTaskProvider,
    private auth: UserProvider,
    private phsToastService: phsToastService,
    private PhsSupportProvider: PhsSupportProvider,
    private loadingCtrl: LoadingController
  ) {
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({content: 'Please wait...'});
    this.loading.present();
  }

  async getSearch(searchInput) {
    this.dataSearch = searchInput
    this.searchData = true;
    this.showLoading();
    this.ManageTaskProvider.manageTask(this.dataSearch, this.activePage, 10)
      .mergeMap(res => res)
      .subscribe((response: any) => {
        this.totalPage = response.pageTotal
        this.dataManagetask = response.data
        this.loading.dismiss()
      }, err => {
        this.showToast(err);
        this.loading.dismiss()
      })
  }

  async takeAction() {
    this.showLoading();
    if(this.action === 'CLOSE' || this.action === 'TERMINATE'){
      this.switchAction();
    }else{
      this.switchAction().subscribe((response: any) => {
        if (response.resultCode === "ERROR" || !response.result) {
          this.showToast(response.resultDescription);
        }
        else {
          this.showToast("Saved Success");
        }
          this.loading.dismiss()
      }, err => {
        console.log(err)
        this.showToast(err);
          this.loading.dismiss()
      })
    }
    
  }

  switchAction() {
    let selectedTasks = this.dataManagetask.filter(item => item.isChecked);
    let body = null;
    if(!selectedTasks) {
      return;
    }

    switch (this.action) {
      case 'SUSPEND': case 'WAIT FOR':
        body = {
          department: "PHS",
          task: selectedTasks.map(item => {
            return { policyNo: item.policyNumber, status: this.action }
          })
        };
        return this.ManageTaskProvider.releaseSuspend(body).mergeMap(res => res);
      case 'CLOSE': case 'TERMINATE':
        let taskErr=[];
        let taskNonErr=[];
        selectedTasks.forEach(item => {
          if(item.taskName === "Error Handler"){
            taskErr.push(
              {
                username:this.username,
                bpmId: item.bpmId,
                decision: this.action.toLowerCase(),
                department: "PHS"
              }
            )
          }else{
            taskNonErr.push({ genId: item.genId, typePengajuan: "", processId: item.bpmId, policyNo: item.policyNumber, status: this.action.toLowerCase() })
          }
        });
        
        let bodyNonErr = {
          department: "PHS",
          task: taskNonErr
        };
        if(bodyNonErr.task.length){
          this.ManageTaskProvider.terminate(bodyNonErr).mergeMap(res => res).subscribe((response: any) => {
            if (response.resultCode === "ERROR" || !response.result) {
              if(response.resultDescription){
                this.showToast(response.resultDescription)
              }else{
                response.task.forEach(element => {
                  this.showToast("Task with gen Id "+element.genId+" status "+element.status);
                });
              }
              
            }
            else {
              this.showToast("Saved Success");
            }
              this.loading.dismiss()
          }, err => {
            this.showToast(err);
            this.loading.dismiss()
          })
        }
        if(taskErr.length){
          this.ManageTaskProvider.retryCase(taskErr).mergeMap(res => res).subscribe((response: any) => {
            if (response.resultCode === "ERROR" || !response.result) {
              if(response.resultDescription){
                this.showToast(response.resultDescription)
              }else{
                response.task.forEach(element => {
                  this.showToast("Task with gen Id "+element.genId+" status "+element.status);
                });
              }
              
            }
            else {
              this.showToast("Saved Success");
            }
              this.loading.dismiss()
          }, err => {
            this.showToast(err);
            this.loading.dismiss()
          })
        }
        return;
      case 'RETRY':
        body = selectedTasks.map(item => {
          return {
            username: this.username,
            bpmId: item.bpmId,
            decision: this.action
          };
        });
        return this.ManageTaskProvider.retryCase(body).mergeMap(res => res);
      case 'TransferUser': case 'TransferPool':
        const observables = selectedTasks.map((item) => {
          body = {
            department: "PHS",
            bpm_id: item.bpmId,
            username: this.action === 'TransferUser' ? this.SelectedDecision : ''
          };
          return this.ManageTaskProvider.transferCaseByBpmId(body).mergeMap(res => res);
        });
        return forkJoin(observables).mergeMap(res => res);
    }
  }

  submitForm(frm: any) {
    this.activePage = 1;
    this.getSearch(frm);
  }

  filterData(page) {
    this.activePage = page;
    this.getSearch(this.dataSearch);
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getInitial();
  }
  async getInitial() {
    this.username = await this.storage.get('username');
    this.showLoading();
    this.ManageTaskProvider.listUsers().mergeMap(res => res)
      .subscribe((response: any) => {
        this.dataInitial = response;
        this.loading.dismiss()
      }, err => {
        this.showToast(err);
        this.loading.dismiss()
      });
  }

  selectAll() {
    this.dataManagetask.forEach(element => {
      element.isChecked = !element.isChecked
    });
  }

  filterItems(searchTerm) {
    return this.dataInitial.filter((item: any) => {
      return item.toLowerCase().indexOf(searchTerm.toLowerCase()) > -1;
    });
  }

  setFilteredItems(query) {
    this.searchbar = "displayAbsolute"
    if (!query) {
      this.getItems = this.dataInitial;
    }
    else {
      this.getItems = this.filterItems(query);
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }
}
