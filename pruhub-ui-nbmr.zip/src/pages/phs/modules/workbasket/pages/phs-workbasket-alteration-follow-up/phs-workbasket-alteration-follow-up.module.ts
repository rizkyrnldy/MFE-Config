import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAlterationFollowUpPage } from './phs-workbasket-alteration-follow-up';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';
@NgModule({
  declarations: [
    PhsWorkbasketAlterationFollowUpPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAlterationFollowUpPage),
    PhsDirectivesModule,
    ComponentsModule,
    PipesModule
  ],
})
export class PhsWorkbasketAlterationFollowUpPageModule { }
