import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { Storage } from '@ionic/storage';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the PhsWorkbasketAlterationFollowUpPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketalterationfollowup",
  segment: "PHS/workbasket/alteration_followup/:id"
})
@Component({
  selector: 'page-phs-workbasket-alteration-follow-up',
  templateUrl: 'phs-workbasket-alteration-follow-up.html',
})
export class PhsWorkbasketAlterationFollowUpPage {
  ionTitle: any;
  dataAlteration: any;
  activePage: number = 1;
  TotalPage: number = 1
  start: number = 0
  end: number = 10
  roles: boolean;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alertCtrl: AlertController,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,  
    public storage: Storage,
    private phsToastService: phsToastService
    ) {
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.roles = (await this.storage.get('roles')).filter(data => data == 'PHS_EXCEPTION_HANDLER').length ? true : false
  }

  async getInitial() {
    this.alterationFollowUpProvider.phrtvalter({ objid: "PHRTVALTER", chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber') }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataAlteration = JSON.parse(response.message);
        console.log(this.dataAlteration, 'response');
        // this.TotalPage = Math.ceil(this.dataAlteration.altInfo.length / 10)
        let totalpage: any = []
        this.dataAlteration.altInfo.forEach(element => {
          if (element.zaltnum)
          {
            totalpage.push(element)
          }
        });
        this.TotalPage = Math.ceil(totalpage.length / 10)
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }
  
  showToast(text) {
    this.phsToastService.showToast(text);
  }

  filterData(page) {
    console.log("page", page)
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  // backMenu() {
  //   const confirm = this.alertCtrl.create({
  //     title: 'Are you sure want to leave this page?',
  //     cssClass: 'showConfrim',
  //     buttons: [
  //       {
  //         text: 'Yes',
  //         handler: () => {
  //           this.navCtrl.setRoot('phsworkbasketlist', {})
  //         }
  //       },
  //       {
  //         text: 'Cancel',
  //         handler: () => {
  //           console.log('Disagree clicked');
  //         }
  //       }
  //     ]
  //   });
  //   confirm.present();
  // }

  ionViewDidLoad() {
    this.getStorage();
    this.getInitial();
  }
  
  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
   this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result){
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })  
  }
}
