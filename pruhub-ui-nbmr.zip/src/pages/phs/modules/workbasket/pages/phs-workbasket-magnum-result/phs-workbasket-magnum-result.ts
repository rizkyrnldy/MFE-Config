import { Component, Renderer2, Inject } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsMagnumProvider } from '../../../../../../providers/phs/workbasket/phsmagnum';
import { Storage } from '@ionic/storage';
import { DOCUMENT } from '@angular/platform-browser';
import { HostListener } from '@angular/core';
import { MagnumResultProvider } from '../../../../../../providers/phs/workbasket/magnumresult';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
/**
 * Generated class for the PhsWorkbasketMajorPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketmagnumdecision",
  segment: "PHS/workbasket/magnum-decision/:id"
})
@Component({
  selector: 'page-phs-workbasket-magnum-result',
  templateUrl: 'phs-workbasket-magnum-result.html',
})
export class PhsWorkbasketMagnumResultPage {
  statSmoking: any;
  jobsField: any;
  benefitsAsurance: any;
  indexDecisionToDelete: any;
  caseUuid: any;
  decisionMagnum: any;
  tempDec: any;
  ionTitle: any;
  buttonDeletePopup: boolean = false;
  constructor(public navCtrl: NavController,
    private phsToastService: phsToastService,
    public storage: Storage,
    private magnumDecision: MagnumResultProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    @Inject(DOCUMENT) private _document,
    public magnumProvider: phsMagnumProvider,
    private _renderer2: Renderer2,
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
  ) {
  }

  setParentHeightResize(magnum) {
    let parent = magnum;
    if (parent.className != 'accordion-body') {
      let element = magnum;
      while ((element = element.parentElement) && !element.classList.contains('accordion-body')) {
        parent = element.parentElement;
      }
    }
    setTimeout(() => {
      let contentHeight = parent.children[0].offsetHeight;
      parent.setAttribute("style", "height:" + contentHeight + "px");
    }, 500);
  }

  splitMagnumDecision(data) {
    let indexHolder = [];
    let labelHolder = [];
    for (let z = 0; z < data.childNodes.length; z++) {
      for (let i = 0; i < data.childNodes[z].childNodes.length; i++) {
        labelHolder = [];
        indexHolder = [];
        for (let j = 0; j < data.childNodes[z].childNodes[i].benefits.length; j++) {
          let label2 = labelHolder.filter((label) => {
            return label == data.childNodes[z].childNodes[i].benefits[j].label
          })

          if (label2.length == 0) {
            labelHolder.push(data.childNodes[z].childNodes[i].benefits[j].label);
          } else {
            indexHolder.push(j);
          }
        }
        for (let k = 0; k < indexHolder.length; k++) {
          this.deleteDecisionObject(z, i, indexHolder[k] - k);
        }
      }
    }

    this.indexDecisionToDelete = indexHolder;
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page ?');
    if (confirm) {
      let _activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
      if(_activityName === "Processor") {
        this.navCtrl.setRoot('phsworkbasketlist', {});
      } else {
        this.navCtrl.setRoot('phsworkbasketdetail', {});
      }
    } 
  }

  getDecisionMagnum() {

    // if (this.scriptDecisionCtrl == "Yes") {
    //   this._renderer2.removeChild(this._document.body, this.tempDec);
    // }

    let dec = this._renderer2.createElement('script');
    dec.type = 'text/javascript';
    dec.src = 'assets/nonangular/new/decision_screen/build/mxg-components-ui-plain-app.js';
    dec.async = false;

    this.tempDec = dec;
    this._renderer2.appendChild(this._document.body, dec);
    // this.scriptDecisionCtrl = "Yes";

    this.storage.get('Authorization').then((Authorization) => {
      this.getDecisionScreen(window);
    })
  }

  deleteDecisionObject(indexLife, k, indexBenefits) {
    this.decisionMagnum.childNodes[indexLife].childNodes[k].benefits.splice(indexBenefits, 1);
    for (let i = 0; i < this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes.length; i++) {
      this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].decisions.splice(indexBenefits, 1);
      if (this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].childNodes) {
        this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].childNodes[0].decisions.splice(indexBenefits, 1);
        if (this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].childNodes[0].childNodes) {
          for (let j = 0; j < this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].childNodes[0].childNodes.length; j++) {
            this.decisionMagnum.childNodes[indexLife].childNodes[k].decisionNodes[i].childNodes[0].childNodes[j].decisions.splice(indexBenefits, 1);
          }
        }
      }
    }
  }
  async getDecisionScreen(window) {
    this.magnumDecision.getCaseIdByGenId(await this.phsHelperStorageService.getStorageNoStringify('genId')).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (response.data) {
          this.caseUuid = response.data.case_id;
          this.storage.get('Authorization').then((Authorization) => {
            this.magnumProvider.getCaseStatus(this.caseUuid, Authorization)
              .subscribe((result) => {
                this.magnumProvider.getCaseDecision(this.caseUuid, Authorization)
                  .subscribe((result) => {
                    if (result) {
                      this.decisionMagnum = result;
                      this.splitMagnumDecision(this.decisionMagnum);
                      let container = document.querySelector('#magnum-decision-ui-container');
                      console.log('container', container)
                      window.mxgWebApiDecision(container, this.decisionMagnum, this.caseUuid);
                      console.log('decisionMagnum', this.decisionMagnum)
                      console.log('caseUuid', this.caseUuid)
                    }
                    else{
                      this.showToast("No data from magnum result")
                    }
                    this.phsSupportProvider.dismissLoading()
                  }, err => {
                    this.showToast(err);
                    this.phsSupportProvider.dismissLoading()
                  })
                this.phsSupportProvider.dismissLoading()
              }, err => {
                this.showToast(err);
                this.phsSupportProvider.dismissLoading()
              })
          })
        }
        else{
          this.showToast("No data from magnum result")
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    // this.getMagnumList(window)
    this.getStorage()
    this.getDecisionMagnum();
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }
}
