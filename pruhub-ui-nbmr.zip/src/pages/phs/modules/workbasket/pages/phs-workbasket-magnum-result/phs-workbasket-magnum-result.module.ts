import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketMagnumResultPage } from './phs-workbasket-magnum-result';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PipesModule } from '../../../../../../pipes/pipes.module';
@NgModule({
  declarations: [
    PhsWorkbasketMagnumResultPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketMagnumResultPage),
    ComponentsModule,
    PdfViewerModule, 
    PipesModule
  ],
})
export class PhsWorkbasketMagnumResultPageModule {}
