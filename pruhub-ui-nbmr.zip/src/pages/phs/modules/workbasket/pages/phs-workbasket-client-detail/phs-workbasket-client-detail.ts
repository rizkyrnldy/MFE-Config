import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { clientDetailProvider } from '../../../../../../providers/phs/workbasket/clientDetail';
import { ModalProvider } from '../../../../../../providers/phs/modal/modal';
import { UserProvider } from '../../../../../../providers/providers';
import { ModalClientSearchPage } from '../phs-workbasket-modal/modal-client-search/modal-client-search';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { Storage } from '@ionic/storage';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';


@IonicPage({
  name: "phsworkbasketclientdetail",
  segment: "PHS/workbasket/client_detail/:id"
})
@Component({
  selector: 'page-phs-workbasket-client-detail',
  templateUrl: 'phs-workbasket-client-detail.html',
})
export class PhsWorkbasketClientDetailPage {

  polis: any = [];
  data: any = [];
  iconDelete = false;
  iconTrash = false;
  disabled = false;
  mainlife: string;
  ionTitle: any;
  role: string;
  newclient: any;
  public addColor: string;
  public text: string;
  disableButton: boolean = true;
  EnableAdd: boolean = false;
  NextTap: boolean;
  selectedSegment: any;
  dataLeft: any;
  dataQuotation: any;
  dataAdditional: any;
  dataSearch: boolean;
  getMasterSex: Object[];
  getMasterCountry: Object[];
  getMasterMaritalStatus: Object[];
  dataMasterReasonInsurance: Object[];
  dataPolicyNumber: Object[];
  getMasterSourceOfIncome: Object[];
  getMasterIncome: Object[];
  getMasterCountryCodes: Object[];
  getMasterSalutation: Object[];
  getMasterOccupation: Object[];
  getListSearchAsPolicy: any = [];
  getListSearchAsMainLife: any = []
  dataPolicyHolder: Object;
  dataLifeAssured: Object;
  dataBoneClientPolicy: any;
  dataBoneNewClient: any;
  dataBoneClientAssure: any;
  getMasterProvince: Object[]
  home_phone: any = { country_phone: "", number: "", type: "Home" }; office_phone: any = { country_phone: "", number: "", type: "Office" }; mobile_phone1: any = { country_phone: "", number: "", type: "GSM1" }; mobile_phone2: any = { country_phone: "", number: "", type: "GSM2" }; cdma: any = { country_phone: "", number: "", type: "CDMA" }
  policyNumberData: any;
  dataMainLifeNumber: any;
  showBtnAddRole: any;
  roles: any;
  validation: any;
  model: {};
  model1: {};
  modelOccupation: {};
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    public clientDetailProvider: clientDetailProvider,
    private modalCtrl: ModalProvider,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private phsSupportProvider: PhsSupportProvider,
    private auth: UserProvider,
    public storage: Storage,
    public alertCtrl: AlertController) {
    this.addColor = "buttonNonActiveClass";
    this.polis = "userPolis";
    this.text = 'Errased Life Assured';
    // this.data = [
    //   {
    //     id: 1,
    //     name: 'Main Life Assured',
    //     value: 'mainLifeAssured'
    //   }
    // ]

  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.getStorage();
    this.getClientRole();
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.roles = (await this.storage.get('roles')).filter(data => data == 'PHS_PSV' || data == 'PHS_PROCESSOR').length > 0
    console.log(this.roles, 'roles');
  }

  async getClientRole() {
    const chdrnum = await this.phsHelperStorageService.getStorageNoStringify('policyNumber');
    const clientNumberOnLocal = await this.phsHelperStorageService.getStorageNoStringify('clientNumber');
    this.clientDetailProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum: chdrnum }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (!response.error) {
          this.TabMainLifeAssured(response)
        }
        this.phsSupportProvider.dismissLoading()
        const clientNumberOnClientRole = response.find(item=>item.clrrrole=='OW').clntnum;
        const clientNumber = clientNumberOnLocal ? clientNumberOnLocal : clientNumberOnClientRole;
        this.getDataBoNewClient(clientNumber, 'payor', null, null)
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  async mergeAddClient() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    if (jsonR) {
      jsonR.jsonRequest.brmsverification.additional_new_client.forEach(element => {
        let number: any
        console.log("element.role", element.role)
        if (!isNaN(element.role)) {
          number = parseInt(element.role)
          this.data.splice(number - 1, 0, {
            clntnum: null,
            name: parseInt(element.role) == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + (number - 1),
            role: '0' + number,
            value: 'formAssured' + (number - 1),
            // newclient: true
          });
        }
      });

      this.getDataBoNewClient(this.data[0].clntnum, this.data[0].role, this.data[0].newclient, null)
      this.mainlife = this.data[0].value
    }
  }

  convertCode(item) {
    switch (item) {
      case "LF 01":
        return "Main Life Assured"
      case "LF 02":
        return "Add Life Assured 01"
      case "LF 03":
        return "Add Life Assured 02"
      case "LF 04":
        return "Add Life Assured 03"
      case "LF 05":
        return "Add Life Assured 04"
      case "OW":
        return "Policy Holder"
      case "PY":
        return "Payor"
    }
  }

  TabMainLifeAssured(params) {
    if (params) {
      params.forEach(element => {
        console.log(element.clrrrole + element.life)
        switch (element.clrrrole + element.life) {
          case "OW":
            element.name = 'Policy Holder'; element.value = 'policyholder'; element.desc = 'Policy Holder'
            break;
          case "PY":
            element.name = 'Payor'; element.value = 'payor'; element.desc = 'Payor'
            break;
          case "LF01":
            element.name = 'Main Life Assured'; element.value = 'mainlifeassured'; element.desc = 'Main Life Assured'
            this.data.push(element)
            break;
          case "LF02":
            element.name = 'Additional Life Assured 1'; element.value = 'additionallifeassured1'; element.desc = 'Additional Life Assured 1'
            this.data.push(element)
            break;
          case "LF03":
            element.name = 'Additional Life Assured 2'; element.value = 'additionallifeassured2'; element.desc = 'Additional Life Assured 2'
            this.data.push(element)
            break;
          case "LF04":
            element.name = 'Additional Life Assured 3'; element.value = 'additionallifeassured3'; element.desc = 'Additional Life Assured 3'
            this.data.push(element)
            break;
          case "LF05":
            element.name = 'Additional Life Assured 4'; element.value = 'additionallifeassured4'; element.desc = 'Additional Life Assured 4'
            this.data.push(element)
            break;
        }
      });
      this.mergeAddClient();
    }
  }

  searchOccupation(event) {
    this.clientDetailProvider.mdengine({ md_name: "occupation", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterOccupation = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  searchCountry(event) {
    this.clientDetailProvider.mdengine({ md_name: "country", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountry = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  getClientDetail(data) {
    this.clientDetailProvider.getClientDetail({ chdrnum: data }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataPolicyHolder = response.policyDetailList[0];
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  searchLifeAssured(id) {
    this.clientDetailProvider.getClientDetail({ chdrnum: id }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataLifeAssured = response.policyDetailList[0]
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  async newLifeAssure(role, newClient, index) {
    let getRole: boolean
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    this.role = role;
    this.newclient = { status: newClient, index: index }
    jsonR.jsonRequest.payload.client.lifeAss.forEach(async element => {
      if (element.role == role) {
        getRole = true
        this.dataLeft = element
        this.dataLeft.salutation = this.dataLeft.sex ? this.dataLeft.sex === 'M' ? 'BAPAK' : 'IBU' : ''
        this.modelOccupation = await this.checkName('occupation', this.dataLeft.occp);
        this.model = await this.checkName('country', this.dataLeft.natlty);
        this.dataLeft.address.forEach(async element => {
          // console.log("element",element) pr rizal
          element.model1 = await this.checkName('country', element.country);
        })
        this.dataLeft.phone.forEach(element => {
          if (element.type) {
            switch (element.type) {
              case 'Home':
                this.home_phone = element
                break
              case 'Office':
                this.office_phone = element
                break
              case 'GSM1':
                this.mobile_phone1 = element
                break
              case 'GSM2':
                this.mobile_phone2 = element
                break
              case 'CDMA':
                this.cdma = element
                break
            }
          }
        })
        this.getDataBoNewClient(this.dataLeft.client_no, 'clientSearch', null, null);
      }
    })
    if (!getRole) { this.createDataLeft(); }
    this.getInitial()
  }

  async getDataBoNewClient(clientNumber, role, newclient, index) {
    this.NextTap = true
    console.log(await this.phsHelperStorageService.getStorageNoStringify('clientNumber'), 'clientNumber')
    if (!isNaN(role) && role) { 
      this.getMasterSex = null, this.getMasterSalutation = null, this.getMasterMaritalStatus = null, this.getMasterCountry = null, this.getMasterOccupation = null, this.getMasterCountry = null, this.getMasterProvince = null, this.getMasterCountryCodes = null, this.getMasterIncome = null;
      this.newLifeAssure(role, newclient, index) 
    }
    else {
      this.clientDetailProvider.getBoneNewClient({ clntnum: clientNumber ? clientNumber : await this.phsHelperStorageService.getStorageNoStringify('clientNumber') }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          if (role == 'payor') {
            this.dataBoneClientPolicy = response
            if (response.clientNo) {
              this.getPolicyRole(response.clientNo, 'policy')
            }
          }
          else if (role == 'clientSearch') {
            this.dataSearch = response.clientNo ? true : false;
            this.dataBoneNewClient = response
            if (response.clientNo) {
              this.getPolicyRole(response.clientNo, 'lifeAssured')
            }
          }
          else if (clientNumber && !role) {
            this.dataBoneNewClient = response
            this.dataSearch = response.clientNo ? true : false;
            this.dataLeft = null;
            if (response.clientNo) {
              this.getPolicyRole(response.clientNo, 'lifeAssured')
            }
          }
          console.log("this.dataBoneNewClient", this.dataBoneNewClient)
          this.phsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.phsSupportProvider.dismissLoading()
        })
      })
    }
  }

  async getPolicyRole(Clntnum, toDo) {
    this.clientDetailProvider.getpolicyrole({ clntnum: Clntnum }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.mergeData(response, toDo)
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  mergeData(response, toDo) {
    console.log(response, "response")
    let data = []
    response.forEach(element => {
      data.push({ policyNo: element.policyNo, rolePolicy: element.rolePolicy == "LF" ? element.rolePolicy + ' ' + element.lifeRole : element.rolePolicy })
    });
    if (data.length) {
      var result = data.reduce(function (r, a) {
        r[a.rolePolicy] = r[a.rolePolicy] || [];
        r[a.rolePolicy].push(a);
        return r;
      }, Object.create(null));
      let keyNames = Object.keys(result);
      if (toDo == 'policy') {
        this.dataPolicyNumber = result;
        this.getListSearchAsPolicy = keyNames
      }
      else if (toDo == 'lifeAssured') {
        this.dataMainLifeNumber = result;
        this.getListSearchAsMainLife = keyNames
      }
    }
  }

  async getInitial() {
    this.clientDetailProvider.getMasterSex().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSex = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.datamasterreasoninsurance().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.dataLeft.buy_ins = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterSourceOfIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.filterSource_Income(response)
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterIncome = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterCountry().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountry = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterOccupation().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterOccupation = response;
        console.log("getMasterOccupation", this.getMasterOccupation)
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterMaritalStatus().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterMaritalStatus = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterCountryCodes().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountryCodes = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterSalutation().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSalutation = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })

    this.clientDetailProvider.getMasterProvince().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterProvince = response
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  searchModal() {
    // this.showModal = true;
    let modalInstance = this.modalCtrl.Modal(ModalClientSearchPage, {});
    modalInstance.onDidDismiss(data => {
      if (data) {
        this.dataLeft.client_no = data
        this.getDataBoNewClient(data, 'clientSearch', null, null)
      }
    })
  }

  filterBuyingInsurance(response) {
    response.forEach(elementRes => {
      this.dataBoneClientPolicy.reasonForBuyingInsurance.forEach(elementStorage => {
        if (elementRes.description.trim() == elementStorage.reasonForBuyingInsurance.trim()) {
          elementRes.isChecked = true
        }
      });
    })
    this.dataBoneClientPolicy.reasonForBuyingInsurance = response;
  }

  filterSource(response) {
    return new Promise((resolve) => {
      response.forEach(elementRes => {
        this.dataLeft.income.forEach(elementStorage => {
          if (elementRes.id == elementStorage.source) {
            elementRes.isChecked = true
          }
        });
      });
      resolve(response)
    })
  }

  async filterSource_Income(response) {
    console.log("this.dataLeft", this.dataLeft)
    let amount = this.dataLeft.income.length ? this.dataLeft.income[0].amount : this.dataLeft.income.amount
    let source = this.dataLeft.income.length ? await this.filterSource(response) : this.dataLeft.income.source
    this.dataLeft.income = {
      amount: amount,
      source: source
    }
  }

  showConfirm() {
    const confirm = this.alertCtrl.create({
      title: 'Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page',
      cssClass: 'showConfrim',
      buttons: [
        {
          text: 'Yes',
          handler: () => {
            this.navCtrl.setRoot('phsworkbasketlist', {})
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Disagree clicked');
          }
        }
      ]
    });
    confirm.present();
  }

  addSegment() {
    var i;
    let enableAdd: boolean = false
    for (i = 1; i < 6; i++) {
      enableAdd = false
      this.data.forEach(element => {
        console.log("loopingan", i + ' ' + parseInt(element.role) + ' ' + parseInt(element.life))
        if (i === parseInt(element.role) || i === parseInt(element.life)) {
          console.log("tidak di add", i + ' ' + parseInt(element.role) + ' ' + parseInt(element.life))
          enableAdd = true
        }
      });
      if (!enableAdd) {
        console.log("index add", i)
        this.data.splice(i - 1, 0, {
          clntnum: null,
          name: i == 1 ? 'Main Life Assured ' : 'Add Life Assured ' + (i - 1),
          // desc: this.data.length == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + this.data.length,
          value: 'formAssured' + (i - 1),
          // role: '0' + (this.data.length + 1),
          role: '0' + i,
          newclient: true
        })
        // this.data.push({          
        //   clntnum: null,
        //   name: i  == 1 ? 'Main Life Assured ' : 'Add Life Assured ' + (i - 1),
        //   // desc: this.data.length == 0 ? 'Main Life Assured ' : 'Add Life Assured ' + this.data.length,
        //   value: 'formAssured' + (i - 1),
        //   // role: '0' + (this.data.length + 1),
        //   role: '0'+ i,
        //   newclient: true
        // });
        console.log("this.data", this.data)
        break;
      }
    }
    this.EnableAdd = true;
    this.disableButton = false;
  }


  showDeleteIcon() {
    this.iconDelete = !this.iconDelete;
    if (this.text === 'Cancel') {
      this.text = 'Erased Life Assured'
    } else {
      this.text = 'Cancel'
    };
    this.iconTrash = !this.iconTrash;
    this.disabled = !this.disabled;
  }

  filterReasonInsurance() {
    return new Promise((resolve) => {
      let arraySelected = []
      this.dataLeft.buy_ins.forEach((element, key) => {
        if (element.isChecked) { delete element.isChecked; arraySelected.push(element) }
      });
      resolve(arraySelected)
    })
  }

  async saveData() {
    this.validation = await this.phsSupportProvider.checkDataEmpty({ name: this.dataLeft.name, sex: this.dataLeft.sex, salutation: this.dataLeft.salutation, marital_status: this.dataLeft.marital_status })
    if (this.validation) {
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      jsonR.jsonRequest.payload.client.lifeAss.forEach(async (element, key) => {
        if (element.role == this.role) {
          jsonR.jsonRequest.payload.client.lifeAss[key] = this.dataLeft
          // jsonR.jsonRequest.payload.client.lifeAss[key].buy_ins        
        }
      })

      jsonR.jsonRequest.payload.quotation.lifeAss.forEach(async element => {
        if (element.role == this.role) {
          // element.income = this.dataLeft.income
          element.sex = this.dataLeft.sex
          element.dob = this.dataLeft.dob
          element.name = this.dataLeft.name
          element.occp = this.dataLeft.occp
          element.client_no = this.dataLeft.client_no
        }
      })


      if (this.newclient.status) {
        this.dataLeft.role = this.role
        this.dataQuotation.sex = this.dataLeft.sex;
        this.dataQuotation.dob = this.dataLeft.dob;
        this.dataQuotation.name = this.dataLeft.name;
        this.dataQuotation.occp = this.dataLeft.occp;
        this.dataQuotation.client_no = this.dataLeft.client_no;
        this.dataQuotation.role = this.role;
        this.dataAdditional.role = this.role;
        this.dataAdditional.documentName = this.role == '01' ? 'Main Life Assured' : 'Life Assured';
        jsonR.jsonRequest.payload.client.lifeAss.push(this.dataLeft);
        jsonR.jsonRequest.payload.quotation.lifeAss.push(this.dataQuotation)
        jsonR.jsonRequest.brmsverification.additional_new_client.push(this.dataAdditional)
      }

      console.log("JsonR", jsonR)
      let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
      if (result) {
        this.EnableAdd = false
        delete this.data[this.newclient.index].newclient
        this.showToast("Save Successful");
        this.newclient = { status: null, index: null }
      }
    }
  }

  async confirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) this.saveData();
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async deleteItem(i, role, newclient) {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want delete this form ?');
    if (confirm) {
      this.data.splice(i, 1);
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      jsonR.jsonRequest.brmsverification.additional_new_client.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.brmsverification.additional_new_client.splice(key, 1);
      });
      jsonR.jsonRequest.payload.client.lifeAss.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.payload.client.lifeAss.splice(key, 1);
      });
      jsonR.jsonRequest.payload.quotation.lifeAss.forEach((element, key) => {
        if (element.role == role)
          jsonR.jsonRequest.payload.quotation.lifeAss.splice(key, 1);
      });
      this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
      this.dataLeft = null; this.dataSearch = false
      if (newclient) { this.EnableAdd = false }
    }
  }

  checkName(name, code) {
    return new Promise((resolve) => {
      let result = ""
      if (code) {
        this.clientDetailProvider.mdengine({ md_name: name, search: code }).subscribe(p1 => {
          p1.subscribe((response: any) => {
            if (response.data.length) {
              result = response.data[0]
              resolve(result)
            }
            else {
              resolve(result)
            }
            this.phsSupportProvider.dismissLoading();
          }, err => {
            this.showToast(err);
            this.phsSupportProvider.dismissLoading();
          })
        })
      }
      else {
        resolve(result)
      }
    })
  }

  createDataLeft() {
    this.dataLeft = {
      income: [{ amount: '', source: '' }],
      pob: "",
      role: "",
      auto_dedup: "",
      mailing_method: "",
      fax: "",
      email: "",
      id_number: "",
      us_tax: "",
      id_exp: "",
      address: [
        {
          zip: "",
          country: "",
          province: "",
          city: "",
          kecamatan: "",
          type: "",
          line3: "",
          line2: "",
          line1: "",
          kelurahan: ""
        }
      ],
      sex: "",
      npwp: "",
      xIns_flag: "",
      buy_ins: [],
      religion: "",
      marital_status: "",
      natlty: "",
      occp: "",
      foreign_tax: "",
      client_no: "",
      phone: [
      ],
      dob: "",
      cob: "",
      edu: "",
      name: "",
      occp_company: "",
      salution: ""
    }
    this.dataQuotation = {
      income: "",
      role: "",
      next_bday: "",
      smoking_status: "",
      occp_class: "",
      jabatan: "",
      sex: "",
      batang_rokok: "",
      occp: "",
      component: [
        {
          product_desc: "",
          cover_age: "",
          product_code: "",
          coi: "",
          sum_ass: "",
          unit_prumed: ""
        }
      ],
      client_no: "",
      dob: "",
      new_client: "Y",
      name: "",
      usaha: "",
      instansi: ""
    }
    this.dataAdditional = {
      role: "",
      clientNo: "",
      documentName: ""
    }
  }
  
  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }

}
