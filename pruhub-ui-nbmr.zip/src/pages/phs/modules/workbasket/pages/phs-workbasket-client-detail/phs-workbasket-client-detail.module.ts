import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketClientDetailPage } from './phs-workbasket-client-detail';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    PhsWorkbasketClientDetailPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketClientDetailPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    IonicSelectableModule
  ],
})
export class PhsWorkbasketClientDetailPageModule {}
