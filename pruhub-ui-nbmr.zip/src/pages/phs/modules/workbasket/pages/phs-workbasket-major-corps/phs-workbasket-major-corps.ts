import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the PhsWorkbasketMajorCorpsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketmajorcorps",
  segment: "PHS/workbasket/major-corps/:id"
})
@Component({
  selector: 'page-phs-workbasket-major-corps',
  templateUrl: 'phs-workbasket-major-corps.html',
})
export class PhsWorkbasketMajorCorpsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhsWorkbasketMajorCorpsPage');
  }

}
