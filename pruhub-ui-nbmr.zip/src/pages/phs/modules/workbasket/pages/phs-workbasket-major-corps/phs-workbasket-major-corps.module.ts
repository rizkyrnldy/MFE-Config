import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsWorkbasketMajorCorpsPage } from './phs-workbasket-major-corps';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    PhsWorkbasketMajorCorpsPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketMajorCorpsPage),
    ComponentsModule,
    IonicSelectableModule
  ],
})
export class PhsWorkbasketMajorCorpsPageModule {}
