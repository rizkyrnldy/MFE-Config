import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalClientSearchPage } from './modal-client-search';

@NgModule({
  declarations: [
    ModalClientSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalClientSearchPage),
  ],
})
export class ModalClientSearchPageModule {}
