import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport'
/**
 * Generated class for the PhsWorkbasketAlterationFollowUp3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketalterationfollowupexclusion",
  segment: "PHS/workbasket/alteration_followupexclusion/:id"
})
@Component({
  selector: 'page-phs-workbasket-alteration-follow-up3',
  templateUrl: 'phs-workbasket-alteration-follow-up3.html',
})
export class PhsWorkbasketAlterationFollowUp3Page {
  ionTitle: any;
  params: any;
  update: boolean = false;
  zaltnum: string;
  dataFollowUp: any;
  exclusion: string;
  dataExclusion: any;
  hxlcNote: any;
  noteModel: any;
  enableWrite: boolean = false;
  start: number = 0;
  end: number = 6;
  first: number = 0;
  last: number = 10;
  hxclnote: Object[] = [{ hxclnote1: '' }, { hxclnote2: '' }, { hxclnote3: '' }, { hxclnote4: '' }, { hxclnote5: '' }, { hxclnote6: '' }];
  pages: any = [];
  hxclnote1: any;
  hxclnote2: any;
  hxclnote3: any;
  hxclnote4: any;
  hxclnote5: any;
  hxclnote6: any;
  startPage: number = 0;
  endPage: number = 6;
  totalData: any;
  selected: number = 1;
  selectedAdd: number = 1;
  soncdExclusion: any[];
  Reason1: Object = { code: "", description: "" };
  Reason2: Object = { code: "", description: "" };
  Reason3: Object = { code: "", description: "" };
  clientImpair: any;
  group: any;
  grouping: any = [];
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperDateTimeService: PhsHelperDateTimeService,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    private auth: UserProvider,
    public PhsSupportProvider: PhsSupportProvider,
  ) {
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.getInitial();
    console.log(this.hxlcNote, 'note');
  }

  async backMenu() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) this.navCtrl.setRoot('phsworkbasketalterationfollowup1', { 'dataFollowUp': this.dataFollowUp })
  }

  async getInitial() {
    this.dataFollowUp = this.navParams.get('dataFollowUp')
    if (this.navParams.get('data')) {
      this.params = this.navParams.get('data');
      this.alterationFollowUpProvider.phrtvexclsService({
        OBJID: "PHRTVEXCLS",
        CHDRNUM: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        ZALTNUM: this.navParams.get('dataFollowUp').zaltnum,
        FUPNO: this.params.fupno
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.dataExclusion = JSON.parse(response.message);
          console.log("this.dataExclusion", this.dataExclusion)
          this.Reason1 = { code: this.dataExclusion.retriveExclusion.reasoncd, description: this.dataExclusion.retriveExclusion.resndesc };
          this.Reason2 = { code: this.dataExclusion.retriveExclusion.reasoncdb, description: this.dataExclusion.retriveExclusion.resndescb };
          this.Reason3 = { code: this.dataExclusion.retriveExclusion.reasoncdc, description: this.dataExclusion.retriveExclusion.resndescc };
          console.log("this.Reason1", this.Reason3)
          // console.log('exclusionInfo', JSON.parse(response.message).exclusionInfo);
          // this.enableWrite = JSON.parse(response.message).exclusionInfo.filter(element => element.hxlcNote === "").length ? false : true          

          this.totalData = JSON.parse(response.message).exclusionInfo.filter(function (el) { return el.hxclnote != '' })
          // console.log('this.enableWrite', this.enableWrite)
          let note = JSON.parse(response.message).exclusionInfo[0].hxclnote.length
          let coloumnNote = Math.ceil(note / 75);
          var i

          // let hxclnote = JSON.parse(response.message).exclusionInfo[0].hxclnote
          // this.hxclnote1 = hxclnote.slice(0, 74).trim()
          // this.hxclnote2 = hxclnote.slice(75, 149).trim()
          // this.hxclnote3 = hxclnote.slice(150, 224).trim()
          // this.hxclnote4 = hxclnote.slice(225, 299).trim()
          // this.hxclnote5 = hxclnote.slice(300, 374).trim()
          // this.hxclnote6 = hxclnote.slice(375, 449).trim()
          console.log("this.totalData.length", this.totalData.length)
          console.log("this.totalData", this.totalData)
          for (i = 1; i <= (this.totalData.length < 1 ? 1 : this.totalData.length); i++) {
            this.pages.push(i)
          }
          if (this.totalData.length) {
            let starthxclnote = 0;
            let start = 0;
            this.totalData.forEach((element, key) => {
              if (key > 0) {
                this.addHxclnote(key + 1)
                start += 6
              }
              let totalHxclnote = Math.ceil(element.hxclnote.length / 75)
              console.log("this.length", Math.ceil(element.hxclnote.length / 75))
              for (i = 1; i <= totalHxclnote; i++) {
                starthxclnote += 1;
                let x = this.sliceBetween(i)
                this.hxclnote[start + (i - 1)]['hxclnote' + (start + i)] = element.hxclnote.slice(x.start, x.end).trim()
              }
            });
          }
          console.log("this.hxclnote", this.hxclnote)
          this.enableWrite = JSON.parse(response.message).exclusionInfo.filter(function (el) { return el.hxclnote != '' }).length ? true : true;
          this.clientImpair = this.dataExclusion.impairmentDetailList

          this.group = this.clientImpair.reduce(function (r, a) {

            r[a.clientId] = r[a.clientId] || [];

            r[a.clientId].push(a);

            return r;

          }, Object.create(null));
          this.grouping = Object.keys(this.group)
          this.PhsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.PhsSupportProvider.dismissLoading()
        })
      })
    }
  }

  onClear(event) {
    console.log(event)
  }

  searchReason(event) {
    this.alterationFollowUpProvider.mdengine({ md_name: "reasoncd_exclusion", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.soncdExclusion = response.data
        this.PhsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.PhsSupportProvider.dismissLoading()
      })
    })
  }

  checkEmpty() {
    let check: boolean;
    check = this.hxclnote.slice(this.startPage, this.endPage).length ? false : true;
    return check
  }

  async doubletap(i) {
    console.log(this.hxclnote, "this.hxclnote")
    console.log("i", i)
    console.log("this.pages", this.pages)
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to delete this page ?');
    if (confirm && this.pages.length > 1) {
      this.pages.splice(i, 1)
      let startErase = i == 0 ? 5 : ((i + 1) * 6) - 1
      let until = i == 0 ? 0 : ((i + 1) * 6) - 6
      for (i = startErase; i >= until; i--) {
        console.log("index", i)
        this.hxclnote.splice(i, 1)
      }
      console.log(this.hxclnote, "this.hxclnote")
      this.hxclnote.forEach((element, i) => {
        let dataStart = 'hxclnote' + (i + 1);
        if (element[Object.keys(element)[0]]) { this.hxclnote[i] = {}; this.hxclnote[i][dataStart] = element[Object.keys(element)[0]]; }
      })
      let dataPages = this.pages
      this.pages = []
      dataPages.forEach((element, key) => {
        this.pages.push(key + 1)
      });
    }
  }

  sliceBetween(i) {
    let x
    switch (i) {
      case 1:
        x = { start: 0, end: 74 }
        return x
      case 2:
        x = { start: 75, end: 149 }
        return x
      case 3:
        x = { start: 150, end: 224 }
        return x
      case 4:
        x = { start: 225, end: 299 }
        return x
      case 5:
        x = { start: 300, end: 374 }
        return x
      case 6:
        x = { start: 375, end: 449 }
        return x
    }
  }

  cosole(con) {
    console.log("this.Reason1", con)
  }

  edit(id) {
    let data = this.dataExclusion.impairmentDetailList.filter(data => data.clientId == id)
    console.log(data, 'edit')
  }

  isActive(item, toDo) {
    // console.log(toDo)
    if (toDo === "currentData") {
      return (this.selected === item);
    }
    else {
      return (this.selectedAdd === item);
    }
  }

  currentData(data, index) {
    this.selected = index
    this.hxclnote1 = data.hxclnote.slice(0, 74).trim()
    this.hxclnote2 = data.hxclnote.slice(75, 149).trim()
    this.hxclnote3 = data.hxclnote.slice(150, 224).trim()
    this.hxclnote4 = data.hxclnote.slice(225, 299).trim()
    this.hxclnote5 = data.hxclnote.slice(300, 374).trim()
    this.hxclnote6 = data.hxclnote.slice(375, 449).trim()
  }

  addHxclnote(index) {
    let totalPage = index * 6
    var i
    for (i = (totalPage - 6); i < totalPage; i++) {
      this.hxclnote.push({})
      this.hxclnote[i]['hxclnote' + (i + 1)] = ''
    }
  }

  async  saveReason() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) {
      let Reason = {
        Reason1: this.Reason1,
        Reason2: this.Reason2,
        Reason3: this.Reason3
      }
      let body = {
        objid: "PHUPDIMP",
        chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        zaltnum: this.navParams.get('dataFollowUp').zaltnum,
        fupno: this.params.fupno,
        fupcde: this.params.fupcde,
        // clntnum1: this.dataImpairmentClient,
        // dataImpairmentClient: this.riderCodeTable[this.dataImpairmentClient],
        riderCodeTable: this.group,
        // indexOfImpairment: this.indexOfImpairment + 1,
        grouping: this.grouping,
        Reason: Reason
      }
      let params = await this.PhsSupportProvider.reqNoteNoUpdate(body)
      this.alterationFollowUpProvider.impairmentDetail(params).subscribe(p1 => {
        p1.subscribe((response: any) => {
          console.log(response, 'response');
          this.showToast("Saved Success");
          this.PhsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.PhsSupportProvider.dismissLoading()
        })
      })
    };
  };

  async addnote() {
    let body: object
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) {
      body = {
        OBJID: "PHADDEXCLS",
        CHDRNUM: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        ZALTNUM: this.navParams.get('dataFollowUp').zaltnum,
        FUPNO: this.params.fupno,
        FUPCDE: this.params.fupcde,
        HXCLLETTYP: ""
      }
      let result = await this.deletenote()
      if (result) {
        if (this.hxclnote.length) {
          console.log('this.hxclnote', this.hxclnote);
          this.hxclnote.forEach((element, i) => {
            // console.log(i)
            let dataStart = 'hxclnote' + (i + 1);
            let dataSave = 'HXCLNOTE' + (i + 1);
            console.log('this.hxclnote' + (i + 1) + ' ' + element[dataStart])
            if (element[Object.keys(element)[0]]) { body[dataSave] = element[Object.keys(element)[0]]; }
          });
          this.alterationFollowUpProvider.phrtvexclsAdd(body).subscribe(p1 => {
            p1.subscribe((response: any) => {
              this.showToast("Add Note Success");
              // this.navCtrl.setRoot('phsworkbasketalterationfollowup1', { 'dataFollowUp': this.dataFollowUp });
              this.PhsSupportProvider.dismissLoading()
            }, err => {
              this.showToast(err);
              this.PhsSupportProvider.dismissLoading()
            })
          })
        }
      }
    };
  };

  clearReason() {
    this.Reason1 = { code: "", description: "" };
    this.Reason2 = { code: "", description: "" };
    this.Reason3 = { code: "", description: "" };
  }

  async deletenote() {
    let CHDRNUM = await this.phsHelperStorageService.getStorageNoStringify('policyNumber')
    return new Promise((resolve) => {
      console.log('delete');
      this.alterationFollowUpProvider.phrtvexclsDelete({
        OBJID: "PHDELEXCLS",
        CHDRNUM: CHDRNUM,
        ZALTNUM: this.navParams.get('dataFollowUp').zaltnum,
        FUPNO: this.params.fupno,
        FUPCDE: this.params.fupcde,
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          // this.phsAlertService.ConfirmAlert('Are you sure delete this data ?');
          // this.showToast("Delete Success");
          // this.navCtrl.setRoot('phsworkbasketalterationfollowup1', { 'dataFollowUp': this.dataFollowUp });
          resolve(true)
          this.PhsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.PhsSupportProvider.dismissLoading()
        })
      })
    })
  }

  async deteteImpairment(i) {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to delete this row ?');
    if (confirm) {
      let Reason = {
        Reason1: this.Reason1,
        Reason2: this.Reason2,
        Reason3: this.Reason3
      }
      let body = {
        objid: "PHUPDIMP",
        chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        zaltnum: this.navParams.get('dataFollowUp').zaltnum,
        fupno: this.params.fupno,
        fupcde: this.params.fupcde,
        // clntnum1: this.dataImpairmentClient,
        // dataImpairmentClient: this.riderCodeTable[this.dataImpairmentClient],
        riderCodeTable: this.group,
        // indexOfImpairment: this.indexOfImpairment + 1,
        grouping: this.grouping,
        Reason: Reason
      }
      let params = await this.PhsSupportProvider.reqNoteNoUpdate(body)
      this.alterationFollowUpProvider.impairmentDetail(params).subscribe(p1 => {
        p1.subscribe((response: any) => {
          console.log(response, 'response');
          this.showToast("Delete Success");
          this.PhsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.PhsSupportProvider.dismissLoading()
        })
      })
      this.grouping.splice(i, 1);
    }
  }

  // async addImpair() {
  //   this.grouping.push({})
  // }

  ionViewDidLoad() {
    this.getStorage();
    console.log('ionViewDidLoad PhsWorkbasketAlterationFollowUp3Page');
  }
  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
    // this.hxclnote = [{ hxclnote1: '' }, { hxclnote2: '' }, { hxclnote3: '' }, { hxclnote4: '' }, { hxclnote5: '' }, { hxclnote6: '' }]
  }

  currentPage(page) {
    this.selectedAdd = page;
    console.log("this.selectedAdd", this.selectedAdd)
    this.endPage = page > 1 ? (page * 6) : 6;
    this.startPage = page > 1 ? this.endPage - 6 : 0;
    console.log(this.startPage + '-' + this.endPage)
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }
}
