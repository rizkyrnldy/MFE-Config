import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAlterationFollowUp3Page } from './phs-workbasket-alteration-follow-up3';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { IonicSelectableModule } from 'ionic-selectable';
@NgModule({
  declarations: [
    PhsWorkbasketAlterationFollowUp3Page,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAlterationFollowUp3Page),
    PipesModule,
    PhsDirectivesModule,
    ComponentsModule,
    IonicSelectableModule
  ],
})
export class PhsWorkbasketAlterationFollowUp3PageModule {}
