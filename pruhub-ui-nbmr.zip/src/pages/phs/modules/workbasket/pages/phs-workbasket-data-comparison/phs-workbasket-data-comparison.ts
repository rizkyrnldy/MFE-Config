import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { DataComparisonProvider } from '../../../../../../providers/phs/workbasket/dataComparison';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime';
import { DetailProvider } from '../../../../../../providers/phs/workbasket/detail';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';  
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the PhsWorkbasketDataComparisonPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketdatacomparison",
  segment: "PHS/workbasket/data-comparison/:id"
})
@Component({
  selector: 'page-phs-workbasket-data-comparison',
  templateUrl: 'phs-workbasket-data-comparison.html',
})
export class PhsWorkbasketDataComparisonPage {
  ionTitle: any;
  dataComparison : any;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public storage: Storage,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    private phsAlertService: phsAlertService,
    private auth: UserProvider,
    private DataComparisonProvider: DataComparisonProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService
    ) {
    
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle')
    this.DataComparisonProvider.getDataComparison({
      genId : await this.phsHelperStorageService.getStorageNoStringify('genId')
    }).subscribe(p1 => {
      p1.subscribe((response:any) => {
        if (response) {
          console.log(response, 'dataComparison');
          this.dataComparison = response;
          this.getTime();
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }
  
  async getTime(){
    this.dataComparison.ilustrationDate.major = this.dataComparison.ilustrationDate.major.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.dataComparison.ilustrationDate.major) : this.dataComparison.ilustrationDate.major;
    this.dataComparison.ilustrationDate.sqs = this.dataComparison.ilustrationDate.sqs.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.dataComparison.ilustrationDate.sqs) : this.dataComparison.ilustrationDate.sqs;
  }

  nameRole(role){
    switch (role) {
      case 'OW':
        return "Policy Holder"         
      case '01':
        return "Main Life Assured"         
      case '02':
        return "Add Life Assured 1"         
      case '03':
        return "Add Life Assured 2"         
      case '04':
        return "Add Life Assured 3"         
      case '05':
        return "Add Life Assured 4"         
    }
  }

  async revalidate(){
    this.phsAlertService.ConfirmAlert('Are you sure want to revalidate this data ?');
  }

  ionViewDidLoad() {
    this.getStorage();
    console.log('ionViewDidLoad PhsWorkbasketDataComparisonPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
   this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result){
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })  
  }
}
