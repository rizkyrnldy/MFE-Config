import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketDataComparisonPage } from './phs-workbasket-data-comparison';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsWorkbasketDataComparisonPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketDataComparisonPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsWorkbasketDataComparisonPageModule {}
