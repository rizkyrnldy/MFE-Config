import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketKesehatanMagnumPage } from './phs-workbasket-kesehatan-magnum';
import { CustomSelectComponent } from '../../../../../../components/shared/forms/custom-select/custom-select';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';

@NgModule({
  declarations: [
    PhsWorkbasketKesehatanMagnumPage,
    CustomSelectComponent
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketKesehatanMagnumPage),
    PhsDirectivesModule,
    ComponentsModule
  ],
})
export class PhsWorkbasketKesehatanMagnumPageModule {}
