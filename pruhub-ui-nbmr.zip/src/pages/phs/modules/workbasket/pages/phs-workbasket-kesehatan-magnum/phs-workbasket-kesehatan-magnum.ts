import { Component, Renderer2, Inject, AfterViewInit } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { phsMagnumProvider } from '../../../../../../providers/phs/workbasket/phsmagnum';
import { Storage } from '@ionic/storage';
import { DOCUMENT } from '@angular/platform-browser';
import { UserProvider } from '../../../../../../providers/providers';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { JSONSPAJ } from './jsonSPAJ';
@Component({
  selector: 'page-phs-workbasket-kesehatan-magnum',
  templateUrl: 'phs-workbasket-kesehatan-magnum.html',
})
export class PhsWorkbasketKesehatanMagnumPage implements AfterViewInit {
  statSmoking: any;
  jobsField: any;
  benefitsAsurance: any;
  indexDecisionToDelete: any;
  caseUuid: any;
  decisionMagnum: any;
  tempDec: any;
  buttonDeletePopup: boolean = false;
  navigationList: any = [];
  isMagnumProduct: String;
  p: any;
  dataMedClient: any = [];
  showAccordion: boolean = true;
  breadcrumbItem: any;
  isBootstrapActive: boolean = true;
  itemsSelected: string[] = [];
  formDefinitionIdList: any;
  magnumShow: any;
  selected: string = "Lifestyle";
  formDefinitionId: string = "";
  rulebaseUuid = null;
  scriptDecisionCtrl: any;
  modelTertanggung: string;
  numberpage: number = 0
  public buttonMedResult: boolean = false;
  public buttonMedResultLpk: boolean = true;
  public jsonSPAJ: any = JSONSPAJ;
  ionTitle: any;
  tertanggung: any;
  constructor(public navCtrl: NavController,
    private auth: UserProvider,
    public storage: Storage,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsToastService: phsToastService,
    @Inject(DOCUMENT) private _document,
    public magnumProvider: phsMagnumProvider,
    private _renderer2: Renderer2,
    private phsAlertService: phsAlertService,
    public navParams: NavParams) {
  }

  ngAfterViewInit() {
    this.loadVendorScript();
  }

  ionViewWillEnter() {
    this.authenticate();
    this.getStorage();
  }

  authenticate() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
    })
  }
  
  loadVendorScript() {
    let ven = this._renderer2.createElement('script');
    ven.type = 'text/javascript';
    ven.src = 'assets/nonangular/formsrenderer/build/vendor/vendor.min.js';
    ven.async = false;
    ven.onload = this.loadMagnumScript.bind(this)
    this._renderer2.appendChild(this._document.body, ven);
  }

  loadMagnumScript() {
    let script = this._renderer2.createElement('script');
    script.type = 'text/javascript';
    script.src = 'assets/nonangular/formsrenderer/build/integration/magnum.min.js';
    script.async = false;
    script.onload = this.startChecking.bind(this, window)
    this._renderer2.appendChild(this._document.body, script);
  }

  changeLives(i) {
    let sKey: any;
    let magCont = document.querySelector('.magnumApplication');
    this.breadcrumbItem = [];
    this.formDefinitionIdList = [];
    for (let j = 0; j < this.navigationList[i].data.length; j++) {
      this.breadcrumbItem.push(this.navigationList[i].data[j].name);
      this.formDefinitionIdList.push(this.navigationList[i].data[j].sequenceKey.formDefinitionId);
    }
    this.isBootstrapActive = true
    console.log(this.navigationList[i].data, "this.navigationList[0].data")
    sKey = this.navigationList[i].data[0].sequenceKey;
    this.selected = this.breadcrumbItem[0];
    console.log("this.selected", this.selected)
    this.formDefinitionId = this.formDefinitionIdList[0];
    this.magnumProvider.resumeMagnum(sKey, window, () => {
      // this.setParentHeight3(magCont);
    });
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle')
    this.tertanggung = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
    if (this.tertanggung) {
      let data = this.tertanggung.jsonRequest.payload.client.lifeAss
      if (data.length) { this.modelTertanggung = data[0].role }
    }
  }

  getDecisionMagnum() {

    if (this.scriptDecisionCtrl == "Yes") {
      this._renderer2.removeChild(this._document.body, this.tempDec);
    }

    let dec = this._renderer2.createElement('script');
    dec.type = 'text/javascript';
    dec.src = 'assets/nonangular/new/decision_screen/build/mxg-components-ui-plain-app.js';
    dec.async = false;

    this.tempDec = dec;
    this._renderer2.appendChild(this._document.body, dec);
    this.scriptDecisionCtrl = "Yes";
  }

  async selectedBreadcrumb(item, i, e) {
    let current = 0;
    let picked = 0;
    let life = 0;
    let counter = 0;
    let holder = [];
    let genId = await this.phsHelperStorageService.getStorageNoStringify('genId')
    this.storage.get('Authorization').then((Authorization) => {
      this.magnumProvider.getNavigationMenu2(this.caseUuid, Authorization)
        .subscribe((result) => {
          if (result.formNavigationModels) {
            for (let ini = 0; ini < result.formNavigationModels.length; ini++) {
              holder.push(result.formNavigationModels[ini]);
              if (result.formNavigationModels[ini].childNodes) {
                for (let z = 0; z < result.formNavigationModels[ini].childNodes.length; z++) {
                  holder.push(result.formNavigationModels[ini].childNodes[z]);
                }
              }
            }

            for (let k = 0; k < holder.length; k++) {
              if (holder[k].current) {
                life = holder[k].lifeId;
                break;
              } else {
                current += 1;
              }
            };
            for (let l = 0; l < life - 1; l++) {
              counter += this.navigationList[l].data.length;
            }

            picked = counter + i;

            if (picked > current) {
              if (!holder[current].complete) {
                this.showToast('You need to complete the current form first!');
              } else if (holder[current].complete) {
                if (!holder[picked - 1].complete) {
                  this.showToast('You need to complete the next form first!');
                } else {
                  let sKey = this.navigationList[life - 1].data[i].sequenceKey;
                  this.magnumProvider.resumeMagnum(sKey, window, () => {
                    // this.setParentHeightMagnumBreadcrumb(e);
                  });
                  this.selected = item;
                  this.formDefinitionId = sKey.formDefinitionId;
                }
              }
            } else {
              let sKey = this.navigationList[life - 1].data[i].sequenceKey;
              this.magnumProvider.resumeMagnum(sKey, window, () => {
                // this.setParentHeightMagnumBreadcrumb(e);
              });
              this.selected = item;
              this.formDefinitionId = sKey.formDefinitionId;
            }
          }
        })
    })
  }

  isActive(item, i) {
    return (this.selected === item && this.formDefinitionId === this.formDefinitionIdList[i]);
  }

  async composeNav() {
    let genId = await this.phsHelperStorageService.getStorageNoStringify('genId')
    this.storage.get('Authorization').then((Authorization) => {
      let lifeId = 1;
      this.magnumProvider.getCaseUuidByPropNo(genId, Authorization).subscribe((result) => {
        if (result.case_id) {
          this.caseUuid = result.case_id;
          this.magnumProvider.getNavigationMenu2(this.caseUuid, Authorization)
            .subscribe((result) => {
              this.navigationList = [
                { data: [] },
                { data: [] },
                { data: [] },
                { data: [] },
                { data: [] }
              ];
              for (let i = 0; i < result.formNavigationModels.length; i++) {
                if (result.formNavigationModels[i].lifeId != lifeId) {
                  lifeId += 1;
                };
                if (result.formNavigationModels[i].lifeId == lifeId) {
                  if (!this.navigationList[lifeId - 1]) {

                  } else {
                    this.navigationList[lifeId - 1].data.push(result.formNavigationModels[i]);
                  }
                }
                if (result.formNavigationModels[i].childNodes) {
                  for (let j = 0; j < result.formNavigationModels[i].childNodes.length; j++) {
                    this.navigationList[lifeId - 1]["data"].push(result.formNavigationModels[i].childNodes[j]);
                  }
                }
              }
              console.log('this.navigationList', this.navigationList)
              this.changeLives(this.numberpage);
            }, error => {
              this.showToast('Failed to compose Navigation');
            })
        }
        else {
          this.showToast("No data from magnum result")
        }
      })
    })
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page ?');
    if (confirm) {
      let _activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
      if(_activityName === "Processor") {
        this.navCtrl.setRoot('phsworkbasketlist', {});
      } else {
        this.navCtrl.setRoot('phsworkbasketdetail', {});
      }
    }
  }

  async startChecking() {
    let NeedMagnum = await this.phsHelperStorageService.getStorageNoStringify('needMagnum')
    if (!NeedMagnum) {
      this.navCtrl.setRoot('phsworkbasketkesehatannonsyariah', { docId: await this.phsHelperStorageService.getStorageNoStringify('documentId') })
    }
    else {
      this.loadRulebase();
    }
  }

  loadRulebase() {
    this.storage.get('Authorization').then((Authorization) => {
      this.magnumProvider.getRulebasesList(Authorization)
        .subscribe((result) => {
          if (result) {
            for (let i = 0; result.rulebaseHeaderObjects.length; i++) {
              if (result.rulebaseHeaderObjects[i].name == 'Prudential Indonesia' && result.rulebaseHeaderObjects[i].status == 'ENABLED') {
                this.rulebaseUuid = result.rulebaseHeaderObjects[i].uuid;
                this.categorizeCategories()
                break;
              }
            }
          }
        }, (err) => {
          console.log('There are some errors getting the rulebase UUID with the following message :', err);
        })
    })
  }

  async categorizeCategories() {
    let genId = await this.phsHelperStorageService.getStorageNoStringify('genId')
    this.storage.get('Authorization').then((Authorization) => {
      this.magnumProvider.categorizeCategories(Authorization, genId, this.jsonSPAJ, this.rulebaseUuid, window, 'Data Client', () => {
        this.composeNav();
        this.continueList(window, Authorization)
        this.backList(window, Authorization);
      });
    })
  }

  continueList(window, Authorization) {
    var magnum = window.Magnum();
    magnum.on('navigation-button', (buttonId, success) => {
      if (buttonId === 'nav_ctrl_continue' && success) {
        for (let i = 0; i < this.breadcrumbItem.length; i++) {
          if (this.breadcrumbItem[i] == this.selected) {
            if (i != this.breadcrumbItem.length - 1) {
              this.selected = this.breadcrumbItem[i + 1];
              this.formDefinitionId = this.formDefinitionIdList[i + 1];
              let magCont = document.querySelector('.magnumApplication');
              // this.setParentHeight3(magCont);
              break;
            } else if (i = this.breadcrumbItem.length - 1) {
              this.numberpage += 1
              this.changeLives(this.numberpage)
              this.modelTertanggung = this.tertanggung.jsonRequest.payload.client.lifeAss[this.numberpage].role;
            }
          }
        }
      }
    })
  }

  backList(window, Authorization) {
    var magnum = window.Magnum();
    magnum.on('navigation-button', (buttonId, success) => {
      if (buttonId === 'nav_ctrl_back' && success) {
        console.log('nav_ctrl_back')
        for (let i = 0; i < this.breadcrumbItem.length; i++) {
          if (this.breadcrumbItem[i] == this.selected) {
            if (i != 0) {
              this.selected = this.breadcrumbItem[i - 1];
              this.formDefinitionId = this.formDefinitionIdList[i - 1];
              let magCont = document.querySelector('.magnumApplication');
              break;
            } else if (i == 0) {
              this.numberpage -= 1
              this.changeLives(this.numberpage)
              this.modelTertanggung = this.tertanggung.jsonRequest.payload.client.lifeAss[this.numberpage].role;
            }
          }
        }
      }
    })
  }

  itemTab(item) {
    switch (item) {
      case "01":
        return "Tertanggung Utama";
      case "02":
        return "Tertanggung Tambahan 1";
      case "03":
        return "Tertanggung Tambahan 2";
      case "04":
        return "Tertanggung Tambahan 3";
      case "05":
        return "Tertanggung Tambahan 4";
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

}
