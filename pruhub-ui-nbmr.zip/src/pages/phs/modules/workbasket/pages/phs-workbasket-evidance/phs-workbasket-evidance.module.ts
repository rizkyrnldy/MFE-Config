import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketEvidancePage } from './phs-workbasket-evidance';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsWorkbasketEvidancePage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketEvidancePage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
})
export class PhsWorkbasketEvidancePageModule {}
