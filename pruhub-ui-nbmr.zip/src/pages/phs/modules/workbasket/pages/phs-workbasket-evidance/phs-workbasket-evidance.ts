import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { EvidanceCodeProvider } from '../../../../../../providers/phs/workbasket/evidancecode';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';

@IonicPage({
  name: "phsworkbasketevidance",
  segment: "PHS/workbasket/evidance/:id"
})
@Component({
  selector: 'page-phs-workbasket-evidance',
  templateUrl: 'phs-workbasket-evidance.html',
})
export class PhsWorkbasketEvidancePage {
  ionTitle: any;
  evidance: any;
  eviTable: any;
  evidanceTableData: any;
  ph: any;
  add1: any;
  add2: any;
  add3: any;
  add4: any;
  add5: any;
  modelManuLife: any;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    public phsHelperStorageService: PhsHelperStorageService,
    private EvidanceCodeProvider: EvidanceCodeProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService
  ) {
    this.modelManuLife = 'PH'
  }

  async revalidate() {
    this.phsAlertService.ConfirmAlert('Are you sure want to revalidate this data ?');
  }
  async getInitial() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.EvidanceCodeProvider.getEvidance({ genId: await this.phsHelperStorageService.getStorageNoStringify('genId') }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        console.log(response);
        if (response) {
          console.log(response, 'response');
          this.evidance = response;
          // set default ManuLife
          if(response.evidencePol.length === 0 && response.evidenceLifeAssured.length > 0) this.modelManuLife = response.evidenceLifeAssured[0].role;

          this.ph = this.evidance.evidenceLifeAssured.filter(data => data.role == 'PH').length ? true : false
          this.add1 = this.evidance.evidenceLifeAssured.filter(data => data.role == 'LA1').length ? true : false
          this.add2 = this.evidance.evidenceLifeAssured.filter(data => data.role == 'LA2').length ? true : false
          this.add3 = this.evidance.evidenceLifeAssured.filter(data => data.role == 'LA3').length ? true : false
          this.add4 = this.evidance.evidenceLifeAssured.filter(data => data.role == 'LA4').length ? true : false
          this.add5 = this.evidance.evidenceLifeAssured.filter(data => data.role == 'LA5').length ? true : false
          this.phsSupportProvider.dismissLoading()
        }
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  ionViewDidLoad() {
    this.getInitial();
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }
}
