import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { PhsWorkbasketDetailDocumentPage } from './phs-workbasket-detail-document';
// import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';

@NgModule({
  declarations: [
    PhsWorkbasketDetailDocumentPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketDetailDocumentPage),
    IonicModule,
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule
  ],
  exports: [
    
  ],
})
export class PhsWorkbasketDetailDocumentPageModule {}
