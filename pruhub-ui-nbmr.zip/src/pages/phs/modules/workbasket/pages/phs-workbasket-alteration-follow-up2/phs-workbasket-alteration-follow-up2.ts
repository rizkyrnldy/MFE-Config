import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';

/**
 * Generated class for the PhsWorkbasketAlterationFollowUp2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketalterationfollowupadd",
  segment: "PHS/workbasket/alteration_followupadd/:id"
})
@Component({
  selector: 'page-phs-workbasket-alteration-follow-up2',
  templateUrl: 'phs-workbasket-alteration-follow-up2.html',
})
export class PhsWorkbasketAlterationFollowUp2Page {
  ionTitle: any;
  params: any;
  update: boolean = false;
  zaltnum: string;
  dataFollowUp: any;
  validation: any;
  placeholder: string = 'Life No';
  ClientNumberSearch: any = [];
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public phsHelperDateTimeService: PhsHelperDateTimeService,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
  ) {
    this.params = {
      fupcde: '',
      lifcnum: '',
      fupsts: '',
      fuprmk: '',
      fupdt: ''
    }
  }

  async backMenu() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) this.navCtrl.setRoot('phsworkbasketalterationfollowup1', { 'dataFollowUp': this.dataFollowUp })
  }

  addClientNumberCode(items) {
    if (items) {
      items.forEach(element => {
        let search = element.life ? element.clrrrole + ' ' + element.life : element.clrrrole;
        console.log("search", search)
        switch (search) {
          case "LF 01":
            this.ClientNumberSearch.push({ description: 'Main Life Assured' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 02":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 01' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 03":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 02' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 04":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 03' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          case "LF 05":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 04' + ' - ' + element.clntnum, clntnum: element.clntnum })
            break;
          // case "OW":
          //   this.ClientNumberSearch.push({ description: 'Policy Holder' + ' - ' + element.clntnum, clntnum: element.clntnum })
          //   break;
          // case "PY":
          //   this.ClientNumberSearch.push({ description: 'Payor' + ' - ' + element.clntnum, clntnum: element.clntnum })
          //   break;
        }
      });
      this.mergeAddClient();
    }
  }

  async mergeAddClient() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.brmsverification.additional_new_client.forEach(element => {
      let number: any
      if (!isNaN(element.role)) {
        switch (element.role) {
          case "01":
            this.ClientNumberSearch.push({ description: 'Main Life Assured' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "02":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 01' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "03":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 02' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "04":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 03' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
          case "05":
            this.ClientNumberSearch.push({ description: 'Add Life Assured 04' + ' - ' + element.clientNo, clntnum: element.clientNo })
            break;
        }
      }
    })
  }

  async getInitial() {
    this.dataFollowUp = this.navParams.get('dataFollowUp')
    this.zaltnum = this.navParams.get('dataFollowUp').zaltnum
    if (this.navParams.get('data')) {
      this.params = this.navParams.get('data')
      this.placeholder = this.params.lifcnum
      console.log(this.params, 'data')
    }
    this.update = this.navParams.get('update')
    this.params.fupdt = this.params.fupdt.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.params.fupdt) : this.params.fupdt;

    this.alterationFollowUpProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum: await this.phsHelperStorageService.getStorageNoStringify("policyNumber") }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (!response.error) {
          this.addClientNumberCode(response)
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  ionViewDidLoad() {
    this.getStorage()
    this.getInitial()
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  async submit(update) {
    // update or save
    this.validation = await this.phsSupportProvider.checkDataGetSaved({ fupcde: this.params.fupcde, lifcnum: this.params.lifcnum, fupsts: this.params.fupsts })
    if (this.validation) {
      this.alterationFollowUpProvider.phrtvaltfl({
        OBJID: "PHUPDALTFL",
        CHDRSEL: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        ZALTNUMSEL: this.navParams.get('dataFollowUp').zaltnum,
        ZALTSTASEL: this.navParams.get('dataFollowUp').zaltstat,
        ZALTTYPSEL: this.navParams.get('dataFollowUp').zalttype,
        FUPCDE1: this.params.fupcde ? this.params.fupcde.toUpperCase() : '',
        CLNTNUM1: this.params.lifcnum,
        FUPDT1: this.params.fupdt.length == 10 ? await this.phsHelperDateTimeService.toFormatDateSaved2(this.params.fupdt) : this.params.fupdt,
        FUPNO1: update ? this.params.fupno : '',
        FUPRMK1: this.params.fuprmk,
        FUPSTS1: this.params.fupsts,
        DELFLAG1: '',
        ADDOPT1: !update ? 'Y' : '',
        YNFLAG: ''
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          let resMessage = JSON.parse(response.message);
          if (resMessage.headerMsg.errlvl == '1') {
            this.showToast(resMessage.headerMsg.app_remaining_msg);
          }
          else {
            if (update) { this.showToast("Update Succses"); }
            else { this.showToast("Succses Add"); }
            this.navCtrl.setRoot('phsworkbasketalterationfollowup1', { 'dataFollowUp': this.dataFollowUp })
          }
          this.phsSupportProvider.dismissLoading()
        }, err => {
          this.showToast(err);
          this.phsSupportProvider.dismissLoading()
        })
      })
      console.log(this.zaltnum);
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  actionEnter(item, nextElement) {
    console.log("we call", item)
    this.alterationFollowUpProvider.phrtvt5661({
      FUPCDE: item ? item.toUpperCase() : '',
      OBJID: "PHRTVT5661"
    }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.phsSupportProvider.dismissLoading()
        let message = JSON.parse(response.message);
        console.log("message", message)
        if (response.code === "200" && response.error === false) {
          if (message.headerRespMsg.errlvl == '1') {
            this.showToast(message.headerRespMsg.app_remaining_msg);
          }
          else {
            this.params.fuprmk = message.phrtvt5661.longdesc
          }
        };
        nextElement.setFocus();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  gotoNextField(nextElement) {
    nextElement.setFocus();
  }

  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }



}
