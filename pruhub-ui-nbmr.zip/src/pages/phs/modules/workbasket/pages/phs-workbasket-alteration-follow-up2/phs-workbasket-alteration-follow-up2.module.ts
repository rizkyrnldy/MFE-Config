import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAlterationFollowUp2Page } from './phs-workbasket-alteration-follow-up2';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
@NgModule({
  declarations: [
    PhsWorkbasketAlterationFollowUp2Page,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAlterationFollowUp2Page),
    PhsDirectivesModule
  ],
})
export class PhsWorkbasketAlterationFollowUp2PageModule {}
