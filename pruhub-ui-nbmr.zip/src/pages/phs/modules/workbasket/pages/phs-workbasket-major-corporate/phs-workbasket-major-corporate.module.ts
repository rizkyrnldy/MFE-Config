import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { PhsWorkbasketMajorCorporatePage } from './phs-workbasket-major-corporate';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { IonicSelectableModule } from 'ionic-selectable';

@NgModule({
  declarations: [
    PhsWorkbasketMajorCorporatePage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketMajorCorporatePage),
    IonicModule,
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    IonicSelectableModule
  ],
})
export class PhsWorkbasketMajorCorporatePageModule {}
