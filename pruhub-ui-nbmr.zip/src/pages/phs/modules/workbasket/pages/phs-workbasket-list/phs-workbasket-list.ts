import { Component, Output, EventEmitter } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PHSTaskProvider } from '../../../../../../providers/phs/workbasket/phstask';
import { BrmsdetailProvider } from '../../../../../../providers/phs/workbasket/brmsdetail';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { UserProvider } from './../../../../../../providers/providers';
import { Storage } from '@ionic/storage';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { Subject } from 'rxjs';
import { query } from '@angular/core/src/animation/dsl';
/**
 * Generated class for the PhsWorkbasketListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketlist",
  segment: "PHS/workbasket/list"
})
@Component({
  selector: 'page-phs-workbasket-list',
  templateUrl: 'phs-workbasket-list.html',
})
export class PhsWorkbasketListPage {

  filterViewBy: any = [];
  filterSortBy: any = [];
  arrPagination: any = [];
  activePage: number = 1;
  totalPage: number = 1;
  role: string
  public viewBy: any;
  public sortBy: any;
  searchTask: any;
  taskDueToday: number;
  data: any = [];
  generalData: any;
  searchTaskChanged: Subject<string> = new Subject<string>();
  constructor(
    private phsToastService: phsToastService,
    public navCtrl: NavController,
    public phsHelperStorageService: PhsHelperStorageService,
    public navParams: NavParams,
    public taskProvider: PHSTaskProvider,
    private brmsdata: BrmsdetailProvider,
    private auth: UserProvider,
    public storage: Storage,
    private phsSupportProvider: PhsSupportProvider,
  ) {
    this.viewBy = ""
    this.sortBy = "createdDateAsc"
    this.filterData(this.activePage);
    this.searchTaskChanged.debounceTime(1000).distinctUntilChanged()
    .subscribe(query=>{
      this.searchTask = query;
      this.filterData(1);
    })
  }

  private async getListData(filter: string, sort: string, search: string, page: number) {
    this.role = (await this.storage.get('roles'))[0]
    this.taskProvider.getAvailableTasks(filter, sort, search, page)
    .mergeMap(res=>res)
      .subscribe((response: any) => {
        this.taskDueToday = response.count;
        this.data = response.data;
        this.totalPage = response.pageTotal
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      });
  }

  searchTaskFieldChanged(e) {
    this.searchTaskChanged.next(e.target.value);
  }

  filterData(page) {
    let dataViewBy = (this.viewBy ? this.viewBy : "")
    let dataSorBy = (this.sortBy ? this.sortBy : "")
    let dataKeyword = (this.searchTask ? this.searchTask : "")
    this.activePage = page;
    this.getListData(dataKeyword, dataSorBy, dataViewBy, this.activePage);
    console.log("DATA SEARCH", dataViewBy, dataSorBy, dataKeyword, this.activePage)
  }

  ionViewDidLoad() {
    this.filterViewBy = [
      { text: "All Data", value: "", isDefault: true },
      { text: "Multiple Transaction", value: "MT=Y", isDefault: false },
      { text: "Single Transaction", value: "MT=N", isDefault: false },
      // {text: "Premium already paid", value: "PS=Paid"},
      // {text: "No Paid Premium", value: "PS<>Paid"},
      { text: "Conventional Product", value: "PT=K", isDefault: false },
      { text: "Sharia Product", value: "PT<>K", isDefault: false },
      { text: "Increase Premium", value: "IP=ICR", isDefault: false },
      { text: "Decrease Premium", value: "IP=DCR", isDefault: false }
    ]
    this.filterSortBy = [
      { text: "Created Date ASC", value: "createdDateAsc", isDefault: true },
      { text: "Created Date DESC", value: "createdDateDesc", isDefault: false },
      { text: "Activity Name ASC", value: "activityNameAsc", isDefault: false },
      { text: "Activity Name DESC", value: "activityNameDesc", isDefault: false }
    ]

    this.arrPagination = [
      { text: "1", url: "page 1" },
      { text: "2", url: "page 1" },
      { text: "3", url: "page 1" },
      { text: "4", url: "page 1" },
      { text: "5", url: "page 1" }
    ]
  }

  onInput(event) {
    console.log("On Input : ", event)
  }

  ionCancel(event) {
    // console.log("On Cancel : ",event)
  }

  saveStorage(row) {
    this.phsHelperStorageService.saveStorageNoStringify(row.clientNumber + ':' + row.policyNumber + ':' + row.transType + ':' +
      row.activityName + ':' + row.roleDistribution, 'ionTitle')
    this.phsHelperStorageService.saveStorageNoStringify(row.genId, 'genId')
    this.phsHelperStorageService.saveStorageNoStringify(row.taskId, 'taskId')
    this.phsHelperStorageService.saveStorageNoStringify(row.taskName, 'taskName')
    this.phsHelperStorageService.saveStorageNoStringify(row.clientNumber, 'clientNumber')
    this.phsHelperStorageService.saveStorageNoStringify(row.policyNumber, 'policyNumber')
    this.phsHelperStorageService.saveStorageNoStringify(row.transType, 'transType')
    this.phsHelperStorageService.saveStorageNoStringify(row.activityName, 'activityName')
    this.phsHelperStorageService.saveStorageNoStringify(row.roleDistribution, 'roleDistribution')
    this.phsHelperStorageService.saveStorageNoStringify(row.bpmId, 'bpmId')
    this.phsHelperStorageService.saveStorageNoStringify(row.role, 'role')
    this.phsHelperStorageService.saveStorageNoStringify(row.needMagnum, 'needMagnum')
    this.phsHelperStorageService.saveStorageNoStringify(row.createdDate, 'createdDate')
    this.phsHelperStorageService.saveStorageNoStringify(row.product, 'product')
    this.phsHelperStorageService.saveStorageNoStringify(row.productCode, 'productCode')
  }

  async goToDetail(row) {
    let body = {
      genId: row.genId,
      taskName: "",
      department: "PHS",
      taskId: row.taskId
    }

    this.brmsdata.getBrmsDetail(body).subscribe(p1 => {
      p1.subscribe((response: any) => {
        // this.generalData = { "result": [{ "data": "79", "name": "trackId" }, { "data": "", "name": "bpmDecision" }, { "data": { "createdDate": "2019-03-11T17:40:39Z", "roleDistribution": "PSV_MSI_P_U11_AG_Y_N_IF_IF_DNC_DN", "activityName": "PSV", "roleName": "PSV" }, "name": "worklistData" }], "jsonRequest": { "payload": { "payor": { "pob": "", "docId": "", "jabatan": "", "phones": [{ "number": "", "type": "Home", "country_phone": "" }, { "number": "", "type": "Office", "country_phone": "" }], "client_type": "", "py_sign": "", "mailing_method": "", "comp_type": "", "usaha": "", "fax": "", "pol_no": "", "instansi": "", "incomes": [{ "amount": "75000000", "source": "" }], "ow_sign": "", "ver": "", "id_number": "", "address": [{ "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Home", "line3": "", "line2": "", "line1": "", "kelurahan": "" }, { "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Office", "line3": "", "line2": "", "line1": "", "kelurahan": "" }], "sex": "", "npwp": "", "res_status": "", "relationship_owner": "", "marital_status": "", "natlty": "", "occp": "", "client_no": "", "dob": "", "new_client": "", "cob": "", "name": "", "occp_company": "", "salution": "" }, "flag": [{ "name": "chg_payor", "value": "N" }, { "name": "payor_flag", "value": "OT" }, { "name": "dmc_submission", "value": "CAPTURED" }, { "name": "policy_no_flag", "value": "N" }, { "name": "agent_code_flag", "value": "N" }, { "name": "tgl_quotation_flag", "value": "N" }, { "name": "time_quotation_flag", "value": "N" }, { "name": "sign_date_form", "value": "Y" }, { "name": "sign_date_hd", "value": "N" }, { "name": "increasing_msa_death", "value": "N" }, { "name": "increasing_msa_add_cc", "value": "N" }, { "name": "increasing_tsa_death", "value": "N" }, { "name": "increasing_fsa_death", "value": "N" }, { "name": "increasing_fsa_add_cc", "value": "N" }, { "name": "add_cc_limit", "value": "N" }, { "name": "increasing_msa_death", "value": "N" }, { "name": "increasing_msa_add_cc", "value": "N" }, { "name": "increasing_tsa_death", "value": "N" }, { "name": "increasing_fsa_death", "value": "N" }, { "name": "increasing_fsa_add_cc", "value": "Y" }, { "name": "add_cc_limit", "value": "N" }], "major": { "tgl_quotation": "15022019", "ow_sign": "", "ver": "", "agent_name": "A.H. OTTO NOORDRAVEN", "docId": "14220101", "ag_sign": "", "vendor_name": "RDSJAYA", "alter_fee": "50000", "time_quotation": "150659", "client": [{ "role": "01", "name": "TIKUS" }, { "role": "02", "name": "GAZAH" }, { "role": "03", "name": "TIKUS" }], "scan_time": "20190227162312", "agent_code": "1307", "prubooster_flag": "", "premium_holiday_period": "", "alter": [{ "occp": "", "ns_to_s": "", "s_to_ns": "", "job_desc": "", "client_role": "", "hobby": "" }], "ttd_place": "JAKARTA" }, "client": { "ttd_date": "", "ow_sign": "", "ver": "", "tt1_sign": "", "tt2_sign": "", "agent_sign": "", "docId": "", "pol_no": "", "lifeAss": [{ "income": [{ "amount": "", "amount_desc": "", "source_desc": "", "source": "" }, { "amount": "", "amount_desc": "", "source_desc": "", "source": "" }], "pob": "", "role": "02", "relation_owner_lifeAss": "", "mailing_method": "", "fax": "", "email": "", "xIns": { "substandard_flag": "" }, "id_number": "", "us_tax": "", "id_exp": "", "address": [{ "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Home", "line3": "", "line2": "", "line1": "", "kelurahan": "" }, { "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Office", "line3": "", "line2": "", "line1": "", "kelurahan": "" }], "sex": "", "npwp": "", "xIns_flag": "", "buy_ins": "", "religion": "", "marital_status": "", "natlty": "", "occp": "", "foreign_tax": "", "client_no": "60017105", "phone": [{ "number": "", "type": "GSM1", "country_phone": "" }, { "number": "", "type": "Phone", "country_phone": "" }, { "number": "", "type": "Office", "country_phone": "" }], "dob": "", "cob": "", "edu": "", "name": "TIKUS", "occp_company": "", "salution": "" }, { "income": [{ "amount": "", "amount_desc": "", "source_desc": "", "source": "" }, { "amount": "", "amount_desc": "", "source_desc": "", "source": "" }], "pob": "", "role": "03", "relation_owner_lifeAss": "", "mailing_method": "", "fax": "", "email": "", "id_number": "", "us_tax": "", "id_exp": "", "address": [{ "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Home", "line3": "", "line2": "", "line1": "", "kelurahan": "" }, { "zip": "", "country": "", "province": "", "city": "", "kecamatan": "", "type": "Office", "line3": "", "line2": "", "line1": "", "kelurahan": "" }], "sex": "", "npwp": "", "xIns_flag": "", "buy_ins": "", "religion": "", "marital_status": "", "natlty": "", "occp": "", "foreign_tax": "", "client_no": "", "phone": [{ "number": "", "type": "GSM1", "country_phone": "" }, { "number": "", "type": "Phone", "country_phone": "" }, { "number": "", "type": "Office", "country_phone": "" }], "dob": "", "cob": "", "edu": "", "name": "KAMPRED", "occp_company": "", "salution": "" }], "ttd_place": "" }, "hd": { "ow_sign": "", "ver": "", "life4_sign": "", "docId": "12010401", "life3_sign": "", "life5_sign": "", "submission_criteria": "", "tgl_ttd": "20190120", "life2_sign": "", "oth_policy": null, "lifeAss": [{ "occp": "BEEK", "data": [{ "no": "01", "answer": "N" }, { "no": "02", "answer": "N" }, { "no": "03", "answer": "20" }, { "no": "04", "answer": "N" }, { "no": "05", "answer": "N" }, { "no": "06", "answer": "N" }, { "no": "07", "answer": "N" }, { "no": "08", "answer": "N" }, { "no": "09", "answer": "N" }, { "no": "10", "answer": "N" }, { "no": "11", "answer": "N" }, { "no": "12", "answer": "N" }], "dob": "18091987", "weight": "55", "jml_rokok": "20", "client_role": "01", "height": "175" }, { "occp": "", "data": [{ "no": "02", "answer": "N" }], "dob": "", "weight": "", "jml_rokok": "", "client_role": "02", "height": "" }, { "occp": "", "data": [{ "no": "02", "answer": "N" }], "dob": "", "weight": "", "jml_rokok": "", "client_role": "03", "height": "" }], "life1_sign": "" }, "quotation": { "substd_flag": "", "bill_cur": "IDR", "agent_name": "A.H. OTTO NOORDRAVEN", "docId": "14221101", "spaj_no": "1615156", "bill_freq": "12", "prusaver_amount": "800000", "time_quotation": "150659", "ben_bill_date": "", "agent_code": "1307", "prusaver_desc": "PRUsaver", "payment_plan": "", "pol_no": "90167025", "premi_berkala": "1200000", "total_coi": "", "tgl_quotation": "15022019", "owner": { "occp": "", "jabatan": "", "name": "", "usaha": "", "instansi": "" }, "ver": "v1.6.9", "premi_yearly": "", "total_premi": "2000000", "ttd_owner": "", "investasi": [{ "fund": "", "percent": "" }], "ttd_agent": "", "prusaver_code": "U1CR", "lifeAss": [{ "income": "", "role": "01", "next_bday": "32", "smoking_status": "N", "occp_class": "3", "jabatan": "", "sex": "F", "batang_rokok": "", "occp": "STDN", "component": [{ "product_desc": "PRUlink syariah generasi baru", "cover_age": "99", "product_code": "U11R", "coi": "100000", "sum_ass": "500000000", "unit_prumed": "" }, { "product_desc": "PRUmed cover syariah", "cover_age": "65", "product_code": "H1WR", "coi": "100000", "sum_ass": "240000", "unit_prumed": "" }], "client_no": "60017196", "dob": "20160210", "new_client": "N", "name": "GAZAH", "usaha": "", "instansi": "" }, { "income": "", "role": "02", "next_bday": "26", "smoking_status": "", "occp_class": "", "jabatan": "", "sex": "", "batang_rokok": "", "occp": "", "component": [{ "product_desc": "PRUparent payor syariah 33", "cover_age": "23", "product_code": "W113", "coi": "100000", "sum_ass": "3000000", "unit_prumed": "" }], "client_no": "60017105", "dob": "", "new_client": "N", "name": "TIKUS", "usaha": "", "instansi": "" }, { "income": "", "role": "03", "next_bday": "32", "smoking_status": "", "occp_class": "", "jabatan": "", "sex": "", "batang_rokok": "", "occp": "", "component": [{ "product_desc": "PRUparent payor syariah 33", "cover_age": "23", "product_code": "W113", "coi": "100000", "sum_ass": "3000000", "unit_prumed": "" }], "client_no": "", "dob": "", "new_client": "Y", "name": "KAMPRED", "usaha": "", "instansi": "" }] }, "policy": { "tgl_pengajuan": "20190225", "type_pengajuan": "COM", "spaj_no": "1615156", "type_product": "K", "pol_no": "90167025" } }, "brmsverification": { "signature_flags": [{ "document_name": "SQS Alt", "id": "14221101" }, { "document_name": "Form Major Alteration", "id": "14220101" }, { "document_name": "Form Health Declaration", "id": "12010401" }], "eligible_auto_revival_flag": null, "documents": [{ "document_name": "SQS Alt", "data_completeness": "Not Complete", "document_checklist": "Complete", "id": "14221101" }, { "document_name": "Form Major Alteration", "data_completeness": "Not Complete", "document_checklist": "Complete", "id": "14220101" }, { "document_name": "Form Health Declaration", "data_completeness": "Not Complete", "document_checklist": "Complete", "id": "12010401" }, { "document_name": "ID KTP", "data_completeness": "", "document_checklist": "Complete", "id": "11010201" }], "receive_amendment": null, "sar_calculator": 1551869817399, "additional_new_client": [{ "role": "03", "clientNo": "", "documentName": "Life Assured" }] } } }
        // this.saveStorage(row);
        // this.phsHelperStorageService.saveStorageStringify(this.generalData, 'getBrmsDet');
        console.log('getBrmsDet', response);
        if (response.resultCode != "ERROR") {
          this.generalData = response;
          this.generalData.genId=row.genId;

          console.log("data bulk",Object.keys(this.generalData.jsonRequest.payload.quotation).length,this.generalData);

          if(Object.keys(this.generalData.jsonRequest.payload.quotation).length > 0 && this.generalData.jsonRequest.payload.quotation.lifeAss.length>0) {
            this.generalData.jsonRequest.payload.quotation.lifeAss.forEach(
              lifeAss => {
                lifeAss.component.forEach(
                  comp => 
                  {
                  
                    comp['model1'] = {
                      code: comp.product_code,
                      description: comp.product_code + " - " + comp.product_desc
                    };

                    comp['temp_model_plantype'] = {
                      code: comp.plan_pph,
                      description: ''
                    };


                  }
                )
              }
            )
          }

          if(Object.keys(this.generalData.jsonRequest.payload.hd).length > 0 && this.generalData.jsonRequest.payload.hd.lifeAss.length !== this.generalData.jsonRequest.payload.quotation.lifeAss.length) {
            let hdLifeAss = this.generalData.jsonRequest.payload.hd.lifeAss;
            let quotationLifeAss = this.generalData.jsonRequest.payload.quotation.lifeAss;
            let hdLifeAssLen = hdLifeAss.length;
            let quotationLifeAssLen = quotationLifeAss.length;
            let stdLifeAss = {
                              client_role: "",
                              data: [
                                {no: "01", answer: ""},
                                {no: "02", answer: ""},
                                {no: "03", answer: ""},
                                {no: "04", answer: ""},
                                {no: "05", answer: ""},
                                {no: "06", answer: ""},
                                {no: "07", answer: ""},
                                {no: "08", answer: ""},
                                {no: "09", answer: ""},
                                {no: "10", answer: ""},
                                {no: "11", answer: ""},
                                {no: "12", answer: ""},
                              ],
                              dob: "",
                              height: "",
                              jml_rokok: "",
                              model1: {code: "", description: ""},
                              temp_model_plantype:{code: "", description: ""},
                              occp: "",
                              weight: "",
                              isAdded: true
                            }
            console.log("MIXIN : ",hdLifeAssLen,quotationLifeAssLen)
            if( hdLifeAssLen < quotationLifeAssLen ) {
              quotationLifeAss.forEach( (lifeAss,index) => {
                if(!hdLifeAss[index]) {
                  hdLifeAss.push(stdLifeAss)
                  hdLifeAss[index].client_role = lifeAss.role
                }
              })
            }
          }

          console.log("data BULK",this.generalData);

          let documentId = response.jsonRequest.brmsverification.documents.filter(data => data.document_name == "Form Health Declaration")
          if (documentId.length) {
            this.phsHelperStorageService.saveStorageNoStringify(documentId[0].id, 'documentId')
          }         
          this.saveStorage(row);
          this.phsHelperStorageService.saveStorageStringify(this.generalData, 'getBrmsDet');
          this.phsHelperStorageService.saveStorageStringify(this.generalData, 'getBrmsDetFlag');
          this.navCtrl.setRoot(this.phsSupportProvider.goToDashboard(row.activityName),{});

        }
        else {
          this.showToast(response.resultDescription);
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
  }
}
