import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Content } from 'ionic-angular';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime';

@IonicPage({
  name: "phsworkbasketcutipremi",
  segment: "PHS/workbasket/cuti_premi/:id"
})
@Component({
  selector: 'page-phs-workbasket-cuti-premi',
  templateUrl: 'phs-workbasket-cuti-premi.html',
})
export class PhsWorkbasketCutiPremiPage {
  pdfSrc: string;
  @ViewChild(Content)
  content: Content;
  mime: string;
  isSticky: boolean = false;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private auth: UserProvider,
    private phsHelperDateTimeService: PhsHelperDateTimeService
    ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhsWorkbasketCutiPremiPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    } 
  }
  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }
}
