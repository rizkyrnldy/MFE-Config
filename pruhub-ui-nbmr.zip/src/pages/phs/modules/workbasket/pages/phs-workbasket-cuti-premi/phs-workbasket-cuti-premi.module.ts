import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketCutiPremiPage } from './phs-workbasket-cuti-premi';
import { ComponentsModule } from '../../../../../../components/components.module';

@NgModule({
  declarations: [
    PhsWorkbasketCutiPremiPage,    
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketCutiPremiPage),
    ComponentsModule
  ],
  exports: [  
  ]
})
export class PhsWorkbasketCutiPremiPageModule {}
