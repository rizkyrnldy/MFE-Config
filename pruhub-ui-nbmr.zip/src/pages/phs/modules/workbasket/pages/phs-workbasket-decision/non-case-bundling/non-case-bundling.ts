import { Component, Input } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { NavController, NavParams } from 'ionic-angular';
import { DecisionProvider } from '../../../../../../../providers/phs/workbasket/decision';
import { PhsHelperStorageService } from '../../../../../../../providers/phs/phshelper/phshelperstorage'
import { Storage } from '@ionic/storage';
import { phsMagnumProvider } from '../../../../../../../providers/phs/workbasket/phsmagnum';
import { PhsSupportProvider } from '../../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../../providers/phs/phshelper/phsToast';
import { PhsHelperDateTimeService } from '../../../../../../../providers/phs/phshelper/phshelperdatetime';
import { debounceTime, delay } from 'rxjs/operators';
import { IonicSelectableComponent } from 'ionic-selectable';
import { Subscription, Observable } from 'rxjs';
import { alterationFollowUpProvider } from '../../../../../../../providers/phs/workbasket/alterationFollowUp';
import { phsAlertService } from '../../../../../../../providers/phs/phshelper/phsAlert';

const WAIT_FOR = 'Wait For';
const SIZE = 99;

@Component({
  selector: 'non-case-bundling',
  templateUrl: 'non-case-bundling.html',
})
export class NonCaseBundlingComponent {

  @Input() role: any;
  @Input() createdDate: any;
  @Input() username: any;
  @Input() activityName: any;
  getBpmDecision: any = [];
  roleDistributionData: any = [];
  roleDistributionList: any = [];
  subDecisionData: any = [];
  reasonDecline: any = [];
  additionalDecisionFlag: any = [];
  arrayLimit: number = 0;
  searchBar: string;
  decisionForm: FormGroup;
  decisionQuery: string = '';
  page: number = 0;
  roleDistributionSubscription: Subscription;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public storage: Storage,
    public magnumProvider: phsMagnumProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    public decisionProvider: DecisionProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsToastService: phsToastService,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    private phsAlertService: phsAlertService
  ) {
    this.decisionForm = new FormGroup({
      selectedDecision: new FormControl('', [Validators.required]),
      queryDecision: new FormControl('', []),
      role: new FormControl('', []),
      dateToWait: new FormControl('', []),
      queryReasonDecline: new FormControl('', []),
    })
    this.decisionForm.valueChanges.debounceTime(300).subscribe(value => {
      if (this.additionalDecisionFlag.length > 0) {
        const decisionsFlag = this.additionalDecisionFlag.map(item => item.decision);
        const rolesFlag = this.additionalDecisionFlag.map(item => item.role);
        if (rolesFlag.indexOf(this.role) > -1 && decisionsFlag.indexOf(value.selectedDecision) > -1) {
          this.decisionForm.addControl('fupcode', new FormControl('', [Validators.required]));
          this.decisionForm.addControl('fupremarks', new FormControl('', [Validators.required]));
          this.decisionForm.addControl('fupstatus', new FormControl('', [Validators.required]));
          this.decisionForm.addControl('mainlifeassno', new FormControl('', [Validators.required]));
        } else {
          if (this.decisionForm.get('fupcode')) {
            this.decisionForm.removeControl('fupcode');
            this.decisionForm.removeControl('fupremarks');
            this.decisionForm.removeControl('fupstatus');
            this.decisionForm.removeControl('mainlifeassno');
          }
        }
      }
    })
    setTimeout(() => {
      this.getInitial();
      this.getSubDecision();
      this.getMasterDataReasonDecline();
      this.getAdditionalDecisionFlag();
    }, 500);
  }


  getMasterDataReasonDecline() {
    this.decisionProvider.getMasterDataReasonDecline(this.role)
      .mergeMap(res => res).subscribe(({ data }) => {
        this.reasonDecline = data;
      })
  }

  getAdditionalDecisionFlag() {
    this.decisionProvider.getCheckDecision(this.role)
      .mergeMap(res => res).subscribe(({ data }) => {
        this.additionalDecisionFlag = data;
      })
  }

  getSubDecision() {
    this.decisionProvider.getSubDecision()
      .mergeMap(res => res).subscribe(({ data }) => {
        this.subDecisionData = data;
      });
  }

  async selectReasonDecline(data) {
    this.searchBar = '';
    this.setFormValue('fupcode', data.follow_up_code);
    this.setFormValue('fupremarks', data.remarks_follow_up);
    this.setFormValue('fupstatus', 'I');
    this.getClientRole();
  }

  async getClientRole() {
    const chdrnum = await this.phsHelperStorageService.getStorageNoStringify("policyNumber")
    this.alterationFollowUpProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum })
      .mergeMap(res => res)
      .subscribe((response: any) => {
        if (!response.error) {
          const data = response.find(item => item.life === "01" && item.clrrrole === "LF");
          this.setFormValue('mainlifeassno', data.clntnum);
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
  }

  selectRole({ decision_desc }) {
    this.searchBar = '';
    this.setFormValue('selectedDecision', decision_desc);
    const role = this.subDecisionData.reduce((acc, current) => {
      if (current.decision == decision_desc) {
        acc = current.role
      }
      return acc
    }, '');
    this.setFormValue('role', role);
    this.updateFormField('referTo', role);
    if (role) {
      this.onSearchRoleDistributionData(role)
    }
    const isRequiredDateToWait = decision_desc === WAIT_FOR;
    this.updateFormField('dateToWait', isRequiredDateToWait);
  }

  updateFormField(fieldName, isRequired) {
    if (isRequired) {
      this.decisionForm.addControl(fieldName, new FormControl('', Validators.required));
    } else {
      this.decisionForm.removeControl(fieldName);
    }
    this.decisionForm.updateValueAndValidity();
  }

  onSearchRoleDistributionData(value) {
    this.roleDistributionList = [];
    this.decisionProvider.getRoleDistribution(value)
      .pipe(debounceTime(2000))
      .subscribe(response => {
        response.subscribe(({ data }) => {
          this.roleDistributionData = data;
          this.arrayLimit = 0;
          this.roleDistributionList = data.slice(this.arrayLimit, SIZE);
        });
      })
  }

  filterRoleDistribution(roleDistributions, text) {
    return roleDistributions.filter(data => {
      return data.role_distribution.toLowerCase().indexOf(text.toLowerCase()) !== -1;
    });
  }

  searchRoleDistribution(event: {
    component: IonicSelectableComponent,
    text: string
  }) {
    let text = event.text.trim().toLowerCase();
    event.component.startSearch();

    // Close any running subscription.
    if (this.roleDistributionSubscription) {
      this.roleDistributionSubscription.unsubscribe();
    }

    if (!text) {
      // Close any running subscription.
      if (this.roleDistributionSubscription) {
        this.roleDistributionSubscription.unsubscribe();
      }

      event.component.items = this.getRoleDistribution(1, SIZE);

      // Enable and start infinite scroll from the beginning.
      this.page = 2;
      event.component.endSearch();
      event.component.enableInfiniteScroll();
      return;
    }

    this.roleDistributionSubscription = this.getRoleDistributionAsync().subscribe(ports => {
      // Subscription will be closed when unsubscribed manually.
      if (this.roleDistributionSubscription.closed) {
        return;
      }
      const data = this.filterRoleDistribution(ports, text);
      event.component.items = data;
      event.component.endSearch();
    });
  }

  getMoreRoleDistribution(event: {
    component: IonicSelectableComponent,
    text: string
  }) {
    let text = (event.text || '').trim().toLowerCase();

    // There're no more ports - disable infinite scroll.
    if (event.component.items.length === this.roleDistributionData.length) {
      event.component.disableInfiniteScroll();
      return;
    }

    this.getRoleDistributionAsync(this.page, SIZE).subscribe(data => {
      data = event.component.items.concat(data);
      if (text) {
        data = this.filterRoleDistribution(data, text);
      }
      event.component.items = data;
      event.component.endInfiniteScroll();
      this.page++;
    });
  }

  getRoleDistribution(page?: number, size?: number): any[] {
    let data = [];
    if (page && size) {
      data = this.roleDistributionData.slice((page - 1) * size, ((page - 1) * size) + size);
    } else {
      data = this.roleDistributionData.slice();
    }
    return data;
  }

  getRoleDistributionAsync(page?: number, size?: number, timeout = 2000): Observable<any[]> {
    return new Observable<any[]>(observer => {
      observer.next(this.getRoleDistribution(page, size));
      observer.complete();
    }).pipe(delay(timeout));
  }

  changeRoleDistribution({ value }) {
    if (value.role_distribution) {
      this.decisionForm.patchValue({ referTo: `Refer to ${value.role_distribution}` });
    }
  }

  setFormValue(key, value) {
    this.decisionForm.patchValue({ [key]: value }, { emitEvent: false });
    this.decisionForm.updateValueAndValidity();
  }

  async getInitial() {
    this.decisionProvider.getBpmDecision({ role_name: this.role, activity: this.activityName })
      .mergeMap(res => res).subscribe((response: any) => {
        if (response.result != false) {
          this.getBpmDecision = response;
        }
      }, err => {
        this.showToast(err);
      })
  }

  async confirm() {
    if (this.decisionForm.valid) {
      const alert = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data?');
      if (alert) {
        this.PROCESS();
      }
    }
  }

  async PROCESS() {
    this.phsSupportProvider.loadingCount()
    const { selectedDecision } = this.decisionForm.getRawValue();
    const genId = await this.phsHelperStorageService.getStorageNoStringify('genId')
    const data = {
      genId,
      activity: this.activityName,
      username: this.username,
      role: this.role,
      decision: selectedDecision,
    }
    this.decisionProvider.checkAuth(data).mergeMap(res => res)
      .subscribe((res: any) => {
        if (res.decisionValidation) {
          this.postData();
        } else {
          this.showToast('Cannot take this decision because ' + res.result);
          this.phsSupportProvider.dismissLoading();
        }
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
  }


  async postData() {
    const { selectedDecision, referTo, dateToWait, fupcode, fupremarks, fupstatus, mainlifeassno } = this.decisionForm.getRawValue();
    let NeedMagnum: any
    NeedMagnum = await this.phsHelperStorageService.getStorageNoStringify('needMagnum')
    let convertData: any = await this.phsSupportProvider.convertData();
    if (convertData) {
      if (NeedMagnum) {
        let _body: any = await this.phsSupportProvider.bodyBoostrap();
        this.storage.get('Authorization').then((Authorization) => {
          this.magnumProvider.submitBootstrapData(_body, Authorization).subscribe((result) => {

          })
        })
      }

      // let items: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
      let items: any = convertData;
      let _dateToWait = new Date();
      if (dateToWait) {
        _dateToWait = new Date(dateToWait.toString().replace("T", " ").replace("Z", ""));
      }
      let _dateToWaitStr = ("0" + _dateToWait.getDate()).slice(-2) + '-' + ("0" + (_dateToWait.getMonth() + 1)).slice(-2) + '-' + _dateToWait.getFullYear() + ' ' + _dateToWait.getHours() + ':00';
      let data = {
        department: "PHS",
        bpmId: await this.phsHelperStorageService.getStorageNoStringify('bpmId'),
        taskId: await this.phsHelperStorageService.getStorageNoStringify('taskId'),
        username: this.username,
        request: [
          {
            data: referTo || selectedDecision,
            datetime: (selectedDecision.toLowerCase() === 'wait for' ? _dateToWaitStr : ''),
            name: "bpmDecision",
            followUp: [
              {
                fupcode, fupremarks, fupstatus, mainlifeassno
              }
            ]
          },
          {
            data: {
              policyNumber: items.jsonRequest.payload.policy.pol_no,
              spajNumber: items.jsonRequest.payload.policy.spaj_no
            },
            name: "worklistData"
          }
        ],
        jsonRequest: items.jsonRequest
      }

      this.decisionProvider.saveData(data)
        .mergeMap(res => res)
        .subscribe((response: any) => {
          if (response.result === false) {
            this.phsSupportProvider.dismissLoading();
            this.showToast(response.resultDescription);
          } else {
            this.phsSupportProvider.dismissLoading();
            this.showToast("Submit Decision Successful");
            this.navCtrl.setRoot('phsworkbasketlist', {})
          }
        }, err => {
          this.showToast(err);
          this.phsSupportProvider.dismissLoading();
        })
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }

}
