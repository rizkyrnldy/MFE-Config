import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketDecisionPage } from './phs-workbasket-decision';
import { IonicSelectableModule } from 'ionic-selectable';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { NonCaseBundlingComponent } from './non-case-bundling/non-case-bundling';
import { CaseBundlingComponent } from './case-bundling/case-bundling';
@NgModule({
  declarations: [
    NonCaseBundlingComponent,
    CaseBundlingComponent,
    PhsWorkbasketDecisionPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketDecisionPage),
    IonicSelectableModule,
    PipesModule,
  ],
})
export class PhsWorkbasketDecisionPageModule {}
