import { Component, Input } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { Storage } from '@ionic/storage';
import { DecisionProvider } from '../../../../../../../providers/phs/workbasket/decision';
import { PhsSupportProvider } from '../../../../../../../providers/phs/phshelper/phsSupport';
import { PhsHelperStorageService } from '../../../../../../../providers/phs/phshelper/phshelperstorage';
import { phsMagnumProvider } from '../../../../../../../providers/phs/workbasket/phsmagnum';
import { phsToastService } from '../../../../../../../providers/phs/phshelper/phsToast';
import { alterationFollowUpProvider } from '../../../../../../../providers/phs/workbasket/alterationFollowUp';
import { debounceTime, delay } from 'rxjs/operators';
import { IonicSelectableComponent } from 'ionic-selectable';
import { Subscription, Observable } from 'rxjs';

const WAIT_FOR = 'Wait For';
const SIZE = 99;

@Component({
  selector: 'case-bundling',
  templateUrl: 'case-bundling.html',
})
export class CaseBundlingComponent {
  @Input() data: Array<any> = [];
  @Input() role: any;
  @Input() createdDate: any;
  @Input() username: any;
  @Input() activityName: any;
  @Input() cutiFlag: any;
  majorDecisionList: Array<any> = [];
  revivalDecisionList: Array<any> = [];
  cutiDecisionList: Array<any> = [];
  roleDistributionList: any = [];
  roleDistributionData: any = [];
  form: FormGroup;
  getBpmDecision: any = [];
  reasonDeclineList: any = [];
  mainLifeAsNo: any;
  hiddenCutiFlagBtn: boolean=true;
  hiddenMajorFlagBtn: boolean=true;
  hiddenRevivalFlagBtn:boolean=true;
  hideRefer: boolean=true;
  page: number = 0;
  arrayLimit: number = 0; 
  searchBar: string;
  subDecisionData: any = [];
  decisionForm: FormGroup;

  constructor(
    public storage: Storage,
    public navCtrl: NavController, 
    public navParams: NavParams,
    public formBuilder: FormBuilder,
    public magnumProvider: phsMagnumProvider,
    public decisionProvider: DecisionProvider,
    private phsToastService: phsToastService,
    private phsSupportProvider: PhsSupportProvider,
    private phsHelperStorageService: PhsHelperStorageService,
    public alterationFollowUpProvider: alterationFollowUpProvider
    ) {
      this.decisionForm = new FormGroup({
        role: new FormControl('', [])
      })

      setTimeout(() => {
        if(this.data) {
          if(this.cutiFlag === 'Y' || this.cutiFlag==='y'){
            this.hiddenCutiFlagBtn=false;
          }

          this.initialize();
          this.getSubDecision();
          this.getClientNoAsMainLife();
          this.getMasterDataReasonDecline();
        }
      }, 500);

      
  }

  initialize() {
    console.log("this.data");
    console.log(this.data);
    const majorExist=this.data.find(item=>item.transactionType=='Major');
    const revivalExist=this.data.find(item=>item.transactionType=='Revival');
    let formBuilderGonnaBe: any={
      major: '',
      revival:'',
      cuti:'',
      finalDecision:''
    };
    if(majorExist){
      this.majorDecisionList = majorExist.decision;
      this.hiddenMajorFlagBtn=false;
      formBuilderGonnaBe.major= this.buildForm();
    }
    if(revivalExist){
      this.revivalDecisionList = revivalExist.decision;
      this.hiddenRevivalFlagBtn=false;
      formBuilderGonnaBe.revival= this.buildForm();
    }
    if(!this.hiddenCutiFlagBtn){
      this.cutiDecisionList = this.data.find(item=>item.transactionType=='StopPremi').decision;
      formBuilderGonnaBe.cuti= this.buildForm();
    }
      
    formBuilderGonnaBe.finalDecision= new FormControl('', [Validators.required]);

    this.form = this.formBuilder.group(formBuilderGonnaBe);
    
    this.form.valueChanges.debounceTime(300).subscribe(value=>{
      this.onFormValueChanges(value);
    });

  }

  async getClientNoAsMainLife() {
    let jsonR:any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    const { client_no } = jsonR.jsonRequest.payload.quotation.lifeAss[0];
    if(!client_no) {
      this.getClientRole();
    } else {
      this.mainLifeAsNo = client_no;
      this.setMainLifeAssNo()
    }
  }

  async getClientRole() {
    this.alterationFollowUpProvider.getClientRole({ objid: "PHRTVCLROL", chdrnum: await this.phsHelperStorageService.getStorageNoStringify("policyNumber") }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (!response.error) {
          this.mainLifeAsNo = response[0].clntnum;
          this.setMainLifeAssNo()
        }
        this.phsSupportProvider.dismissLoading()
      }, err => {
        this.phsToastService.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  setMainLifeAssNo() {
    if(!this.hiddenMajorFlagBtn){
      this.form.get('major').get('mainlifeassno').setValue(this.mainLifeAsNo);
    }
    if(!this.hiddenRevivalFlagBtn){
      this.form.get('revival').get('mainlifeassno').setValue(this.mainLifeAsNo);
    }
    if(!this.hiddenCutiFlagBtn){
      this.form.get('cuti').get('mainlifeassno').setValue(this.mainLifeAsNo);
    }
  }

  buildForm() {
    return new FormGroup({
      decision: new FormControl('', [Validators.required]),
      fupcode: new FormControl(''),
      fupremarks: new FormControl({value: '', disabled: true}, []),
      fupstatus: new FormControl(''),
      mainlifeassno: new FormControl(''),
    })
  }
  
  onFormValueChanges(value) {
    if(value.finalDecision == WAIT_FOR) {
      this.form.addControl('dateToWait', new FormControl('', [Validators.required]));
    } else if (value.finalDecision != WAIT_FOR) {
      this.form.removeControl('dateToWait');
    } 

    if(!this.hiddenMajorFlagBtn){
      if(value.major.decision == 'Decline' || value.major.decision == 'Refer to Declined') {
        console.log('masuk major refer to declined');
        this.form.get('major').get('fupcode').setValidators([Validators.required])
        this.form.get('major').get('fupremarks').setValidators([Validators.required])
      } else {
        this.form.get('major').get('fupcode').setValidators([]);
        this.form.get('major').get('fupremarks').setValidators([]);
        this.form.get('major').get('fupcode').setValue('');
        this.form.get('major').get('fupremarks').setValue('');
        this.form.get('major').get('fupstatus').setValue('');
      }
    }

    if(!this.hiddenRevivalFlagBtn){
      if(value.revival.decision == 'Decline' || value.revival.decision == 'Refer to Declined') {
        this.form.get('revival').get('fupcode').setValidators([Validators.required])
        this.form.get('revival').get('fupremarks').setValidators([Validators.required])
      } else {
        this.form.get('revival').get('fupcode').setValidators([]);
        this.form.get('revival').get('fupremarks').setValidators([]);
        this.form.get('revival').get('fupcode').setValue('');
        this.form.get('revival').get('fupremarks').setValue('');
        this.form.get('revival').get('fupstatus').setValue('');
      }
    }

    if(!this.hiddenCutiFlagBtn){
      if(value.cuti.decision == 'Decline' || value.cuti.decision == 'Refer to Declined') {
        this.form.get('cuti').get('fupcode').setValidators([Validators.required])
        this.form.get('cuti').get('fupremarks').setValidators([Validators.required])
      } else {
        this.form.get('cuti').get('fupcode').setValidators([]);
        this.form.get('cuti').get('fupremarks').setValidators([]);
        this.form.get('cuti').get('fupcode').setValue('');
        this.form.get('cuti').get('fupremarks').setValue('');
        this.form.get('cuti').get('fupstatus').setValue('');
      }
    }

    
  }

  getMasterDataReasonDecline() {
    this.decisionProvider.getMasterDataReasonDecline(this.role).subscribe(response=>{
      response.subscribe(({data})=>{
        this.reasonDeclineList = data;
      })
    })
  }

  onSelectDecision(type, value) {
    console.log("onselectDecision");
    this.form.get(type).get('decision').setValue(value.decision);

    if(value.auto_populate === 'Y') {
      if(!this.hiddenCutiFlagBtn){
        this.form.get('cuti').get('decision').setValue(value.decision);
      }
      if(!this.hiddenMajorFlagBtn){
        this.form.get('major').get('decision').setValue(value.decision);
      }
      if(!this.hiddenRevivalFlagBtn){
        this.form.get('revival').get('decision').setValue(value.decision);
      }
    }

    const { major, revival, cuti } = this.form.getRawValue();
    console.log({major, revival, cuti});

    const sendMajor=major.decision;
    const sendRevival=revival.decision;
    const sendCuti=cuti.decision

    if(!this.hiddenCutiFlagBtn && !this.hiddenMajorFlagBtn && !this.hiddenRevivalFlagBtn){
      this.getFinalDecision(sendMajor, sendRevival, sendCuti);
    }else{
      if(this.hiddenCutiFlagBtn){
        if( sendMajor && sendRevival) {
          this.getFinalDecision(sendMajor, sendRevival, '');
        }
      }
      if(this.hiddenMajorFlagBtn){
        if(sendRevival && sendCuti) {
          this.getFinalDecision('', sendRevival, sendCuti);
        }
      }
      if(this.hiddenRevivalFlagBtn){
        if( sendMajor && sendCuti) {
          this.getFinalDecision(sendMajor, '', sendCuti);
        }
      }
    }
    
    
  }

  onSelectReason(type, value) {
    this.form.get(type).get('fupremarks').setValue(value.remarks_follow_up);
    this.form.get(type).get('fupcode').setValue(value.follow_up_code);
    this.form.get(type).get('fupstatus').setValue('I');
  }

  getFinalDecision(major, revival, cuti) {
    this.phsSupportProvider.loadingCount();
    this.decisionProvider.getFinalDecisionForCaseBundling(major, revival, cuti)
    .subscribe(httpResponse=>{
      httpResponse.subscribe(response=>{
        this.phsSupportProvider.dismissLoading();
        this.phsToastService.showToast(response.message)
        this.form.get('finalDecision').setValue(response.data ? response.data.finalDecision : '');
        const decision_desc=response.data ? response.data.finalDecision : '';
        this.form.get('finalDecision');
        this.searchBar='';
        const role = this.subDecisionData.reduce((acc, current)=>{
          if (current.decision == decision_desc) {
            acc = current.role;
          }
          return acc
        }, '');
        
        this.setFormValue('role', role);
        this.updateFormField('referTo', role);
        if (role) {
          this.hideRefer=false;
          this.onSearchRoleDistributionData(role)
        }else{
          this.hideRefer=true;
        }
        const isRequiredDateToWait = decision_desc === WAIT_FOR;
        this.updateFormField('dateToWait', isRequiredDateToWait);
            
      }, error =>{ 
        this.phsSupportProvider.dismissLoading();
      })
    }, error => {
      this.phsSupportProvider.dismissLoading();
    })
  }


  async postData() {
    let { finalDecision, major, revival, cuti, dateToWait } = this.form.getRawValue();
    const { referTo } = this.decisionForm.getRawValue();
    console.log("save DAta CASE BUNDLING");
    console.log({ finalDecision, major, revival, cuti, dateToWait })
    let NeedMagnum: any;
    NeedMagnum = await this.phsHelperStorageService.getStorageNoStringify('needMagnum')
    let convertData: any = await this.phsSupportProvider.convertData();

    /**
    * Emptying major fupcode, fupremarks, fupstatus, mainlifeassno when reason to decline is same with revival
    */
    if(major.decision === 'Decline' && major.decision === revival.decision && major.fupcode === revival.fupcode) {
      major.fupcode = '';
      major.fupremarks = '';
      major.fupstatus = '';
      major.mainlifeassno = '';
    }
    
    if (convertData) {
      if (NeedMagnum) {
        let _body: any = await this.phsSupportProvider.bodyBoostrap();
        this.storage.get('Authorization').then((Authorization) => {
          this.magnumProvider.submitBootstrapData(_body, Authorization).subscribe((result) => {})
        })
      }
      
      let items: any = convertData;
      let _dateToWaitStr = "";
      if(dateToWait) {
        let _dateToWait = new Date(dateToWait.toString().replace("T"," ").replace("Z",""));
        _dateToWaitStr = ("0" + _dateToWait.getDate()).slice(-2) + '-' + ("0" + (_dateToWait.getMonth() + 1)).slice(-2) + '-' + _dateToWait.getFullYear() + ' ' + _dateToWait.getHours() + ':00';
      }

      let bundlingSend=[];
      if(!this.hiddenMajorFlagBtn){
        bundlingSend.push({
          type: "Major",
          ...major,
        });
      }

      if(!this.hiddenRevivalFlagBtn){
        bundlingSend.push({
          type: "Revival",
          ...revival
        });
      }

      if(!this.hiddenCutiFlagBtn){
        bundlingSend.push({
          type:"StopPremi",
          ...cuti
        });
      }

      let data = {
        department: "PHS",
        bpmId: await this.phsHelperStorageService.getStorageNoStringify('bpmId'),
        taskId: await this.phsHelperStorageService.getStorageNoStringify('taskId'),
        username: await this.storage.get('username'),
        request: [
          {
            data: referTo || finalDecision,
            datetime: _dateToWaitStr,
            name: "bpmDecision",
            Bundling: bundlingSend
          },
          {
            data: {
              policyNumber: items.jsonRequest.payload.policy.pol_no,
              spajNumber: items.jsonRequest.payload.policy.spaj_no
            },
            name: "worklistData"
          }
        ],
        jsonRequest: items.jsonRequest
      }

      // console.log("data to be save");
      // console.log(data);

      this.decisionProvider.saveData(data).subscribe(p1 => {
        p1.subscribe((response: any) => {
          if(response.result===false) {
            this.phsSupportProvider.dismissLoading();
            this.phsToastService.showToast(response.resultDescription);
          } else {
            this.phsSupportProvider.dismissLoading();
            this.phsToastService.showToast("Submit Decision Successful");
            this.navCtrl.setRoot('phsworkbasketlist', {})
          }
        }, err => {
          this.phsToastService.showToast(err);
          this.phsSupportProvider.dismissLoading();
        })
      })

    }
  }

  setFormValue(key, value) {
    this.decisionForm.patchValue({[key]: value}, {emitEvent: false});
    this.decisionForm.updateValueAndValidity();
  }

  updateFormField(fieldName, isRequired) {
    if (isRequired) {
      this.decisionForm.addControl(fieldName, new FormControl('', Validators.required));
    } else {
      this.decisionForm.removeControl(fieldName);
    }
    this.decisionForm.updateValueAndValidity();
  }

  getSubDecision() {
    this.decisionProvider.getSubDecision()
    .subscribe(response => {
      response.subscribe(({data}) => {
        this.subDecisionData = data;
      });
    })
  }

  onSearchRoleDistributionData(value) {
    this.roleDistributionList = [];
    this.decisionProvider.getRoleDistribution(value)
    .pipe(debounceTime(2000))
    .subscribe(response => {
      response.subscribe(({data}) => {
        this.roleDistributionData = data;
        this.arrayLimit = 0;
        this.roleDistributionList = data.slice(this.arrayLimit, SIZE);
      });
    })
  }

  getMoreRoleDistribution(event: {
    component: IonicSelectableComponent,
    text: string
  }) {
    let text = (event.text || '').trim().toLowerCase();

    // There're no more ports - disable infinite scroll.
    if (event.component.items.length === this.roleDistributionData.length) {
      event.component.disableInfiniteScroll();
      return;
    }

    this.getRoleDistributionAsync(this.page, SIZE).subscribe(dataR => {
      dataR = event.component.items.concat(dataR);
      if (text) {
        dataR = this.filterRoleDistribution(dataR, text);
      }
      event.component.items = dataR;
      event.component.endInfiniteScroll();
      this.page++;
    });
  }

  getRoleDistributionAsync(page?: number, size?: number, timeout = 2000): Observable<any[]> {
    return new Observable<any[]>(observer => {
      observer.next(this.getRoleDistribution(page, size));
      observer.complete();
    }).pipe(delay(timeout));
  }

  filterRoleDistribution(roleDistributions, text) {
    return roleDistributions.filter(dataR => {
      return dataR.role_distribution.toLowerCase().indexOf(text.toLowerCase()) !== -1;
    });
  }

  getRoleDistribution(page?: number, size?: number): any[] {
    let data = [];
    if (page && size) {
      data = this.roleDistributionData.slice((page - 1) * size, ((page - 1) * size) + size);
    } else {
      data = this.roleDistributionData.slice();
    }
    return data;
  }

  changeRoleDistribution({value}) {
    if (value.role_distribution) {
      this.decisionForm.patchValue({referTo: `Refer to ${value.role_distribution}`});
    }
  }
  
}