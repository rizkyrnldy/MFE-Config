import { Component } from '@angular/core';
import { IonicPage, NavController } from 'ionic-angular';
import { DecisionProvider } from '../../../../../../providers/phs/workbasket/decision';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { Storage } from '@ionic/storage';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';

@IonicPage({
  name: "phsworkbasketdecision",
  segment: "PHS/workbasket/decision"
})
@Component({
  selector: 'page-phs-workbasket-decision',
  templateUrl: 'phs-workbasket-decision.html',
})
export class PhsWorkbasketDecisionPage {

  isCaseBundling: boolean = false;
  data:Array<any> = [];
  ionTitle:any;
  role: any;
  createdDate: any;
  username: any;
  activityName: any;
  cutiFlag:any='';
  

  constructor(
    public navCtrl: NavController,
    public storage: Storage,
    public phsHelperStorageService: PhsHelperStorageService,
    public decisionProvider: DecisionProvider,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
  ) {
  }

  async ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.role = await this.phsHelperStorageService.getStorageNoStringify('role');
    this.createdDate = await this.phsHelperStorageService.getStorageNoStringify('createdDate');
    this.activityName = await this.phsHelperStorageService.getStorageNoStringify('activityName');
    this.username = await this.phsHelperStorageService.getStorageNoStringify('username');
    const brms:any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    if(brms.jsonRequest.payload.premiumHoliday){
      this.cutiFlag=brms.jsonRequest.payload.premiumHoliday.flag;
    }
    this.validateCaseBundling();
  }

  async backMenu() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page?');
    if (confirm) this.navCtrl.setRoot('phsworkbasketlist', {})
  }


  async validateCaseBundling() {
    this.phsSupportProvider.loadingCount();
    const transaction_code = await this.phsHelperStorageService.getStorageNoStringify('transType');
    const activity_name = await this.phsHelperStorageService.getStorageNoStringify('activityName');
    
    this.decisionProvider.validateCaseBundling(`${transaction_code||""}${this.cutiFlag||""}`, activity_name)
    .subscribe(http=>{
      http.subscribe(response=>{
          this.phsSupportProvider.dismissLoading();
          if(response.data) {
            this.data = response.data;
            this.isCaseBundling = true
          }
        }, error =>{
          console.log(error);
          this.phsSupportProvider.dismissLoading();
          this.phsToastService.showToast('Failed to fetch data');
      })
    })
  }


}
