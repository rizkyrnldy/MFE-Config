import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Content } from 'ionic-angular';
import { DetailDocumentProvider } from '../../../../../../providers/phs/workbasket/detailDocument.'
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';

export interface incomeData {
  id: string;
  description: string;
}

/**
 * Generated class for the PhsWorkbasketMajorPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@IonicPage({
  name: "phsworkbasketmajor",
  segment: "PHS/workbasket/major/:id"
})
@Component({
  selector: 'page-phs-workbasket-major',
  templateUrl: 'phs-workbasket-major.html',
})
export class PhsWorkbasketMajorPage {
  pdfSrc: string;
  // @ViewChild(StickyContainerComponent) stickyContainer: StickyContainerComponent;
  @ViewChild(Content)
  content: Content;
  currTop: number = 0;
  params: any;
  mime: string;
  formJobs: any;
  statusMerokok: any;
  paymentMethod: any;
  jobsMethod: any;
  payload: any;
  getMasterIncome: Object[]
  isSticky: boolean = false;
  buttonDeletePopup: boolean = false;
  ionTitle: any;
  dataAlter: any[];
  validation: any;
  imageDocument: string = "imageDocBRMS";
  documentFixed: string;
  linkImage: string;
  pesertaTertanggung: string = ""; 
  pesertaTertanggung1: string = ""; 
  pesertaTertanggung2: string = ""; 
  pemegangPolis: string = "";

  occupationList: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    // private events: Events,
    public phsHelperStorageService: PhsHelperStorageService,
    private detailDocumentProvider: DetailDocumentProvider,
    private phsHelperDateTimeService: PhsHelperDateTimeService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
  ) {
    // this.pdfSrc = "Assets/pdf/c4611_sample_explain.pdf";   
    this.statusMerokok = [{ statusMerokok: null, status: null, default: true }]
    this.formJobs = [
      {
        id: null,
        nameFrom: null,
        pekerjaanAtasNama: null,
        pekerjaanBaru: null,
        deskripsiJobs: null,
        default: true
      }
    ]
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) this.navCtrl.setRoot(this.navParams.get('dataSub') ? 'phsworkbasketsubmittedform' : 'phsworkbasketdetail', {})
  }

  searchOccupation(event) {
    this.detailDocumentProvider.mdengine({ md_name: "occupation", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.jobsMethod = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }


  getInitial() {
    this.detailDocumentProvider.getMasterMethodOfPay().subscribe(p1 => {
      p1.subscribe((response: any) => {
        console.log("Response", response)
        this.paymentMethod = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    // this.detailDocumentProvider.getMasterOccupation().subscribe(p1 => {
    //   p1.subscribe((response: any) => {
    //     console.log("Response", response)
    //     this.jobsMethod = response
    //     this.phsSupportProvider.dismissLoading();
    //   }, err => {
    //     this.showToast(err);
    //     this.phsSupportProvider.dismissLoading();
    //   })
    // })

    this.detailDocumentProvider.getMasterSourceOfIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        console.log("Response", response)
        // this.sourceIncome = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.detailDocumentProvider.getMasterIncome().subscribe(p1 => {
      p1.subscribe((response: any) => { 
        console.log("INCOME",response)
        this.getMasterIncome = response
        this.getMasterIncome.sort((a:incomeData,b:incomeData)=>{return (parseInt(a.id)-parseInt(b.id))})
        console.log("this.getMasterIncome", this.getMasterIncome)
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  onPageScroll(event) {
    console.log("page scroll", this.isSticky, event.scrollTop)
    if (!this.isSticky && event.scrollTop > 200) {
      this.isSticky = true
      console.log("sticky true", this.isSticky)
    } else if (this.isSticky && event.scrollTop < 200) {
      this.isSticky = false
      console.log("sticky false", this.isSticky)
    }
    // this.stickyContainer.setSticky(event)
    // this.currTop = event.scrollTop
    // console.log("SCROLL", this.currTop, event.scrollTop)
    // Send event to Native
    // this.events.publish('changePosition',{ top: event.scrollTop })
  }

  addPerokok() {
    this.payload.major.alter.push({
      occp: "",
      ns_to_s: "",
      s_to_ns: "",
      job_desc: "",
      jml_batang: "",
      client_role: "",
      hobby: "",
    });
    // this.buttonDeletePopup = !this.buttonDeletePopup;
  }

  async deletePerokok(i, data) {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure delete this data ?');
    if (confirm) this.payload.major.alter.splice(i, 1);
    console.log(i);
    console.log("data", data)
  }

  // addFormJob() {
  //   this.payload.major.alter.push({
  //     occp: "",
  //     ns_to_s: "",
  //     s_to_ns: "",
  //     job_desc: "",
  //     jml_batang: "",
  //     client_role: "",
  //     hobby: "",     
  //   });
  // }

  deleteForm(i) {
    this.formJobs.splice(i, 1);
  }
  ngAfterViewInit() {
    // this.content.onScrollElementTransitionEnd(this.onPageScroll);
  }

  getImage() {
    this.detailDocumentProvider.getContentCMByItemId({
      "genId": this.params.genId,
      "docId": this.params.docId
    }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.pdfSrc = 'data:' + response.mime + ';base64,' + response.byteDoc;
        this.linkImage = 'getfile/' + this.params.genId + '/' + this.params.docId;
        this.mime = response.mime;
        setTimeout(() => {
          this.documentFixed = "document-fixed"
          this.phsSupportProvider.dismissLoading();
        }, 100);
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
      this.phsSupportProvider.dismissLoading();
    }, err => {
      this.showToast(err);
      this.phsSupportProvider.dismissLoading();
    })
  }

  switchRole(role) {
    switch (role) {
      case 1:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
        ];
        break;
      case 2:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
          {
            id: '02', description: "02 - Additional Life Assured  1"
          }
        ];
        break;
      case 3:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
          {
            id: '02', description: "02 - Additional Life Assured  1"
          },
          {
            id: '03', description: "03 - Additional Life Assured  2"
          }
        ];
        break;
      case 4:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
          {
            id: '02', description: "02 - Additional Life Assured  1"
          },
          {
            id: '03', description: "03 - Additional Life Assured  2"
          },
          {
            id: '04', description: "04 - Additional Life Assured  3"
          }
        ];
        break;
      case 5:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
          {
            id: '02', description: "02 - Additional Life Assured  1"
          },
          {
            id: '03', description: "03 - Additional Life Assured  2"
          },
          {
            id: '04', description: "04 - Additional Life Assured  3"
          },
          {
            id: '05', description: "05 - Additional Life Assured  4"
          }
        ];
        break;
      default:
        this.dataAlter = [
          {
            id: '01', description: "01 - Main Life Assured"
          },
          {
            id: '02', description: "02 - Additional Life Assured  1"
          },
          {
            id: '03', description: "03 - Additional Life Assured  2"
          },
          {
            id: '04', description: "04 - Additional Life Assured  3"
          },
          {
            id: '05', description: "05 - Additional Life Assured  4"
          }
        ];
    }
  }

  checkrole() {
    let role
    this.payload.quotation.lifeAss.forEach(element => {
      if (!isNaN(element.role)) {
        role = !role ? parseInt(element.role) : role
        if (role < parseInt(element.role)) {
          role = parseInt(element.role);
        }
      }
    });
    if (role) { this.switchRole(role) }
  }

  async getStorage() {
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet')
    console.log("jsonR", jsonR)
    this.payload = jsonR.jsonRequest.payload;
    this.payload.major.client.forEach(async element => {
      if (element.role) {
        switch (element.role) {
          case 'OW':
            this.pemegangPolis = element.name
            break
          case "01":
            this.pesertaTertanggung = element.name
            break
          case '02':
            this.pesertaTertanggung1 = element.name
            break
          case '03':
            this.pesertaTertanggung2 = element.name
            break
        }
      }
    })
    console.log("CASE ",this.payload.major.alter)
    this.payload.major.alter.forEach(async element => {
      element.model1 = await this.checkName('occupation', element.occp);
    })    
    this.checkrole();
    this.params =
      {
        genId: await this.phsHelperStorageService.getStorageNoStringify('genId'),
        docId: this.navParams.get('docId')
      }
    console.log("new Date(this.payload.major.tgl_quotation)", new Date(this.payload.major.tgl_quotation))
    this.payload.major.tgl_quotation = this.payload.major.tgl_quotation.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.payload.major.tgl_quotation) : this.payload.major.tgl_quotation;
    this.payload.policy.tgl_pengajuan = this.payload.policy.tgl_pengajuan.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.payload.policy.tgl_pengajuan) : this.payload.policy.tgl_pengajuan;
    this.payload.major.time_quotation = this.payload.major.time_quotation.length == 6 ? await this.phsHelperDateTimeService.toFormatTime_v1(this.payload.major.time_quotation) : this.payload.major.time_quotation;
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.getImage();
  }

  // addAtasNama(client_role){
  //   this.dataAlter.forEach((element,index) => {
  //     if (element.id == client_role)
  //     {
  //       this.dataAlter.splice(index,1) 
  //     }
  //   });
  // }

  ionViewDidLoad() {
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
      this.getInitial();
      this.getStorage();
    })
  }

  goToPage(link: string, param: object) {
    this.navCtrl.setRoot(link, param)
  }

  async confirm() {

    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) this.saveData();
  }

  async saveData() {
    this.validation = await this.phsSupportProvider.checkDataEmpty({ pol_no: this.payload.policy.pol_no, pemegangPolis: this.pemegangPolis, pesertaTertanggung: this.pesertaTertanggung, pesertaTertanggung1: this.pesertaTertanggung1, pesertaTertanggung2: this.pesertaTertanggung2 })
    if (this.validation) {
      let client = []
      if (this.pemegangPolis) { client.push({ name: this.pemegangPolis, role: 'OW' }) }
      if (this.pesertaTertanggung) { client.push({ name: this.pesertaTertanggung, role: '01' }) }
      if (this.pesertaTertanggung1) { client.push({ name: this.pesertaTertanggung1, role: '02' }) }
      if (this.pesertaTertanggung2) { client.push({ name: this.pesertaTertanggung2, role: '03' }) }
      this.payload.major.client = client
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      // this.payload.major.tgl_quotation = await this.phsHelperDateTimeService.resetDateFormat(this.payload.major.tgl_quotation,"-")
      console.log("Data Local : ",jsonR.jsonRequest.payload)
      console.log("Data Payload : ",this.payload)
      jsonR.jsonRequest.payload = this.payload;      
      let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
      if (result) {
        this.showToast("Save Successful");
        this.navCtrl.setRoot('phsworkbasketdetail', {})
      }
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  checkName(name, code) {
    return new Promise((resolve) => {
      let result = ""
      if (code) {
        this.detailDocumentProvider.mdengine({ md_name: name, search: code }).subscribe(p1 => {
          p1.subscribe((response: any) => {
            if (response.data.length) {
              result = response.data[0]
              resolve(result)
            }
            else {
              resolve(result)
            }
            this.phsSupportProvider.dismissLoading();
          }, err => {
            this.showToast(err);
            this.phsSupportProvider.dismissLoading();
          })
        })
      }
      else {
        resolve(result)
      }
    })
  }
  
  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }
}

