import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { PhsWorkbasketMajorPage } from './phs-workbasket-major';
// import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { IonicSelectableModule } from 'ionic-selectable';

@NgModule({
  declarations: [
    PhsWorkbasketMajorPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketMajorPage),
    IonicModule,
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    IonicSelectableModule
  ],
  exports: [
    
  ],
})
export class PhsWorkbasketMajorPageModule {}
