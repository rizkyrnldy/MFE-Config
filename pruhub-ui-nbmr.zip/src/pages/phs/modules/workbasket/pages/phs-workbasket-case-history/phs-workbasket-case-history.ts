import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { caseSheetProvider } from '../../../../../../providers/phs/workbasket/caseSheet';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
/**
 * Generated class for the PhsWorkbasketCaseHistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketcasehistory",
  segment: "PHS/workbasket/case_history/:id"
})
@Component({
  selector: 'page-phs-workbasket-case-history',
  templateUrl: 'phs-workbasket-case-history.html',
})
export class PhsWorkbasketCaseHistoryPage {
  ionTitle: any;
  dataCaseSheet: any = []
  start: number = 0
  end: number = 10
  activePage: number = 1;
  totalPage: number = 1;
  constructor(public navCtrl: NavController,
    private phsSupportProvider: PhsSupportProvider,
    public caseSheetProvider: caseSheetProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    public navParams: NavParams,
    private auth: UserProvider,
    private phsToastService: phsToastService
  ) {
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }


  async getInitial() {
    this.caseSheetProvider.getcasehistory({ genId: await this.phsHelperStorageService.getStorageNoStringify('genId') }).subscribe(p1 => {
      // this.caseSheetProvider.getcasehistory({ genId: 'PHS_201903131846301' }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (response) {          
          this.dataCaseSheet = response;
          this.totalPage = Math.ceil(response.length / 10)
          console.log("this.totalPage", this.totalPage)
          this.phsSupportProvider.dismissLoading()
        }
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading()
      })
    })
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  filterData(page) {
    console.log("page", page)
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  ionViewDidLoad() {
    this.getStorage()
    this.getInitial()
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }
}


