import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketCaseHistoryPage } from './phs-workbasket-case-history';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { ComponentsModule } from '../../../../../../components/components.module';
@NgModule({
  declarations: [
    PhsWorkbasketCaseHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketCaseHistoryPage),
    PhsDirectivesModule,
    ComponentsModule
  ],
})
export class PhsWorkbasketCaseHistoryPageModule {}
