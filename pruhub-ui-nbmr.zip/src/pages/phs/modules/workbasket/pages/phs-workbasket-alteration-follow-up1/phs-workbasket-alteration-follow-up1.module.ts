import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAlterationFollowUp1Page } from './phs-workbasket-alteration-follow-up1';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
import { ComponentsModule } from '../../../../../../components/components.module';
@NgModule({
  declarations: [
    PhsWorkbasketAlterationFollowUp1Page,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAlterationFollowUp1Page),
    PhsDirectivesModule,
    ComponentsModule,
    PipesModule
  ],
})
export class PhsWorkbasketAlterationFollowUp1PageModule {}
