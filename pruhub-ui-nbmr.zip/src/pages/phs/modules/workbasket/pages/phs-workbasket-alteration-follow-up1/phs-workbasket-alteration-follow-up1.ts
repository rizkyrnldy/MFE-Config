import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { alterationFollowUpProvider } from '../../../../../../providers/phs/workbasket/alterationFollowUp';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
/**
 * Generated class for the PhsWorkbasketAlterationFollowUp1Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketalterationfollowup1",
  segment: "PHS/workbasket/alteration_followup1/:id"
})
@Component({
  selector: 'page-phs-workbasket-alteration-follow-up1',
  templateUrl: 'phs-workbasket-alteration-follow-up1.html',
})
export class PhsWorkbasketAlterationFollowUp1Page {
  ionTitle: any;
  dataAlteration: any;
  activePage: number = 1;
  TotalPage: number = 1
  start: number = 0
  end: number = 10
  dataFollowUp: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public alterationFollowUpProvider: alterationFollowUpProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private auth: UserProvider,
    private phsSupportProvider: PhsSupportProvider,
  ) {
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
  }

  async getInitial() {
    this.dataFollowUp = this.navParams.get('dataFollowUp')
    if (this.dataFollowUp.zaltnum) {
      this.alterationFollowUpProvider.phrtvaltfu({
        objid: "PHRTVALTFU",
        chdrnum: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        zaltnum: this.dataFollowUp.zaltnum
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.dataAlteration = JSON.parse(response.message);
          let totalpage: any = []
          this.dataAlteration.flupInfo.forEach(element => {
            if (element.fupcde) {
              totalpage.push(element)
            }
          });
          this.TotalPage = Math.ceil(totalpage.length / 10)
          this.phsSupportProvider.dismissLoading()
        }, err => {
        this.showToast(err);
          this.phsSupportProvider.dismissLoading()
        })
      })
    }    
  }

  async deleteData(data) {
    let result = await this.phsAlertService.ConfirmAlert('Are you sure delete this data ?');
    if (result) {
      this.alterationFollowUpProvider.phrtvaltfl({
        OBJID: "PHUPDALTFL",
        CHDRSEL: await this.phsHelperStorageService.getStorageNoStringify('policyNumber'),
        ZALTNUMSEL: this.dataFollowUp.zaltnum,
        ZALTSTASEL: this.dataFollowUp.zaltstat,
        ZALTTYPSEL: this.dataFollowUp.zalttype,
        FUPCDE1: data.fupcde,
        FUPNO1: data.fupno,
        FUPSTS1: data.fupsts,
        DELFLAG1: 'Y',
        YNFLAG: ''
      }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.showToast("Delete Item");
          this.getInitial();
          this.phsSupportProvider.dismissLoading()
        }, err => {
        this.showToast(err);
          this.phsSupportProvider.dismissLoading()
        })
      })
      console.log(data)
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    } 
    this.getStorage();
    this.getInitial();
   this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result){
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    }) 
  }

  filterData(page) {
    console.log("page", page)
    this.start = page == 1 ? 0 : 10 * (page - 1);
    this.end = page == 1 ? 10 : 10 * page;
    this.activePage = page;
  }

  getPageNumber(action) {
    this.filterData(parseInt(action));
  }

}
