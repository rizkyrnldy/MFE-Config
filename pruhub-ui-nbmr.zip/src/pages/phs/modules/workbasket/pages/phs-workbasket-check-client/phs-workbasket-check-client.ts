import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ModalProvider } from '../../../../../../providers/phs/modal/modal';
import { ModalClientSearchPage } from '../phs-workbasket-modal/modal-client-search/modal-client-search';
import { CheckClientProvider } from '../../../../../../providers/phs/workbasket/checkclient';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage'
import { PhsHelperDateTimeService } from '../../../../../../providers/phs/phshelper/phshelperdatetime'
import { filter } from 'rxjs/operators';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
/**
 * Generated class for the PhsWorkbasketCheckClientPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketcheckclient",
  segment: "PHS/workbasket/check_client/:id"
})
@Component({
  selector: 'page-phs-workbasket-check-client',
  templateUrl: 'phs-workbasket-check-client.html',
})
export class PhsWorkbasketCheckClientPage {

  public gender: any;
  public salutation: any;
  public meried: any;
  public Mgender: any;
  public Msalutation: any;
  public Mmeried: any;
  dataRight: any;
  dataLeft: any;
  params: any;
  ionTitle: any;
  getMasterSex: Object[]
  getMasterCountry: Object[]
  getMasterMaritalStatus: Object[]
  datamasterreasoninsurance: Object[]
  getMasterSourceOfIncome: Object[]
  getMasterIncome: Object[]
  getMasterCountryCodes: Object[]
  getMasterSalutation: Object[]
  getMasterOccupation: Object[]
  getMasterProvince: Object[]
  disabled: string
  home_phone: any = { country_phone: "", number: "", type: "Home" }; office_phone: any = { country_phone: "", number: "", type: "Office" }; mobile_phone1: any = { country_phone: "", number: "", type: "GSM1" }; mobile_phone2: any = { country_phone: "", number: "", type: "GSM2" }; cdma: any = { country_phone: "", number: "", type: "CDMA" };
  titleClient: any;
  validation: any;
  model1: {};
  model: {};
  modelOCcupation: {};
  constructor(
    private phsSupportProvider: PhsSupportProvider,
    public navCtrl: NavController,
    public navParams: NavParams,
    private modalCtrl: ModalProvider,
    private checkclientProvider: CheckClientProvider,
    public phsHelperStorageService: PhsHelperStorageService,
    public phsHelperDateTimeService: PhsHelperDateTimeService,
    private phsAlertService: phsAlertService,
    private phsToastService: phsToastService,
    private auth: UserProvider
  ) {

  }

  searchModal() {
    // this.showModal = true;
    let modalInstance = this.modalCtrl.Modal(ModalClientSearchPage, {});
    modalInstance.onDidDismiss(data => {
      if (data) {
        this.dataLeft.client_no = data
        this.getBoneNewClient(data)
      }
    })
  }

  async getBoneNewClient(data) {
    if (data) {
      this.checkclientProvider.getBoneNewClient({ clntnum: data }).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.dataRight = response;
          console.log("SAR Response", this.dataRight)
          this.phsSupportProvider.dismissLoading();
        }, err => {
          this.showToast(err);
          this.phsSupportProvider.dismissLoading();
        })
      })
    }
  }

  async getStorage() {
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle')
    let dataNav = this.navParams.get('data')
    let roleClient = dataNav.documentName === 'Payor' ? '' : dataNav.role;
    this.titleClient = dataNav.documentName + ' ' + roleClient
    this.params =
      {
        getBrmsDet: await this.phsHelperStorageService.getStorageStringify('getBrmsDet'),
        genId: await this.phsHelperStorageService.getStorageNoStringify('genId'),
      }
    if (dataNav.documentName == "Payor") {
      this.dataLeft = this.params.getBrmsDet.jsonRequest.payload.payor
      this.dataLeft.salutation = this.dataLeft.sex ? this.dataLeft.sex === 'M' ? 'BAPAK' : 'IBU' : ''
      console.log("this.1", this.dataLeft)
      this.modelOCcupation = await this.checkName('occupation', this.dataLeft.occp);
      this.model = await this.checkName('country', this.dataLeft.natlty);
      this.dataLeft.address.forEach(async element => {
        element.model1 = await this.checkName('country', element.country);
      })
      console.log("this.2", this.dataLeft)
    }
    else {
      this.params.getBrmsDet.jsonRequest.payload.client.lifeAss.forEach(async element => {
        if (element.role == dataNav.role) {
          this.dataLeft = element
          this.dataLeft.salutation = this.dataLeft.sex ? this.dataLeft.sex === 'M' ? 'BAPAK' : 'IBU' : ''
          console.log("this.dataLeft.salutation", this.dataLeft.salutation)
          this.modelOCcupation = await this.checkName('occupation', this.dataLeft.occp);
          this.model = await this.checkName('country', this.dataLeft.natlty);
          this.dataLeft.address.forEach(async element => {
            element.model1 = await this.checkName('country', element.country);
          })
        }
      });
    }
    this.dataLeft.dob = this.dataLeft.dob.length == 8 ? await this.phsHelperDateTimeService.toFormatDate_v2(this.dataLeft.dob) : this.dataLeft.dob;
    this.dataLeft.phone.forEach(element => {
      if (element.type) {
        switch (element.type) {
          case 'Home':
            this.home_phone = element
            break
          case 'Office':
            this.office_phone = element
            break
          case 'GSM1':
            this.mobile_phone1 = element
            break
          case 'GSM2':
            this.mobile_phone2 = element
            break
          case 'CDMA':
            this.cdma = element
            break
        }
      }
    })
    console.log("hey jug")
    this.getBoneNewClient(this.dataLeft.client_no);
    this.getInitial()
  }

  getInitial() {
    this.checkclientProvider.getMasterSex().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSex = response;
        this.phsSupportProvider.dismissLoading();
      })
    }, err => {
      this.showToast(err);
      this.phsSupportProvider.dismissLoading();
    })

    this.checkclientProvider.datamasterreasoninsurance().subscribe(p1 => {
      p1.subscribe((response: any) => {
        if (this.dataLeft.buy_ins) {
          if (this.dataLeft.buy_ins.length) {
            // response.forEach(elementRes => {
            //   this.dataLeft.buy_ins.forEach(elementStorage => {
            //     if (elementRes.id == elementStorage.id) {
            //       elementRes.isChecked = true
            //     }
            //   });
            // });
            // this.dataLeft.buy_ins = response
          } else { this.dataLeft.buy_ins = response }
        } else { this.dataLeft.buy_ins = response }
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterSourceOfIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.filterSource_Income(response);
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterIncome().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterIncome = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterMaritalStatus().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterMaritalStatus = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterCountryCodes().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountryCodes = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterSalutation().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterSalutation = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })

    this.checkclientProvider.getMasterProvince().subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterProvince = response;
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  searchOccupation(event) {
    this.checkclientProvider.mdengine({ md_name: "occupation", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterOccupation = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  searchCountry(event) {
    this.checkclientProvider.mdengine({ md_name: "country", search: event.text }).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.getMasterCountry = response.data
        this.phsSupportProvider.dismissLoading();
      }, err => {
        this.showToast(err);
        this.phsSupportProvider.dismissLoading();
      })
    })
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
    this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result) {
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    })
    this.getStorage();
  }

  filterReasonInsurance() {
    return new Promise((resolve) => {
      let arraySelected = []
      this.dataLeft.buy_ins.forEach((element, key) => {
        if (element.isChecked) { delete element.isChecked; arraySelected.push(element) }
      });
      resolve(arraySelected)
    })
  }

  filterSource(response) {
    return new Promise((resolve) => {
      response.forEach(elementRes => {
        this.dataLeft.income.forEach(elementStorage => {
          if (elementRes.id == elementStorage.source) {
            elementRes.isChecked = true
          }
        });
      });
      resolve(response)
    })
  }

  async filterSource_Income(response) {
    let amount = this.dataLeft.income.length ? this.dataLeft.income[0].amount : this.dataLeft.income.amount
    let source = this.dataLeft.income.length ? await this.filterSource(response) : this.dataLeft.income.source
    this.dataLeft.income = {
      amount: amount,
      source: source
    }
  }

  ionViewDidLoad() {
    // this.startMaster();
    // this.getBoneNewClient();
  }

  async confirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to save this data ?');
    if (confirm) this.saveData();
  }

  async saveData() {
    this.validation = await this.phsSupportProvider.checkDataEmpty({ name: this.dataLeft.name, sex: this.dataLeft.sex, salutation: this.dataLeft.salutation, marital_status: this.dataLeft.marital_status })
    if (this.validation) {
      let phone = []
      if (this.home_phone.country_phone && this.home_phone.number) { phone.push(this.home_phone) }
      if (this.office_phone.country_phone && this.office_phone.number) { phone.push(this.office_phone) }
      if (this.mobile_phone1.country_phone && this.mobile_phone1.number) { phone.push(this.mobile_phone1) }
      if (this.mobile_phone2.country_phone && this.mobile_phone2.number) { phone.push(this.mobile_phone2) }
      if (this.cdma.country_phone && this.cdma.number) { phone.push(this.cdma) }
      this.dataLeft.phone = phone;
      // this.dataLeft.buy_ins = await this.filterReasonInsurance()
      if (this.navParams.get('data').documentName == "Payor") {
        this.params.getBrmsDet.jsonRequest.payload.payor = this.dataLeft
      }
      else {
        this.params.getBrmsDet.jsonRequest.payload.client.lifeAss.forEach((element, key) => {
          if (element.role == this.navParams.get('data').role) {
            this.params.getBrmsDet.jsonRequest.payload.client.lifeAss[key] = this.dataLeft
          }
        });
      }
      let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
      jsonR.jsonRequest.payload = this.params.getBrmsDet.jsonRequest.payload;
      let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
      if (result) {
        this.showToast("Save Successful");
        this.navCtrl.setRoot('phsworkbasketdetail', {})
      }
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  async showConfirm() {
    let confirm = await this.phsAlertService.ConfirmAlert('Are you sure want to leave this page? <br> Unsaved data will be lose after you leave this page');
    if (confirm) this.navCtrl.setRoot('phsworkbasketdetail', {});
  }

  checkName(name, code) {
    return new Promise((resolve) => {
      let result = ""
      if (code) {
        this.checkclientProvider.mdengine({ md_name: name, search: code }).subscribe(p1 => {
          p1.subscribe((response: any) => {
            if (response.data.length) {
              result = response.data[0]
              resolve(result)
            }
            else {
              resolve(result)
            }
            this.phsSupportProvider.dismissLoading();
          }, err => {
            this.showToast(err);
            this.phsSupportProvider.dismissLoading();
          })
        })
      }
      else {
        resolve(result)
      }
    })
  }

  get maxDate() {
    return this.phsHelperDateTimeService.getMaxDate();
  }
  
}
