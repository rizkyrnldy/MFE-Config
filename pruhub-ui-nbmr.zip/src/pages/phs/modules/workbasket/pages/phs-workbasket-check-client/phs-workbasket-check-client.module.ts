import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketCheckClientPage } from './phs-workbasket-check-client';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { PipesModule } from '../../../../../../pipes/pipes.module';
// import { ExpandableComponent } from '../../../../../../components/shared/expandable/expandable';
import { IonicSelectableModule } from 'ionic-selectable';

@NgModule({
  declarations: [
    PhsWorkbasketCheckClientPage
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketCheckClientPage),
    ComponentsModule,
    PhsDirectivesModule,
    PipesModule,
    IonicSelectableModule
  ],
  exports: [
    
  ]
})
export class PhsWorkbasketCheckClientPageModule {}
