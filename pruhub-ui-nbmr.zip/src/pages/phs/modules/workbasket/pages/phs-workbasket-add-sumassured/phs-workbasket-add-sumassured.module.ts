import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhsWorkbasketAddSumAssuredPage } from './phs-workbasket-add-sumassured';
import { ComponentsModule } from '../../../../../../components/components.module';
import { PhsDirectivesModule } from '../../../../../../directives/phs/phs.directives.module';
import { IonicSelectableModule } from 'ionic-selectable';

@NgModule({
  declarations: [
    PhsWorkbasketAddSumAssuredPage,
  ],
  imports: [
    IonicPageModule.forChild(PhsWorkbasketAddSumAssuredPage),
    ComponentsModule,
    IonicSelectableModule,
    PhsDirectivesModule
  ],
})
export class PhsWorkbasketAddSumAssuredPageModule {}
