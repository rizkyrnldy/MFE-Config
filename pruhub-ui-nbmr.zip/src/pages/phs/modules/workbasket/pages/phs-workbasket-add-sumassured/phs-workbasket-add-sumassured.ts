import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { phsAlertService } from '../../../../../../providers/phs/phshelper/phsAlert';
import { UserProvider } from './../../../../../../providers/providers';
import { PhsHelperStorageService } from '../../../../../../providers/phs/phshelper/phshelperstorage';
import { ProcessOutputProvider } from '../../../../../../providers/phs/workbasket/processOutput';
import { phsToastService } from '../../../../../../providers/phs/phshelper/phsToast';
import { PhsSupportProvider } from '../../../../../../providers/phs/phshelper/phsSupport';
import { PhsMasterDataProvider } from '../../../../../../providers/phs-master-data/phs-master-data';
import { Storage } from '@ionic/storage';

/**
 * Generated class for the PhsWorkbasketAddSumAssuredPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage({
  name: "phsworkbasketaddsumassured",
  segment: "PHS/workbasket/add-sumassured/:id"
})
@Component({
  selector: 'page-phs-workbasket-add-sumassured',
  templateUrl: 'phs-workbasket-add-sumassured.html',
})
export class PhsWorkbasketAddSumAssuredPage {
  summAdd: any;
  ionTitle: any;
  prosses: any;
  index: any;
  quotation: any;
  role: any;
  reasons: Array<any>;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private phsAlertService: phsAlertService,
    public phsHelperStorageService: PhsHelperStorageService,
    private ProcessOutputProvider : ProcessOutputProvider,
    private phsToastService: phsToastService,
    private auth: UserProvider,
    private phsMasterData: PhsMasterDataProvider,
    private phsSupportProvider: PhsSupportProvider,
    private storage: Storage,
    ) {
    this.summAdd = {
      subStandarCode: '',
      load: '',
      rateAdjust: '',
    }
    this.reasons = [];
  }

  async revalidate(){
    this.phsAlertService.ConfirmAlert('Are you sure want to revalidate this data ?');
  }

  async getData(){
    this.ionTitle = await this.phsHelperStorageService.getStorageNoStringify('ionTitle');
    this.summAdd = this.navParams.get('addSum');
    this.index = this.navParams.get('index');
    this.role = this.navParams.get('role');
    this.prosses = this.navParams.get('prosses');
    this.getReasonDataOptions();
  }

  getReasonDataOptions() {
    this.storage.get('Authorization').then((auth)=>{
      this.phsMasterData.getReasonCode(auth).subscribe(({data})=>{
      if(data) {
        this.reasons = data.map(item=>{
          item.label = `${item.reason_code} - ${item.reason_description}`;
          return item;
        })
        this.summAdd.reason = this.reasons.filter(item=>item.reason_code==this.summAdd.reason)[0];
      }
    });
    });
  }

  async saveData(){
    let jsonR: any = await this.phsHelperStorageService.getStorageStringify('getBrmsDet');
    jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index].product_code = this.summAdd.product_code;
    jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index].reason = this.summAdd.reason.reason_code;
    jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index].load = this.summAdd.load;
    jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index].rate_adj = this.summAdd.rate_adj;

    jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index].plan_pph = this.summAdd.plan_pph;

    console.log(jsonR.jsonRequest.payload.quotation.lifeAss[this.role].component[this.index], 'addSum')
    // this.payload.quotation.time_quotation = await this.phsHelperDateTimeService.toFormatTimeSaved(this.payload.quotation.time_quotation)
    let result = await this.phsHelperStorageService.saveStorageStringify(jsonR, 'getBrmsDet')
    if (result) {
      this.showToast("Add Sum Assured Successful");
      this.navCtrl.setRoot('phsworkbasketprocessoutput', {})
    }
  }

  showToast(text) {
    this.phsToastService.showToast(text);
  }

  ionViewDidLoad() {
    this.getData();
    console.log('ionViewDidLoad PhsWorkbasketAddSumAssuredPage');
  }

  ionViewWillEnter() {
    if (!this.auth.loggedIn()) {
      this.auth.logout();
      this.navCtrl.setRoot('LoginPage');
    }
   this.phsHelperStorageService.getStorageNoStringify('ionTitle').then((result) => {
      if (!result){
        this.navCtrl.setRoot('phsworkbasketbacktoworkbasket');
      }
    }) 
  }
}
