export const NewTask = {
    "jsonRequest": "",
    "request": [
      {
        "data": "59464",
        "name": "trackId"
      },
      {
        "data": "",
        "name": "bpmDecision"
      },
      {
        "data": {},
        "name": "worklistData"
      }
    ],
    "password": "",
    "username": "",
    "taskId": "",
    "bpmId": ""
  }