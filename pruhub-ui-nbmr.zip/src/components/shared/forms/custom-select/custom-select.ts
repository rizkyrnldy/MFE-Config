import { Component, Input } from '@angular/core';

/**
 * Generated class for the CustomSelectComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'custom-select',
  templateUrl: 'custom-select.html'
})
export class CustomSelectComponent {

  text: string;
  @Input("eventEmit") onEvent:Function;
  @Input("customAttr") attribute: any;

  constructor() {
    console.log("Attribute", this.attribute)
  }

  triggerEvent(event) {
    this.onEvent(event)
  }

}
