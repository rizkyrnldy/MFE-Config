import { Component, Input, ViewChild, ElementRef, Renderer } from '@angular/core';

@Component({
  selector: 'expandable',
  templateUrl: 'phs-expandable.html'
})
export class ExpandableComponent {

    @ViewChild('expandWrapper', {read: ElementRef}) expandWrapper;
    @Input('expanded') expanded;
    @Input('accordionTitle') accordionTitle;

    el_Height: number;
    elInit: boolean = true;

    constructor(public renderer: Renderer) {
      
    }

    ngAfterViewChecked() {
      // this.elInit = false;
    }

    ngAfterViewInit(){
      this.el_Height = this.expandWrapper.nativeElement.offsetHeight; 
      this.renderer.setElementStyle(this.expandWrapper.nativeElement, 'height', "auto"); 
    }

    expandItem() {
      // console.log("GGG") 
      this.expanded = !this.expanded;
      this.elInit = true;
    }

}