import { Component, Input, Output, EventEmitter } from '@angular/core';

/**
 * Generated class for the PaginationComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */

@Component({
  selector: 'pagination',
  templateUrl: 'phs-pagination.html'
})
export class PaginationComponent {

  @Input() currentPage:string;
  @Input() totalPage:string;
  @Output() changePage = new EventEmitter<string>();
  numbers: Object[];
  currentNumber: number;
  totalNumber: number;

  constructor() {
  }

  ngOnInit() {
    this.updatePages()
    console.log('Hello PaginationComponent Component',this.currentNumber,this.totalNumber);
  }

  ngOnChanges() {
    this.updatePages()
    console.log('CHANGE',this.currentNumber,this.totalNumber);
  }

  updatePages() {
    this.currentNumber = parseInt(this.currentPage);
    this.totalNumber = parseInt(this.totalPage);
    this.numbers = Array(this.totalNumber).fill(0).map((x,i)=>i);
  }

  actionPage(action){
    let setPage = 0;
    switch(action) {
      case 'first':
        setPage = 1
        break;
      case 'prev':
        setPage = parseInt(this.currentPage)-1;
        break;
      case 'next':
        setPage = parseInt(this.currentPage)+1;
        break;
      case 'last':
        setPage = this.totalNumber
        break;
      default:
        setPage = action
        break;
    }
    this.currentPage = setPage.toString();
    this.changePage.next(setPage.toString())
  } 

}