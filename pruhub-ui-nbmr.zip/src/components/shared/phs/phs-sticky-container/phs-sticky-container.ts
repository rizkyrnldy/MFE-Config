import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, HostListener, Input } from '@angular/core';
import { Events } from 'ionic-angular';
import { Observer, Observable } from 'rxjs';

/**
 * Generated class for the StickyContainerComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'sticky-container',
  templateUrl: 'phs-sticky-container.html'
})
export class StickyContainerComponent {

  @ViewChild('stickyMenu', { read: ElementRef }) menuElement: ElementRef;

  @Input('isSticky') isSticky:boolean;
  sticky: boolean = false;
  elementPosition: any;
  currTop:number = 5;

  constructor(private events: Events) { 
    
  }

  // onRenderChannge(){
  //   return this.currTop;
  // }

  // addTop() {
  //   this.currTop += 50;
  //   console.log(this.currTop );
  // 

  updateTopPosition() {
    this.sticky = this.isSticky
    console.log("INNER",this.sticky,this.isSticky)
  }

  ngOnChanges() {
    console.log("CHANGE",this.isSticky)
    this.updateTopPosition()
  }

  ngOnInit() {

    this.updateTopPosition()
 
    // var that = this;
    // this.events.subscribe('changePosition', (event)=>{
     
    //   that.addTop();

    //   /*setTimeout(function(){
       
    //     that.currTop = event.top
    //     console.log("DATA",that.currTop);
    //   },2000);*/

    // })
  }

  // ngAfterViewInit(){
  //   this.elementPosition = this.menuElement.nativeElement.offsetTop; 
  //   // this.currTop = this.elementPosition;
  //   console.log("Element Pos : ", this.elementPosition) 
  // }

  // setSticky(event) {
  //   const windowScroll = event.scrollTop;
  //   if(windowScroll >= this.elementPosition){
  //     // this.isSticky = true;
  //     this.currTop = windowScroll
  //   } else if(windowScroll <= this.elementPosition) {
  //     // this.isSticky = false;
  //     this.currTop = this.elementPosition
  //   }
  //   console.log("SCROLL",this.currTop)
  // }

  // @HostListener('document:scroll', ['$event'])
  //   handleScroll(){
  //     const windowScroll = window.pageYOffset;
  //     console.log("SCROLL",windowScroll)
  //     if(windowScroll >= this.elementPosition){
  //       this.sticky = true;
  //     } else {
  //       this.sticky = false;
  //     }
  //   }

}
