import { Component, Input, SimpleChanges } from '@angular/core';
import * as $ from "jquery"
import { URLServices } from '../../../../providers/url-services';
import { PhsSupportProvider } from '../../../../providers/phs/phshelper/phsSupport';
declare var require: any
/**
 * Generated class for the DocumentViewerComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'document-viewer',
  templateUrl: 'phs-document-viewer.html'
})
export class DocumentViewerComponent {

  @Input('pdfSrc') phsPdfSrc: string;
  @Input('isShowAllPage') phsIsShowAllPage: boolean = false;
  @Input('mime') phsMime: string;
  @Input('class') phsClass: string;
  @Input('linkImage') phsLinkImage: string;
  currentZoom: number = 1;
  currentDeg: number = 0;
  transformOrigin: any = '0% 0% 0px'
  ImageModif: Object;
  loading: boolean;
  constructor(private urlService: URLServices, private phsSupportProvider: PhsSupportProvider) {
    console.log('Hello DocumentViewerComponent Component');
    console.log(this.phsMime, "this.phsMime")
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      if (changes.phsMime) {
        // this.phsSupportProvider.loadingCount();        
        this.loading = true
        this.tiffData()
      }
    }
  }

  tiffData() {
    if (this.phsMime) {
      var Tiff = require('tiff.js');
      var xhr = new XMLHttpRequest();
      xhr.open('GET', this.urlService.apiPHS + '/pruhub-phs-masterdata-engine/' + this.phsLinkImage);
      xhr.responseType = 'arraybuffer';
      xhr.onload = function (e) {
        var buffer = xhr.response;
        var tiff = new Tiff({ buffer: buffer });
        for (var i = 0, len = tiff.countDirectory(); i < len; ++i) {
          tiff.setDirectory(i);
          var canvas = tiff.toCanvas();
          $('.image').append(canvas);
        }
      };
      setTimeout(() => {
        this.loading = false
      }, 3000)
      xhr.send();
    }
    else {
      setTimeout(() => {
        this.loading = false
      }, 3000)
    }
  }

  async zoom(act) {
    if (this.phsMime == 'application/pdf') {
      switch (act) {
        case "in":
          (this.currentZoom <= 10 ? this.currentZoom += 0.2 : this.currentZoom = 10)
          break;
        case "out":
          (this.currentZoom <= 1 ? this.currentZoom = 1 : this.currentZoom -= 0.2)
          break;
      }
      console.log("ZOOM", this.currentZoom)
    }
    else {
      if (act == 'in') {
        this.currentZoom + 0.1 <= 2 ? this.currentZoom += 0.1 : this.currentZoom;
        this.transformOrigin = await this.checkTranformOrigin(this.currentDeg)
        if (this.phsMime != 'image/tiff') {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ') rotate(' + this.currentDeg + 'deg)',
            '-ms-transform': 'rotate(' + this.currentDeg + 'deg)', /* IE 9 */
            '-webkit-transform': 'rotate(' + this.currentDeg + 'deg)', /* Safari 3-8 */
            'transform-origin': this.transformOrigin
          }
        }
        else {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ')'          
          }
        }
      }
      else if (act == 'out') {
        this.currentZoom - 0.1 > 0 ? this.currentZoom -= 0.1 : this.currentZoom;
        this.transformOrigin = await this.checkTranformOrigin(this.currentDeg)
        if (this.phsMime != 'image/tiff') {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ') rotate(' + this.currentDeg + 'deg)',
            '-ms-transform': 'rotate(' + this.currentDeg + 'deg)', /* IE 9 */
            '-webkit-transform': 'rotate(' + this.currentDeg + 'deg)', /* Safari 3-8 */
            'transform-origin': this.transformOrigin
          }
        }
        else {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ')'          
          }
        }
      }
    }
    console.log("this.ImageModif", this.ImageModif)
  }

  async  rotate(act) {
    if (this.phsMime == 'application/pdf') {
      switch (act) {
        case "right":
          (this.currentDeg < 270 ? this.currentDeg += 90 : this.currentDeg = 0)
          break;
        case "left":
          (this.currentDeg <= 0 ? this.currentDeg = 270 : this.currentDeg -= 90)
          break;
      }
      console.log("ROTATE", this.currentDeg)
    }
    else {
      if (act == "right") {
        this.currentDeg = this.currentDeg + 90 > 360 ? 90 : this.currentDeg + 90
        this.transformOrigin = await this.checkTranformOrigin(this.currentDeg)
        if (this.phsMime != 'image/tiff') {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ') rotate(' + this.currentDeg + 'deg)',
            '-ms-transform': 'rotate(' + this.currentDeg + 'deg)', /* IE 9 */
            '-webkit-transform': 'rotate(' + this.currentDeg + 'deg)', /* Safari 3-8 */
            'transform-origin': this.transformOrigin
          }
        }
        else {
          $("canvas").css({ 'transform': 'rotate(' + this.currentDeg + 'deg)' });
        }
      }
      else if (act == "left") {
        this.currentDeg = this.currentDeg - 90 < 0 ? 270 : this.currentDeg - 90
        this.transformOrigin = await this.checkTranformOrigin(this.currentDeg)
        if (this.phsMime != 'image/tiff') {
          this.ImageModif = {
            'transform': 'scale(' + this.currentZoom + ') rotate(' + this.currentDeg + 'deg)',
            '-ms-transform': 'rotate(' + this.currentDeg + 'deg)', /* IE 9 */
            '-webkit-transform': 'rotate(' + this.currentDeg + 'deg)', /* Safari 3-8 */
            'transform-origin': this.transformOrigin
          }
        }
        else {
          $("canvas").css({ 'transform': 'rotate(' + this.currentDeg + 'deg)' });
        }
      }
    }
    console.log("this.ImageModif", this.ImageModif)
  }

  checkTranformOrigin(currentDeg) {
    return new Promise((resolve) => {
      let result
      if (currentDeg == 0) {
        result = '0% 0% 0px'
      }
      else if (currentDeg == 90) { result = 'center' }
      else if (currentDeg == 180) { result = '50% 60% 0px' }
      else if (currentDeg == 270) { result = 'center' }
      else { result = '0% 0% 0px' }

      resolve(result)
    })
  }

  leftAction() {
    console.log(this.phsClass, "this.phsClass")
    if (this.phsClass == 'image-left') {
      $(".image-left .block").animate({ "left": "-=50px" }, "fast");
    }
    else if (this.phsClass == 'image-right') {
      $(".image-right .block").animate({ "left": "-=50px" }, "fast");
    }
    else {
      $(".block").animate({ "left": "-=50px" }, "fast");
    }
    console.log($(".block"))
  }

  rightAction() {
    console.log(this.phsClass, "this.phsClass")
    if (this.phsClass == 'image-left') {
      $(".image-left .block").animate({ "left": "+=50px" }, "fast");
    }
    else if (this.phsClass == 'image-right') {
      $(".image-right .block").animate({ "left": "+=50px" }, "fast");
    }
    else {
      $(".block").animate({ "left": "+=50px" }, "fast");
    }
    console.log($(".block"))
  }

  upAction() {
    console.log(this.phsClass, "this.phsClass")
    if (this.phsClass == 'image-left') {
      $(".image-left .block").animate({ "top": "-=50px" }, "fast");
    }
    else if (this.phsClass == 'image-right') {
      $(".image-right .block").animate({ "top": "-=50px" }, "fast");
    }
    else {
      $(".block").animate({ "top": "-=50px" }, "fast");
    }
    console.log($(".block"))
  }

  downAction() {
    console.log(this.phsClass, "this.phsClass")
    if (this.phsClass == 'image-left') {
      $(".image-left .block").animate({ "top": "+=50px" }, "fast");
    }
    else if (this.phsClass == 'image-right') {
      console.log("we call")
      $(".image-right .block").animate({ "top": "+=50px" }, "fast");
    }
    else {
      $(".block").animate({ "top": "+=50px" }, "fast");
    }
    console.log($(".block"))
  }
}

