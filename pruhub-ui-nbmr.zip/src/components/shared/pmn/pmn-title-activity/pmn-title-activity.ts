import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { UserProvider, PmnProvider, MainMenuProvider } from '../../../../providers/providers';
import { PmnPayloadHelperProvider } from '../../../../providers/pmn/pmnPayLoadHelper';
import { PmnToastService } from '../../../../providers/pmn/pmnToast';
import { Storage } from '@ionic/storage';
import { MyApp } from '../../../../app/app.component'


/**
* Generated class for the PaginationComponent component.
*
* See https://angular.io/api/core/Component for more info on Angular
* Components.
*/

@Component({
  selector: 'pmnTitleActivity',
  templateUrl: 'pmn-title-activity.html'
})
export class PmnTitleActivityComponent {

  username: string;

  @Input() additionalText: any;
  titleTab: string;
  refdata: any;
  isAdmission: boolean = false;
  isOutpatient: boolean = false;
  isHNWI: boolean = false;
  activity: any = [
    'PMN Exception Bomb',
    'PMN Log Assesser',
    'PMN Case Monitoring',
    'PMN Discharge',
    'PMN Investigator',
    'PMN Internal Doctor',
    'PMN Top Up Log',
    'PMN PRE LOG',
    'PMN GOP REOPEN',
    'PMN OUTPATIENT',
    'GOP JET VERIFIER'];
  showModal: boolean = false;
  showModalTimer: any;
  isDialogActive = '0';

  constructor(public navCtrl: NavController,
    public navParams: NavParams, public pmnProvider: PmnProvider,
    public pmnPayLoadHelper: PmnPayloadHelperProvider,
    private pmnToastService: PmnToastService,
    public auth: UserProvider,
    public storage: Storage,
    public alertCtrl: AlertController,
    public myApp: MyApp) {
    storage.get('username').then((val) => {
      this.username = val;
    }
    );
  }

  dialog(param) {
    (async () => {
      const alert = await this.alertCtrl.create({
        enableBackdropDismiss: false,
        title: 'Notification',
        message: param,
        buttons: [
          {
            text: 'OK',
            handler: () => {
              this.navCtrl.setRoot("PmnWorkbasketPage");
          }}
        ]
      })
      await alert.present();
    })()
	}
  @HostListener('window:storage', ['$event'])
  onStorageChange(event: StorageEvent) {
    if (event.key == "pmnActiveTab" && this.isDialogActive == '0') { this.isDialogActive = '1'; this.dialog("System detects new claim activity in another tab on the same browser, page will be redirected back to workbasket by system to avoid data error"); }
  }

  ngOnInit() {
    console.log('Hello PmnTitleActivityComponent Component');
  }

  ngOnChanges() {
    this.getData();
  }

  getData() {
    this.pmnPayLoadHelper.getPmnCurrentActivity().then((item: any) => {
      this.refdata = item;
      if (this.activity.indexOf(item.activity) >= 0) {
        this.isAdmission = true;
      }

      if (item.priority == "1") {
        this.isHNWI = true;
      }
      this.getTitleCurrentActivity(item);
    })
    this.onPageScroll(true);
  }

  goToPage() {
    if (this.isAdmission) {
      this.navCtrl.setRoot("PmnWorkbasketPage", { data: { currentActivity: this.refdata, additionalData: { decision: '' } } }).catch(function (e) {
        console.log(e);
      });
    }
    else {
      this.navCtrl.setRoot("PmnSettlementWorkbasketPage").catch(function (e) {
        console.log(e);
      });
    }
  }

  async ngOnDestroy() {
    if (!this.auth.loggedIn()) {
      this.logout();
    }
    this.onPageScroll(false);
  }

  getTitleCurrentActivity(body) {
    if (this.isAdmission) {
      this.titleTab = this.additionalText + body.roleDistribution + " : " + body.policyNo + " : " + body.priorApprovalNo + " : " + body.lifeAssuredName;
    }
    else {
      this.titleTab = body.roleDistribution + " : " + body.invoiceNo + " : " + body.invoiceId;
    }
  }

  @HostListener('document:mousewheel', ['$event'])
  @HostListener('window:click', ['$event'])
  scroll = (event): void => {
    this.onPageScroll(true);
  };

  onPageScroll(e) {
    let time = 1800 * 1000;
    this.showModal = true;
    clearTimeout(this.showModalTimer);
    this.showModalTimer = setTimeout(() => {
      if (e) {
        this.confirmationModal();
      }
    }, time);
  }

  confirmationModal() {
    let condition = true;
    this.showModal = false;
    let timer = 120 * 1000;
    const alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Alert',
      message: 'Are you sure want to leave this page ?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            this.onPageScroll(true);
            alert.dismiss();
            condition = false
          }
        },
        {
          text: 'Yes',
          handler: () => {
            this.myApp.logout();
            alert.dismiss();
          }
        }
      ]
    })
    alert.present();
    setTimeout(() => {
      alert.dismiss();
      if (condition) {
        this.myApp.logout();
      }
    }, timer);
  }

  logout() {
    let body = {
      username: this.username,
    }
    this.pmnProvider.clearSession(body).subscribe((resp: any) => {
      console.log("Success Logout")
    }, err => {
      console.log(err)
    });
  }
}