import { PmnProvider } from './../../../../providers/pmn/pmnProvider';
import { Component, OnInit, Input } from '@angular/core';
import { PmnHospitalisationService } from '../../../../providers/pmn/pmnHospitalisation';
import { UtilityPMNProvider } from '../../../../providers/pmn/utilitypmn';
import { DatePipe } from '@angular/common';
import { PmnToastService } from '../../../../providers/pmn/pmnToast';
import { AlertController, LoadingController, NavController } from 'ionic-angular';
import { PmnPayloadHelperProvider } from '../../../../providers/pmn/pmnPayLoadHelper';

@Component({
  selector: 'pmn-hosp-rider-pro',
  templateUrl: 'pmn-hospitalisation-rider-pro.html'
})
export class PmnHospRiderPro implements OnInit {

  constructor(
    private pmnHospitalisationProvider: PmnHospitalisationService,
    public pmnProvider: PmnProvider,
    public util: UtilityPMNProvider,
    private datePipe: DatePipe,
    private pmnToastService: PmnToastService,
    private alertCtrl: AlertController,
    private loadingCtrl: LoadingController,
    private navCtrl: NavController,
    private pmnPayLoadHelper: PmnPayloadHelperProvider,
  ) { }

  // Input
  @Input() childMessage: any;
  @Input() activityName: string;
  @Input() tabIndex: number;
  @Input() switchPlanData: any;

  ngOnInit() {
    this.getData();
    this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
  }

  telehealthList: any = [
    { value: "Inpatient" },
    { value: "One Day Surgery" },
    { value: "Cancer" }
  ];
  passed: boolean = false;
  timer: any;
  filteredDocumentMasterData: any[];
  notes = {
    shortDesc: '',
    longDesc: '',
    freetext: false
  };
  notesDesc: string = '';
  notesSearchBar: any;

  filteredDiagnoseTypeMasterData: any;

  surgeryTypeMasterData: any;
  filteredSurgeryTypeMasterData: any;

  doctorMasterData: any;
  filteredDoctorMasterData: any;
  filteredNotesMasterData: any;

  currentDate: any;

  icd10: any = [];
  diagnose: string;
  selectedDiagnose: any = '';
  icdCode: any;

  surgeryResponse: any = [];
  surgery: string;
  selectedSurgery: any = '';
  surgeryCode: any;

  surgeryCost: any = '';
  equipmentCost: any = '';
  surgicalInstrumentCost: any = '';
  otherSurgicalCost: any = '';

  searchbar = [];
  searchbarSurgery = [];
  doctorSearchBar = [];
  
  searchbarTele = [];
  filteredDiagnoseTele: any;

  searchbarPhysiciatric = [];
  filteredDiagnosePhysiciatri: any;

  loading: any;
  data: any;
  toggleInfo: Boolean = false;
  riderClaimType: String = 'HB';
  dataIsEditable: Boolean = true;
  toggleClaimPaid = false;

  selected: any;
  inpatients: any[];
  outpatients: any[];
  otherBenefits: any[];
  hospitalName: String;
  hasCalculateBenefit: Boolean = false;
  changeFromUserInput: Boolean = false;
  calculateCount: number = 0;
  transformedBenefitArray: any;
  transformedBenefitAnomaly = [];
  fullRoom = [];
  availableRider = [];
  masterPlan: any;

  // Benefit HS
  planHS = ['H1ED', 'H1JR', 'H1J1', 'H1LR', 'H1L1', 'H1QR', 'H1G1', 'H1RR', 'H1SR', 'H1GR', 'H1RR'];
  planHSPlus = ['H1TR', 'H1UR'];
  ipTwoToFiveNonCermat = ['SP','OC','MC','TC','SC','OO','ME','DG','BC','DI','LC','OM','PH','PO','PJ','PI','IG','OG','TS','TJ','LS'];
  ipTwoToFiveCermat = ['SP','OC','MC','TC','SC','OO','ME','DG','BC','DI','LC','OM','PH','PO','PJ','PI','IG','OG','PK','T1','T2','T3','T4','TS','TJ','LS'];
  decisionOpt: any[] = [
    { value: 'idr', text: 'IDR' },
    { value: 'usd', text: 'USD' }
  ];
  currencyDecision = "IDR";
  override = false;
  outpatient = false;
  tabsActive: any = 0;
  disableFeature: boolean = false;
  psikiatriDgHistory: any= [];
  psikiatriHistory: any= [];
  telehealthDateHistory: any=[];
  telehealthDgHistory: any=[];

  // Ex-Gracia State
  isExGratia: boolean = false;
  showExGratiaFields: boolean = false;
  exGratia = {
    supportREAS: {
      value: false,
      isValidationError: false,
      required: true
    },
    isSpecificType: {
      value: false,
      valueByType: "",
      isValidationError: false,
      required: true
    },
    amount: {
      value: "",
      isValidationError: false,
      required: true
    },
    recommendation: {
      value: "",
      isValidationError: false,
      required: true
    },
    reason: {
      value: "",
      isValidationError: false,
      required: true
    },
    code: {
      options: [
        {
          label: "ELI",
          value: "ELI",
          description: "Exgratia Lack Internal PMN"
        },
        {
          label: "EXE",
          value: "EXE",
          description: "Exgratia Lack External PMN"
        },
        {
          label: "EXK",
          value: "EXK",
          description: "Exgratia Specific Condition"
        },
        {
          label: "EGD",
          value: "EGD",
          description: "Exgratia Claim DSA"
        },
        {
          label: "EGR",
          value: "EGR",
          description: "Exgratia Others Supported REAS"
        },
        {
          label: "EXO",
          value: "EXO",
          description: "Exgratia Others Unsupported REAS"
        },
        {
          label: "STC",
          value: "STC",
          description: "Exgratia Covid"
        }
      ],
      select: {
        value: "",
        description: ""
      },
      isValidationError: false,
      required: true
    }
  }

  // Start Ex-Gracia Events
  populateExGratiaFields(){
    this.data.exGratia.proceedWithExGratia && (
      this.isExGratia = this.data.exGratia.proceedWithExGratia || false,
      this.showExGratiaFields = this.data.exGratia.proceedWithExGratia || false,
      this.exGratia.amount.value = this.data.exGratia.amount || "",
      this.exGratia.code.select.value = this.data.exGratia.exGratiaCode.split(" - ")[0] || "",
      this.exGratia.code.select.description = this.data.exGratia.exGratiaCode.split(" - ")[1] || "",
      this.exGratia.isSpecificType.value = this.data.exGratia.exGratiaType === "specific" ? true : false,
      this.exGratia.isSpecificType.valueByType = this.data.exGratia.exGratiaType || "",
      this.exGratia.reason.value = this.data.exGratia.reason || "",
      this.exGratia.recommendation.value = this.data.exGratia.recommendation || "",
      this.exGratia.supportREAS.value = this.data.exGratia.supportREAS || false
    )
  };
  async onClickProceedExGratia(value: boolean) {
    const alert = this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Alert',
      message: 'Mohon klik "Save" setelah melakukan Perubahan di Ex-Gratia',
      buttons: [
        {
          text: 'OK',
          handler: () => {
            this.isExGratia = value;
            this.showExGratiaFields = value;
            !value && this.exGratiaResetFields();
          }
        }
      ]
    })
    await alert.present();
  }

  onClickChangeExGratiaSupportReas(value: boolean): void {
    this.exGratia.supportREAS.value = value;
  }

  onClickChangeExGratiaIsSpecificType(value: boolean): void {
    this.exGratia.isSpecificType.value = value;
    this.exGratia.isSpecificType.valueByType = value ? "specific" : "non-specific"
  }

  getExGratiaCodeDescription(): void {
    this.exGratia.code.options.forEach(code => code.value === this.exGratia.code.select.value && (
      this.exGratia.code.select.description = code.description
    ));
  }

  exGratiaResetFields(): void {
    Object.keys(this.exGratia).forEach(field => {
      switch (field) {
        case "isSpecificType":
        case "supportREAS":
          return (
            this.exGratia[field].value = false,
            this.exGratia[field].isValidationError = false
          )
        case "code":
          return (
            this.exGratia[field].select.value = "",
            this.exGratia[field].select.description = "",
            this.exGratia[field].isValidationError = false
          )
      
        default:
          return (
            this.exGratia[field].value = "",
            this.exGratia[field].isValidationError = false
          )
      }
    })
  };

  exGratiaFieldsValidation(cb: (isExGratia:boolean, exGratiaFields: any) => void): void {
    if(!this.isExGratia) return cb(this.isExGratia, this.exGratia);
    let fieldNotValid = new Array();
    Object.keys(this.exGratia).forEach(field => {
      field !== "code" 
        ? this.exGratia[field].value === "" && this.exGratia[field].required
          ? (this.exGratia[field].isValidationError = true, fieldNotValid.push(true))
          : (this.exGratia[field].isValidationError = false)
        : this.exGratia[field].select.value === "" && this.exGratia[field].required
          ? (this.exGratia[field].isValidationError = true, fieldNotValid.push(true))
          : (this.exGratia[field].isValidationError = false)
    });
    fieldNotValid.length > 0 
      ? this.pmnToastService.showToast("Please Fill the Ex-Gratia fields")
      : cb(this.isExGratia, this.exGratia);
  };
  // End Ex-Gracia Events

  getTotalInnerLimitBenefit(dgIndex) {
    return this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + this.removeCurrency(cur.innerLimit), 0);
  }

  getTotalQty(dgIndex) {
    return this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + this.removeCurrency(cur.qty), 0);
  }

  getTotalPersonalFeePerDiagnose(dgIndex) {
    const totalPersonalFee = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + this.removeCurrency(cur.totalPersonalFee), 0);
    return totalPersonalFee;
  }

  getTotalPersonalFee() {
    const totalPersonalFee = this.data.diagnose.reduce((acc1, cur1) => {
      return acc1 + cur1.benefitClaim.reduce((acc2, cur2) => acc2 + this.removeCurrency(cur2.totalPersonalFee), 0);
    }, 0);
    return totalPersonalFee;
  }

  getTotalClaimDeclinePerDiagnose(dgIndex) {
    const totalClaimDecline = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + this.removeCurrency(cur.totalClaimDecline), 0);
    return totalClaimDecline;
  }

  getTotalClaimDecline() {
    const totalClaimDecline = this.data.diagnose.reduce((acc1, cur1) => {
      return acc1 + cur1.benefitClaim.reduce((acc2, cur2) => acc2 + this.removeCurrency(cur2.totalClaimDecline), 0);
    }, 0);
    return totalClaimDecline;
  }

  getTotalClaimSubmit(flag: string, dgIndex?) {
    let totalClaimSubmit = 0;
    if ([' ', 'Y', 'N', 'S', '*', '**', 'T'].indexOf(flag) == -1) return 0;
    switch (flag) {
      case '*': // Total per diagnose
        totalClaimSubmit = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + (Number.isNaN(+cur.totalClaimSubmit) ? this.removeCurrency(cur.totalClaimSubmit) : cur.totalClaimSubmit), 0);
        break;
      case '**': // Total all diagnose
        totalClaimSubmit = this.data.diagnose.reduce((acc1, cur1) => {
          return acc1 + cur1.benefitClaim.reduce((acc2, cur2) => acc2 + (Number.isNaN(+cur2.totalClaimSubmit) ? this.removeCurrency(cur2.totalClaimSubmit) : cur2.totalClaimSubmit), 0);
        }, 0);
        break;
      default:
        totalClaimSubmit = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => {
          const claimSubmit = (cur.inpatientFlag == flag) ? (Number.isNaN(+cur.totalClaimSubmit) ? this.removeCurrency(cur.totalClaimSubmit) : cur.totalClaimSubmit) : 0;
          return acc + claimSubmit;
        }, 0);
        break;
    }
    return totalClaimSubmit;
  }

  getTotalClaimPaid(flag: string, dgIndex?) {
    let totalClaimPaid = 0;
    if ([' ', 'Y', 'N', 'S', '*', '**', 'T'].indexOf(flag) == -1) return 0;
    switch (flag) {
      case '*': // Total per diagnose
        totalClaimPaid = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => acc + (Number.isNaN(+cur.totalClaimPaid) ? this.removeCurrency(cur.totalClaimPaid) : cur.totalClaimPaid), 0);
        break;
      case '**': // Total all diagnose
        totalClaimPaid = this.data.diagnose.reduce((acc1, cur1) => {
          return acc1 + cur1.benefitClaim.reduce((acc2, cur2) => acc2 + (Number.isNaN(+cur2.totalClaimPaid) ? this.removeCurrency(cur2.totalClaimPaid) : cur2.totalClaimPaid), 0);
        }, 0);
        break;
      default: // for each benefit flag
        totalClaimPaid = this.data.diagnose[dgIndex].benefitClaim.reduce((acc, cur) => {
          const claimPaid = (cur.inpatientFlag == flag) ? (Number.isNaN(+cur.totalClaimPaid) ? this.removeCurrency(cur.totalClaimPaid) : cur.totalClaimPaid) : 0;
          return acc + claimPaid;
        }, 0);
        break;
    }
    return totalClaimPaid;
  }

  calculateBenefit(diagnoseIndex, benefitIndex, invoiceIndex) {
    const amountSubmitted = this.removeCurrency(this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice[invoiceIndex].amountSubmitted);
    const qty = this.removeCurrency(this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice[invoiceIndex].qty);
    const personalFee = this.removeCurrency(this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice[invoiceIndex].personalFee);

    this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].qty = this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice.reduce((acc, cur) => acc + this.removeCurrency(cur.qty), 0);
    this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].totalClaimSubmit = this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice.reduce((acc, cur) => acc + this.removeCurrency(cur.amountSubmitted), 0);

    this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].totalClaimDecline = this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice.reduce((acc, cur) => acc + this.removeCurrency(cur.claimDecline), 0);
    this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].totalClaimPaid = this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice.reduce((acc, cur) => acc + this.removeCurrency(cur.claimPaid), 0);
    this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].totalPersonalFee = this.data.diagnose[diagnoseIndex].benefitClaim[benefitIndex].invoice.reduce((acc, cur) => acc + this.removeCurrency(cur.personalFee), 0);
  }

  calculateAll() {
    this.data.diagnose.forEach(dg => {
      dg.surgery.forEach(sg => {
        sg.detail.forEach(sgd => {
          sgd.amountSubmitted = this.removeCurrency(this.cleanInput(sgd.amountSubmitted));
          sgd.personalFee = this.removeCurrency(this.cleanInput(sgd.personalFee));

          if (sgd.amountSubmitted < sgd.personalFee) {
            this.pmnToastService.showToast("Personal fee can't be higher than Claim Submit");
            sgd.personalFee = 0;
          }

          // Wrong format pasted number checking
          if (sgd.amountSubmitted != (sgd.wrongAmountSubmitted)) {
            delete sgd.wrongAmountSubmitted;
          }
          if (sgd.personalFee != (sgd.wrongPersonalFee)) {
            delete sgd.wrongPersonalFee;
          }
        });
      });

      dg.benefitClaim.forEach(bc => {
        bc.invoice.forEach(inv => {
          inv.qty = this.removeCurrency(this.cleanInput(inv.qty));
          inv.amountSubmitted = this.removeCurrency(this.cleanInput(inv.amountSubmitted));
          inv.personalFee = this.removeCurrency(this.cleanInput(inv.personalFee));

          if (inv.amountSubmitted < inv.personalFee) {
            this.pmnToastService.showToast("Personal fee can't be higher than Claim Submit");
            inv.personalFee = 0;
          }

          // Wrong format pasted number checking
          if (inv.amountSubmitted != (inv.wrongAmountSubmitted)) {
            delete inv.wrongAmountSubmitted;
          }
          if (inv.personalFee != (inv.wrongPersonalFee)) {
            delete inv.wrongPersonalFee;
          }
        });

        bc.qty = +(bc.invoice.reduce((acc, cur) => acc + cur.qty, 0)).toFixed(2);
        bc.totalClaimSubmit = +(bc.invoice.reduce((acc, cur) => acc + cur.amountSubmitted, 0)).toFixed(2);
        bc.totalClaimDecline = +(bc.invoice.reduce((acc, cur) => acc + cur.claimDecline, 0)).toFixed(2);
        bc.totalClaimPaid = +(bc.invoice.reduce((acc, cur) => acc + cur.claimPaid, 0)).toFixed(2);
        bc.totalPersonalFee = +(bc.invoice.reduce((acc, cur) => acc + cur.personalFee, 0)).toFixed(2);

      });

      dg.diagCalculation.totalClaimSubmit = +(dg.benefitClaim.reduce((acc, cur) => acc + cur.totalClaimSubmit, 0)).toFixed(2);
      dg.diagCalculation.claimDecline = +(dg.benefitClaim.reduce((acc, cur) => acc + cur.totalClaimDecline, 0)).toFixed(2);
      dg.diagCalculation.claimPaid = +(dg.benefitClaim.reduce((acc, cur) => acc + cur.totalClaimPaid, 0)).toFixed(2);
      dg.diagCalculation.personalFee = +(dg.benefitClaim.reduce((acc, cur) => acc + cur.totalPersonalFee, 0)).toFixed(2);
    });
    this.data.claimPaid.claimSubmit = +(this.data.diagnose.reduce((acc, cur) => acc + cur.diagCalculation.totalClaimSubmit, 0)).toFixed(2);
    this.data.claimPaid.claimDecline = +(this.data.diagnose.reduce((acc, cur) => acc + cur.diagCalculation.claimDecline, 0)).toFixed(2);
    this.data.claimPaid.claimPaid = +(this.data.diagnose.reduce((acc, cur) => acc + cur.diagCalculation.claimPaid, 0)).toFixed(2);
    this.data.claimPaid.personalFee = +(this.data.diagnose.reduce((acc, cur) => acc + cur.diagCalculation.personalFee, 0)).toFixed(2);
    this.data.totalUsage = this.data.claimPaid.claimPaid;
  }

  calculateTaxDisc(claimPaid) {
    const param = {
      caseId: this.childMessage.caseId,
      claimSettlementId: this.childMessage.claimSettlementId,
      claimAmount: String(claimPaid.claimPaid),
      amountAdjustmentFlag: false,
      discountAdjustmentFlag: false,
      hospitalCode: "",
      amountAdjustment: "",
      discountAdjustment: ""
    }

    this.pmnHospitalisationProvider.calculateDiscountTax(param).subscribe(auth => {
      auth.subscribe((resp: any) => {
        this.data.discount.discountType = resp.discountType;
        this.data.discount.percentage = resp.percentage;
        this.data.discount.totalDiscount = resp.totalDiscount;
        this.data.discount.totalPayment = resp.totalPayment;
        this.data.discount.adjustTotalDiscount = resp.adjustTotalDiscount;
        this.data.discount.adjustTotalPayment = resp.adjustTotalPayment;
        this.data.tax.totalTax = resp.totalTax;
        this.data.tax.ppnValue = resp.ppnValue;
        this.data.tax.pph23Value = resp.pph23Value;
      }, (err: any) => {
        this.pmnToastService.showToast(`Error Tax & Discount Calculation ${err}`);
      });
    });
  }

  selectFilteredNotes(note) {
    this.notesSearchBar = 'displayNone';
    this.data.notes = note.shortDesc;
    this.data.description = note.longDesc;
    return;
  }

  selectFilteredDoctor(index, doctor) {
    this.doctorSearchBar[index] = 'displayNone';
    this.filteredDoctorMasterData = null;
    this.data.diagnose[index].dokter.dokterCode = doctor.doctorCode.trim();
    this.data.diagnose[index].dokter.dokterName = doctor.doctorName.trim();
    let doctorLicence = doctor.doctorName.split(',');
    if (doctorLicence.length == 1) {
      this.data.diagnose[index].dokter.dokterLicense = 'GP';
    } else {
      this.data.diagnose[index].dokter.dokterLicense = doctorLicence[doctorLicence.length - 1].trim();
    }
    // No doctor speciality in master doctor;
    return;
  }

  selectFilteredDiagnose(index, diagnose, benefitIdx, type) {
    if (type == 'phsyciatric') {
      this.searchbarPhysiciatric[index] = 'displayNone';
      this.filteredDiagnosePhysiciatri = null;
      this.data.diagnose[index].benefitClaim[benefitIdx].diagnoseHistory = diagnose.itemitem.trim() + ' - ' + diagnose.genarea.trim();
    }
    if (type == 'telehealth') {
      this.searchbarTele[index] = 'displayNone';
      this.filteredDiagnoseTele = null;
      this.data.diagnose[index].telehealth.diagnoseHistory = diagnose.itemitem.trim() + ' - ' + diagnose.genarea.trim();
    }
    if(type == 'diagnose') {
      this.searchbar[index] = 'displayNone';
      this.filteredDiagnoseTypeMasterData = null;
      if (this.data.diagnose.findIndex(d => d.icdCode == diagnose.itemitem.trim()) == -1) {
        this.data.diagnose[index].diagnosis = diagnose.itemitem.trim() + ' - ' + diagnose.genarea.trim();
        this.data.diagnose[index].diagnosisType = diagnose.genarea.trim();
        this.data.diagnose[index].icdCode = diagnose.itemitem.trim();
      } else {
        this.data.diagnose[index].diagnosis = '';
        this.pmnToastService.showToast('Selected diagnose is already filled. Please select another diagnose');
      }      
    }
    return;
  }

  selectFilteredSurgery(dgIndex, sgIndex, surgery) {
    this.searchbarSurgery[dgIndex][sgIndex] = 'displayNone';
    this.filteredSurgeryTypeMasterData = null;
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryDesc = surgery.longdesc.trim();
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryCode = surgery.descitem.trim();
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryType = surgery.desctabl.trim();
    return;
  }

  setFiltered(type: string, filter: string, index, i = 0) {
    if (type != 'notes' && filter.length < 1) return;
    switch (type) {
      case 'diagnoseType':
        this.getDiagnose(filter, 'diagnose');
        this.searchbar[index] = "displayAbsolute";
        break;
      case 'diagnoseTele':
        this.getDiagnose(filter,'diagnoseTele');
        this.searchbarTele[index] = "displayAbsolute";
        break;
      case 'diagnosePhysiciatric':
        this.getDiagnose(filter, 'diagnosePhysiciatric');
        this.searchbarPhysiciatric[index] = "displayAbsolute";
        break;
      case 'surgeryType':
        this.getSurgery(filter);
        this.searchbarSurgery[index][i] = "displayAbsolute";
        break;
      case 'doctor':
        this.getDoctor(filter);
        this.doctorSearchBar[index] = "displayAbsolute";
        break;
      case 'notes':
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          this.getDocument(filter);
          this.notesSearchBar = "displayAbsolute";
        }, 1000)
        break;
    }
  }

  onInputSymptonDate(dgIndex, event) {
    const currentDate = this.datePipe.transform(this.currentDate, 'MM/dd/yy');
    const inputedDate = this.datePipe.transform(event.target.value, 'MM/dd/yy');
    if (new Date(inputedDate) > new Date(currentDate)) {
      this.data.diagnose[dgIndex].symptonDate1 = currentDate;
    } else {
      this.data.diagnose[dgIndex].symptonDate1 = inputedDate;
    }
  }

  onCancelNotes() {
    this.data.notes = '';
    this.data.description = '';
    this.data.remarks = '';

    this.filteredNotesMasterData = null;
    this.notesSearchBar = 'displayNone';
  }

  onCancelDiagnose(dgIndex, benefitIdx, type) {
    if (type == 'diagnose') {
      this.data.diagnose[dgIndex].diagnosis = '';
      this.data.diagnose[dgIndex].icdCode = '';
      this.data.diagnose[dgIndex].diagnosisType = '';
      this.filteredDiagnoseTypeMasterData = null;
      this.searchbar[dgIndex] = 'displayNone';
    }

    if (type == 'tele') {
      this.data.diagnose[dgIndex].telehealth.diagnoseHistory = '';
      this.searchbarTele[dgIndex] = 'displayNone';
    }

    if (type == 'phsyciatric') {
      this.data.diagnose[dgIndex].benefitClaim[benefitIdx].diagnoseHistory = '';
      this.searchbarPhysiciatric[dgIndex] = 'displayNone';
    }
  }

  onCancelDoctorName(dgIndex) {
    // Reset data on cancel
    this.data.diagnose[dgIndex].dokter.dokterCode = '';
    this.data.diagnose[dgIndex].dokter.dokterLicense = '';
    this.data.diagnose[dgIndex].dokter.dokterSpeciality = '';
    this.data.diagnose[dgIndex].dokter.dokterName = '';
    this.filteredDoctorMasterData = null;

    this.doctorSearchBar[dgIndex] = 'displayNone';
  }

  onCancelSurgery(dgIndex, sgIndex) {
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryDesc = '';
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryCode = '';
    this.data.diagnose[dgIndex].surgery[sgIndex].surgeryType = '';
    this.filteredSurgeryTypeMasterData = null;

    this.searchbarSurgery[dgIndex][sgIndex] = 'displayNone';
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });

    this.loading.present();
  }

  resetJSON(obj) {
    for (let prop in obj) {
      if (typeof obj[prop] == 'object') this.resetJSON(obj[prop]);
      if (typeof obj[prop] == 'number') obj[prop] = 0
      if (typeof obj[prop] == 'string') obj[prop] = '';
      if (typeof obj[prop] == 'boolean') obj[prop] = false;
    }
  }

  formatMoney(val) {
    if (val == null) {
      val = 0;
      val = val.toFixed(2);
    }
    if (val == 0 || val == '0') return val;
    if (typeof val == 'number' && val != 0) {
      val = val.toFixed(2);
      val = val.replace('.', ',');
    }
    if (typeof val == 'string' && val.indexOf('0,') == 0) {
      return val;
    }
    val = this.util.format(val);
    return val;
  }

  removeCurrency(val) {
    if (val == null) {
      val = 0;
    }
    if (val == 0 || val == '0') return 0;
    if (!Number.isNaN(+val)) { // if val is number
      val += '';
      let dotIndex = val.indexOf('.');
      if (('' + val).indexOf(',') == -1 && (val.length > dotIndex + 3)) {
        val = ('' + val).replace(/\./g, '');
      }
      val = this.formatMoney(+val);
    }
    val = val.replace(/\./g, '');
    val = val.replace(',', '.');
    val = +(Number.parseFloat(val).toFixed(2));

    return val;
  }

  cleanInput(val) {
    if (val == null) {
      val = 0;
      val = val.toFixed(2);
    }
    val = val.toString();
    val = val.replace(/[^0-9\,\.]+/g, '');
    if (val.indexOf(',') != -1) {
      let i = val.indexOf(',');
      val = val.slice(0, i + 3);
    }
    return val;
  }

  onPaste(e, obj, objName) {
    let clipboardData = e.clipboardData;
    let pastedText = clipboardData.getData('text');
    let commaIndex = pastedText.indexOf(',');
    if (commaIndex == -1) return;
    if (pastedText.length - 1 > commaIndex + 2) {
      obj[objName] = this.removeCurrency(this.cleanInput(pastedText));
    }
  }

  checkWrongFormatPaste(obj) {
    if (obj.amountSubmitted != obj.wrongFormatNum) {
      delete obj.wrongFormatNum;
    }
  }

  showHideInformation() {
    this.toggleInfo = !this.toggleInfo;
  }

  showHideClaimPaid() {
    this.toggleClaimPaid = !this.toggleClaimPaid;
  }

  getDoctor(filter: String) {
    const hospcd = this.data.hospitalName.split(' ')[0];
    const param = { input: '', hospcd };
    filter = filter.toLowerCase();

    if (!this.doctorMasterData) {
      this.pmnHospitalisationProvider.getMasterDoctor(param).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.doctorMasterData = response.dataMaster;
          this.filteredDoctorMasterData = this.doctorMasterData.filter(item => item.doctorName.toLowerCase().indexOf(filter) != -1);
        }, err => {
          this.pmnToastService.showToast(`Error while getting doctor data. ${err}`);
        });
      });
    } else {
      this.filteredDoctorMasterData = this.doctorMasterData.filter(item => item.doctorName.toLowerCase().indexOf(filter) != -1);
    }
    return;
  }

  getDiagnose(filter: String, type) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.hitDiagnose(filter).then((response: any) => {
        if (type == 'diagnoseTele') {
          this.filteredDiagnoseTele = response.dataMaster.filter(item => item.itemitem.toLowerCase().indexOf(filter) != -1 || item.genarea.toLowerCase().indexOf(filter) != -1);
        }
        if (type == 'diagnosePhysiciatric') {
          this.filteredDiagnosePhysiciatri = response.dataMaster.filter(item => item.itemitem.toLowerCase().indexOf(filter) != -1 || item.genarea.toLowerCase().indexOf(filter) != -1);
        }
        if (type == 'diagnose') {
          this.filteredDiagnoseTypeMasterData = response.dataMaster.filter(item => item.itemitem.toLowerCase().indexOf(filter) != -1 || item.genarea.toLowerCase().indexOf(filter) != -1);
        }
      }).catch(error => { console.log(error) }
      );
    }, 1000)
    return;
  }

  hitDiagnose(diag){
    const param = { input: diag.toLowerCase() };
    return new Promise((resolve, reject) => {
    this.pmnProvider.getMaster(param, 'getAdditionalDiag').subscribe(auth => {
        auth.subscribe((value: any) => {
          value ? resolve(value) : reject('error');
        }, err => {
          reject('error')
        });
      });
    });
  }

  getSurgery(filter: String) {
    this.surgeryResponse = [];
    let param = { input: '' };
    let type: string = "getSurgeryType";
    filter = filter.toLowerCase();

    if (!this.surgeryTypeMasterData) {
      this.pmnProvider.getMaster(param, type).subscribe(p1 => {
        p1.subscribe((response: any) => {
          this.surgeryTypeMasterData = response.dataMaster;
          this.filteredSurgeryTypeMasterData = this.surgeryTypeMasterData.filter(item => item.descitem.toLowerCase().indexOf(filter) != -1 || item.longdesc.toLowerCase().indexOf(filter) != -1);
        }, err => {
          this.pmnToastService.showToast(`Error while getting surgery type data. ${err}`);
        })
      });
    } else {
      this.filteredSurgeryTypeMasterData = this.surgeryTypeMasterData.filter(item => item.descitem.toLowerCase().indexOf(filter) != -1 || item.longdesc.toLowerCase().indexOf(filter) != -1);
    }
  }

  getData() {
    const param = {
      caseId: this.childMessage.reffId || '',
      priorApprovalNo: this.childMessage.priorApprovalNo || '',
      activity: this.activityName,
      pchc: false
    }
    if (this.switchPlanData) {
      this.data = this.switchPlanData;
      try {
        this.prepareData();
      } catch (err) {
        console.error(`Error while preparing data. ${err}`);
      }
      this.transformBenefit();
    } else {
      this.pmnHospitalisationProvider.getData(param).subscribe(r1 => {
        r1.subscribe(response => {
          this.data = response;
            this.psikiatriDischDate(response.policyNo, response.admissionDate, response.diagnose);
            this.getTeleFromInit(response.diagnose);
          try {
            this.prepareData();
          } catch (err) {
            console.error(`Error while preparing data. ${err}`);
          }
          this.transformBenefit();
        }, (err: any) => {
          this.pmnToastService.showToast(`Error while getting data. ${err}`);
        });
      });
    }
  }

  getDocument(filter: string) {
    filter = filter.toLowerCase();

    const param = {
      input: filter,
      flag: 'PMN_CLAIM_SETTLEMENT'
    };

    this.pmnProvider.getPendingDocument(param).subscribe(p1 => {
      p1.subscribe((response: any) => {
        this.filteredDocumentMasterData = response.filter(item => item.shortDesc.toLowerCase().indexOf(filter) != -1);
      }, err => {
        this.pmnToastService.showToast(`Error while getting document. ${err}`);
        console.error(err);
      })
    });
  }

  changeTabs(i) {
    this.tabsActive = i;
  }

  async save() {
    // Start validate mandatory field

    if (this.activityName != 'PMN Case Monitoring') {
      let validData = true;

      // Policy No
      if (!this.data.policyNo) {
        this.pmnToastService.showToast('PolicyNo is empty');
        return;
      }

      // Addmission Date
      if (!this.data.admissionDate) {
        this.pmnToastService.showToast('Addmission Date is empty');
        return;
      }

      // Hospital Code and Hospital Name
      if (!this.data.hospitalName) {
        this.pmnToastService.showToast('Hospital name is empty');
        return;
      }

      let index = 0;
      // ICD Code
      const invalidIcdCode = this.data.diagnose.some((dg, i) => {
        index = i;
        return !dg.icdCode;
      });

      if (invalidIcdCode) {
        this.pmnToastService.showToast(`icdCode is empty. Please input Diagnose Type at Diagnose ${index + 1}`);
        return;
      }

      // Sympton Date
      const invalidSymptonDate = this.data.diagnose.some((dg, i) => {
        index = i;
        return !dg.symptonDate1;
      });

      if (invalidSymptonDate) {
        this.pmnToastService.showToast(`Please input Sympton Date ${index + 1}`);
        return;
      }

      // Doctor Name
      const invalidDoctorName = this.data.diagnose.some((dg, i) => {
        index = i;
        return !dg.dokter.dokterName;
      });

      if (invalidDoctorName) {
        this.pmnToastService.showToast(`Please input Doctor Name ${index + 1}`);
        return;
      }

      // Diagnose remark
      if (this.activityName != 'PMN CLAIM SETTLEMENT') {
        const diagnoseRemark = this.data.diagnose.some((dg, i) => {
          index = i;
          return !dg.additionalDiagnosis;
        });

        if (diagnoseRemark) {
          this.pmnToastService.showToast(`Please input Diagnose Remarks ${index + 1}`);
          return;
        }
      }

      // Validate if data inputted or not by totalClaimSubmitted and QTY
      let isThereWrongFormat = false;
      for (let i = 0; i < this.data.diagnose.length; i++) {
        let isSomeDataInputted = this.data.diagnose[i].benefitClaim.some(bc => {
          return bc.totalClaimSubmit || bc.totalPersonalFee
        });

        if (['PMN OUTPATIENT', 'GOP JET VERIFIER'].indexOf(this.activityName) != -1) {
          if (i == 0) {
            if (!isSomeDataInputted) {
              this.pmnToastService.showToast('Please input at least one Qty and Claim Submit in one benefit');
              return;
            }
          }
        } else {
          if (!isSomeDataInputted) {
            this.pmnToastService.showToast('Please input at least one Qty and Claim Submit in one benefit');
            return;
          }
        }

        isThereWrongFormat = this.data.diagnose[i].surgery[0].detail.some(detail => {
          return detail.hasOwnProperty('wrongAmountSubmitted') || detail.hasOwnProperty('wrongPersonalFee');
        });
        if (isThereWrongFormat) {
          this.pmnToastService.showToast('Please input again some field with red color highlight');
          return;
        }

        isThereWrongFormat = this.data.diagnose[i].benefitClaim.some(benefit => {
          return benefit.invoice[0].hasOwnProperty('wrongAmountSubmitted') || benefit.invoice[0].hasOwnProperty('wrongPersonalFee');
        });
        if (isThereWrongFormat) {
          this.pmnToastService.showToast('Please input again some field with red color highlight');
          return;
        }
      }

      // end checking mandatory field
    } else {
      let isThereWrongFormat = false;
      for (let i = 0; i < this.data.diagnose.length; i++) {
        isThereWrongFormat = this.data.diagnose[i].surgery[0].detail.some(detail => {
          return detail.hasOwnProperty('wrongAmountSubmitted') || detail.hasOwnProperty('wrongPersonalFee');
        });
        if (isThereWrongFormat) {
          this.pmnToastService.showToast('Please input again some field with red color highlight');
          return;
        }

        isThereWrongFormat = this.data.diagnose[i].benefitClaim.some(benefit => {
          return benefit.invoice[0].hasOwnProperty('wrongAmountSubmitted') || benefit.invoice[0].hasOwnProperty('wrongPersonalFee');
        });
        if (isThereWrongFormat) {
          this.pmnToastService.showToast('Please input again some field with red color highlight');
          return;
        }
      }
    }
    if (!this.hasCalculateBenefit && this.changeFromUserInput) {
      this.pmnToastService.showToast('Please click benefit calculator first before saving');
      return;
    }
    this.calculateAll();
    const jsonToSend = JSON.parse(JSON.stringify(this.data));
    jsonToSend.priorApprovalNo = this.childMessage.priorApprovalNo || '';
    jsonToSend.diagnose.forEach(element => {
      delete element.expand;
      delete element.expandDailyRoom;
      delete element.expandInpatient;
      delete element.expandOutpatient;
      delete element.expandOtherBenefit;
      delete element.expandTelehealth;
    });

    // Remove number
    jsonToSend.remainingAnnualLimit = Number.isNaN(+jsonToSend.remainingAnnualLimit) ? this.removeCurrency(jsonToSend.remainingAnnualLimit) : jsonToSend.remainingAnnualLimit;
    jsonToSend.fixedAmmount = Number.isNaN(+jsonToSend.fixedAmmount) ? this.removeCurrency(jsonToSend.fixedAmmount) : jsonToSend.fixedAmmount;
    jsonToSend.basicRoomPrice = Number.isNaN(+jsonToSend.basicRoomPrice) ? this.removeCurrency(jsonToSend.basicRoomPrice) : jsonToSend.basicRoomPrice;
    jsonToSend.entitleRoom = Number.isNaN(+jsonToSend.entitleRoom) ? this.removeCurrency(jsonToSend.entitleRoom) : jsonToSend.entitleRoom;
    jsonToSend.prorationArea = Number.isNaN(+jsonToSend.prorationArea) ? this.removeCurrency(jsonToSend.prorationArea) : jsonToSend.prorationArea;
    jsonToSend.noClaimBonus = Number.isNaN(+jsonToSend.noClaimBonus) ? this.removeCurrency(jsonToSend.noClaimBonus) : jsonToSend.noClaimBonus;
    jsonToSend.deductible = Number.isNaN(+jsonToSend.deductible) ? this.removeCurrency(jsonToSend.deductible) : jsonToSend.deductible;
    jsonToSend.unpaidDowngradeClaim = Number.isNaN(+jsonToSend.unpaidDowngradeClaim) ? this.removeCurrency(jsonToSend.unpaidDowngradeClaim) : jsonToSend.unpaidDowngradeClaim;
    jsonToSend.prorationFactor = Number.isNaN(+jsonToSend.prorationFactor) ? this.removeCurrency(jsonToSend.prorationFactor) : jsonToSend.prorationFactor;
    jsonToSend.primeLmtBoostr = Number.isNaN(+jsonToSend.primeLmtBoostr) ? this.removeCurrency(jsonToSend.primeLmtBoostr) : jsonToSend.primeLmtBoostr;
    jsonToSend.claimPaid.claimSubmit = Number.isNaN(+jsonToSend.claimPaid.claimSubmit) ? this.removeCurrency(jsonToSend.claimPaid.claimSubmit) : jsonToSend.claimPaid.claimSubmit;
    jsonToSend.claimPaid.personalFee = Number.isNaN(+jsonToSend.claimPaid.personalFee) ? this.removeCurrency(jsonToSend.claimPaid.personalFee) : jsonToSend.claimPaid.personalFee;
    jsonToSend.claimPaid.claimDecline = Number.isNaN(+jsonToSend.claimPaid.claimDecline) ? this.removeCurrency(jsonToSend.claimPaid.claimDecline) : jsonToSend.claimPaid.claimDecline;
    jsonToSend.claimPaid.claimPaid = Number.isNaN(+jsonToSend.claimPaid.claimPaid) ? this.removeCurrency(jsonToSend.claimPaid.claimPaid) : jsonToSend.claimPaid.claimPaid;
    jsonToSend.totalUsage = jsonToSend.claimPaid.claimPaid;
    this.data.totalUsage = jsonToSend.claimPaid.claimPaid;

    jsonToSend.diagnose.forEach(diag => {
      diag.symptonDate1 = this.datePipe.transform(diag.symptonDate1, 'MM/dd/yy');
      diag.additionalDiagnosis = diag.additionalDiagnosis != null ? diag.additionalDiagnosis.replace(/\n/g, " ").replace(/(<([^>]+)>)/g, '').replace(/[^a-zA-Z0-9 ]/g, "").replace(/ {2,}/g, " ").trim() : '';

      diag.surgery.forEach(sg => {
        sg.detail.forEach(dt => {
          dt.amountSubmitted = Number.isNaN(+dt.amountSubmitted) ? this.removeCurrency(dt.amountSubmitted) : dt.amountSubmitted;
          dt.personalFee = Number.isNaN(+dt.personalFee) ? this.removeCurrency(dt.personalFee) : dt.personalFee;
        });
      });

      diag.benefitClaim.forEach(bc => {
        bc.innerLimit = Number.isNaN(+bc.innerLimit) ? this.removeCurrency(bc.innerLimit) : bc.innerLimit;
        bc.qty = Number.isNaN(+bc.qty) ? this.removeCurrency(bc.qty) : bc.qty;
        bc.totalClaimSubmit = Number.isNaN(+bc.totalClaimSubmit) ? this.removeCurrency(bc.totalClaimSubmit) : bc.totalClaimSubmit;
        if (bc.totalClaimSubmit == 0 || bc.totalClaimSubmit == '') {
          bc.qty = 0;
        }
        bc.totalClaimPaid = Number.isNaN(+bc.totalClaimPaid) ? this.removeCurrency(bc.totalClaimPaid) : bc.totalClaimPaid;
        bc.totalClaimDecline = Number.isNaN(+bc.totalClaimDecline) ? this.removeCurrency(bc.totalClaimDecline) : bc.totalClaimDecline;
        bc.totalPersonalFee = Number.isNaN(+bc.totalPersonalFee) ? this.removeCurrency(bc.totalPersonalFee) : bc.totalPersonalFee;
        bc.invoice.forEach(inv => {
          inv.amountSubmitted = Number.isNaN(+inv.amountSubmitted) ? this.removeCurrency(inv.amountSubmitted) : inv.amountSubmitted;
          inv.personalFee = Number.isNaN(+inv.personalFee) ? this.removeCurrency(inv.personalFee) : inv.personalFee;
          inv.claimPaid = Number.isNaN(+inv.claimPaid) ? this.removeCurrency(inv.claimPaid) : inv.claimPaid;
          inv.claimDecline = Number.isNaN(+inv.claimDecline) ? this.removeCurrency(inv.claimDecline) : inv.claimDecline;
        });
      });

      diag.diagCalculation.totalClaimSubmit = Number.isNaN(+diag.diagCalculation.totalClaimSubmit) ? this.removeCurrency(diag.diagCalculation.totalClaimSubmit) : diag.diagCalculation.totalClaimSubmit;
      diag.diagCalculation.personalFee = Number.isNaN(+diag.diagCalculation.personalFee) ? this.removeCurrency(diag.diagCalculation.personalFee) : diag.diagCalculation.personalFee;
      diag.diagCalculation.claimDecline = Number.isNaN(+diag.diagCalculation.claimDecline) ? this.removeCurrency(diag.diagCalculation.claimDecline) : diag.diagCalculation.claimDecline;
      diag.diagCalculation.claimPaid = Number.isNaN(+diag.diagCalculation.claimPaid) ? this.removeCurrency(diag.diagCalculation.claimPaid) : diag.diagCalculation.claimPaid;
    });

    let dataToSend = {
      hospitalizationDetail: jsonToSend,
      activity: this.activityName,
      claimSettlementId: this.childMessage.claimSettlementId || ''
    }

    // Ex-Gracia validation & merge to payload
    this.exGratiaFieldsValidation((isExGratia, exGratiaFields) => {
      let getExGratiaCodeDesc: string = ""

      isExGratia && (
        getExGratiaCodeDesc = exGratiaFields.code.select.description === "" 
          ? exGratiaFields.code.options.forEach(code => code.value === exGratiaFields.code.select.value && (code.description))
          : exGratiaFields.code.select.description
      );
      Object.assign(dataToSend.hospitalizationDetail, {
        exGratia: {
          "proceedWithExGratia": isExGratia,
          "supportREAS": isExGratia ? exGratiaFields.supportREAS.value : false,
          "exGratiaCode": isExGratia ? `${exGratiaFields.code.select.value} - ${getExGratiaCodeDesc}` : '',
          "exGratiaType": isExGratia ? exGratiaFields.isSpecificType.value === false ? "non-specific" : "specific" : '',
          "amount": isExGratia ? exGratiaFields.amount.value.replace(/\.+/g, "").replace(",", ".") : '',
          "recommendation": isExGratia ? exGratiaFields.recommendation.value : '',
          "reason": isExGratia ? exGratiaFields.reason.value : ''
        }
      });
      console.log("EX_GRATIA: FINISH_VALIDATION", {
        isExGratia, 
        exGratiaFields,
        dataToSend
      });
      this.saveConfirmation(dataToSend);
    });
    // existing
    // this.saveConfirmation(dataToSend);
  }

  saveData(data) {
    this.showLoading();
    this.pmnHospitalisationProvider.saveData(data).subscribe(p1 => {
      p1.subscribe(response => {
        this.loading.dismiss();
        this.pmnToastService.showToast('Success Saving Data');
        if (this.activityName == 'PMN CLAIM SETTLEMENT') {
          setTimeout(() => {
            this.navCtrl.setRoot("PmnSettlementWorkbasketPage");
          }, 2000)
        }
      }, err => {
        this.loading.dismiss();
        this.pmnToastService.showToast(`Error while saving data. ${err}`);
      })
    }, err => {
      this.loading.dismiss();
      this.pmnToastService.showToast(`Error while saving data. ${err}`);
    });
  }

  async saveConfirmation(data) {
    const alert = await this.alertCtrl.create({
      enableBackdropDismiss: false,
      title: 'Alert',
      message: 'Are you sure want to save this data?',
      buttons: [
        {
          text: 'No'
        },
        {
          text: 'Save',
          handler: () => {
            this.saveData(data);
          }
        }
      ]
    })
    await alert.present();
  }

  addNewDiagnose() {
    if (this.data.diagnose.length >= 5) {
      this.pmnToastService.showToast('Maximum diagnose is 5');
      return;
    }

    let benefitClaim = JSON.parse(JSON.stringify(this.data.diagnose[0].benefitClaim));
    // Only some benefit showed for diagnose 2-5
    if (['PMN OUTPATIENT', 'GOP JET VERIFIER'].indexOf(this.activityName) == -1) {
      if (['H123', 'H133'].indexOf(this.data.riderCode.split(' ')[0].trim()) == -1) {
        benefitClaim = benefitClaim.filter(benefit => this.ipTwoToFiveNonCermat.indexOf(benefit.benefitCode.slice(0, 2)) != -1);
      } else {
        benefitClaim = benefitClaim.filter(benefit => this.ipTwoToFiveCermat.indexOf(benefit.benefitCode.slice(0, 2)) != -1);
      }
    }

    this.fullRoom.push(false);

    const newDiagnose = {
      "icdSeq": this.data.diagnose.length + 1,
      "icdCode": "",
      "symptonDate1": "",
      "diagnosis": "",
      "diagnosisType": "",
      "dokter": {
        "dokterCode": "",
        "dokterName": "",
        "dokterLicense": "",
        "dokterSpeciality": ""
      },
      "additionalDiagnosis": "",
      "surgery": [
        {
          "surgeryCode": "",
          "surgeryDesc": "",
          "surgeryRemark": "",
          "seqnumb": "",
          "surgeryType": "",
          "detail": [
            {
              "benefitCode": "MC",
              "benefitDesc": "Biaya Rawat Operasi",
              "amountSubmitted": 0,
              "personalFee": 0
            },
            {
              "benefitCode": "TC",
              "benefitDesc": "Biaya Peralatan",
              "amountSubmitted": 0,
              "personalFee": 0
            },
            {
              "benefitCode": "SC",
              "benefitDesc": "Biaya Ahli Bedah",
              "amountSubmitted": 0,
              "personalFee": 0
            },
            {
              "benefitCode": "OO",
              "benefitDesc": "Biaya Bedah Lain-lain",
              "amountSubmitted": 0,
              "personalFee": 0
            }
          ]
        }
      ],
      "diagCalculation": {
        "totalClaimSubmit": 0,
        "personalFee": 0,
        "claimDecline": 0,
        "claimPaid": 0
      },
      "telehealth": {
        "dischargeDateHistory": "",
        "diagnoseHistory": "",
        "otherDischargeDateHistory": "",
        "telehealthRelated": ""
      },
      "benefitClaim": benefitClaim,
    }

    newDiagnose.benefitClaim.forEach(element => {
      element.totalClaimSubmit = 0;
      element.totalPersonalFee = 0;
      element.totalClaimDecline = 0;
      element.totalClaimPaid = 0;
      element.qty = 0;
      element.invoice.forEach(e => {
        e.amountSubmitted = 0;
        e.personalFee = 0;
        e.qty = 0;
        e.claimPaid = 0;
        e.claimDecline = 0;
      });
    });

    this.data.diagnose.push(newDiagnose);
    this.searchbar.push('displayNone');
    this.doctorSearchBar.push('displayNone');
    this.searchbarSurgery.push(['displayNone']);
    this.transformBenefit();
  }

  deleteDiagnose(dgIndex) {
    if (dgIndex == 0) return;
    this.data.diagnose.splice(dgIndex, 1);
  }

  deleteSurgeryInfo(dgIndex, surgeryIndex) {
    if (surgeryIndex == 0) return;
    this.data.diagnose[dgIndex].surgery.splice(surgeryIndex, 1);
  }

  // The detail must be the same as the first row
  addSurgery(i) {
    if (this.data.diagnose[i].surgery.length >= 4) {
      this.pmnToastService.showToast('Maximum surgery is 4');
      return;
    }
    this.data.diagnose[i].surgery.push(
      {
        "surgeryCode": "",
        "surgeryDesc": "",
        "surgeryRemark": "",
        "seqnumb": "",
        "surgeryType": "",
        "detail": (() => {
          let arr = [];
          for (let item of this.data.diagnose[0].surgery[0].detail) {
            let obj = { ...item };
            obj.amountSubmitted = 0
            obj.personalFee = 0
            arr.push(obj);
          }
          return arr;
        })()
      }
    );
    this.searchbarSurgery[i].push('displayNone');
  }

  benefitCalculation() {
    console.log('Rider Pro')
    this.showLoading();
    for (let i = 0; i < this.data.diagnose.length; i++) {
      if (!this.data.diagnose[i].benefitClaimActive) {
        this.data.diagnose[i].benefitClaimActive = [];
      }
    }
    const data = this.removeMoneyFormat(this.data);
    if (['PMN OUTPATIENT', 'GOP JET VERIFIER'].indexOf(this.activityName) != -1) {
      this.outpatient = true;
    }

    data.outpatient = this.outpatient;
    // data.override = this.override;
    this.pmnHospitalisationProvider.calculateBenefit(data).subscribe(r1 => {
      r1.subscribe((response: any) => {
        if (response.error) {
          this.loading.dismiss();
          console.error(response.error);
          this.pmnToastService.showToast(`Error: ${response.message || 'Error'}`);
          return;
        }

        if (response.notif) {
          (async () => {
            const alert = await this.alertCtrl.create({
              enableBackdropDismiss: false,
              title: 'Notification',
              message: response.notif,
              buttons: [
                {
                  text: 'OK'
                }
              ]
            })
            await alert.present();
          })()
        }

        this.data.primeLmtBoostr = response.primeLmtBoostr;
        this.data.remainingAnnualLimit = response.remainingAnnualLimit;
        this.data.deductible = response.deductible;
        this.data.noClaimBonus = response.noClaimBonus;
        this.data.unpaidDowngradeClaim = response.unpaidDowngradeClaim;
        this.data.prorationFactor = response.prorationFactor;
        this.data.prorationArea = response.prorationArea;
        this.data.fixedAmmount = response.fixedAmmount;
        this.data.entitleRoom = response.entitleRoom;
        this.data.basicRoomPrice = response.basicRoomPrice;
        this.data.lodging = response.lodging;
        this.data.planCoverageArea = response.planCoverageArea;
        this.data.entitleRoomDesc = response.entitleRoomDesc;

        // Remaining Days from benefit calculation response
        this.data.remainingRoomAndBoard = response.remainingRoomAndBoard;
        this.data.remainingPhysiotheraphy = response.remainingPhysiotheraphy;
        this.data.remainingDailyCashBenefit = response.remainingDailyCashBenefit;
        this.data.remainingHomeNursing = response.remainingHomeNursing;
        this.data.remainingPalliative = response.remainingPalliative;
        this.data.remainingPhysiciatric = response.remainingPhysiciatric;
        this.data.remainingICU = response.remainingICU;
        this.data.remainingICUVegetatif = response.remainingICUVegetatif;
       
        this.data.calculationFlag = response.calculationFlag;

        this.data.benefitCostSummary = response.benefitCostSummary;

        this.data.roomTypeUpOneLevel = response.roomTypeUpOneLevel;
        this.data.roomPriceUpOneLevel = response.roomPriceUpOneLevel;
        for (let i = 0; i < this.data.diagnose.length; i++) {
          if (!this.data.diagnose[i].benefitClaimActive) {
            this.data.diagnose[i].benefitClaimActive = response.diagnose[i].benefitClaimActive || [];
          }
          this.data.diagnose[i].telehealth = response.diagnose[i].telehealth;
        }

        response.diagnose.forEach((d, i) => {
          if (['H123', 'H133'].indexOf(data.riderCode.split(' ')[0].trim()) != -1) {
            d.surgery.forEach((surgery, surgeryIndex) => {
              let surgeryType = surgery.surgeryType;
              if (surgeryType.length == 2 && surgeryType[0] == 'T' && !Number.isNaN(+surgeryType[1])) {
                surgeryType = 'Type ' + surgeryType[1];
              }
              this.data.diagnose[i].surgery[surgeryIndex].surgeryType = surgeryType;
            });
          }
          d.benefitClaim.forEach((b, j) => {
            this.data.diagnose[i].benefitClaim[j].qtypaid = b.qtypaid;
            b.invoice.forEach((inv, k) => {
              this.data.diagnose[i].benefitClaim[j].invoice[k].qty = inv.qty;
              this.data.diagnose[i].benefitClaim[j].invoice[k].claimDecline = inv.claimDecline;
              this.data.diagnose[i].benefitClaim[j].invoice[k].claimPaid = inv.claimPaid;
              if (['H123', 'H133'].indexOf(data.riderCode.split(' ')[0].trim()) != -1) {
                this.data.diagnose[i].benefitClaim[j].invoice[k].amountSubmitted = inv.amountSubmitted;
                this.data.diagnose[i].benefitClaim[j].invoice[k].personalFee = inv.personalFee;
              }
              // Auto populate surgery information
              if (['Biaya Rawat Operasi', 'Biaya Peralatan', 'Biaya Ahli Bedah', 'Biaya Bedah Lain-lain'].indexOf(b.benefitDescription) != -1) {
                this.data.diagnose[i].benefitClaim[j].invoice[k].amountSubmitted = inv.amountSubmitted;
                this.data.diagnose[i].benefitClaim[j].invoice[k].personalFee = inv.personalFee;
                // this.data.diagnose[i].benefitClaim[j].invoice[k].qty = 1; // Because there's no qty in surgery infomation
              }
            })
          });
        })
        
        if (this.activityName == 'PMN CLAIM SETTLEMENT') {
          this.calculateTaxDisc(response.claimPaid);
        }
        this.calculateAll();
        this.calculateParentValue(0, 0, true);
        this.hasCalculateBenefit = true;
        this.changeFromUserInput = false;
        this.loading.dismiss();
        this.pmnToastService.showToast('Success');
        this.showNotifFreeRoomUp();
      }, err => {
        this.loading.dismiss();
        this.pmnToastService.showToast(`Error while calculating benefit. ${err}`);
      })
    }, err => {
      this.loading.dismiss();
      this.pmnToastService.showToast(`Error while calculating benefit. ${err}`);
    })
  }

  showNotifFreeRoomUp(){
    console.log("DEBUG_FREE_ROOM : RIDERPRO |", { data: this, activity: this.activityName, freeRoomUpFlag: this.data.freeRoomUpFlag})
    const isFreeRoomUpgrade: boolean = this.data.freeRoomUpFlag !== undefined ? this.data.freeRoomUpFlag : false;
    const isToastContent: string = "Hospital use free Room Upgrade, Please confirm to Hospital related to room price";
    return isFreeRoomUpgrade ? this.pmnToastService.showToast(isToastContent) : null;
  };

  removeMoneyFormat(data: any) {
    const jsonToSend = JSON.parse(JSON.stringify(data));

    jsonToSend.priorApprovalNo = this.childMessage.priorApprovalNo || '';

    // Remove number
    jsonToSend.remainingAnnualLimit = this.removeCurrency(jsonToSend.remainingAnnualLimit);
    jsonToSend.fixedAmmount = this.removeCurrency(jsonToSend.fixedAmmount);
    jsonToSend.basicRoomPrice = this.removeCurrency(jsonToSend.basicRoomPrice);
    jsonToSend.entitleRoom = this.removeCurrency(jsonToSend.entitleRoom);
    jsonToSend.prorationArea = this.removeCurrency(jsonToSend.prorationArea);
    jsonToSend.noClaimBonus = this.removeCurrency(jsonToSend.noClaimBonus);
    jsonToSend.deductible = this.removeCurrency(jsonToSend.deductible);
    jsonToSend.unpaidDowngradeClaim = this.removeCurrency(jsonToSend.unpaidDowngradeClaim);
    jsonToSend.prorationFactor = this.removeCurrency(jsonToSend.prorationFactor);
    jsonToSend.primeLmtBoostr = this.removeCurrency(jsonToSend.primeLmtBoostr);
    jsonToSend.claimPaid.claimSubmit = this.removeCurrency(jsonToSend.claimPaid.claimSubmit);
    jsonToSend.claimPaid.personalFee = this.removeCurrency(jsonToSend.claimPaid.personalFee);
    jsonToSend.claimPaid.claimDecline = this.removeCurrency(jsonToSend.claimPaid.claimDecline);
    jsonToSend.claimPaid.claimPaid = this.removeCurrency(jsonToSend.claimPaid.claimPaid);
    jsonToSend.totalUsage = this.removeCurrency(jsonToSend.totalUsage);

    jsonToSend.diagnose.forEach(diag => {
      diag.symptonDate1 = this.datePipe.transform(diag.symptonDate1, 'MM/dd/yy');

      diag.surgery.forEach(sg => {
        sg.detail.forEach(dt => {
          dt.amountSubmitted = this.removeCurrency(dt.amountSubmitted);
          dt.personalFee = this.removeCurrency(dt.personalFee);
        });
      });

      diag.benefitClaim.forEach(bc => {
        bc.innerLimit = this.removeCurrency(bc.innerLimit);
        bc.qty = this.removeCurrency(bc.qty);
        bc.totalClaimSubmit = this.removeCurrency(bc.totalClaimSubmit);
        bc.totalClaimPaid = this.removeCurrency(bc.totalClaimPaid);
        bc.totalClaimDecline = this.removeCurrency(bc.totalClaimDecline);
        bc.totalPersonalFee = this.removeCurrency(bc.totalPersonalFee);
        bc.invoice.forEach(inv => {
          inv.qty = this.removeCurrency(inv.qty);
          inv.amountSubmitted = this.removeCurrency(inv.amountSubmitted);
          inv.personalFee = this.removeCurrency(inv.personalFee);
          inv.claimPaid = this.removeCurrency(inv.claimPaid);
          inv.claimDecline = this.removeCurrency(inv.claimDecline);
        });
      });

      diag.diagCalculation.totalClaimSubmit = this.removeCurrency(diag.diagCalculation.totalClaimSubmit);
      diag.diagCalculation.personalFee = this.removeCurrency(diag.diagCalculation.personalFee);
      diag.diagCalculation.claimDecline = this.removeCurrency(diag.diagCalculation.claimDecline);
      diag.diagCalculation.claimPaid = this.removeCurrency(diag.diagCalculation.claimPaid);
    });

    return jsonToSend;
  }

  transformBenefit() {
    const anomaly = [];
    this.transformedBenefitArray = JSON.parse(JSON.stringify(this.data.diagnose)).map((d, i) => {
      const data = [];
      d.benefitClaim.map((b, i) => {
        b.originalIndex = i;
        if (b.benefitLevel == 'Y') {
          b.child = [];
          data.push(b);
        } else {
          if (b.inpatientFlag != data[data.length - 1].inpatientFlag) {
            anomaly.push(b);
          } else {
            data[data.length - 1].child.push(b);
          }
        }
      })
      return data;
    });
    this.calculateParentValue(0, 0, true);
    this.transformedBenefitAnomaly = [...anomaly];
    this.getHistoricalPlan(this.childMessage.admissionId, this.data.selectedEligibleRider);
  }

  calculateParentValue(diagnoseIndex, transformIndex, all = false) {
    const data = this.removeMoneyFormat(this.data);
    if (!all) {
      let result = {
        innerLimit: 0,
        qty: 0,
        amountSubmitted: 0,
        personalFee: 0,
        claimDecline: 0,
        claimPaid: 0
      };
      result = this.transformedBenefitArray[diagnoseIndex][transformIndex].child.reduce((acc, cur, i) => {
        acc.qty += data.diagnose[diagnoseIndex].benefitClaim[cur.originalIndex].invoice[0].qty;
        acc.amountSubmitted += data.diagnose[diagnoseIndex].benefitClaim[cur.originalIndex].invoice[0].amountSubmitted;
        acc.claimDecline += data.diagnose[diagnoseIndex].benefitClaim[cur.originalIndex].invoice[0].claimDecline;
        acc.claimPaid += data.diagnose[diagnoseIndex].benefitClaim[cur.originalIndex].invoice[0].claimPaid;
        acc.personalFee += data.diagnose[diagnoseIndex].benefitClaim[cur.originalIndex].invoice[0].personalFee;
        return acc;
      }, result);
      this.transformedBenefitArray[diagnoseIndex][transformIndex].invoice[0].qty = +result.qty.toFixed(2);
      this.transformedBenefitArray[diagnoseIndex][transformIndex].invoice[0].amountSubmitted = +result.amountSubmitted.toFixed(2);
      this.transformedBenefitArray[diagnoseIndex][transformIndex].invoice[0].claimDecline = +result.claimDecline.toFixed(2);
      this.transformedBenefitArray[diagnoseIndex][transformIndex].invoice[0].claimPaid = +result.claimPaid.toFixed(2);
      this.transformedBenefitArray[diagnoseIndex][transformIndex].invoice[0].personalFee = +result.personalFee.toFixed(2);
    } else {
      for (let i = 0; i < this.data.diagnose.length; i++) {
        for (let j = 0; j < this.transformedBenefitArray[i].length; j++) {
          let result = {
            innerLimit: 0,
            qty: 0,
            amountSubmitted: 0,
            personalFee: 0,
            claimDecline: 0,
            claimPaid: 0
          };
          result = this.transformedBenefitArray[i][j].child.reduce((acc, cur) => {
            acc.qty += data.diagnose[i].benefitClaim[cur.originalIndex].invoice[0].qty;
            acc.amountSubmitted += data.diagnose[i].benefitClaim[cur.originalIndex].invoice[0].amountSubmitted;
            acc.claimDecline += data.diagnose[i].benefitClaim[cur.originalIndex].invoice[0].claimDecline;
            acc.claimPaid += data.diagnose[i].benefitClaim[cur.originalIndex].invoice[0].claimPaid;
            acc.personalFee += data.diagnose[i].benefitClaim[cur.originalIndex].invoice[0].personalFee;
            return acc;
          }, result);
          this.transformedBenefitArray[i][j].invoice[0].qty = +result.qty.toFixed(2);
          this.transformedBenefitArray[i][j].invoice[0].amountSubmitted = +result.amountSubmitted.toFixed(2);
          this.transformedBenefitArray[i][j].invoice[0].claimDecline = +result.claimDecline.toFixed(2);
          this.transformedBenefitArray[i][j].invoice[0].claimPaid = +result.claimPaid.toFixed(2);
          this.transformedBenefitArray[i][j].invoice[0].personalFee = +result.personalFee.toFixed(2);
        }
      }
    }
  }

  prepareData() {
    if (this.data == null) {
      throw new Error('Data is not ready')
    }

    this.fullRoom = Array(this.data.diagnose.length).fill(false);
    this.searchbar = Array(this.data.diagnose.length).fill('displayNone');
    this.doctorSearchBar = Array(this.data.diagnose.length).fill('displayNone');
    this.searchbarSurgery = Array(this.data.diagnose.length).fill(null);
    for (let i = 0; i < this.searchbarSurgery.length; i++) {
      this.searchbarSurgery[i] = Array(this.data.diagnose[i].surgery.length).fill('displayNone');
    }
    for (let i = 0; i < this.data.diagnose.length; i++) {
      if (this.data.diagnose[i].icdSeq == 0) {
        this.data.diagnose[i].icdSeq = i + 1;
      }
    }
    this.data.diagnose.forEach(d => {
      d.benefitClaim.forEach(b => {
        if (b.benefitCode.slice(0, 2) == 'MR') {
          b.inpatientFlag = 'S';
        }
      })
    })
  }

  updateFullRoom(diagnoseIndex) {
    this.data.diagnose[diagnoseIndex].benefitClaim.forEach(benefit => {
      benefit.fullRoom = this.fullRoom[diagnoseIndex];
    });
  }

  getRemainingDays(dgIndex: number, bIndex: number, benefitCode: string) {
    let benefitCodePrefix = benefitCode.slice(0, 2);

    if (benefitCodePrefix == 'RB'){
      return this.data.remainingRoomAndBoard || 0;
    }
    if (benefitCodePrefix == 'IV') {
      return this.data.remainingICUVegetatif || 0;
    }
    if (benefitCodePrefix == 'IC') {
      return this.data.remainingICU || 0;
    }
    if (benefitCodePrefix == 'PT' || benefitCodePrefix == 'PY' || benefitCodePrefix == 'PI') {
      return this.data.remainingPhysiotheraphy || 0;
    }
    if (benefitCodePrefix == 'LO') {
      return this.data.lodging || 0;
    }
    if (benefitCodePrefix == 'DB') {
      return this.data.remainingDailyCashBenefit || 0;
    }
    if (benefitCodePrefix == 'HN') {
      return this.data.remainingHomeNursing || 0;
    }
    if (benefitCodePrefix == 'IG' || benefitCodePrefix == 'OG') {
      return this.data.remainingPhysiciatric || 0;
    }
    if (benefitCodePrefix == 'PC' || benefitCodePrefix == 'PD') {
      return this.data.remainingPalliative || 0;
    }
    return 0; // Default
  }

  qtyCannotZero(dgIndex, benefitIndex) {
    let benefit = this.data.diagnose[dgIndex].benefitClaim[benefitIndex].invoice[0];
    if (benefit.amountSubmitted != 0 && (benefit.qty == 0 || benefit.qty == '')) {
      benefit.qty = 1;
      this.pmnToastService.showToast("QTY cannot 0. QTY set to 1");
    }
  }

  paste(e) {
    console.log(e);
  }

  getHistoricalPlan(admissionId, rider) {
    let param = {
      admissionId: admissionId
    }

    this.pmnProvider.getHistoricalPlan(param).subscribe((auth => {
      auth.subscribe((resp: any) => {
        if (Array.isArray(resp)) {
          this.availableRider = resp.filter((item: any) => {
            return this.planHS.indexOf(item.riderCodeHistory) == -1 && this.planHSPlus.indexOf(item.riderCodeHistory) == -1;
          });
        }
      }, err => {
        console.error(err);
      })
    }))
    this.getPlan(rider);
  }

  getPlan(riderCode) {
    this.masterPlan = [];
    let par =
    {
      ridercode: riderCode.split("-")[0].trim(),
      admissionId: this.childMessage.admissionId,
    }
    this.pmnProvider.getPlan(par).subscribe(auth => {
      auth.subscribe((response: any) => {
        this.masterPlan = response.result;
        this.populateExGratiaFields();
      }, err => {
        this.pmnToastService.showToast(err);
      });
    });
  }

  onEligiblePlanOpt(selectedPlan) {
    // Reset fullroom
    this.data.fullRoom = false;
    this.masterPlan.forEach(e => {
      if (selectedPlan == e.plan) {
        this.data.selectedDeductible = e.deductible;
      }
    });
    this.loadAutoMapping(selectedPlan, this.data.switchPlan)
  }

  onClickSwitchPlan(value) {
    if (value) {
      this.data.switchPlan = true;
    }
    else {
      this.data.switchPlan = false;
      this.loadAutoMapping(null, false);
    }
  }

  loadAutoMapping(plan, isSwitchplan: boolean) {
    let description: any;
    this.availableRider.forEach(desc => {
      if (this.data.selectedEligibleRider == desc.riderCodeHistory) {
        description = desc.productNameHistory;
      }
    });
    let param = {
      caseId: this.childMessage.reffId,
      priorApprovalNo: this.childMessage.admissionId,
      activity: this.childMessage.activity,
      selectedRiderCode: isSwitchplan ? this.data.selectedEligibleRider : "",
      selectedRiderDescription: isSwitchplan ? description : "",
      selectedPlan: isSwitchplan ? plan : "",
      switchPlan: this.data.switchPlan
    }

    this.showLoading();
    this.pmnHospitalisationProvider.getBenefitMapping(param).subscribe(auth => {
      auth.subscribe((resp: any) => {
        this.loading.dismiss();
        this.mapNewBenefit(resp);
      }, err => {
        this.loading.dismiss();
        this.pmnToastService.showToast(`Error Load Automapping, ${err}`);
      })
    })
  }

  mapNewBenefit(data) {
    if (data.claimType != 'HS') {
      this.data = data;
      try {
        this.prepareData();
      } catch (err) {
        console.error(`Error while preparing data. ${err}`);
      }
      this.transformBenefit();
    }
    else {
      this.navCtrl.setRoot('PmnHospitalisationPage', { dataBenefit: { mapping: data, currentActivity: this.childMessage } });
    }
  }

  onBenefitInformationChanges(type){
    type == 'fullRoom' ? this.data.override = false : this.data.fullRoom = false;
  }

  startCalculation(){
    if (this.data.activeTreatmentDate != '' && (this.data.activeTreatmentDate < this.datePipe.transform(this.data.admissionDate, 'yyyy-MM-dd'))) {
      let alertTreatmentDate = this.alertCtrl.create({
        title: 'Notification',
        message: 'Make sure Active treatment date already updated',
        enableBackdropDismiss: false,
        buttons: [
          {
            text: 'Ok',
            handler: () => {
              this.benefitCalculation();
            }
          }
        ]
      });
      return alertTreatmentDate.present();
    }
    
    let emptyTreatmentDate = false;
    let teleHistDateValidation = false;
    let teleValidation = false;
    for (let i = 0; i < this.data.diagnose.length; i++) {
      this.data.diagnose[i].benefitClaim.some(val => {
        // cancer validation
        if (val.benefitCode.indexOf('SV') == 0 && this.data.activeTreatmentDate == "") {
          val.invoice.some(bc => {
            if (bc.amountSubmitted > 0 || bc.qty > 0)
              emptyTreatmentDate = true;
          })
        }
        // Telehealth validation
        if (['TS','TJ','LS'].indexOf(val.benefitCode.slice(0, 2)) != -1 && this.data.diagnose[i].telehealth.dischargeDateHistory == "") {
          val.invoice.some(bc => {
            if (bc.amountSubmitted != 0 || bc.qty != 0)
            teleHistDateValidation = true;
          })
        }

        // Telehealth other validation
        if(['H121', 'H131', 'H123', 'H133'].indexOf(this.data.riderCode.split(' ')[0].trim()) != -1){
          if(this.data.diagnose[i].telehealth.dischargeDateHistory.toLowerCase() == 'lainnya' && (this.data.diagnose[i].telehealth.diagnoseHistory == '' || this.data.diagnose[i].telehealth.otherDischargeDateHistory == '')){
            teleValidation = true;
          }
        }
      })
      if (emptyTreatmentDate) {
        this.pmnToastService.showToast(`Mandatory input active treatment date at diagnose ${i + 1}`);
        return;
      }

      if (teleHistDateValidation) {
        this.pmnToastService.showToast(`Mandatory input historical date`);
        return;
      }

      if (teleValidation) {
        this.pmnToastService.showToast(`Mandatory input diagnose and discharge date`);
        return;
      }
    }
    this.benefitCalculation();
  }

  psikiatriDischDate(polNo, admissionDate, dg) {
    this.historicalDischDate(polNo, admissionDate, '', false).then((resp: any) => {
      this.psikiatriHistory = resp;
      this.psikiatriHistory.push({
        "dischargeDate": "Lainnya",
        "rgpynum": "",
        "diagnose": ""
      });
      this.getDgHistoricalFromInit(dg);
    }).catch(error => {
      let data = [{ "dischargeDate": "Lainnya", "rgpynum": "", "diagnose": "" }]
      this.psikiatriHistory = data;
    });
  }

  getHistoricalDiag(polNo, data, diagIdx, benefitCode, select) {
    this.historicalDg(polNo, data.rgpynum).then((resp: any) => {
      if (resp.length == 1) {
        this.data.diagnose[diagIdx].benefitClaim.forEach((b, i) => {
          if (data.diagnose == "") {
            if (b.benefitCode == benefitCode) {
              this.loadHistoricalDgPsikiatri(diagIdx, i, data.diagnose, resp, true);
            }
          } else {
            this.loadHistoricalDgPsikiatri(diagIdx, i, data.diagnose, resp, false);
          }
        });
      } else {
        this.psikiatriDgHistory[diagIdx] = resp;
      }
    });
  }

  loadHistoricalDgPsikiatri(dgIndex, benefitIdx, diagnoseHistory, diagResp, isHistorical) {
    if (isHistorical) {
      this.data.diagnose[dgIndex].benefitClaim[benefitIdx].diagnoseHistory = diagResp[0].diagnose;
      this.psikiatriDgHistory[dgIndex] = diagResp;
    } else {
      this.data.diagnose[dgIndex].benefitClaim[benefitIdx].diagnoseHistory = diagnoseHistory;
      this.psikiatriDgHistory[dgIndex].push({
        "diagnose": diagnoseHistory,
      })
    }
  }

  getDgHistoricalFromInit(diag){
    diag.forEach((dg, dgIdx) => {
      dg.benefitClaim.forEach((benefit, benefitIdx) => {
        if (['IG', 'OG'].indexOf(benefit.benefitCode.slice(0, 2)) != -1 && (benefit.dischargeDateHistory != '' && benefit.dischargeDateHistory.toLowerCase() != 'lainnya')) {
          let histDate = this.psikiatriHistory.filter(d => d.dischargeDate == benefit.dischargeDateHistory)
          this.getHistoricalDiag(this.data.policyNo, histDate[0], dgIdx, benefit.benefitCode, false);
        }
      });
    })
  }

  getTeleFromInit(diag){
    diag.forEach((dg, dgIdx) => {
      this.selectTeleHistoricalDischDate(dg.telehealth.telehealthRelated, dg.telehealth.dischargeDateHistory, dgIdx);
    })
  }

  checkDiagnose(dgIdx, benefitIdx, lastDiagnoseIdx, benefitCode, isSelect){
    const e = (document.getElementById("lastDischargeDate")) as HTMLSelectElement;
    const selectedIdx =  e.selectedIndex;
    this.getHistoricalDiag(this.data.policyNo, this.psikiatriHistory[selectedIdx], dgIdx, benefitCode, isSelect);
  }

  changeLastDischargeDateFormat(date){
    !isNaN(Date.parse(date)) ? date = this.datePipe.transform(date, 'dd MMM yyyy') : date = date;
    return date;
  }

  loadStorageOpenCase() {
    let result: any
    this.pmnPayLoadHelper.getPmnCurrentActivity().then((payloadOpenCase) => {
      result = payloadOpenCase;
      result.roleDistribution != 'PMN_CLAIM_SETTLEMENT_DE' && result.activity == 'PMN CLAIM SETTLEMENT' ? this.disableFeature = true : this.disableFeature = false;
    })
  }

  historicalDischDate(polNo, admDate, bfCode, from) {
    const req = { chdrnum: polNo, admissionDate: this.datePipe.transform(admDate, 'yyyy-MM-dd'), benefitCode: bfCode, teleHealth: from };
    return new Promise((resolve, reject) => {
      this.pmnHospitalisationProvider.loadHistoricalDischargeDate(req).subscribe(auth => {
        auth.subscribe((value: any) => {
          value = value.sort((a, b) => {
            return new Date(b.dischargeDate).getTime() - new Date(a.dischargeDate).getTime();
          })
          value ? resolve(value) : reject('error');
        }, err => {
          reject('error: ' + err);
        });
      });
    });
  }

  historicalDg(polNo, rgpynum) {
    const req = { chdrnum: polNo, rgpynum: rgpynum };
    return new Promise((resolve, reject) => {
      this.pmnHospitalisationProvider.loadHistoricalDiag(req).subscribe(auth => {
        auth.subscribe((value: any) => {
          value ? resolve(value) : reject('error');
        }, err => {
          reject('error: ' + err);
        });
      });
    });
  }

  selectTeleHistoricalDischDate(data, dateHistory, idx) {
    let bCode: any;

    switch (data.toLowerCase()) {
      case 'cancer':
        bCode = 'CT%';
        break;
      case 'one day surgery':
        bCode = 'OD%'
        break;
      default:
        bCode = ''
        break;
    }
    this.historicalDischDate(this.data.policyNo, this.datePipe.transform(this.data.admissionDate, 'yyyy-MM-dd'), bCode, true).then((resp: any) => {
      this.telehealthDateHistory[idx] = resp;
      this.telehealthDateHistory[idx].push({
        "dischargeDate": "Lainnya",
        "rgpynum": "",
        "diagnose": ""
      });

      if (dateHistory != null && dateHistory != '') {
        let e = this.telehealthDateHistory[idx].filter(item => item.dischargeDate == dateHistory);
        this.loadHistoricalTele(e, idx);
      }
    }).catch(error => {
      let data = [{ "dischargeDate": "Lainnya", "rgpynum": "", "diagnose": "" }]
      this.telehealthDateHistory[idx] = data;
    });
  }

  loadHistoricalTele(e, dgIdx) {
    if (e[0].diagnose == "") {
      this.loadHistoricalDgTele(this.data.policyNo, e[0].rgpynum, dgIdx);
    }
    else {
      this.data.diagnose[dgIdx].telehealth.diagnoseHistory = e[0].diagnose;
      this.telehealthDgHistory[dgIdx] = e;
    }
  }
  
  selectTeleDg(data, idx){
    let e = this.telehealthDateHistory[idx].filter(item => item.dischargeDate == data);
    this.loadHistoricalTele(e,idx);
  }

  loadHistoricalDgTele(polNo, rgpynum, dgIdx) {
    this.historicalDg(polNo, rgpynum).then((resp: any) => {
      if (resp.length == 1) {
        this.data.diagnose[dgIdx].telehealth.diagnoseHistory = resp[0].diagnose;
      }
      this.telehealthDgHistory[dgIdx] = resp;
    }).catch(error => { console.log(error) }
    );
  }

  getRemainingTele(dgIndex, benefitIdx, benCode){
    let benefitCode = benCode.slice(0, 2);
    if (benefitCode == 'TS'){
      return this.data.diagnose[dgIndex].telehealth.remainingTeleRI || 0;
    }
    if (benefitCode == 'TJ'){
      return this.data.diagnose[dgIndex].telehealth.remainingTeleODS || 0;
    }
    if (benefitCode == 'LS'){
      return this.data.diagnose[dgIndex].telehealth.remainingTeleCancer || 0;
    }
  
    return 0;
  }

  clearDiagHistory(type, dgIdx, benIdx, value) {
    if (value.toLowerCase() == 'lainnya' && type == 'physiciatric') {
      this.data.diagnose[dgIdx].benefitClaim[benIdx].diagnoseHistory = '';
    }
    if (type == "teleRelated") {
      this.data.diagnose[dgIdx].telehealth.dateHistory = '';
      this.data.diagnose[dgIdx].telehealth.dischargeDateHistory = '';
      this.data.diagnose[dgIdx].telehealth.otherDischargeDateHistory = '';
      this.data.diagnose[dgIdx].telehealth.diagnoseHistory = '';
    }
    if (type == 'tele' && value.toLowerCase() == 'lainnya') {
      this.data.diagnose[dgIdx].telehealth.diagnoseHistory = '';
    }
  }

  agreementWithPSLAValue(value) {
    if (value == 'Y') {
      value = 'YES';
    }
    if (value == 'N') {
      value = 'NO';
    }
    if (value == '') {
      value = 'NO SETTING';
    }
    return value;
  }

}