import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { PmnProvider } from '../../../../providers/providers';
import { PmnPayloadHelperProvider } from '../../../../providers/pmn/pmnPayLoadHelper';
import { PmnToastService } from '../../../../providers/pmn/pmnToast';

@Component({
  selector: 'pmntabworkbasket',
  templateUrl: 'pmn-tab-workbasket.html'
})
export class PmnTabworkbasketComponent {
  @Input() tabIndex: any;
  @Input() refdata: any;
  tabsActive: any = 0;
  topUpLog: boolean = true;
  tabs: any[];
  titleTab: any;
  activity: any;

  constructor(public navCtrl: NavController,
    public navParams: NavParams, public pmnProvider: PmnProvider,
    public pmnPayLoadHelper: PmnPayloadHelperProvider,
    private pmnToastService: PmnToastService) {
  }

  ngOnInit() {
    console.log('Hello PmnTabworkbasketComponent Component');
  }

  ngOnChanges() {
    this.tabsActive = Number.parseInt(this.tabIndex);
  }

  createTabData() {
    this.pmnPayLoadHelper.getPmnCurrentActivity().then((currentActivity: any) => {
      this.tabs = [];

      let param = currentActivity.type == 'FINAL_BILL' ? currentActivity.type : currentActivity.role;
      this.pmnProvider.getTabByRole(param).subscribe(p1 => {
        p1.subscribe(response => {
          for (let i = 0; i < response.length; i++) {
            this.tabs.push({ id: i, label: response[i].tabname, page: response[i].state });
          }
          this.pmnPayLoadHelper.dismissLoading();
        });
      }, err => {
        this.pmnToastService.showToast(err);
        this.pmnPayLoadHelper.dismissLoading()
      });
    });
  }

  ngAfterViewInit() {
    console.log('ngAfterViewInit');
    this.createTabData();
  }

  changeTabs(i) {
    this.tabsActive = i;
    let pagename = this.getPage(i);
    this.goToPage(pagename);
  }

  getPage(tabIndex) {
    let page = '';
    for (let i = 0; i < this.tabs.length; i++) {
      if (this.tabs[i].id == tabIndex) {
        page = this.tabs[i].page;
        break;
      }
    }
    return page;
  }

  goToPage(page) {
    this.navCtrl.setRoot(page, { data: { currentActivity: this.refdata, additionalData: { decision: '' } } }).catch(function (e) {
      console.log(e);
    });

  }
}