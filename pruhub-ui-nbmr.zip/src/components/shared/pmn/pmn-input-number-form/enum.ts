/**
 *
 *
 * @export
 * @enum {number}
 */
export enum CleanInputParam {
  isCurrency = "currency",
  isLos = "los",
  isTempSuspend = "tempSuspend"
};

/**
 *
 *
 * @export
 * @enum {number}
 */
export enum inputNumberPrefixType {
  idr = "idr",
  percentage = "percentage"
};