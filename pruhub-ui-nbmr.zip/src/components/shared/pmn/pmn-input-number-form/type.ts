import { CleanInputParam, inputNumberPrefixType } from "./enum";

export type CleanInputParamTypes = CleanInputParam.isCurrency
  | CleanInputParam.isLos
  | CleanInputParam.isTempSuspend;
export type InputNumberPrefixTypes = inputNumberPrefixType.idr 
  | inputNumberPrefixType.percentage