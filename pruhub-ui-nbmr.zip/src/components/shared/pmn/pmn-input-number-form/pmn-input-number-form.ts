import { Component, Input } from '@angular/core';
import { PmnForm } from '../../../../models/pmn/pmn-form/PmnForm'
import { UtilityPMNProvider } from '../../../../providers/pmn/utilitypmn';
import { CleanInputParam, inputNumberPrefixType } from './enum';
import { CleanInputParamTypes, InputNumberPrefixTypes } from './type';

/**
 * @name pmnInputNumberForm
 * @description
 * a input number for handle currency in PMN Pruhub
 * only coma and number, decimal is 2 digit after coma handler for user input
 * 
 * @usage
 * ```html
 * <pmnInputNumberForm
 *   isLabel="Number Input Form"
 *   isPlaceholder="Number Input Form Placeholder"
 *   isPrefix="idr"
 *   [isValue]="dataInputNumberForm"
 *   [cleanInputParam]="currency" => deprecated 
 *   [decimalUse]="true"
 *   [isMaxDigit]="20"
 *   [isDisabled]="true" 
 *   (inputBlur)="dataInputNumberForm = $event"
 *   [isValidationError]="validationError"
 *   [isValidationMessageError]="validationErrorMessage"
 * >
 * </pmnInputNumberForm>
 * ```
 * * @advance
 * pmnInputNumberForm props
 * | Option                   | Type      | Description                                               |
 * |--------------------------|-----------|-----------------------------------------------------------|
 * | cleanInputParam          | `string`  | set "currency" | "los" | "tempSuspend" => deprecated      |
 * | isLabel                  | `string`  | value for set title label form input                      |
 * | isPlaceholder            | `string`  | value for set placeholder form input                      |
 * | isPrefix                 | InputNumberPrefixTypes  | show prefix in input                        |
 * | decimalUse               | `string`  | triger for use decimal or no                              |
 * | isDisabled               | `boolean` | triger disable form input                                 |
 * | isRequired               | `boolean` | triger appear start in label form                         |
 * | isValue                  | `string`  | state value  2 way data binding                           |
 * | isValidationError        | `boolean` | for triger appear error form input                        |
 * | isValidationMessageError | `boolean` | for triger appear error message form input                |
 * | inputBlur                | `string`  | get value from selected list options                      |
 * | isMaxDigit               | `number`  | set max digit, default is 20                              |
 */

@Component({
  selector: 'pmnInputNumberForm',
  templateUrl: 'pmn-input-number-form.html'
})
export class PmnInputNumberFormComponent extends PmnForm {
  @Input() cleanInputParam: CleanInputParamTypes = CleanInputParam.isCurrency;
  @Input() isPrefix: InputNumberPrefixTypes = inputNumberPrefixType.idr
  @Input() decimalUse: boolean = true;
  @Input() isMaxDigit: number = 20;
  readonly decimalScale: number = 2;
  valueIsMax: boolean = false;
  useComma: boolean = false;
  keyboardKeyControlAIsPressed = false
  constructor(
    private util: UtilityPMNProvider
  ) {
    super()
  };

  ngOnInit() {
    this.inputBlur.emit(this.isValue);
    this.isLabel = this.capitalizingTitle(this.isLabel);
    this.isValue !== "" && this.populateMoneyFormat();
    this.isValue !== "" && this.makeMoneyFormat();
    this.valueIsMax = this.valueIsMaxChecker();
    this.changeUseComma(this.isValue);
  };

  populateMoneyFormat() {
    if (typeof this.isValue == 'string' && this.isValue !== '') {
      this.isValue = this.isValue.replace('.', ',');
    };
  };

  inputChange(): void {
    return this.makeMoneyFormat()
  };

  makeMoneyFormat(): void {
    this.isValue = this.moneyFormater(this.isValue)
  };

  modelChangeHandler(event: string): void {
    this.isValue = event
  };

  useCommaChecker(value: string): boolean {
    return /\,+/g.test(value)
  };

  valueIsMaxChecker(): boolean {
    const getValue = this.isValue.replace(/\.+/g, "").split(",")[0]
    return getValue === undefined
      ? false
      : getValue.length >= this.isMaxDigit;
  };

  decimalIsMaxChecker(): boolean {
    const getDecimal = this.isValue.replace(/\.+/g, "").split(",")[1]
    return getDecimal === undefined
      ? false
      : getDecimal.length >= this.decimalScale;
  };

  backspaceHandler(event: string): void {
    this.valueIsMaxChecker() &&
      this.valueIsMax &&
      (this.valueIsMax = false);
  };

  onPaste(event: { clipboardData: any; target: { value: any; }; }) {
    let clipboardData = event.clipboardData;
    let pastedText = clipboardData.getData('text');
    var numberRegex = /\d+/g;
    const valueIsNumber = numberRegex.test(pastedText);

    if(!valueIsNumber) {
      return false;
    }else{
      this.keyboardKeyControlAIsPressedReset()
      const matchIsNumber = pastedText.match(numberRegex);
      const pasted = matchIsNumber.join("").slice(0,this.isMaxDigit);
      this.isValue = pasted;
      this.isValue !== "" && this.makeMoneyFormat();
      return false
    }
  };

  keyboardKeyControlAIsPressedReset(){
    this.valueIsMax = false
    this.useComma = false
    this.keyboardKeyControlAIsPressed = false
  };

  numberAndComaOnly(event: KeyboardEvent): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    let _vm = this.valueIsMaxChecker();
    this.valueIsMax = _vm;

    this.keyboardKeyControlAIsPressed && (
      this.isValue = "",
      this.keyboardKeyControlAIsPressedReset()
    );

    if (charCode === 44) return this.decimalUse;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) return false;

    if (this.useComma && this.decimalIsMaxChecker()) return false;
    if (this.valueIsMax && this.useComma && this.decimalIsMaxChecker()) return false;
    if (this.valueIsMax && !this.useComma) return false;
    return true;
  };

  moneyFormater(val): string {
    if (val == null || Number.isNaN(val)) {
      val = 0;
      val = val.toFixed(this.decimalScale);
    };
    if (val == 0 || val == '0') return val;
    if (typeof val == 'number' && val != 0) {
      val = val.toFixed(this.decimalScale);
      val = val.replace('.', ',');
    };
    if (typeof val == 'string' && val.indexOf('0,') == 0) {
      return val;
    };
    return this.util.format(val);
  };

  onBlur() {
    this.autoAddDecimalHandler();
  };

  autoAddDecimalHandler() {
    this.isValue !== '' &&
      this.isValue.indexOf(',') == -1 &&
      Number(this.isValue) === Number('0') &&
      (this.isValue = this.moneyFormater('0'));

    this.isValue.indexOf(',') == -1 &&
      this.isValue !== '' &&
      (this.isValue = `${this.isValue},00`);

    this.isValue.indexOf(',') != -1 &&
      (this.isValue = this.moneyFormater(this.isValue));

    this.cleanInput(this.isValue);
  };

  controlAHandler(event: KeyboardEvent) {
    this.changeControlAIsPressed();
  };

  changeControlAIsPressed() {
    this.valueIsMax && this.useComma && (this.keyboardKeyControlAIsPressed = true)
    this.valueIsMax && (this.keyboardKeyControlAIsPressed = true);
    this.useComma && (this.keyboardKeyControlAIsPressed = true);
  };

  changeUseComma(val) {
    this.useComma = this.useCommaChecker(val);
  };

  /**
   * @name cleanInput
   * coma no more than 1 
   * coma accepted after numbers
   * decimal is 2 digit after coma
   * whitespace - leading zero handler
   */
  cleanInput(val): string {
    this.changeUseComma(val)

    if (val === "," && val.length === 1) {
      val = ""
    };
    val = val.replace(/\,+/g, ',')

    if (val == null || Number.isNaN(val)) {
      val = 0
      val = val.toFixed(this.decimalScale);
    };

    this.inputBlur.emit(this.isValue);
    return val;
  };
};