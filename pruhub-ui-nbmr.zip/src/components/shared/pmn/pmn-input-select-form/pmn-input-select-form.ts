import { Component, Input, Output, EventEmitter } from '@angular/core';
import { PmnForm } from '../../../../models/pmn/pmn-form/PmnForm';

export interface PmnInputSelectOptions {
  value: string;
  label: string;
};

/**
 * @description 
 * 
 * @export
 * @class PmnInputSelectFormComponent
 * @extends {PmnForm}
 */
@Component({
  selector: 'pmnInputSelectForm',
  templateUrl: 'pmn-input-select-form.html'
})
export class PmnInputSelectFormComponent extends PmnForm {
  @Output() onChangeHandler = new EventEmitter<string>();
  @Input() options: PmnInputSelectOptions[] = [
    {
      label: "Ya",
      value: "y"
    },
    {
      label: "Tidak",
      value: "n"
    }
  ];
  ngOnInit() {
    this.inputBlur.emit(this.isValue);
    this.isLabel = this.capitalizingTitle(this.isLabel);
    this.isPlaceholder = this.capitalizingTitle(this.isPlaceholder);
  };
  onBlur = (): void => {
    this.inputBlur.emit(this.isValue);
    this.onChangeHandler.emit(this.isValue);
  };
};