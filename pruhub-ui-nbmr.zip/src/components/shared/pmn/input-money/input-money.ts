import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'input-money',
  templateUrl: 'input-money.html'
})
export class InputMoneyComponent {

  constructor() {
    console.log('Hello InputMoneyComponent Component');
  }

  @Output() inputBlur = new EventEmitter<string>();
  @Input() val: string = '';
  @Input() placeholder: string = '';
  @Input() disabled: boolean = false;
  @Input() decimalLength: number = 2;

  ngOnInit() {
    if (this.val && !Number.isNaN(+this.val)) {
      this.val = this.toMoneyFormat(+this.val);
      this.inputBlur.emit(this.val);
    }
  }

  onBlur() {
    this.val = this.toMoneyFormat(this.moneyToNumber(this.val));
    this.inputBlur.emit(this.val);
  }

  toMoneyFormat(value: number | string, format = 'id') {
    if (value == '' || value == '') return '0';
    return new Intl.NumberFormat('id', {
      minimumFractionDigits: this.decimalLength,
      maximumFractionDigits: this.decimalLength
    }).format(+value);
  }

  moneyToNumber(value: string, format = 'id') {
    let cleanNumber = '';
    if (value == '' || value == '') return '0';
    if (format == 'id') {
      cleanNumber = value.replace(/\./g, '').replace(/\,/g, '.');
      // If value is not using idr format then it will return NaN number
      if (Number.isNaN(+cleanNumber)) {
        let firstDotIndex = cleanNumber.indexOf('.');
        let secondDotIndex = cleanNumber.indexOf('.', firstDotIndex + 1);
        if (secondDotIndex != -1) {
          cleanNumber = cleanNumber.slice(0, secondDotIndex);
        }
        if (Number.isNaN(+cleanNumber)) return '0';
        return cleanNumber.slice(0, firstDotIndex + this.decimalLength + 1);
      }
    }
    if (Number.isNaN(+cleanNumber)) return '0';
    return cleanNumber;
  }

  preventNonNumericalInputDown(e) {
    let val = e.target.value;
    val = this.removeAllNonNumeric(val);
    e.target.value = val;
  }

  preventNonNumericalInputUp(e) {
    let val = e.target.value;
    val = this.removeAllNonNumeric(val);
    e.target.value = val;
  }

  removeAllNonNumeric(val: string): string {
    return val.replace(/[^0-9,.]/g, '');
  }

}
