import { Component, Input } from '@angular/core';
import { PmnForm } from '../../../../models/pmn/pmn-form/PmnForm';
/**
 * @description
 * @export
 * @class PmnInputTextFormComponent
 * @extends {PmnForm}
 */
@Component({
  selector: 'pmnInputTextForm',
  templateUrl: 'pmn-input-text-form.html'
})
export class PmnInputTextFormComponent extends PmnForm {
  @Input() isMaxCharlength: string = "100";
  ngOnInit() {
    this.inputBlur.emit(this.isValue);
    this.isLabel = this.capitalizingTitle(this.isLabel);
    this.isPlaceholder = this.capitalizingTitle(this.isPlaceholder);
  };
  onBlur = () => this.inputBlur.emit(this.isValue);
};