import { Component, Input } from '@angular/core';
import { PmnForm } from '../../../../models/pmn/pmn-form/PmnForm';
/**
 * @description
 * @export
 * @class PmnInputTextareaComponent
 * @extends {PmnForm}
 */
@Component({
  selector: 'pmnInputTextareaForm',
  templateUrl: 'pmn-input-textarea-form.html'
})
export class PmnInputTextareaComponent extends PmnForm {
  @Input() isRows: string = "8";
  @Input() isMaxCharlength: string = "2500";
  isErrorMaxCharLength: boolean = false;
  ngOnInit() {
    this.inputBlur.emit(this.isValue);
    this.isLabel = this.capitalizingTitle(this.isLabel);
    this.isPlaceholder = this.capitalizingTitle(this.isPlaceholder);
  };
  onBlur = (): void => {
    this.inputBlur.emit(this.isValue);
    this.onCheckLength();
  };
  onKeyup = (): void => {
    this.onCheckLength();
  };
  onCheckLength = (): void => {
    this.isValue.length === Number(this.isMaxCharlength) 
      ? ( this.isErrorMaxCharLength = true )
      : ( this.isErrorMaxCharLength = false );
  };
  public getReport = (): string => `Max ${this.isValue.length} of ${this.isMaxCharlength} characters`;
};