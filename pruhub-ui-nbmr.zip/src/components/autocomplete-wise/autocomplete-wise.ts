import { Component, Input, forwardRef, SimpleChanges } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

/**
 * Generated class for the AutocompleteWiseComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */

const noop = () => {
};

export const AUTOCOMPLETE_WISE_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => AutocompleteWiseComponent),
  multi: true
};

interface OnChanges {
  ngOnChanges(changes: SimpleChanges): void
}

@Component({
  selector: 'autocomplete-wise',
  templateUrl: 'autocomplete-wise.html',
  providers: [AUTOCOMPLETE_WISE_CONTROL_VALUE_ACCESSOR]
})
export class AutocompleteWiseComponent implements ControlValueAccessor, OnChanges {

  @Input() data: any;
  @Input() placeholder: any;
  @Input() initValue: any;
  @Input() multi?: boolean = false;
  @Input() dataMultiEdit?: any;
  @Input() close?: boolean = false;

  constructor() {
    this.text = 'Hello World';

    let length_char = 10;
    let characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let charactersLength = characters.length;
    for (let i = 0; i < length_char; i++) {
      this.id_autocomplete += characters.charAt(Math.floor(Math.random() * charactersLength));
      this.id_autocomplete_result += characters.charAt(Math.floor(Math.random() * charactersLength + 1));
    }
  }

  async ngOnChanges(changes: SimpleChanges) {
    // console.log('change ', changes);
    
    if ( changes.data ) {
      if ( changes.data.firstChange == false ) {
        this.data = changes.data.currentValue;
        clearInterval(this.loadData);
        this.getData();
        // console.log('all data ', this.data, changes.data);
      }
    }

    // pakai param [close]="your data" jika ingin nge hapus data dari luar component, dan harus boolean true
    if ( changes.close && changes.close.currentValue === true && !this.multi) {
      this.resultAPI.filter((x, idx) => {
        this.showHideData[idx] = true;
        return x;
      })
    }
    
    // for remove data multi
    if ( changes.close && changes.close.currentValue === true && this.multi ) {
      await this.closeDataMulti();
    }
  }

  text: string;
  id_autocomplete: string;
  id_autocomplete_result: string;
  db: any = [];
  dbVal: any = [];
  resultAPI: any = [];
  listCount: number;
  loadData: any;

  showHide = {}

  dataMulti: any = [];
  showHideData: any = [];
  takeData: any = [];
  indexTakeData: any = [];
  valueDataMulti: any = [];
  lastShowHideData: any = [];

  ngOnInit() {
    this.startPage();

    this.showHide[this.id_autocomplete] = false;
    this.showHide[this.id_autocomplete_result] = false;

    // console.log('this multi ', this.multi)
  }

  getData() {
    let data = this.data
    this.db = data.map((e, i) => {
      return e.text;
    })
    this.dbVal = data.map((e, i) => {
      return e.value;
    })
    this.showHideData = data.map((e, i) => { return true })

    this.innerValue = data;
    this.writeValue(this.initValue)

    // console.log('init value ', this.initValue)

    this.resultAPI = data.map((e, i) => {
      return e.text;
    })

    if ( this.multi ) {
      let db = this.db;
      let dbVal = this.dbVal;
      let dataMultiEdit = this.dataMultiEdit;
      let showHideData = this.showHideData;

      // this.takeData.push( dataText );
      // this.valueDataMulti.push( data );
      // this.indexTakeData.push( idx );


      for (let i = 0; i < dbVal.length; i++) {
        for (let j = 0; j < dataMultiEdit.length; j++) {
          if ( dbVal[i] == dataMultiEdit[j]) {
            showHideData[i] = false;
            this.takeData.push( db[i] )
            this.valueDataMulti.push( dataMultiEdit[j] )
            this.indexTakeData.push( i )
          }
        }

        if ( i+1 == dbVal.length ) {
          
          let result = this.resultAPI;
          let showHideData = this.showHideData;
          
          // var filteredArr = result.filter((x, idx) => {
          result.filter((x, idx) => {
            if ( showHideData[idx] ) {
              this.lastShowHideData.push(true);
              return x;
            } else {
              this.lastShowHideData.push(false);
            }
          });
          
          // this.db = filteredArr;
          // console.log('ini sudah di akhir data ', i+1, this.showHideData, this.lastShowHideData, filteredArr);
        }
      }

      // console.log(' when edit ', dbVal, showHideData)
    }


    // console.log('data full ', this.resultAPI, this.db, this.data)
  }

  startPage() {
    this.loadData = setInterval(() => {

      if (this.data.length < 1) {
        // console.log('data autocomplete is empty')
      } else {
        this.getData()
        clearInterval(this.loadData)
      }

    }, 500)

  }

  //The internal data model
  public innerValue: any = '';

  //Placeholders for the callbacks which are later providesd
  //by the Control Value Accessor
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  //get accessor
  get value(): any {
    return this.innerValue;
  };

  //set accessor including call the onchange callback
  set value(v: any) {
    // console.log('value ', v, this.innerValue)
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
    }
  }

  //From ControlValueAccessor interface
  writeValue(value: any) {
    // console.log('writeValue ', value)
    if (value !== this.innerValue) {
      this.innerValue = value;
    }
  }

  //Set touched on blur
  onBlur() {
    this.onTouchedCallback();
  }

  registerOnChange(fn: any): void {
    this.onChangeCallback = fn
  }

  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
  }

  focusInput() {
    this.showHide[this.id_autocomplete_result] = true;
  }

  focusOutInput() {
    setTimeout(() => {
      this.showHide[this.id_autocomplete_result] = false;
    }, 300)
  }

  chooseData(evt, idx) {
    // console.log('chooseData ', evt, idx)

    let allData = this.data;
    let val = evt.target.innerText;

    // console.log('show hide before ', this.showHideData);
    
    for (let i = 0; i < allData.length; i++) {
      if (val == allData[i].text) {
        let data = this.data[i].value;
        let dataText = this.data[i].text;
        
        
        if (!this.multi) {
          this.innerValue = data;
          this.writeValue(data);
          this.onChangeCallback(data);
        } else {
          this.showHideData[idx] = false;
          this.lastShowHideData[idx] = false;
          this.takeData.push( dataText );
          this.valueDataMulti.push( data );
          this.indexTakeData.push( idx );
          
          this.writeValue(this.valueDataMulti);
          this.onChangeCallback(this.valueDataMulti);

          this.innerValue = ' ';
          this.initValue = ' ';
          setTimeout(() => {
            this.innerValue = '';
            this.initValue = '';
            this.filter();
          }, 300);
        }

        this.showHide[this.id_autocomplete_result] = false;
      }
    }
  }

  removeDataInput() {
    this.resultAPI.filter((x, idx) => {
      this.showHideData[idx] = true;
      return x;
    })
    this.innerValue = '';
    this.writeValue('');
    this.onChangeCallback('');
  };

  async closeDataMulti() {
    let showHideData = this.showHideData;
    const data = this.data;

    // for delete data in array by index;
    data.map((dd, idx) => {
      showHideData[ idx ] = true;

      if ( idx + 1 === data.length ) {
        this.indexTakeData = [];
        this.takeData = [];
        this.valueDataMulti = [];
      }
    })
  }

  async closeData(evt, idx) {
    let showHideData = this.showHideData;
    let takeData = this.takeData;
    let indexTakeData = this.indexTakeData;
    let valueDataMulti = this.valueDataMulti;

    // for delete data in array by index;
    let a = indexTakeData.splice( idx, 1 )[0];
    showHideData[ a ] = true;
    this.lastShowHideData[ a ] = true;
    takeData.splice( idx, 1 );
    valueDataMulti.splice( idx, 1 );

    this.writeValue(this.valueDataMulti);
    this.onChangeCallback(this.valueDataMulti);

  }

  filter(evt?) {
    let val:string = evt ? evt.target.value : '';
    let result = this.resultAPI;
    
    // console.log('result api ', result)
    
    var str = val.toUpperCase()
    // var filteredArr = result.filter((x, idx) => {
    result.filter((x, idx) => {
      let resFilter = x.toUpperCase().includes(str);

      // console.log('result search ', resFilter, this.showHideData[idx], idx);
      if ( this.multi ) {
        if ( resFilter && this.lastShowHideData[idx] ) {
          this.showHideData[idx] = true;
          return resFilter;
        } else {
          this.showHideData[idx] = false;
        }
      } else {
        if ( resFilter ) {
          this.showHideData[idx] = true;
          return resFilter;
        } else {
          this.showHideData[idx] = false;
        }
      }

    })

    // let finish = filteredArr;

    // console.log('filteredArr ', finish, this.showHideData);

    // this.db = filteredArr;
  }

}
