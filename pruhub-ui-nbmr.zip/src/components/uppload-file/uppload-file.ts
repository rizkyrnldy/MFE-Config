import { UpploadFileProvider, MainMenuProvider } from './../../providers/providers';
import { Component, Input } from '@angular/core';

/**
 * Generated class for the UpploadFileComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'uppload-file',
  templateUrl: 'uppload-file.html'
})
export class UpploadFileComponent {
  listFile:any=[];
  credential:string;
  text: string;
  // @Input('jobUrl') jobUrl:string;
  constructor(public upploadFileProvider : UpploadFileProvider,
    public mainMenu : MainMenuProvider) {
      this.credential = this.mainMenu.username;
  }
  uploadFile(event:any):void{
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      console.log(element)
      this.listFile.push(element)
    }  
    this.upploadFileProvider.setFileToStorage(this.listFile);
  }
  deleteImgHandler(filename:any){
    this.listFile = this.listFile.filter((res) => {
      return res.name.indexOf(filename) === -1;
    })
    this.upploadFileProvider.setFileToStorage(this.listFile);
  }
}
