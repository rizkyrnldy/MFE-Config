import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { TiffImageComponent } from './tiff-image/tiff-image';
import { RichTextComponent } from './rich-text/rich-text';
import { ExpandableComponent } from './shared/phs/phs-expandable/phs-expandable';
import { DocumentViewerComponent } from './shared/phs/phs-document-viewer/phs-document-viewer';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PaginationComponent } from './shared/phs/phs-pagination/phs-pagination';
import { StickyContainerComponent } from './shared/phs/phs-sticky-container/phs-sticky-container';
import { PmnTabworkbasketComponent } from './shared/pmn/pmn-tab-workbasket/pmn-tab-workbasket';
import { PmnTitleActivityComponent } from './shared/pmn/pmn-title-activity/pmn-title-activity';
import { InputMoneyComponent } from './shared/pmn/input-money/input-money';
import { HospitalisationComponent } from './shared/pmn/pmn-hospitalisation/hospitalisation';
import { PmnHospitalisationHsComponent } from './shared/pmn/pmn-hospitalisation-hs/pmn-hospitalisation-hs';
import { AutocompleteWiseComponent } from './autocomplete-wise/autocomplete-wise';
import { PipesModule } from './../pipes/pipes.module';
import { DirectivesModule } from './../directives/directives.module';
import { PmnHospitalisationPruCermatComponent } from './shared/pmn/pmn-hospitalisation-pru-cermat/pmn-hospitalisation-pru-cermat';
import { PmnHospitalisationCHComponent } from './shared/pmn/pmn-hospitalisation-ch/pmn-hospitalisation-ch';
import { PmnHospRiderPro } from './shared/pmn/pmn-hospitalisation-rider-pro/pmn-hospitalisation-rider-pro';
import { PmnInputNumberFormComponent } from './shared/pmn/pmn-input-number-form/pmn-input-number-form';
import { PmnInputSelectFormComponent } from './shared/pmn/pmn-input-select-form/pmn-input-select-form';
import { PmnInputTextareaComponent } from './shared/pmn/pmn-input-textarea-form/pmn-input-textarea-form';
import { PmnInputTextFormComponent } from './shared/pmn/pmn-input-text-form/pmn-input-text-form';

// PRULADYS
import { LadysClaimInformationFormComponent } from './ladys/ladys-claim-information-form/ladys-claim-information-form';
import { LadysClaimDocumentFormComponent } from './ladys/ladys-claim-document-form/ladys-claim-document-form';
import { LadysClaimDocumentsTableComponent } from './ladys/ladys-claim-documents-table/ladys-claim-documents-table';

@NgModule({
	declarations: [TiffImageComponent, RichTextComponent, ExpandableComponent,
		DocumentViewerComponent,
		PaginationComponent,
		PmnTabworkbasketComponent,
		PmnTitleActivityComponent,
		StickyContainerComponent,
		HospitalisationComponent,
		AutocompleteWiseComponent,
		PmnHospitalisationHsComponent,
		LadysClaimInformationFormComponent,
		LadysClaimDocumentFormComponent,
		LadysClaimDocumentsTableComponent,
		InputMoneyComponent,
		PmnHospitalisationPruCermatComponent,
		PmnHospitalisationCHComponent,
		PmnHospRiderPro,
		PmnInputNumberFormComponent,
		PmnInputSelectFormComponent,
		PmnInputTextareaComponent,
		PmnInputTextFormComponent
	],
	imports: [
		IonicModule, 
		PdfViewerModule,
		DirectivesModule,
		PipesModule
	],
	exports: [TiffImageComponent, RichTextComponent, ExpandableComponent,
		DocumentViewerComponent,
		PaginationComponent,
		PmnTabworkbasketComponent,
		PmnTitleActivityComponent,
		StickyContainerComponent,
		HospitalisationComponent,
		AutocompleteWiseComponent,
		PmnHospitalisationHsComponent,
		LadysClaimInformationFormComponent,
		LadysClaimDocumentFormComponent,
		LadysClaimDocumentsTableComponent,
		InputMoneyComponent,
		PmnHospitalisationPruCermatComponent,
		PmnHospitalisationCHComponent,
		PmnHospRiderPro,
		PmnInputNumberFormComponent,
		PmnInputSelectFormComponent,
		PmnInputTextareaComponent,
		PmnInputTextFormComponent
	]
})
export class ComponentsModule { }
