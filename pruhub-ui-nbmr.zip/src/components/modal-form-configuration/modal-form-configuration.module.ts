import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalFormConfigurationPage } from './modal-form-configuration';

@NgModule({
  declarations: [
    ModalFormConfigurationPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalFormConfigurationPage),
  ],
})
export class ModalFormConfigurationPageModule {}
