import {
  Component,
} from '@angular/core';
import {
  IonicPage,
  NavController,
  NavParams,
  ViewController,
  // LoadingController
} from 'ionic-angular';

import { AlertController } from "ionic-angular/components/alert/alert-controller";

/**
 * Generated class for the ModalFormConfigurationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal-form-configuration',
  templateUrl: 'modal-form-configuration.html',
})
export class ModalFormConfigurationPage {
  public label: Object;
  public username: any;
  public formInit: any;
  public formInput: object;
  public response: any;
  public payload: any;
  public loader: any;
  public data: any;
  public file: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public viewCtrl: ViewController,
    public alertCtrl: AlertController,
    // private loadingCtrl: LoadingController,
  ) {

    this.data = {};
    this.data = { ...this.navParams.data };
    const modal = this.data.modalFormInit;
    this.formInput = {};
    this.label = modal.label;
    this.formInit = modal.formInit;
    this.formInput = { ...modal.formInput };

  }

  ionViewDidLoad() {
    // console.log('ionViewDidLoad ModalFormConfigurationPage');
  }

  previewFile(e: any, slug: any) {
    let file = e.target.files[0];
    var reader = new FileReader();
    reader.onloadend = () => {
      // console.log(reader.result);
      this.formInput[slug] = reader.result;
    }
    if (file && file.type == "image/svg+xml" && file.size < 1 * Math.pow(10, 6)) {
      reader.readAsText(file);
      let formIndex = 0;
      this.formInit.map((data, index) => {
        if (data.slug == slug) {
          formIndex = index
        }
      })
      this.formInit[formIndex].isEmpty = false;
    } else {
      alert("wrong file type or no file provided");
    }

  }

  inputHandler(e: any, slug: any) {
    let value = e.target.value;
    this.formInput[slug] = value;
    let formIndex = 0;
    this.formInit.map((data, index) => {
      if (data.slug == slug) {
        formIndex = index
      }
    })
    this.formInit[formIndex].isEmpty = false;
    // e.target.value = this.formInput[slug];
  }

  isEmptyHandler(slug: any) {
    let formIndex = 0;
    this.formInit.map((data, index) => {
      if (data.slug == slug) {
        formIndex = index
      }
    })
    this.formInit[formIndex].isEmpty = false;
  }

  errorHandler(error) {
    const alert = this.alertCtrl.create({
      title: "Warning",
      message: error,
      buttons: [
        {
          text: "ok",
        }
      ]
    });
    alert.present();
  }

  cancel() {
    this.viewCtrl.dismiss({
      section: 'cancel'
    })
  }

  save() {
    this.formInit = this.formInit.map((data) => {
      const dat = this.formInput[data.slug]
      if (data.input.type === 'number') {
        this.formInput[data.slug] = String(dat).trim() ? String(dat).trim() : 0;
      } else {
        this.formInput[data.slug] = String(dat).split(";").filter((e) => e != '').join(";").trim();
      }
      return {
        ...data,
        isEmpty: data.input.required ? this.formInput[data.slug] == '' : false,
      }
    })

    if (this.formInit.filter((e) => e.isEmpty).length === 0) {
      var changed = false;
      this.formInit.map((l) => {
        if (this.formInput[l.slug] != this.data.modalFormInit.formInput[l.slug]) {
          changed = true;
        };
      })
      if (changed) {
        this.viewCtrl.dismiss({
          section: 'submit',
          formInput: this.formInput,
        })
      } else {
        this.viewCtrl.dismiss({
          section: 'cancel',
        })
      }
    }
  }

}
