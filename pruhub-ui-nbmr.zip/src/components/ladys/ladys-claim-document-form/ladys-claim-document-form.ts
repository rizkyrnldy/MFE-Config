import { Component } from '@angular/core';

/**
 * Generated class for the LadysClaimDocumentFormComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'ladys-claim-document-form',
  templateUrl: 'ladys-claim-document-form.html'
})
export class LadysClaimDocumentFormComponent {

  file = {
    id_card: null,
    claim_form: null,
    original_certificate: null,
    medical_resume: null,
    lab_examination_result: null,
    bank_account_book: null,
    insurable_interest_documents: null,
    death_certificate: null,
    id_card_beneficiary: null,
    driving_license_beneficiary: null,
    amendment: null,
    police_report: null,
    other_documents: null,
  }

  constructor() {
    console.log('Hello LadysClaimDocumentFormComponent Component');
  }

}
