import { Component, Input } from '@angular/core';

/**
 * Generated class for the LadysClaimInformationFormComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'ladys-claim-information-form',
  templateUrl: 'ladys-claim-information-form.html'
})
export class LadysClaimInformationFormComponent {

  dataArray: any;
  valueCi: any[] = [
    {
      desc: 'Critical Illness date < 90 days from Issued date (Disease)',
      value: 'Critical Illness date < 90 days from Issued date (Disease)'
    },
    {
      desc: 'Critical Illness date < Issued date',
      value: 'Critical Illness date < Issued date'
    },
    {
      desc: 'Critical Illness (Disease) Caused include in the policy exclusion',
      value: 'Critical Illness (Disease) Caused include in the policy exclusion'
    },
    {
      desc: 'Claim > 1x per participant',
      value: 'Claim > 1x per participant'
    },
  ];
  valueAd: any[] = [
    {
      desc: 'Accident Death date > 90 days from Issued date (Accident)',
      value: 'Accident Death date > 90 days from Issued date (Accident)'
    },
    {
      desc: 'Accident Death (Accident) Caused include in the policy exclusion',
      value: 'Accident Death (Accident) Caused include in the policy exclusion'
    },
    {
      desc: 'Claim > 1x per participant',
      value: 'Claim > 1x per participant'
    },
  ];
  @Input() claimType: string = '';
  @Input() viewer: boolean = false;
  @Input() approval: boolean = false;
  @Input() payment: boolean = false;
  @Input() closed: boolean = false;


  state = {
    POLICY_NUMBER: '',
    // CERTIFICATE_NUMBER: '',
    PARTICIPANT_NUMBER: '',
    PARTICIPANT_NAME: '',
    REGISTRATION_DATE: null,
    CLAIM_TYPE: '',
    HOSPITAL_NAME: '',
    DOCTOR_NAME: '',
    SUM_ASSURED: '',
    OTHER_DISEASE: '',
    ACCIDENT_NON_TRAFFIC: '',
    ACCIDENT_TRAFFIC: '',
    OTHER_ACCIDENT: '',
    ACCIDENT_DATE: null,
    DATE_OF_DEATH: null,
    TIME_OF_DEATH: null,
    PLACE_OF_DEATH: '',
    DEATH_CHRONOLOGY: '',
    BENEFICIARY_NAME: '',
    BENEFICIARY_ADDRESS: '',
    BENEFICIARY_BANK_NAME: '',
    BENEFICIARY_ACCOUNT_NUMBER: '',
    BENEFICIARY_ACCOUNT_NAME: '',
    CI_EXCEPTION: false,
    AD_EXCEPTION: false,

    REJECTED_REASON: null,

    PAYMENT_DATE: null,
    PAYMENT_VOUCHER_NUMBER: null,
    CLOSED_DATE: null,

  }

  constructor() {
    this.viewer;
    this.approval;
    console.log('Hello LadysClaimInformationFormComponent Component');
  }

  ngOnChanges() {
    this.dataArray = (this.claimType === 'AD' ? this.valueAd : this.valueCi);
    this.viewer;
    this.approval;
  }

  parsePaymentDate(value) {
    if (Object.keys(value).length) {
      this.state.PAYMENT_DATE = `${value.year}-${value.month}-${value.day}`;
    }
  }

  parseClosedDate(value) {
    if (Object.keys(value).length) {
      this.state.CLOSED_DATE = `${value.year}-${value.month}-${value.day}`;
    }
  }

}
