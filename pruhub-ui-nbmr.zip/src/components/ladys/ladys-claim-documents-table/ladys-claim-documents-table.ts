import { Component, Input } from '@angular/core';
import { AlertController } from 'ionic-angular';
import { MasterPruladysProvider } from '../../../providers/providers';

/**
 * Generated class for the LadysClaimDocumentsTableComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'ladys-claim-documents-table',
  templateUrl: 'ladys-claim-documents-table.html'
})
export class LadysClaimDocumentsTableComponent {
  authorization: string;
  username: string;
  
  @Input() donwnloadFile: any;
  file_attachment: any;
  index_file: number;
  file_type: any;
  claimDetail: any;
  docId: any;
  listDropdown: any;

  // arrayDocId: any[] = [];

  @Input() api: any;
  @Input() claimNumber: any;
  @Input() claimSequence: any;
  @Input() regDate: any;
  // fileName: any;

  // listDropdown: any;
  // valueDropdown: any;


  constructor(
    private masterPruladys: MasterPruladysProvider,
    public alertCtrl: AlertController
  ) {
    console.log('Hello LadysClaimDocumentsTableComponent Component', this.claimDetail);
    this.api;
    this.claimNumber;
    this.claimSequence;
    this.regDate;
    this.getListDropdown();
  }

  ngOnChanges() {
    this.removeExt();
  }

  getListDropdown() {
    this.masterPruladys.GetDropdownList('', this.authorization, this.username)
      .subscribe((res) => {
        console.log('data', res)
        if (res.responseCode !== "200") {
          this.presentAlert("Error", res.responseMessage || 'Failed');
        } else {
          this.listDropdown = res.data
        }
      })
  }

  presentAlert(title, subtitle) {
    const alert = this.alertCtrl.create({
      title: title,
      subTitle: subtitle,
      buttons: ['OK']
    });
    alert.present();
  }

  removeExt() {
    if (this.file_attachment && this.file_attachment.length) {
      let files = this.file_attachment;
      files.forEach(x => {
        let name = x.filename;
        let splitName = name.split('.').slice(0, -1).join('.');
        x.docId = splitName;
      })
    }
  }

}
