$(document).ready(function () {
    if (localStorage.getItem('jsonData')) {
        $('textarea').val(localStorage.getItem('jsonData'));
    }
});
$(document).on('click', '.set-data', function () {
    localStorage.setItem('jsonData', $('textarea').val());
    window.location = 'decision.html';
});

$(document).on('click', '.back', function () {
    window.location = 'index.html';
});
