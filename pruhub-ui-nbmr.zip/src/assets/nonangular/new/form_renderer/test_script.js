
(function(window) {

            function Test () {

                console.log("DOM Content Loaded");

                var actionType = window.parent.document.getElementById('inpActionType').value;
                // var bootstrapData = window.parent.document.getElementById('inpBootstrapData').value;

                var bootstrapData = {
                };

                // Specify the container for the forms renderer
                var container = document.querySelector('#magnumApplication');

                var configOptions = {
                    restEntryPointUrl: window.parent.document.getElementById('inpRestEntryPointUrl').value,
                    rulebase: window.parent.document.getElementById('inpRulebase').value,
                    preventCache: true,
                    customLoadingScreen: {
                        onLoadingStart: function() {
                            //Loading screen start
                        },
                        onLoadingEnd: function() {
                            //Loading screen end
                        }
                    }
                };

                // First invocation of window.Magnum() instantiates Magnum application, and links Forms Renderer to given document node
                var magnum = window.Magnum(container, configOptions, function afterMagnumInit() {
                    if (actionType === 'resumeCase') {
                        // Case can be created immediately after initialisation in the callback function, or later on, for example, after user clicks some button            
                        magnum.resumeCase({
                            caseData: {
                                'case': window.parent.document.getElementById('inpCaseUuid').value
                            }
                        });
                    } else if (actionType === 'startCase') {
                        // Case can be created immediately after initialisation in the callback function, or later on, for example, after user clicks some button            
                        magnum.startCase({
                            caseData: {
                                rulebaseUuid: window.parent.document.getElementById('inpRulebase').value,
                                language: 'en_GB',
                                mandatoryValidationsSettings: {
                                    validateOnNextForm: true,
                                    validateOnPreviousForm: false,
                                    validateOnSubmit: false
                                }
                            },
                            bootstrapData: JSON.parse(window.parent.document.getElementById('inpBootstrapData').value),
                            applicantData: {
                                '33': {
                                    displayName: '33'
                                }
                            }
                        });
                    } else {
                        console.error('Unsupported actionType'  + actionType);
                    }
                });

                // Adding a listener to some Magnum event
                magnum.on('case-completed', function() {
                    container.innerHTML = 'THANK YOU!';
                });

            };

            // Test();

            // document.querySelector('#test').innerHTML = 'Success';
            // alert('This is from test_script.js');
            Test();

        })(window);