/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 18);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = angular;

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

angular.module('mxg.templates', []);

module.exports = angular.module('mxg.summary', ['mxg.templates'])
    .config(['$sceProvider', function (sce) {
        sce.enabled(false);
    }])
    .directive('overview', __webpack_require__(2))
    .directive('overviewForm', __webpack_require__(4))
    .directive('overviewFormElement', __webpack_require__(6))
    .directive('overviewQuestion', __webpack_require__(7))
    .directive('overviewSectionInline', __webpack_require__(9))
    .directive('overviewSectionInstance', __webpack_require__(11))
    .directive('overviewSectionRepeating', __webpack_require__(13))
    .directive('overviewSectionStatic', __webpack_require__(15))
    .name;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function Overview() {
    'use strict';
    return {
        restrict: 'AE',
        scope: {
            overviewModel: '=overview',
            onFormClick: '&?',
            emptyValueLabel: '@?',
            isDisabled: '=?'
        },
        template: __webpack_require__(3),

        controller: ['$scope', function overviewController($scope) {

            var overviewCtrl = this;

            if (!$scope.isDisabled) {
                overviewCtrl.goToForm = function (formSequenceKey) {
                    $scope.onFormClick({
                        formSequenceKey: formSequenceKey
                    });
                };
            }

        }],
        controllerAs: 'overviewCtrl',

        link: function ($scope, $element) {

            $element.addClass('createcase_OVERVIEW');

            $scope.isLifeGroup = function (formGroup) {
                return angular.isDefined(formGroup.lifeId);
            };

            $scope.getLifeDisplayName = function (formGroup) {
                return formGroup.lifeDisplayName || 'Applicant ' + formGroup.lifeId;
            };

        }

    };
};


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = "<div class=\"overview container\">\r\n    <div class=\"mxg-application-container\">\r\n        <div class=\"mxg-form-area-container\">\r\n            <span ng-repeat-start=\"formGroup in overviewModel.caseSummary.forms track by $index\" ng-show=\"false\"></span>\r\n\r\n            <div ng-if=\"isLifeGroup(formGroup)\" class=\"row overview_applicant\">\r\n                <div class=\"col-md-16\">\r\n                    <h3 ng-bind=\"getLifeDisplayName(formGroup)\" class=\"overview_applicant_name\"></h3>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"row\">\r\n                <div class=\"col-md-16\">\r\n                    <div ng-repeat=\"formModel in formGroup.forms\" overview-form-element=\"formModel\"\r\n                         ng-disabled=\"overviewModel.returnToCaseDisabled\"></div>\r\n                </div>\r\n            </div>\r\n\r\n            <span ng-repeat-end ng-show=\"false\"></span>\r\n        </div>\r\n    </div>\r\n</div>\r\n";

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function OverviewForm() {
    'use strict';
    return {
        restrict: 'AE',
        require: '^?overview',
        template: __webpack_require__(5),
        scope: {
            form: '=overviewForm'
        },
        link: function ($scope, $element, $attrs, overviewCtrl) {

            $element.addClass('overview_form fluid-table');

            $scope.formTitleClick = function ($event, formSequenceKey) {
                $event.preventDefault();

                if ($scope.$parent && !$scope.$parent.getDisabled()) {
                    getCallBackParent($scope.$parent, formSequenceKey);
                }
                return false;
            };

        }
    };
};

let formClick = null;

function getCallBackParent(parent, formSequenceKey) {
    if (formClick) {
        return formClick(formSequenceKey);
    }
    if (parent.$parent && !parent.onFormClick) {
        return getCallBackParent(parent.$parent, formSequenceKey);
    } else if (parent.onFormClick) {
        formClick = parent.onFormClick;
        return parent.onFormClick(formSequenceKey);
    } else {
        return null;
    }
}


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = "<div class=\"row row__header\">\r\n    <div class=\"col-md-16\">\r\n         <a ng-href=\"\" ng-click=\"formTitleClick($event, form.sequenceKey)\" class=\"btn btn-link\" ng-disabled=\"$parent.getDisabled()\"><h3 class=\"overview_form_title\" ng-bind=\"form.title\"></h3></a>\r\n    </div>\r\n</div>\r\n<div ng-repeat=\"child in form.childElements\" overview-form-element=\"child\"></div>\r\n<div class=\"row row__delimiter\">\r\n    <div class=\"col-md-16\">\r\n        &nbsp;\r\n    </div>\r\n</div>\r\n\r\n";

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = ['$compile', function OverviewFormElement($compile) {
    "use strict";

    var getDirectiveName = function (type) {
        return 'overview-' + type.toLowerCase().replace('_', '-');
    };

    return {
        restrict: "AE",
        scope: {
            model: "=overviewFormElement"
        },
        link: function ($scope, $element, $attrs) {

            var locator = getAbstractLocator($scope.model);

            var elementType = $scope.model.type;
            var compiledElement;

            var template = angular.element('<div></div>');
            template.attr(getDirectiveName(elementType), "model");
            compiledElement = $compile(template)($scope);
            if (locator !== null) {
                compiledElement.attr('data-mxg-locator', locator);
            }

            $element.replaceWith(compiledElement);

            $scope.getDisabled = function () {
                return isDisabledFu($scope);
            };

            function getAbstractLocator(formElement) {
                return angular.isString(formElement.locator) ? formElement.locator.replace(/\[[^\]]*\]/g, '') : null;
            }

        }
    };
}];
var isDisabledValue = null;

function isDisabledFu(parent) {
    if (isDisabledValue) {
        return isDisabledValue;
    } else if (parent.isDisabled) {
        isDisabledValue = parent.isDisabled;
        return parent.isDisabled;
    } else if (parent.$parent) {
        return isDisabledFu(parent.$parent);
    }
}


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = ['dateFilter', function overviewQuestion(dateFilter) {
    "use strict";
    var QuestionDataType = {
        "INTEGER_TEXTBOX": "INTEGER_TEXTBOX",
        "STRING_TEXTBOX_SINGLE": "STRING_TEXTBOX_SINGLE",
        "DECIMAL_TEXTBOX": "DECIMAL_TEXTBOX",
        "BOOLEAN_RADIO_BUTTONS_HORIZONTAL": "BOOLEAN_RADIO_BUTTONS_HORIZONTAL",
        "MULTISELECT_CHECKBOXES_VERTICAL": "MULTISELECT_CHECKBOXES_VERTICAL",
        "DATE": "DATE",
        "DATE_PARTIAL": "DATE_PARTIAL",
        "DROPDOWN": "DROPDOWN",
        "DROPDOWN_COMBOBOX": "DROPDOWN_COMBOBOX",
        "INTEGER_SPINNER": "INTEGER_SPINNER",
        "INTEGER_SLIDER": "INTEGER_SLIDER",
        "STRING_TEXTBOX_MULTI": "STRING_TEXTBOX_MULTI",
        "STRING_DICTIONARY": "STRING_DICTIONARY",
        "DROPDOWN_LABELLED_BUTTONS": "DROPDOWN_LABELLED_BUTTONS",
        "DROPDOWN_ICONIC_BUTTONS": "DROPDOWN_ICONIC_BUTTONS",
        "DROPDOWN_RADIO_BUTTONS_HORIZONTAL": "DROPDOWN_RADIO_BUTTONS_HORIZONTAL",
        "DROPDOWN_RADIO_BUTTONS_VERTICAL": "DROPDOWN_RADIO_BUTTONS_VERTICAL",
        "MULTISELECT_LABELLED_BUTTONS": "MULTISELECT_LABELLED_BUTTONS",
        "MULTISELECT_ICONIC_BUTTONS": "MULTISELECT_ICONIC_BUTTONS",
        "MULTISELECT_DROPDOWN": "MULTISELECT_DROPDOWN"
    };
    var QuestionValueType = {
        "INTEGER": "INTEGER",
        "STRING": "STRING",
        "REFERENCE": "REFERENCE",
        "DECIMAL": "DECIMAL",
        "DATE": "DATE",
        "DATE_PARTIAL": "DATE_PARTIAL",
        "REFERENCE_MULTI": "REFERENCE_MULTI"
    };
    var DatePartialFormat = {
        VALID_PART_FORMATS: ['YYYY', 'MM', 'DD', 'MMM'],
        VALID_DELIMITERS: [' ', '.', '-', '/', '\\'],
        PARSING_PATTERN: /(y{4}|m{3}|m{2}|d{2}|[ -\\\/])/gi,
        DEFAULT_INPUT_FORMAT: 'yyyy-mm-dd',
        PROPERTIES: {
            YYYY: {
                canonicalFormat: 'yyyy',
                pattern: /^((19|20)\d\d+)$/i,
                inputMask: '9999',
                priority: 0
            },
            MM: {
                canonicalFormat: 'MM',
                pattern: /^(0[1-9]|1[012]+)$/i,
                inputMask: '99',
                priority: 1
            },
            MMM: {
                canonicalFormat: 'MMM',
                inputMask: '999',
                priority: 1
            },
            DD: {
                canonicalFormat: 'dd',
                pattern: /^(0[1-9]|[12][0-9]|3[01])$/i,
                inputMask: '99',
                priority: 2
            }
        }
    };
    return {
        template: __webpack_require__(8),
        require: '^?overview',
        scope: {
            question: '=overviewQuestion'
        },
        link: function overviewQuestionLink(scope, element) {
            var DEFAULT_DECIMAL_SYMBOL = '.';

            element.addClass('row overview_question');
            scope.detailsVisible = false;

            scope.triggerReferenceView = function (event) {
                scope.detailsVisible = !scope.detailsVisible;
                $(event.target).parent().find('.referenceValuesList').toggleClass('hidden')
            };

            scope.hasReferenceValues = function () {
                return scope.question.referenceValues && (scope.question.referenceValues.length);
            };

            scope.getReferenceValues = function () {
                return scope.question.referenceValues;
            };

            scope.getAnswer = function overviewQuestionGetAnswer() {

                var valueType = dataTypeToValueTypeMap(scope.question && scope.question.dataType ? scope.question.dataType : null);
                var displayValue = getQuestionValue(valueType);
                if (scope.question.value.emptyValue) {
                    return getEmptyValueLabel(scope);
                }

                return displayValue;

            };

            function getQuestionValue(valueType) {
                var result = '';
                if (!scope.question.value.emptyValue) {
                    switch (valueType) {
                        case QuestionValueType.REFERENCE:
                        case QuestionValueType.DROPDOWN:
                            result = scope.question.value.referenceDataValues[0].name;
                            break;
                        case QuestionValueType.INTEGER:
                            result = scope.question.value.intValue;
                            break;
                        case QuestionValueType.STRING:
                            result = scope.question.value.stringValue;
                            break;
                        case QuestionValueType.REFERENCE_MULTI:
                            result = scope.question.value.referenceDataValues.map(function (item) {
                                return item.name;
                            }).join(', ');
                            break;
                        case QuestionValueType.DATE:
                            result = processDateValue();
                            break;
                        case QuestionValueType.DATE_PARTIAL:
                            result = processDatePartialValue();
                            break;
                        case QuestionValueType.DECIMAL:
                            result = processDecimalValue();
                            break;
                    }
                } else {
                    result = getEmptyValueLabel(scope)
                }

                return result;
            }

            function dataTypeToValueTypeMap(dataType) {

                switch (dataType) {
                    case QuestionDataType.INTEGER_TEXTBOX:
                    case QuestionDataType.INTEGER_SPINNER:
                    case QuestionDataType.INTEGER_SLIDER:
                        return QuestionValueType.INTEGER;
                    case QuestionDataType.STRING_TEXTBOX_SINGLE:
                    case QuestionDataType.STRING_TEXTBOX_MULTI:
                        return QuestionValueType.STRING;
                    case QuestionDataType.STRING_DICTIONARY:
                        return QuestionValueType.REFERENCE;
                    case QuestionDataType.DECIMAL_TEXTBOX:
                        return QuestionValueType.DECIMAL;
                    case QuestionDataType.DATE:
                        return QuestionValueType.DATE;
                    case QuestionDataType.DATE_PARTIAL:
                        return QuestionValueType.DATE_PARTIAL;
                    case QuestionDataType.MULTISELECT_CHECKBOXES_VERTICAL:
                    case QuestionDataType.MULTISELECT_LABELLED_BUTTONS:
                    case QuestionDataType.MULTISELECT_ICONIC_BUTTONS:
                    case QuestionDataType.MULTISELECT_DROPDOWN:
                        return QuestionValueType.REFERENCE_MULTI;
                    case QuestionDataType.DROPDOWN:
                    case QuestionDataType.DROPDOWN_COMBOBOX:
                    case QuestionDataType.DROPDOWN_LABELLED_BUTTONS:
                    case QuestionDataType.DROPDOWN_ICONIC_BUTTONS:
                    case QuestionDataType.DROPDOWN_RADIO_BUTTONS_HORIZONTAL:
                    case QuestionDataType.DROPDOWN_RADIO_BUTTONS_VERTICAL:
                        return QuestionValueType.REFERENCE;
                    default :
                        break;
                }

            }

            function processDateValue() {
                var dateFormat = 'yyyy-MM-dd';
                scope.question.formElementProperties.forEach(function (property) {
                    if (property.name && property.name === 'INPUT_FORMAT') {
                        dateFormat = property.value.stringValue;
                    }
                });

                var value = scope.question.value && scope.question.value.dateValue ? scope.question.value.dateValue : null;
                return dateFormat ? formatDateValue(value, dateFormat) : value;
            }

            function processDatePartialValue() {
                var dateFormat = 'yyyy-MM-dd';
                scope.question.formElementProperties.forEach(function (property) {
                    if (property.name && property.name === 'INPUT_FORMAT') {
                        dateFormat = property.value.stringValue;
                    }
                });
                var value = scope.question.value && scope.question.value.datePartialValue ? scope.question.value.datePartialValue : null;
                return dateFormat ? formatDatePartialValue(value, dateFormat) : value;
            }

            function processDecimalValue() {
                var delimiter;
                if (scope.question && scope.question.formElementProperties) {
                    scope.question.formElementProperties.every(function (property) {
                        if (property.name && property.name === 'INPUT_FORMAT') {
                            delimiter = property.value.stringValue;
                            return void 0;
                        }
                    });
                }

                var value = scope.question.value && scope.question.value.decimalValue ? scope.question.value.decimalValue : null;
                return delimiter ? (value + '').replace(DEFAULT_DECIMAL_SYMBOL, delimiter) : value;
            }

            function formatDateValue(value, format) {
                return dateFilter(new Date(value), format, 'UTC');
            }

            function formatDatePartialValue(value, format) {

                var partValues = value.split('-');
                var valuePartsCount = partValues.length;

                var dateValue = new Date(value);
                var formattedParts = [];
                var parsed = format.match(DatePartialFormat.PARSING_PATTERN);
                var delimiter = DatePartialFormat.VALID_DELIMITERS[0];

                (parsed || []).forEach(function (item) {

                    var partProperties = DatePartialFormat.PROPERTIES[item.toUpperCase()];

                    if (partProperties) {
                        (partProperties.priority < valuePartsCount) && formattedParts.push(dateFilter(dateValue, partProperties.canonicalFormat, 'UTC'));
                    } else if (DatePartialFormat.VALID_DELIMITERS.indexOf(item) !== -1) {
                        delimiter = item;
                    }

                });

                return formattedParts.join(delimiter);

            }
        }
    };
}];

var emptyValue = null;

function getEmptyValueLabel(parent) {
    if (emptyValue) {
        return emptyValue;
    } else if (parent.emptyValueLabel) {
        emptyValue = parent.emptyValueLabel;
        return parent.emptyValueLabel;
    } else if (parent.$parent) {
        return getEmptyValueLabel(parent.$parent);
    } else {
        return 'No';
    }
}


/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = "<span ng-if=\"hasReferenceValues()\" class=\"branch-toggler branch-toggler__off overview_question_drop\" ng-class=\"{'branch-toggler__off':!detailsVisible}\" ng-click=\"triggerReferenceView($event)\"></span>\r\n<div class=\"overview_question_wording col-md-7 col-md-offset-1 col-sm-8\" ng-bind-html=\"question.title\"></div>\r\n<div class=\"overview_question_answer col-md-8 col-sm-8\" ng-bind=\"getAnswer()\"></div>\r\n\r\n<ul ng-if=\"hasReferenceValues()\" class=\"referenceValuesList hidden\">\r\n    <li ng-repeat=\"element in getReferenceValues()\">{{element.name}}</li>\r\n</ul>\r\n";

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function () {
    "use strict";
    return {
        template: __webpack_require__(10),
        require: '^?overview',
        scope: {
            section: '=overviewSectionInline'
        },
        link: function ($scope, $element) {
            $element.addClass('overview_section overview_section__inline');
        }
    };
};


/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = "<span ng-repeat-start=\"child in section.childElements\" ng-show=\"false\"></span>\r\n<div overview-form-element=\"child\"></div>\r\n<span ng-repeat-end ng-show=\"false\"></span>\r\n";

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function () {
    "use strict";
    return {
        template: __webpack_require__(12),
        require: '^?overview',
        scope: {
            section: '=overviewSectionInstance'
        },
        link: function ($scope, $element) {
            $element.addClass('overview_section overview_section__instance');
        }
    };
};


/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = "<span ng-repeat-start=\"child in section.childElements\" ng-show=\"false\"></span>\r\n<div overview-form-element=\"child\"></div>\r\n<span ng-repeat-end ng-show=\"false\"></span>\r\n";

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function () {
    "use strict";
    return {
        template: __webpack_require__(14),
        require: '^?overview',
        scope: {
            section: '=overviewSectionRepeating'
        },
        link: function ($scope, $element) {
            $element.addClass('overview_section overview_section__repeating');
        }
    };
};


/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = "<div class=\"row row__header\" ng-if=\"section.title\">\r\n    <div class=\"col-md-16\">\r\n        <span class=\"overview_section_title\" ng-bind=\"section.title\"></span>\r\n    </div>\r\n</div>\r\n\r\n<span ng-repeat-start=\"child in section.childElements\" ng-show=\"false\"></span>\r\n\r\n<div ng-if=\"$index>0\" class=\"row\">\r\n    <div class=\"col-md-16\">\r\n        &nbsp;\r\n    </div>\r\n</div>\r\n\r\n<div overview-form-element=\"child\"></div>\r\n\r\n<span ng-repeat-end ng-show=\"false\"></span>\r\n\r\n\r\n";

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = function () {
    "use strict";
    return {
        template: __webpack_require__(16),
        require: '^?overview',
        scope: {
            section: '=overviewSectionStatic'
        },
        link: function ($scope, $element) {
            $element.addClass('overview_section overview_section__static');
            if ($scope.section.title) {
                $element.addClass('overview_section__with_title');
            }
        }
    };
};


/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = "<div class=\"row row__header\" ng-if=\"section.title\">\r\n    <div class=\"col-md-16\">\r\n        <span class=\"overview_section_title\" ng-bind=\"section.title\"></span>\r\n    </div>\r\n</div>\r\n<span ng-repeat-start=\"child in section.childElements\" ng-show=\"false\"></span>\r\n<div overview-form-element=\"child\"></div>\r\n<span ng-repeat-end ng-show=\"false\"></span>\r\n";

/***/ }),
/* 17 */,
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var angular = __webpack_require__(0);
var summary = __webpack_require__(1);
window.MXG_SUMMARY = (function (window, angular) {
    "use strict";
    var instance = null;
    function init(container, model, disabled, emptyValueLabel, onFormClick) {
        var decision;
        angular.module(summary).run(['$rootScope', '$compile', '$timeout', function ($rootScope, $compile, $timeout) {
                var $scope = $rootScope.$new();
                $scope.model = model;
                $scope.disabled = disabled;
                $scope.emptyValueLabel = emptyValueLabel;
                $scope.onClick = onFormClick;
                decision = $compile('<div overview="model" empty-value-label="emptyValueLabel" is-disabled="disabled" on-forn-click="onClick()"></div>')($scope);
                $timeout(function () {
                    angular.element(container).append(decision);
                });
            }]);
        angular.bootstrap(container, [summary]);
    }
    return function (container, model, disabled, emptyValueLabel, onFormClick) {
        if (instance === null) {
            instance = init(container, model, disabled, emptyValueLabel, onFormClick);
        }
        return instance;
    };
})(window, angular);


/***/ })
/******/ ]);