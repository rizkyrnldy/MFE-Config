﻿(function (window, angular) {

/**
 * This is a main module that combines all other modules.
 * This module should not contain any components i.e. directives/controllers/factories
 * because it will be impossible to test them due to all dependenices
 *
 */
angular.module('mxg.templates', []); // placeholder module for templates
angular.module('magnum', [
    'ngSanitize',
    'mxg.magnum.Magnum',
    'mxg.rulebase',
    'mxg.magnum.MagnumContainer',
    'mxg.Navigation',
    'mxg.magnum.MagnumFormCtrl',
    'mxg.magnum.MagnumForm',
    'mxg.markupToHTML',
    'mxg.form',
    'mxg.activeCase.ActiveCase',
    'mxg.caseManager.CaseManager',
    'mxg.components',
    'mxg.formElement',
    'mxg.translation',
    'mxg.helpers',
    'mxg.resources',
    'mxg.templates',
    'mxg.system',
    'mxg.messages'
]).config(['$httpProvider', function ($httpProvider) {
    "use strict";
    $httpProvider.interceptors.push('mxgHttpFixStatusCodeInterceptor');
    $httpProvider.interceptors.push('mxgRestInterceptor');
    $httpProvider.interceptors.unshift('mxgCommonHttpInterceptor');
    $httpProvider.interceptors.push('mxgPreventCachingInterceptor');
    $httpProvider.interceptors.push('mxgServiceUnavailableInterceptor');
}]).run(['mxgFatalErrorHandler', function (FatalErrorHandler) {
    "use strict";
    FatalErrorHandler.enable();
}]);

angular.module('mxg.activeCase.ActiveCase',
    [
        'mxg.components.ProcessManager',
        'mxg.activeCase.ActiveCaseErrorHandler',
        'mxg.activeCase.ActiveCaseValidator',
        'mxg.activeCase.FormChangeReasons',
        'mxg.resources.CaseResource',
        'mxg.formElement.FormElementModelCreator',
        'mxg.navigation.NavigationModel',
        'mxg.case.BootstrapApproach',
        'mxg.case.CaseStatus',
        'mxg.system.ErrorModel',
        'mxg.system.RuntimeConstants',
        'mxg.case.ExitCaseDirection',
        'mxg.system.Events',
        'mxg.system.RootScope',
        'mxg.magnum.Config',
        'mxg.rulebase'
    ])
    .factory('mxgActiveCase', [
        '$q',
        '$filter',
        'mxgProcessManager',
        'mxgActiveCaseValidator',
        'mxgActiveCaseErrorHandler',
        'mxgRulebaseService',
        'mxgRootScope',
        'mxgFormElementModelCreator',
        'mxgCaseResource',
        'mxgNavigationModel',
        'mxgBootstrapApproach',
        'mxgCaseStatus',
        'mxgErrorModel',
        'mxgRuntimeConstants',
        'mxgExitCaseDirection',
        'mxgEvents',
        'MagnumConfig',
        'mxgApplicantNameSource',
        'mxgFormChangeReasons',
        function mxgActiveCase($q, $filter, ProcessManager, ActiveCaseValidator, ActiveCaseErrorHandler, RulebaseService, mxgRootScope, FormElementModelCreator, CaseResource, NavigationModel, BootstrapApproach, CaseStatus, ErrorModel, RuntimeConstants, ExitCaseDirection, mxgEvents, Config, APPLICANT_NAME_SOURCE, FORM_CHANGE_REASONS) {
            'use strict';

            var caseData = null,
                caseStatus = null,
                activeForm = null,
                navigation = new NavigationModel(),
                applicantData,
                forceFormSubmit = false,
                caseExists = false;

            var performCaseRequest = (function () {
                var submitRequests = ['saveAndGetFormById', 'saveAndGetPreviousForm', 'saveAndGetNextForm', 'saveCurrentForm', 'partialSubmit'];
                return function (request, args) {
                    ActiveCaseValidator.resetMessages();
                    var isFormSubmit = submitRequests.indexOf(request) !== -1;
                    var requestFunc = CaseResource[request];
                    return $q(function (resolve, reject) {
                        requestFunc.apply(CaseResource, args)
                            .then(function (response) {
                                /* All other requests are expected to return same data structure for caseData */
                                if ((request !== 'partialSubmit') && !ActiveCaseValidator.validateCaseDataStructure(
                                        response.data || null)) {
                                    return $q.reject(ErrorModel.getIncorrectServerResponseError(request));
                                }
                                isFormSubmit && fireFormSubmittedSuccess();
                                resolve(response);
                            })
                            .catch(function (response) {
                                processRestErrors(response, isFormSubmit);
                                reject('REST ERROR');
                            });
                    });
                };
            })();

            var processRestErrors = (function () {
                var specialErrorCodesProcessingMap = {};
                specialErrorCodesProcessingMap[RuntimeConstants.ErrorCode.LAST_FORM] = function () {
                    checkStatusChange(CaseStatus.COMPLETE);
                    mxgRootScope.$broadcast(mxgEvents.CASE_COMPLETE, angular.copy(caseData));
                    exitCase(ExitCaseDirection.RIGHT);
                };
                specialErrorCodesProcessingMap[RuntimeConstants.ErrorCode.FIRST_FORM] = function () {
                    exitCase(ExitCaseDirection.LEFT);
                };
                specialErrorCodesProcessingMap[RuntimeConstants.ErrorCode.CURRENT_FORM_NOT_COMPLETED] = function () {
                    partialSubmit();
                };

                return function (response, wasFormSubmit) {
                    var responseData = response.data || {};
                    var errorStatus = '' + response.status;
                    var errorCode = responseData.code;
                    if ((errorStatus === '500') && (errorCode in specialErrorCodesProcessingMap)) {
                        /*  We got an error response after a form submit, but it turned out, that it is a special kind of error, indicating changes in the interview course, so we assume that actual submit was successful and form-submitted event should be triggered. */
                        wasFormSubmit && fireFormSubmittedSuccess();
                        specialErrorCodesProcessingMap[errorCode]();
                    }
                    else {
                        ActiveCaseErrorHandler.processErrorResponse(errorStatus, responseData);
                    }
                };
            })();

            function updateNavigationMenu(navigationModel) {
                var applicantnameSource = Config.getOption('applicantnameSource');
                var params = [navigationModel];
                if (navigationModel && applicantnameSource === APPLICANT_NAME_SOURCE.HOSTAPP) {
                    params.push(applicantData);
                }
                navigation.setMenu.apply(navigation, params);
            }

            function exitCase(direction) {
                mxgRootScope.$broadcast(mxgEvents.EXIT_CASE, angular.copy(caseData), direction);
                stop();
            }

            function submitIsRequired() {
                return forceFormSubmit || !activeForm.checkWasSubmitted() || activeForm.hasChanged();
            }

            function checkStatusChange(newStatus) {

                if (!caseExists) {
                    return;
                }

                var oldStatus = caseStatus;
                if (newStatus && newStatus !== caseStatus) {
                    caseStatus = newStatus;
                } else {
                    if (caseStatus === null) {
                        caseStatus = navigation.areAllFormsCompleted() ? CaseStatus.COMPLETE : CaseStatus.INCOMPLETE;
                    }

                    if (!navigation.areAllFormsCompleted() && caseStatus === CaseStatus.COMPLETE) {
                        caseStatus = CaseStatus.INCOMPLETE;
                    }
                    if (navigation.areAllFormsCompleted() && caseStatus === CaseStatus.INCOMPLETE) {
                        caseStatus = CaseStatus.COMPLETE;
                    }
                }

                if (oldStatus !== null && oldStatus !== caseStatus) {
                    mxgRootScope.$broadcast(mxgEvents.CASE_STATUS_CHANGED, angular.copy(caseData), caseStatus);
                }

            }

            function fireFormSubmittedSuccess() {
                mxgRootScope.$broadcast(mxgEvents.CASE_FORM_SUBMITTED, angular.copy(caseData), activeForm.toJSON());
            }

            /**
             * @private
             * @param {mxgFormChangeReasons} reasonForChange
             * @param {Boolean|undefined} forceNextFormSubmit
             * @returns {Function}
             */
            function getNewFormProcessor(reasonForChange, forceNextFormSubmit) {
                return function (response) {
                    var data = response.data || null;
                    if (angular.isObject(data)) {
                        activeForm = FormElementModelCreator.create(data.resultingForm);
                        RulebaseService.setActiveLanguageCode(activeForm.getAttribute('language'));
                        updateNavigationMenu(data.formList.formNavigationModels);
                    }
                    else {
                        activeForm = null;
                    }
                    mxgRootScope.$broadcast(mxgEvents.CASE_FORM_CHANGED, {
                        reasonForChange: reasonForChange,
                        menu: navigation
                    });
                    checkStatusChange();
                    forceFormSubmit = forceNextFormSubmit || false;
                }
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getActiveForm
             * @returns {mxgFormElementModel|null}
             */
            function getActiveForm() {

                if (!caseExists) {
                    return null;
                }

                return activeForm || null;

            }

            function processCaseData(initData) {
                return {
                    'case': initData.caseUuid,
                    rulebase: initData.rulebaseUuid,
                    bootstrapApproach: initData.bootstrapType,
                    mandatoryValidationsSettings: initData.mandatoryValidationsSettings
                };
            }

            function processApplicantData(initData) {
                var applicantnameSource = Config.getOption('applicantnameSource');
                return applicantnameSource === APPLICANT_NAME_SOURCE.HOSTAPP && angular.isObject(
                    initData) ? initData : undefined;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#stop
             */
            function stop() {
                caseExists = false;
                caseData = null;
                activeForm = null;
                applicantData = undefined;
                updateNavigationMenu(null);
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getRulebase
             * @returns {*}
             */
            function getRulebase() {
                return caseExists ? caseData.rulebase : null;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getLanguageCode
             * @returns {*}
             */
            function getLanguageCode() {
                return activeForm ? activeForm.getLanguage() : null;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getMandatoryValidationsSetting
             * @param {String} optionName
             * @returns {Boolean}
             */
            function getMandatoryValidationsSetting(optionName) {
                if (!caseData) {
                    return false;
                }
                var settings = caseData.mandatoryValidationsSettings || {};
                return (optionName in settings) ? settings[optionName] : false;
            }

            /**
             * @private
             * @param {Function} action
             * @param {String} mandatoryValidationOption
             * @returns {Function}
             */
            function withValidation(action, mandatoryValidationOption) {
                mandatoryValidationOption = mandatoryValidationOption || RuntimeConstants.mandatoryValidations.SUBMIT;
                return function () {
                    var argsArray = Array.prototype.slice.call(arguments);
                    var validationOptions = {
                        skipEmptyValues: !getMandatoryValidationsSetting(mandatoryValidationOption)
                    };
                    ActiveCaseValidator.resetMessages();

                    return $q(function (resolve, reject) {
                        ActiveCaseValidator.validateForm(activeForm, validationOptions)
                            .then(function () {
                                mxgRootScope.$broadcast(mxgEvents.CASE_CHECK_VALID);
                                resolve(action.apply(null, argsArray));
                            })
                            .catch(function () {
                                mxgRootScope.$broadcast(mxgEvents.CASE_CHECK_INVALID);
                                reject('Form Validation Failed');
                            });
                    });

                };
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getFormById
             * @param {Object} sequenceKey
             * @param {Boolean} discardChanges
             * @param {mxgFormChangeReasons} reason
             */
            function getFormById(sequenceKey, discardChanges, reason) {
                var request;
                var args;
                discardChanges = discardChanges || false;
                reason = reason || FORM_CHANGE_REASONS.NAV_MENU_CLICK;
                if (!discardChanges && submitIsRequired()) {
                    request = 'saveAndGetFormById';
                    args = [caseData.case, sequenceKey, activeForm.toJSON()];
                } else {
                    request = 'getFormById';
                    args = [caseData.case, sequenceKey, discardChanges];
                }
                var promise = performCaseRequest(request, args).then(getNewFormProcessor(reason, discardChanges));
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getPrevForm
             * @returns {Promise}
             */
            function getPrevForm() {
                var request = submitIsRequired() ? 'saveAndGetPreviousForm' : 'getPreviousForm';
                var args = [caseData.case, activeForm.toJSON()];
                var promise = performCaseRequest(request, args)
                    .then(getNewFormProcessor(FORM_CHANGE_REASONS.NAV_CONTROL_BACK));
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#getNextForm
             * @returns {Promise}
             */
            function getNextForm() {
                var request = submitIsRequired() ? 'saveAndGetNextForm' : 'getNextForm';
                var args = [caseData.case, activeForm.toJSON()];
                var promise = performCaseRequest(request, args)
                    .then(getNewFormProcessor(FORM_CHANGE_REASONS.NAV_CONTROL_CONTINUE));
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#saveForm
             * @returns {Promise}
             */
            function saveForm() {
                if (submitIsRequired()) {
                    var request = 'saveCurrentForm';
                    var args = [caseData.case, activeForm.toJSON()];
                    var promise = performCaseRequest(request, args)
                        .then(getNewFormProcessor(FORM_CHANGE_REASONS.NAV_CONTROL_SAVE));
                    ProcessManager.run(promise);
                    return promise;
                }
                else {
                    return $q.when(true);
                }
            }

            /**
             * @ngdoc method
             * @method ActiveCase#reloadActiveForm
             * @param {Object} params
             * @returns {Promise}
             */
            function reloadActiveForm(params) {
                var sequenceKey = activeForm.getSequenceKey();
                if (angular.isObject(params)) {
                    angular.extend(sequenceKey, params);
                }
                return getFormById(sequenceKey, true, FORM_CHANGE_REASONS.NAV_CONTROL_RELOAD);
            }

            /**
             * @ngdoc method
             * @method ActiveCase#startCase
             * @param {Object} data
             * @returns {Promise}
             */
            function startCase(data) {

                stop();

                var _caseData = angular.isObject(data) ? data.caseData : null;
                var bootstrapData = angular.isObject(data) ? data.bootstrapData : null;
                var _applicantData = angular.isObject(data) ? data.applicantData : undefined;

                var startCaseModel = {};

                if (angular.isObject(_caseData)) {
                    angular.extend(startCaseModel, _caseData);
                }

                startCaseModel.language = startCaseModel.language || RulebaseService.getDefaultLanguageCode();

                if (angular.isObject(bootstrapData)) {
                    angular.extend(startCaseModel, {
                        bootstrapType: BootstrapApproach.HOST_APP,
                        bootstrapData: bootstrapData
                    });
                }

                applicantData = processApplicantData(_applicantData);

                var promise = performCaseRequest('startCase', [startCaseModel])
                    .then(function (response) {
                        if (response.data) {
                            caseData = processCaseData(response.data);
                            mxgRootScope.$broadcast(mxgEvents.CASE_CREATED, angular.copy(caseData),
                                caseData.bootstrapApproach, bootstrapData);
                        }
                        return response;
                    })
                    .then(finishCaseSetup(FORM_CHANGE_REASONS.SETUP_CASE_CREATED));
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#resumeCase
             * @param {Object} data
             * @returns {Promise}
             */
            function resumeCase(data) {

                stop();

                var _caseData = angular.isObject(data) ? data.caseData : null;
                var bootstrapModel = angular.isObject(data) ? data.bootstrapData : null;
                var _applicantData = angular.isObject(data) ? data.applicantData : undefined;
                var currentForm = angular.isObject(data) ? data.currentForm : null;

                if (!angular.isObject(_caseData) || !_caseData.case) {
                    mxgRootScope.$broadcast(mxgEvents.FATAL_ERROR, "cannot resume case without ID");
                    return $q.when(null);
                }

                var request;
                var args;

                if (angular.isObject(bootstrapModel)) {
                    request = 'submitBootstrapAndGetNext';
                    args = [_caseData.case, bootstrapModel];
                } else if (angular.isObject(currentForm)) {
                    request = 'getFormById';
                    args = [_caseData.case, currentForm];
                } else {
                    request = 'getCurrentForm';
                    args = [_caseData.case];
                }

                applicantData = processApplicantData(_applicantData);

                var promise = performCaseRequest(request, args)
                    .then(function (response) {
                        if (response.data) {
                            caseData = processCaseData(response.data);
                            mxgRootScope.$broadcast(mxgEvents.CASE_RESUMED, angular.copy(caseData),
                                caseData.bootstrapApproach, bootstrapModel);
                        }
                        return response;
                    })
                    .then(finishCaseSetup(FORM_CHANGE_REASONS.SETUP_CASE_RESUMED));
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @ngdoc method
             * @method ActiveCase#partialSubmit
             * @returns {Promise}
             */
            function partialSubmit() {

                var validationOptions = {
                    skipEmptyValues: true,
                    silent: true
                };

                var promise = ActiveCaseValidator.validateForm(activeForm, validationOptions)
                    .then(performCaseRequest.bind(null, 'partialSubmit', [caseData.case, activeForm.toJSON()]))
                    .then(function (response) {
                        var data = response.data || null;
                        if (!angular.isObject(data)) {
                            return;
                        }
                        if (activeForm.processPartialSubmitResponse(data)) {
                            forceFormSubmit = true;
                            mxgRootScope.$broadcast(mxgEvents.CASE_FORM_CHANGED, {
                                reasonForChange: FORM_CHANGE_REASONS.PARTIAL_SUBMIT,
                                menu: navigation
                            });
                            if (caseStatus !== CaseStatus.INCOMPLETE) {
                                checkStatusChange(CaseStatus.INCOMPLETE);
                            }
                        }
                    });
                ProcessManager.run(promise);
                return promise;
            }

            /**
             * @private
             * @param {mxgFormChangeReasons} reason
             * @returns {Function}
             * */
            function finishCaseSetup(reason) {
                return function (response) {
                    caseExists = true;
                    getNewFormProcessor(reason)(response);
                    return response;
                };
            }

            var service = {
                stop: stop,
                getRulebase: getRulebase,
                getLanguageCode: getLanguageCode,
                getMandatoryValidationsSetting: getMandatoryValidationsSetting,
                getNextForm: withValidation(getNextForm, RuntimeConstants.mandatoryValidations.NEXT),
                getPrevForm: withValidation(getPrevForm, RuntimeConstants.mandatoryValidations.PREVIOUS),
                saveForm: withValidation(saveForm, RuntimeConstants.mandatoryValidations.SUBMIT),
                getFormById: withValidation(getFormById, RuntimeConstants.mandatoryValidations.SUBMIT),
                getActiveForm: getActiveForm,
                reloadActiveForm: reloadActiveForm,
                startCase: startCase,
                resumeCase: resumeCase,
                partialSubmit: partialSubmit,
                navigation: navigation
            };

            /**
             * @ngdoc method
             * @method ActiveCase#exists
             * @description
             * returns true if there is a case currently in progress
             * @returns {boolean}
             */
            service.exists = function () {
                return caseExists;
            };

            /**
             * @ngdoc method
             * @method ActiveCase#isCaseComplete
             * @returns {boolean}
             */
            service.isCaseComplete = function () {
                return service.exists() && service.navigation.areAllFormsCompleted();
            };

            /**
             * @ngdoc method
             * @method ActiveCase#completeCaseSafeExit
             * @returns {Promise}
             */
            service.completeCaseSafeExit = function () {
                if (!service.isCaseComplete()) {
                    return $q.reject(false);
                }
                return service.saveForm().then(function () {
                    service.isCaseComplete() && exitCase(ExitCaseDirection.APPLICATION_COMPLETE);
                    return true;
                });
            };

            return service;

        }]);

angular.module('mxg.activeCase.ActiveCaseErrorHandler', [
    'mxg.validation.ValidationErrorMap',
    'mxg.system.ErrorModel',
    'mxg.system.Events',
    'mxg.system.RootScope',
    'mxg.translation.TranslateService'
])
    .service('mxgActiveCaseErrorHandler', [
        'mxgValidationErrorMap', 'mxgErrorModel', 'mxgEvents', 'mxgRootScope', 'mxgTranslateService',
        function (ValidationErrorMap, ErrorModel, mxgEvents, mxgRootScope, TranslateService) {

            var service = this;

            service.processErrorResponse = function (errorStatus, responseData) {
                var errorModel;
                switch (errorStatus) {
                    case 'BUSY':
                        errorModel = ErrorModel.create(responseData);
                        mxgRootScope.$broadcast(mxgEvents.FATAL_ERROR, errorModel.toString(), errorModel);
                        break;
                    case '400':
                        responseData && ValidationErrorMap.process(responseData);
                        break;
                    case '500':
                        errorModel = ErrorModel.create(fixErrorMessage(responseData));
                        mxgRootScope.$broadcast(mxgEvents.FATAL_ERROR, errorModel.toString(), errorModel);
                        break;
                    default:
                        //
                }
            };

            function fixErrorMessage(data) {
                var errorModels = angular.isArray(data) ? data : [data];
                var processed = errorModels.map(function (item) {
                    if (!angular.isObject(item) || !item.ruleId || (item.ruleId != '4035')) {
                        return item;
                    }
                    return {
                        code: '2007',
                        message: TranslateService.getById('UserMessages.2007')
                    };
                });
                return processed.length === 1 ? processed[0] : processed;
            }

        }]);

angular.module('mxg.activeCase.ActiveCaseValidator', [
    'mxg.validation.ValidationType',
    'mxg.validation.ValidationErrorMap',
    'mxg.messages.MessagesMap',
    'mxg.formElement.FormElementModelValidator',
    'mxg.translation.TranslateService',
    'mxg.components.DialogService'
])
    .factory('mxgActiveCaseValidator', [
        '$q', 'mxgValidationType', 'mxgValidationErrorMap', 'mxgMessagesMap', 'mxgFormElementModelValidator',
        'mxgTranslateService', 'mxgDialogService',
        function ($q, ValidationType, ValidationErrorMap, MessagesMap, FormElementModelValidator,
                  TranslateService, DialogService) {

            function validateForm(formModel, options) {

                options = options || {};

                return $q(function (resolve, reject) {

                    var validationErrors = FormElementModelValidator.validate(formModel);

                    if (options.skipEmptyValues) {
                        validationErrors = validationErrors.filter(function (error) {
                            return error.type !== ValidationType.MANDATORY
                        });
                    }

                    if (validationErrors.length) {
                        !options.silent && renderErrors(validationErrors);
                        reject(false);
                    }
                    else {
                        resolve(true);
                    }

                });

            }

            function validateCaseDataStructure(data) {
                return angular.isObject(data) &&
                    angular.isObject(data.formList) &&
                    angular.isArray(data.formList.formNavigationModels) &&
                    angular.isObject(data.resultingForm);
            }

            function renderErrors(errors) {

                var processedErrors = errors.reduce(function (reduced, item) {

                    var error = angular.extend(item,
                        {message: TranslateService.getByErrorCode(item.code, item.params)});

                    if (item.type == ValidationType.ALERT) {
                        reduced.alert.push(error);
                    }
                    else {
                        reduced.banner.push(error);
                    }

                    return reduced;

                }, {banner: [], alert: []});

                ValidationErrorMap.processValidationErrors(processedErrors.banner);

                if (processedErrors.alert.length) {
                    DialogService.alert(processedErrors.alert[0].message);
                }

            }

            function resetMessages() {
                ValidationErrorMap.reset();
                MessagesMap.reset();
            }

            return {
                validateForm: validateForm,
                validateCaseDataStructure: validateCaseDataStructure,
                resetMessages: resetMessages
            };

        }]);

angular.module('mxg.activeCase.FormChangeReasons', [])
    .constant('mxgFormChangeReasons', {
        SETUP_CASE_CREATED: 'SETUP_CASE_CREATED',
        SETUP_CASE_RESUMED: 'SETUP_CASE_RESUMED',
        NAV_CONTROL_CONTINUE: 'NAV_CONTROL_CONTINUE',
        NAV_CONTROL_BACK: 'NAV_CONTROL_BACK',
        NAV_CONTROL_SAVE: 'NAV_CONTROL_SAVE',
        NAV_CONTROL_RELOAD: 'NAV_CONTROL_RELOAD',
        NAV_MENU_CLICK: 'NAV_MENU_CLICK',
        PARTIAL_SUBMIT: 'PARTIAL_SUBMIT'   
    });


angular.module('mxg.case.BootstrapApproach', [])
    .constant('mxgBootstrapApproach', {
        HOST_APP: 'HOST_APP',
        GENERIC: 'GENERIC'
    });
angular.module('mxg.case.CaseStatus', [])
    .constant('mxgCaseStatus', {
        INCOMPLETE: 'INCOMPLETE',
        COMPLETE: 'COMPLETE'
    });
angular.module('mxg.case.ExitCaseDirection', [])
    .constant('mxgExitCaseDirection', {
        LEFT: 'LEFT',
        RIGHT: 'RIGHT',
        APPLICATION_COMPLETE: 'APPLICATION_COMPLETE'
    });

angular.module('mxg.caseManager.CaseManager', ['mxg.activeCase.ActiveCase'])
    .factory('mxgCaseManager', ['mxgActiveCase', function (ActiveCase) {
        "use strict";
        return {
            startCase: function (data) {
                return ActiveCase.startCase(data);
            },
            resumeCase: function (data) {
                return ActiveCase.resumeCase(data);
            }
        };
    }]);
/**
 * This interceptors MUST be added through unshift
 * @example
 * $httpProvider.interceptors.unshift('mxgCommonHttpInterceptor');
 */
angular.module('mxg.components.CommonHttpInterceptor', [])
    .factory('mxgCommonHttpInterceptor', ['$q', function mxgCommonHttpInterceptor($q) {
        "use strict";
        return {
            request: function (config) {
                if (config.url.indexOf('mxg-') === 0 && config.url.indexOf('mxg-template/') === -1) {
                    config.magnum = true;
                }
                return config;
            },
            response: function (response) {
                if (+response.status < 200 || +response.status > 299) {
                    return $q.reject(response);
                }
                return response;
            }
        }
    }]);
angular.module('mxg.components', [
    'mxg.components.inputMask.InputMask',
    'mxg.components.inputMask.DateFormatMask',
    'mxg.components.CommonHttpInterceptor',
    'mxg.components.PartialDate',
    'mxg.components.RestInterceptor',
    'mxg.components.PreventCachingInterceptor',
    'mxg.components.RulebaseInterceptor',
    'mxg.components.ProcessManager',
    'mxg.components.ConditionsCustomFunctions',
    'mxg.components.CoverSheet',
    'mxg.components.HelpText',
    'mxg.components.HttpFixStatusCodeInterceptor',
    'mxg.components.Dialog',
    'mxg.components.DialogService',
    'mxg.components.ElementId',
    'mxg.components.ServiceUnavailableInterceptor',
    'mxg.components.noUiSlider',
    'mxg.components.iDateFilter',
    'mxg.components.typedValue'
]);

angular.module('mxg.components.ConditionsCustomFunctions', [])
    .factory('mxgConditionsCustomFunctions', function () {

        /*
         * @description
         * All parameters are supposed to be full valid dates in "yyyy-MM-dd" format
         * If value is a valid, but not full date(i.e. "2016-08") it considered to be invalid and
         * returns false
         * @param {String} value
         * @param {String} rangeMinValue
         * @param {String} rangeMaxValue
         * @returns {Boolean}
         * */
        function dateInRange(value, rangeMinValue, rangeMaxValue) {
            value = Array.isArray(value) ? value[0] : value;
            value = '' + value;
            rangeMinValue = Array.isArray(rangeMinValue) ? rangeMinValue[0] : rangeMinValue;
            rangeMaxValue = Array.isArray(rangeMaxValue) ? rangeMaxValue[0] : rangeMaxValue;

            if (!value || (value.length < 10)) {
                return false;
            }
            var dates = [
                new Date(value),
                rangeMinValue ? new Date(rangeMinValue) : null,
                rangeMaxValue ? new Date(rangeMaxValue) : null
            ];
            if (dates.some(function (dateValue) {
                    return !dateValue ? false : isValidDate(dateValue);
                })) {
                return false;
            }
            if (rangeMinValue && !rangeMaxValue) {
                return dates[0] >= dates[1];
            }
            if (!rangeMinValue && rangeMaxValue) {
                return dates[0] <= dates[2];
            }
            if (rangeMinValue && rangeMaxValue) {
                return (dates[0] >= dates[1]) && (dates[0] <= dates[2]);
            }
            return true;
            function isValidDate(dateValue) {
                return dateValue.toString() === 'Invalid Date';
            }
        }

        return {
            dateInRange: dateInRange
        };

    });


angular.module('mxg.components.CoverSheet', [
    'mxg.components.CoverSheetCtrl'
]).directive('mxgCoverSheet', [function () {
    'use strict';
    return {
        scope: false,
        controller: 'mxgCoverSheetCtrl',
        controllerAs: 'coverSheet',
        link: function ($scope) {
            $scope.$watch(function () {
                return $scope.coverSheet.visible();
            }, function (newValue) {
                $scope.coverSheet.onCoverStateChange(newValue);
            });
        }
    };
}]);

angular.module('mxg.components.CoverSheetCtrl', [
    'mxg.components.ProcessManager',
    'mxg.magnum.Config',
    'mxg.magnum.MagnumContainerElement'
]).controller('mxgCoverSheetCtrl', [
    '$compile', '$scope', '$element', 'mxgProcessManager', 'MagnumConfig', 'MagnumContainerElement',
    function ($compile, $scope, $element, ProcessManager, MagnumConfig, MagnumContainerElement) {
        'use strict';

        var coverSheet = this;

        var customLoadingScreen = MagnumConfig.getOption('customLoadingScreen');

        var defaultLoadingState = (function ($scope, $element) {
            var attached = null;
            var coverElement = $compile(angular.element('<div class="mxg-cover-sheet"></div>'))($scope);
            var COVERED_CLASS = 'mxg-covered';
            return {
                start: function () {
                    if (attached) {
                        return;
                    }
                    attached = true;
                    $element.addClass(COVERED_CLASS);
                    $element.prepend(coverElement);
                },
                stop: function () {
                    if (!attached) {
                        return;
                    }
                    coverElement.detach();
                    $element.removeClass(COVERED_CLASS);
                    attached = null;
                }
            };
        })($scope, $element);

        coverSheet.visible = function () {
            return ProcessManager.isRunning() || MagnumContainerElement.isRendering();
        };

        if (customLoadingScreen) {
            var loadingStart = customLoadingScreen.onLoadingStart;
            var loadingEnd = customLoadingScreen.onLoadingEnd;
            coverSheet.onCoverStateChange = function (isActive) {
                isActive ? loadingStart() : loadingEnd();
            }
        } else {
            coverSheet.onCoverStateChange = function (isActive) {
                isActive ? defaultLoadingState.start() : defaultLoadingState.stop();
            }
        }

    }
]);

angular.module('mxg.components.Dialog', [])
    .directive('mxgDialog', [function () {
        "use strict";

        return {
            restrict: 'AE',
            templateUrl: 'mxg-template/components/ModalDialog.html',
            scope: {
                message: '@mxgMessage',
                actions: '=mxgActions',
                onAnswer: '&mxgOnAnswer',
                type: '@mxgModalType',
                title: '@mxgModalTitle'
            },
            link: function ($scope, $element) {
                $element.addClass('mxg-modal');
            }
        };

    }]);

angular.module('mxg.components.DialogService', [
    'mxg.components.Dialog',
    'mxg.translation.TranslateService',
    'mxg.system.RootScope',
    'mxg.magnum.MagnumContainerElement',
    'mxg.helpers.PositionHelper'
])
    .factory('mxgDialogService', [
        '$q', '$compile', '$timeout', 'mxgTranslateService', 'mxgRootScope', 'MagnumContainerElement', 'mxgPositionHelper',
        function ($q, $compile, $timeout, TranslateService, mxgRootScope, MagnumContainerElement, PositionHelper) {
            "use strict";

            var showModal = function (title, message, actions, type, customScope, customElement) {

                var parentScope = customScope || mxgRootScope.$new();
                var containerElement = customElement || MagnumContainerElement.get().children(0);

                var deferred = $q.defer();
                var dialogElement;
                var dialogScope = parentScope.$new();

                dialogScope.message = message;
                dialogScope.actions = actions;
                dialogScope.type = type;
                dialogScope.title = title;
                dialogScope.onAnswer = function (response) {
                    deferred.resolve(response);
                    dialogElement.empty().remove();
                    containerElement.css({
                        'min-height':  'inherit'
                    });
                };

                dialogElement = $compile('<div data-mxg-dialog data-mxg-message="{{message}}" data-mxg-actions="actions" data-mxg-on-answer="onAnswer(response)" data-mxg-modal-type="{{type}}" data-mxg-modal-title="{{title}}"></div>')(dialogScope);
                containerElement.prepend(dialogElement);

                $timeout(function() {
                    var modalElement = dialogElement[0].querySelector('.mxg-modal-dialog');
                    if (modalElement) {
                        var modalHeight = PositionHelper.height(modalElement);
                        containerElement.css({
                            'min-height': (modalHeight + 20) + 'px'
                        });
                    }
                });

                return deferred.promise;

            };

            var showConfirm = function (message, scope, containerElement) {
                var actions = [
                    {
                        id: 'magnum_dialog_btn_yes',
                        caption: TranslateService.getById('ActionControls.BTN_LABEL_YES'),
                        actionType: 'primary',
                        action: true
                    },
                    {
                        id: 'magnum_dialog_btn_no',
                        caption: TranslateService.getById('ActionControls.BTN_LABEL_NO'),
                        actionType: 'default',
                        action: false
                    }
                ];

                return showModal(TranslateService.getById('FrontEndLabels.WARNING_ALERT_TITLE'), message, actions, 'warning',
                    scope, containerElement);
            };

            var showAlert = function (message, scope, containerElement) {

                var actions = [
                    {
                        id: 'magnum_dialog_btn_ok',
                        caption: TranslateService.getById('ActionControls.BTN_LABEL_OK'),
                        actionType: 'primary',
                        action: true
                    }
                ];
                return showModal(TranslateService.getById('FrontEndLabels.ERROR_ALERT_TITLE'), message, actions, 'error',
                    scope, containerElement);
            };

            return {
                confirm: showConfirm,
                alert: showAlert
            };

        }]);

/**
 * @ngdoc filter
 * @name mxgElementIdFilter
 * @description This filter is created to clear input id string from dots and replace them with underscore. But it may be used to any string.
 * @param {string} input String to be filtered
 * @returns {string} Filtered string
 * @usage
 * <input type="text" id="{{formElement.getElementId() | mxgElementId}}" name="{{formElement.getElementName()}}" />
 *
 */
angular.module('mxg.components.ElementId', [])
    .filter('mxgElementId', function () {
        "use strict";
        return function (input) {
            return input && input.replace(/[^a-zA-Z0-9]/g, '_');
        }
    });
angular.module('mxg.components.HelpText', ['ngSanitize', 'mxg.markupToHTML'])
    .directive('mxgHelpText', [function () {
        'use strict';
        return {
            template: '<span class="mxg-help-text-icon mxg-icon mxg-icon-help"></span><span class="mxg-help-text-tooltip" ng-class="{\'mxg-help-text-tooltip-visible\': visible}" ng-bind-html="text | mxgMarkupToHTML"></span>',
            restrict: 'A',
            scope: {
                text: '@mxgHelpText'
            },
            link: function ($scope, $element) {
                $element.addClass('mxg-help-text');

                var parentEl = $element[0];
                var tooltipTextEl = parentEl.querySelector('.mxg-help-text-tooltip');
                var tooltipIconEl = parentEl.querySelector('.mxg-help-text-icon');
                var mouseClickable = false;

                var mouseLeave = function () {
                    $scope.visible = false;
                    $scope.$digest();
                };

                var setTransform = function (elem, str) {
                    elem.style.webkitTransform = str;
                    elem.style.MozTransform = str;
                    elem.style.msTransform = str;
                    elem.style.OTransform = str;
                    elem.style.transform = str;
                };

                var mouseEnter = function () {
                    $scope.visible = true;
                    $scope.$digest();

                    var containerStyle = document.querySelector('.mxg-application-form').getBoundingClientRect();
                    var container = {
                        width: parseInt(
                            containerStyle.width) || window.innerWidth || document.documentElement.clientWidth,
                        left: parseInt(containerStyle.left) || 0,
                        right: parseInt(
                            containerStyle.right) || window.innerWidth || document.documentElement.clientWidth
                    };
                    var textWidth = parseInt(window.getComputedStyle(tooltipTextEl).getPropertyValue('width')) || 0;
                    var tooltipIconLeft = tooltipIconEl.getBoundingClientRect().left;

                    if (container.width <= textWidth) {
                        // Smaller than Screen
                        tooltipTextEl.style.width = container.width + 'px';
                        setTransform(tooltipTextEl, 'translate(' + (container.left - tooltipIconLeft) + 'px, 115%)');
                    } else {
                        var freeSizeFromRight = container.right - tooltipIconLeft;
                        var freeSizeFromLeft = tooltipIconLeft - container.left;

                        if (freeSizeFromRight > textWidth / 2 && freeSizeFromLeft > textWidth / 2) {
                            // To Center
                            setTransform(tooltipTextEl, 'translate(-50%, 115%)');
                        } else if (freeSizeFromLeft > textWidth / 2) {
                            // Not enough space from right
                            setTransform(
                                tooltipTextEl, 'translate(' + (container.width - freeSizeFromLeft - textWidth) + 'px, 115%)');
                        } else {
                            // Not enough space from left
                            setTransform(tooltipTextEl, 'translate(' + -freeSizeFromLeft + 'px, 115%)');
                        }
                    }
                };

                $element.on('touchend', function () {
                    if ($scope.visible) {
                        mouseLeave();
                    } else {
                        mouseEnter();
                    }
                });

                $element.on('mouseleave', function () {
                    mouseClickable = true;
                    mouseLeave();
                });

                $element.on('mouseenter', function () {
                    mouseClickable = false;
                    mouseEnter();
                });
            }
        }
    }]);

/**
 * This interceptor is used to map HTTP status codes to those used throughout Magnum application: 500 and 400
 * And it appeared that we cannot rely on HTTP status only because it can be changed by proxy or something like this,
 * so we need to check response data if it contains some known error code
 */
angular.module('mxg.components.HttpFixStatusCodeInterceptor', [
    'mxg.system.ErrorModel'
])
    .factory('mxgHttpFixStatusCodeInterceptor', [
        '$q',
        'mxgErrorModel',
        function mxgHttpFixStatusCodeInterceptor($q, ErrorModel) {
            'use strict';

            function fixResponse(response) {
                if (response.config.magnum) {
                    if (ErrorModel.isFormValidationError(response.data)) {
                        response.status = 400;
                    }
                    else if (ErrorModel.isErrorHTTPResponse(response) ) {
                        response.status = 500;
                    }
                    if ((+response.status === 500) && !angular.isObject(response.data)) {
                        response.data = {
                            message: response.data
                        };
                    }
                }
                return response;
            }

            return {
                response: fixResponse,
                responseError: function (response) {
                    return $q.reject(fixResponse(response));
                }
            };

        }]);

/**
 * @ngdoc filter
 * @name mxgIDate
 */
angular.module('mxg.components.iDateFilter', ['mxg.helpers.DateHelper'])
    .filter('mxgIDate', ['dateFilter', 'mxgDateHelper', function (dateFilter, DateHelper) {
        'use strict';

        return function (date, format, timezone) {
            var validDateFormat =  DateHelper.canonizeDateFormat(format);
            return dateFilter(date, validDateFormat, timezone);
        };

    }]);

/**
 * Factory that returns contructor function for partial dates
 *
 * It does not provide validation methods but just gives an easier access to the date elements
 * It does not use `new mxgPartialDate()` notation as it's harder to mock
 *
 * @example
 * var date = mxgPartialDate("2014");
 * var date = mxgPartialDate("2014-Oct");
 * var date = mxgPartialDate("2014-Jun-12");
 *
 */
angular.module('mxg.components.PartialDate',
    ['mxg.helpers.DateHelper'])
    .factory('mxgPartialDate', ['mxgDateHelper', function mxgPartialDate(DateHelper) {
        'use strict';

        function pad(number) {
            return ("00" + number).slice(-2);
        }

        /**
         * @class
         * @param date
         */
        function partialDate(date) {

            if (angular.isDate(date)) {
                this.setFullDate(date.getFullYear(), date.getMonth() + 1, date.getDate());
            } else {
                var parts = (date || "").split(" ")[0].split('-');
                this._year = parts[0] || null;
                this._month = parts[1] || null;
                this._date = parts[2] || null;
            }

        }
        /**
         *
         * @param value
         * @returns {mxgPartialDate}
         */
        partialDate.prototype.setFullYear = function (value) {
            this._year = value;
            return this;
        };

        /**
         *
         * @param value
         * @returns {mxgPartialDate}
         */
        partialDate.prototype.setMonth = function (value) {
            this._month = value;
            return this;
        };

        /**
         *
         * @param value
         * @returns {mxgPartialDate}
         */
        partialDate.prototype.setDate = function (value) {
            this._date = value;
            return this;
        };

        /**
         *
         * @returns {Number|null}
         */
        partialDate.prototype.getFullYear = function () {
            return parseInt(this._year) || null;
        };

        /**
         *
         * @returns {Number|null}
         */
        partialDate.prototype.getMonth = function () {
            return parseInt(this._month) || null;
        };

        /**
         *
         * @returns {Number|null}
         */
        partialDate.prototype.getDate = function () {
            return parseInt(this._date) || null;
        };

        /**
         *
         * @returns {string}
         */
        partialDate.prototype.toString = function () {

            return this._year ? this._year + (this._month > 0 ? ("-" + pad(this._month) + (this._date ? "-" + pad(
                        this._date) : "")) : "") : null;

        };

        /**
         * @returns {{partialDate}}
         */
        partialDate.prototype.normalize = function () {
            var dateCopy = mxgPartialDate(this.toString());
            if (dateCopy.getMonth() === null) {
                dateCopy.setMonth(6);
                dateCopy.setDate(30);
            } else if (dateCopy.getDate() === null) {
                dateCopy.setDate(15);
            }
            return dateCopy;
        };

        partialDate.prototype.toDate = function () {
            return DateHelper.createDateInLocalTimezone(this.toString());
        };

        partialDate.prototype.setFullDate = function (year, month, date) {
            return year && this.setFullYear(year)
                && month && this.setMonth(month)
                && date && this.setDate(date);
        };

        partialDate.prototype.compareTo = function (date) {
            date = mxgPartialDate(date);
            var comparator = function (a, b) {
                return a > b ? 1 : (a < b ? -1 : 0);
            };

            var comparison = comparator(this.getFullYear(), date.getFullYear());
            if (!comparison && this.getMonth()) {
                comparison = comparator(this.getMonth(), date.getMonth())
            }
            if (!comparison && this.getDate()) {
                comparison = comparator(this.getDate(), date.getDate())
            }
            return comparison;
        };

        partialDate.prototype.greaterThan = function (date) {
            return this.compareTo(date) === 1;
        };

        partialDate.prototype.lessThan = function (date) {
            return this.compareTo(date) === -1;
        };

        partialDate.prototype.equals = function (date) {
            return this.compareTo(date) === 0;
        };

        var mxgPartialDate = function (date) {

            return new partialDate(date);
        };
        return mxgPartialDate;
    }]);

angular.module('mxg.components.PreventCachingInterceptor', ['mxg.magnum.Config'])
    .factory('mxgPreventCachingInterceptor', ['MagnumConfig', function mxgPreventCachingInterceptor(Config) {
        'use strict';
        return {
            request: function (config) {
                if (Config.getOption('preventCache',
                        false) && config.magnum === true && config.method.toLowerCase() === 'get') {
                    var preventingParams = {};
                    preventingParams[Config.getOption('requestTimestampPropertyName',
                        '_mxg')] = new Date().getTime() + Math.random();
                    config.params = angular.extend(config.params || {}, preventingParams);
                }
                return config;
            }
        }
    }]);

angular.module('mxg.components.ProcessManager', [])
    .constant('mxgProcessStatus', {
        RUNNING: 1,
        IDLE: 0
    })
    .constant('mxgGlobalProcessName', 'GLOBAL')
    .factory('mxgProcessManager', ['$q', 'mxgProcessStatus', 'mxgGlobalProcessName', function ($q, ProcessStatus, GlobalGroupName) {
        "use strict";
        var groups = {};

        var getGroup = function (groupName) {
            if (groups[groupName]) {
                return groups[groupName];
            }

            return groups[groupName] = {
                processes: null,
                status: ProcessStatus.IDLE,
                __eventHandlers: {},
                __runningProcCount: 0
            };

        };

        var triggerEventCallback = function (group, event, callback) {
            callback();
        };

        var triggerEvent = function (group, event) {
            if (group.__eventHandlers[event]) {
                group.__eventHandlers[event].forEach(function (callback) {
                    triggerEventCallback(group, event, callback);
                });
            }
        };

        /**
         *
         * @type {{run: run, onStart: onStart, onFinish: onFinish, onIdle: onIdle, runInGroup: runInGroup, onGroupStart: onGroupStart, onGroupFinish: onGroupFinish, onGroupRuning: onGroupRuning, onGroupIdle: onGroupIdle, isGroupRunning: isGroupRunning}}
         */
        var ProcessManager = {
            run: function (promise) {
                return ProcessManager.runInGroup(GlobalGroupName, promise);
            },
            /**
             *
             */
            onStart: function (callback) {
                return ProcessManager.onGroupStart(GlobalGroupName, callback);
            },
            /**
             *
             */
            onFinish: function (callback) {
                return ProcessManager.onGroupFinish(GlobalGroupName, callback);
            },
            /**
             *
             */
            onIdle: function (callback) {
                return ProcessManager.onGroupIdle(GlobalGroupName, callback);
            },

            /**
             *
             * @param callback
             * @returns {*}
             */
            onRunning: function (callback) {
                return ProcessManager.onGroupRuning(GlobalGroupName, callback);
            },
            /**
             *
             * @returns {boolean}
             */
            isRunning: function () {
                return ProcessManager.isGroupRunning(GlobalGroupName);
            },

            /**
             *
             * @param groupName
             * @param promise
             */
            runInGroup: function (groupName, promise, additional) {
                var group = getGroup(groupName);
                promise = $q.when(promise);

                if (group.status === ProcessStatus.IDLE) {
                    triggerEvent(group, 'start');
                    triggerEvent(group, 'running');
                }

                group.status = ProcessStatus.RUNNING;
                group.__runningProcCount++;
                promise.add = additional;
                (group.processes = group.processes || []).push(promise);

                var onFulfilled = function () { // we need to change status when completed
                    group.processes.splice(group.processes.indexOf(promise), 1);
                    group.__runningProcCount--;
                    if (group.__runningProcCount === 0) {
                        triggerEvent(group, 'finish');
                        triggerEvent(group, 'idle');
                        group.status = ProcessStatus.IDLE;

                    }

                };
                promise['finally'](onFulfilled);
            },
            /**
             *
             * @param groupName
             * @param callback
             * @returns {Function}
             */
            onGroupStart: function (groupName, callback) {
                var group = getGroup(groupName);
                var eventHandlers = group.__eventHandlers['start'] = group.__eventHandlers['start'] || [];
                eventHandlers.push(callback);
                return function () {
                    eventHandlers.splice(eventHandlers.indexOf(callback), 1);
                }
            },
            /**
             *
             * @param groupName
             * @param callback
             * @returns {Function}
             */
            onGroupFinish: function (groupName, callback) {
                var group = getGroup(groupName);
                var eventHandlers = group.__eventHandlers['finish'] = group.__eventHandlers['finish'] || [];
                eventHandlers.push(callback);
                return function () {
                    eventHandlers.splice(eventHandlers.indexOf(callback), 1);
                }
            },
            /**
             * This callback will be called if the group started or it is running right now
             * @param groupName
             * @param callback
             */
            onGroupRuning: function (groupName, callback) {
                var group = getGroup(groupName);
                var eventHandlers = group.__eventHandlers['running'] = group.__eventHandlers['running'] || [];

                eventHandlers.push(callback);
                if (group.status === ProcessStatus.RUNNING) {
                    triggerEventCallback(group, 'running', callback);
                }

                return function () {
                    eventHandlers.splice(eventHandlers.indexOf(callback), 1);
                }

            },
            /**
             *
             * @param groupName
             * @param callback
             * @returns {Function}
             */
            onGroupIdle: function (groupName, callback) {
                var group = getGroup(groupName);
                var eventHandlers = group.__eventHandlers['idle'] = group.__eventHandlers['idle'] || [];

                eventHandlers.push(callback);
                if (group.status === ProcessStatus.IDLE) {
                    triggerEventCallback(group, 'idle', callback);
                }

                return function () {
                    eventHandlers.splice(eventHandlers.indexOf(callback), 1);
                }
            },
            /**
             *
             * @param groupName
             * @returns {boolean}
             */
            isGroupRunning: function (groupName) {
                var group = getGroup(groupName);
                return group.status === ProcessStatus.RUNNING;
            }
        };
        return ProcessManager;
    }]);
/**
 * This interceptor is used to redirect all request sent through $http service to be redirected to the correct entry point
 */
angular.module('mxg.components.RestInterceptor', ['mxg.magnum.Config'])
    .factory('mxgRestInterceptor', ['MagnumConfig', function RestInterceptor(MagnumConfig) {
        'use strict';
        return {
            request: function (config) {
                var restEntryPointUrl;
                var restData;
                if (config.url.indexOf('mxg-rest/') === 0) {
                    restEntryPointUrl = MagnumConfig.getOption('restEntryPointUrl', '');
                    if (angular.isFunction(restEntryPointUrl)) {
                        restData = config.restData || {
                            id: config.url,
                            params: {}
                        };
                        config.url = restEntryPointUrl(restData.id, restData.params);
                    }
                    else {
                        config.url = config.url.replace('mxg-rest/', restEntryPointUrl);
                    }
                }
                return config;
            }
        };
    }]);

/**
 * This interceptor is used to redirect all request sent through $http service to be redirected to the correct entry point
 */
angular.module('mxg.components.RulebaseInterceptor', [
    'mxg.rulebase.RulebaseService'
])
    .factory('mxgRulebaseInterceptor', [
        'mxgRulebaseService',
        function RulebaseInterceptor(RulebaseService) {
        "use strict";

        return {
            request: function (config) {
                var rulebase = RulebaseService.getActiveRulebase();
                if (config.magnum === true) {
                    config.url = config.url.replace('rulebases/current', 'rulebases/' + rulebase);
                }
                return config;
            }
        };

    }]);

/**
 * This interceptor is used to redirect all request sent through $http service to be redirected to the correct entry point
 */
angular.module('mxg.components.ServiceUnavailableInterceptor', ['mxg.magnum.Config'])
    .factory('mxgServiceUnavailableInterceptor', ['$q', 'mxgRootScope', 'mxgEvents', 'mxgErrorModel', function ServiceUnavailableInterceptor($q, mxgRootScope, mxgEvents, ErrorModel) {
        "use strict";
        return {
            response: function (response) {
                if (response.config.magnum && response.status === 503 && response.data.code === 'FATAL') {
                    var error = ErrorModel.create(response.data);
                    mxgRootScope.$broadcast(mxgEvents.FATAL_ERROR, error.getMessage(), error);
                }
                return response;
            }
        }

    }]);

angular.module('mxg.form', [
    'mxg.form.widgets',
    'mxg.form.controls',
    'mxg.form.InputGroup',
    'mxg.form.validationBanner.ValidationBanner',
    'mxg.form.validation.ValidationElement',
    'mxg.form.validation.ValidationTooltipTrigger'
]);
angular.module('mxg.form.InputGroup', [])
    .directive('mxgInputGroup', function () {
        "use strict";
        return {
            templateUrl: 'mxg-template/form/InputGroup.html',
            transclude: true,
            scope: {
                preText: "@?mxgPreText",
                postText: "@?mxgPostText"

            },
            link: function ($scope, $element) {
            }
        }
    });
/**
 * @ngdoc factory
 * @name mxgConditionalFormElementModel
 */
angular.module('mxg.formElement.ConditionalFormElementModel', [
    'mxg.system.RootScope',
    'mxg.formElement.FormElementModel',
    'mxg.formElement.FormElementLocationService',
    'mxg.formElement.FormElementType',
    'mxg.formElement.conditions.ConditionEvaluator'
])
    .factory('mxgConditionalFormElementModel', [
        'mxgRootScope',
        'mxgFormElementModel',
        'mxgFormElementLocationService',
        'mxgFormElementType',
        'mxgConditionEvaluator',
        function (mxgRootScope, FormElementModel, FormElementLocationService, FormElementType, ConditionEvaluator) {
            'use strict';

            /**
             * @class ConditionalFormElement
             * @param {Object} model
             * @param {Object} parentNode
             */
            function ConditionalFormElement(model, parentNode) {
                this.setCondition(model.condition);
                this._parentInstances = null;
                var parent = parentNode;
                while (parent) {
                    var parentType = parent.getType();
                    if (parentType === FormElementType.SECTION_INSTANCE.toString()) {
                        if (!this._parentInstances) {
                            this._parentInstances = [];
                        }
                        this._parentInstances[this._parentInstances.length] = parent;
                    }
                    parent = parent.getParent();
                }
                FormElementModel.call(this, model, parentNode);
            }

            ConditionalFormElement.prototype = Object.create(FormElementModel.prototype);
            ConditionalFormElement.prototype.constructor = ConditionalFormElement;

            ConditionalFormElement.prototype.canHaveCondition = function () {
                return true;
            };

            ConditionalFormElement.prototype.setCondition = function (condition) {
                this._evaluator = angular.isObject(condition) ? new ConditionEvaluator(condition) : null;
                this._locatedElements = {};
                this._staticConditionValue = null;
                if (this._evaluator) {
                    this.conditional = true;
                } else {
                    this._staticConditionValue = true;
                }
            };

            /**
             * There is no need to add a child node in case if this element's condition is always evaluated to false
             * @param childModel
             * @param {Boolean} rebuildIds
             */
            ConditionalFormElement.prototype.addChild = function (childModel, rebuildIds) {
                if (this._staticConditionValue === false) {
                    return;
                }
                return FormElementModel.prototype.addChild.call(this, childModel, rebuildIds);
            };

            ConditionalFormElement.prototype.removeChild = function (childModel) {
                var updatedChildren = FormElementModel.prototype.removeChild.call(this, childModel);
                ConditionalFormElement.resetConditionsCache(this.getRoot());
                return updatedChildren;
            };

            ConditionalFormElement.prototype.hasStaticConditionValue = function () {
                return this._staticConditionValue !== null;
            };

            ConditionalFormElement.prototype.getStaticConditionValue = function () {
                return this._staticConditionValue;
            };

            ConditionalFormElement.prototype.evaluateCondition = function () {
                if (this._staticConditionValue !== null) {
                    return this._staticConditionValue;
                }
                var actualValuesMap = {};
                var self = this;
                var hasSomeValues = false;
                this._evaluator.getLocators().forEach(function (locator) {
                    var valueObject = null;
                    var located = self.getValueForCondition(locator);
                    if (located == null) {
                        actualValuesMap[locator] = null;
                        return;
                    }
                    located = located.filter(function (item) {
                        return item != null;
                    });
                    if (located.length) {
                        actualValuesMap[locator] = located;
                        hasSomeValues = true;
                    }
                    else {
                        actualValuesMap[locator] = null;
                    }
                });
                return hasSomeValues && this._evaluator.evaluateCondition(actualValuesMap);
            };

            ConditionalFormElement.prototype.locateElements = function (locator) {

                if (angular.isArray(this._locatedElements[locator]) && this._locatedElements[locator].length) {
                    return this._locatedElements[locator];
                }
                var found = null;
                if (this._parentInstances) {
                    // we need to search with context; it must either exist in current instance or anywhere else besides sibling instances
                    found = ConditionalFormElement.findInParentsContext(locator, this._parentInstances, this.getRoot());
                }
                else {
                    found = FormElementLocationService.findAllByLocator(locator, 'getLocator', this.getRoot());
                }
                if (found) {
                    this._locatedElements[locator] = found;
                    return found;
                }
                else {
                    return null;
                }
            };

            ConditionalFormElement.prototype.findFormElement = function (locator) {
                var locatedElements = this.locateElements(locator);
                if (locatedElements == null) {
                    return null;
                }
                var evaluateConditionRecursive = function (formElement) {
                    if (!formElement) {
                        return true;
                    }
                    return (!formElement.evaluateCondition || formElement.evaluateCondition())
                        && evaluateConditionRecursive(formElement.getParent());
                };
                var validForEvaluation = locatedElements.filter(evaluateConditionRecursive);
                if (!validForEvaluation.length) {
                    return null;
                }
                return validForEvaluation;
            };

            ConditionalFormElement.prototype.getValueForCondition = function (locator) {
                var located = this.findFormElement(locator);
                if (located == null) {
                    return null;
                }
                return located.map(function (item) {
                    return item.isEmpty() ? null : item.toJSON().value;  //getValueForCondition();
                });
            };

            ConditionalFormElement.prototype.resetCache = function () {
                this._locatedElements = {};
                this._staticConditionValue = null;
            };

            /**
             * @method ConditionalFormElement.resetConditionsCache
             * @static
             * @param rootNode
             */
            ConditionalFormElement.resetConditionsCache = function (rootNode) {
                (function resetConditionsWithChildren(node) {
                    node.conditional && node.resetCache();
                    node.getChildElements().forEach(resetConditionsWithChildren);
                })(rootNode);
            };

            /**
             * @static
             */
            ConditionalFormElement.findInParentsContext = function (locator, parentInstances, root) {
                var foundElements = null;
                var excludeContexts = [];
                parentInstances.some(function (parentInstance) {
                    foundElements = FormElementLocationService.findAllByLocator(locator, 'getLocator', parentInstance, excludeContexts);
                    excludeContexts.push(parentInstance);
                    return !!foundElements;
                });
                if (!foundElements) {
                    excludeContexts.length = 0;
                    parentInstances.some(function (parentInstance) {
                        foundElements = FormElementLocationService.findAllByLocator(FormElementLocationService.normalizeLocator(locator), 'getAbstractLocator', parentInstance, excludeContexts);
                        excludeContexts.push(parentInstance);
                        return !!foundElements;
                    });
                }
                if (!foundElements) {
                    foundElements = FormElementLocationService.findAllByLocator(locator, 'getLocator', root);
                }
                return foundElements;
            };

            return ConditionalFormElement;

        }]);

angular.module('mxg.formElement.FocusManager', [])
    .factory('mxgFocusManager', [function () {
        'use strict';
        var focusNext = null;

        return {

            /**
             * attempt to take focus. If it is possible to take focus it will be taken and true will be returned
             * otherwise it will return false
             * * @param {String} id
             * @returns {Boolean}
             */
            attemptToTakeFocus: function (id) {
                if (focusNext === id) {
                    focusNext = null;
                    return true;
                }
                return false;
            },

            /**
             * after focus has been requested the next question to take focus will take it and lock focus again
             * @param {String} id
             * @returns {Object}
             */
            requestFocus: function (id) {
                focusNext = id;
                return this;
            },

            /**
             * @returns {Boolean}
             */
            focusTaken: function () {
                return focusNext !== null;
            },

            /**
             * @returns {Object}
             */
            resetFocus: function () {
                focusNext = null;
                return this;
            }
        };
    }]);

angular.module('mxg.formElement.FormConfig', [])
    .service('mxgFormConfig', [function () {
        'use strict';
        var service = this;

        service._options = {
            tabIndex: 1,
            highlightUnansweredQuestions: false,
            renderingMode: 'global' /* global | local */
        };

        service.getOption = function (name) {
            return service._options[name];
        };

        service.setOption = function (name, value) {
            service._options[name] = value;
            return this;
        };

        service.getRenderingMode = function () {
            return service.getOption('renderingMode');
        };

        service.getRenderingClass = function () {
            return 'mxg-rendering__' + service.getRenderingMode();
        };

        service.setRenderingMode = function (value) {
            return service.setOption('renderingMode', value);
        };

    }]);

angular.module('mxg.formElement.FormElement', [
    'mxg.formElement.FormConfig',
    'mxg.formElement.FormElementType'
])
    .directive('mxgFormElement', [
        '$compile', 'mxgFormConfig', 'mxgFormElementType',
        function ($compile, FormConfig, FormElementType) {
            'use strict';

            function getDirectiveName(formElement) {
                var type = formElement ? formElement.getType() : null;
                return (type && FormElementType[type]) ? FormElementType[type].getDirectiveName() : null;
            }

            return {
                terminal: true,
                restrict: 'A',
                scope: false,
                link: function ($scope, $element, $attrs) {
                    var directiveScope;

                    var cleanupLastContent = function () {
                        $element.empty();
                        if (directiveScope) {
                            directiveScope.$destroy();
                            directiveScope = null;
                        }
                    };

                    var unregisterWatcher = $scope.$watch($attrs.mxgFormElement, function (newValue) {
                        cleanupLastContent();
                        var directiveName = getDirectiveName(newValue);
                        if (!directiveName) {
                            return;
                        }
                        if (newValue.isRoot()) {
                            FormConfig.setRenderingMode('global');
                        }
                        else {
                            unregisterWatcher();
                        }
                        var renderingClass = FormConfig.getRenderingClass();
                        $element.addClass(renderingClass);
                        setTimeout(function () {
                            directiveScope = $scope.$new(true);
                            directiveScope.formElement = newValue;
                            directiveScope.formTabIndex = FormConfig.getOption('tabIndex');
                            var directiveElement = $compile('<div ' + directiveName + ' ></div>')(directiveScope);
                            if (directiveScope.formElement.getAbstractLocator() !== null) {
                                directiveElement.attr('data-mxg-locator',
                                    directiveScope.formElement.getAbstractLocator());
                            }
                            $element.append(directiveElement);
                            $element.removeClass(renderingClass);
                        });
                    });

                }
            };
        }]);

angular.module('mxg.formElement', [
    'mxg.formElement.conditions',
    'mxg.formElement.FormConfig',
    'mxg.formElement.FormElementChildren',
    'mxg.formElement.FormElement',
    'mxg.formElement.FormElementModel', // extended models should be added as deps inside of FormElementModel
    'mxg.formElement.FormElementModelValidator',
    'mxg.formElement.FormElementLocationService',
    'mxg.formElement.formElementProperty',
    'mxg.formElement.sectionRepeating',
    'mxg.formElement.form',
    'mxg.formElement.sectionStatic',
    'mxg.formElement.sectionInstance',
    'mxg.formElement.sectionInline',
    'mxg.formElement.question',
    'mxg.formElement.QuestionDataType',
    'mxg.formElement.FormElementType',
    'mxg.formElement.FormElementModelCreator'
]);

/**
 * @ngdoc directive
 * @name  mxgFormElementChildren
 * @description
 *  This directive was created as an attempt to get rid of ng-repeat when rendering hierarchical structure of a Form.
 *  It is important to understand thought, that it can be used only for "static" children, which a not supposed to change
 *  during an interview, with the additional condition that as soon current Form changes, it rerendered from scratch.
 *  This directive render children once and do not listen to any changes dynamically, so it cannot be used for instances
 *  of a Repeating Section.
 * @example
 *   <mxg-form-element-children/>
 */
angular.module('mxg.formElement.FormElementChildren', [])
    .directive('mxgFormElementChildren', ['$compile', '$templateCache', function ($compile, $templateCache) {
        'use strict';
        var childrenTemplate = $templateCache.get('mxg-template/formElement/FormElement.children.html');
        return {
            scope: false,
            link: function ($scope, $element) {

                if ($scope.formElement.getChildElements().length) {
                    compileChildrenElements($scope, $element, childrenTemplate);
                }
                else {
                    $element.remove();
                }

                function compileChildrenElements($scope, placeHolder, template) {
                    var currentElement = placeHolder;
                    $scope.formElement.getChildElements().forEach(function (item, index) {
                        var localScope = $scope.$new(true);
                        localScope.el = item;
                        var child = $compile(template)(localScope);
                        if (index === 0) {
                            currentElement.replaceWith(child);
                            currentElement = child;
                        }
                        else {
                            currentElement.after(child);
                            currentElement = child;
                        }
                    });
                }

            }
        };
    }]);

/**
 * @description
 * "context" here means some node of a FormModel tree (either FormModel itself or any of it's Sections).
 * IMPORTANT: currently all conditional checks (comparator, locatorGetter) start with children of the given context
 * TODO: make conditions checking consistent (both for find* and findAll* methods)
 */
angular.module('mxg.formElement.FormElementLocationService', [
    'mxg.formElement.FormElementType'
])
    .service('mxgFormElementLocationService', ['mxgFormElementType', function (FormElementType) {
        'use strict';
        var service = this;

        service.normalizeLocator = function (locator) {
            return locator ? locator.replace(/\[[^\]]*\]/g, '') : null;
        };

        service.findByComparator = function (comparator, context, checkConditions) {
            if (checkConditions && !context.evaluateCondition()) {
                return null;
            }
            return _findFirstByComparatorIterator(comparator, context, checkConditions);
        };

        service.findAllByLocator = function (locator, locatorGetter, context, excludeContexts) {
            var foundElements = _findAllLocatorIterator(locator, locatorGetter, context, excludeContexts);
            return foundElements.length ? foundElements : null;
        };

        service.findAllByUUID = function (uuid, context) {
            return service.findAllByLocator(uuid, 'getUUID', context);
        };

        service.findAllByType = function (type, context) {
            return service.findAllByLocator(type, 'getType', context);
        };

        service.findInContext = function (locator, context) {
            var foundElements = service.findAllByLocator(locator, 'getAbstractLocator', context);
            if (foundElements && foundElements.length) {
                return foundElements[0];
            }
            foundElements = service.findAllByLocator(locator, 'getLocator', context.getRoot());
            return (foundElements && foundElements.length) ? foundElements[0] : 0;
        };

        service.mapFormElementsByUUID = function(context, filterByType) {
            var outputMap= {};
            (function mapByUUIDRecursively(formElementModel) {
                var uuid;
                if (!filterByType || (formElementModel.getType() === filterByType)) {
                    uuid = formElementModel.getUUID();
                    outputMap[uuid] = outputMap[uuid] || [];
                    outputMap[uuid].push(formElementModel);
                }
                (formElementModel.getChildElements() || []).forEach(mapByUUIDRecursively);
            })(context);
            return outputMap;
        };

        service.updateQuestionsLocators = function (model, context) {
            var questionType = FormElementType.QUESTION.toString();
            var questionsMap = service.mapFormElementsByUUID(context, questionType);
            var processed = [];
            var questionsList = [];
            (function extractQuestions(node) {
                if (node.type === questionType) {
                    questionsList.push(node);
                    return;
                }
                (node.childElements || []).forEach(extractQuestions);
            })(model);
            questionsList.forEach(function (question) {
                var foundQuestions = questionsMap[question.questionDefinitionId] || null;
                if (foundQuestions === null) {
                    return;
                }
                foundQuestions.some(function (questionModel) {
                    if (processed.indexOf(questionModel) !== -1) {
                        return false;
                    }
                    if (questionModel.getLocator() !== question.locator) {
                        questionModel.setLocator(question.locator);
                    }
                    processed.push(questionModel);
                    return true;
                });
            });
        };

        function _findFirstByComparatorIterator(comparator, context, checkConditions) {
            var found = null;
            var childNodes = context.getChildElements() || [];
            childNodes.some(function (item) {
                if (checkConditions && !item.evaluateCondition()) {
                    return false;
                }
                found = comparator(item) ? item : _findFirstByComparatorIterator(comparator, item, checkConditions);
                return found !== null;
            });
            return found;
        }

        function _findAllLocatorIterator(locator, locatorGetter, context, excludeContexts) {
            var childNodes = context.getChildElements() || [];
            var foundElements = [];
            childNodes.forEach(function (item) {
                var foundHere = null;
                if (item[locatorGetter]() === locator) {
                    foundHere = [item];
                }
                else if (!excludeContexts || (excludeContexts.indexOf(item) === -1)) {
                    foundHere = _findAllLocatorIterator(locator, locatorGetter, item, excludeContexts);
                }
                if (foundHere != null) {
                    foundElements = foundElements.concat(foundHere);
                }
            });
            return foundElements;
        }


    }]);

angular.module('mxg.formElement.FormElementModel', [
    'mxg.formElement.FormElementModelCreator',
    'mxg.formElement.FormElementLocationService',
    'mxg.formElement.formElementProperty.FormElementProperty',
    'mxg.formElement.formElementProperty.FormElementPropertyModel'
])
    .factory('mxgFormElementModel', [
        '$injector', 'mxgFormElementLocationService', 'mxgFormElementProperty', 'mxgFormElementPropertyModel',
        function mxgFormElementModel($injector, FormElementLocationService, FormElementProperty, FormElementPropertyModel) {
            'use strict';

            var FormElementModelCreator = $injector.get('mxgFormElementModelCreator');

            /**
             * @class
             */
            function FormElementModel(model, parentNode) {
                this._attributes = model;
                this._childElements = [];
                this._parent = parentNode || null;
                this._level = this._parent ? this._parent._level + 1 : 1;
                if (parentNode) {
                    this._root = parentNode.getRoot();
                    this._formElementId = this._root._getChildFormElementId();
                }
                else {
                    this._root = this;
                    this._formElementId = 0;
                    buildRootFormElementIdManager(this);
                }

                this._optional = !!this._attributes.optional;
                this._locator = this._attributes.locator;
                this._uuid = this._attributes.uuid;
                this._formElementProperties = buildFormElementProperties(this.getAttribute('formElementProperties'));
                (this.getAttribute('childElements') || []).forEach(this.addChild.bind(this));
            }

            function buildFormElementProperties(serverModelCollection) {

                var propertiesModelMap = {};

                if (angular.isArray(serverModelCollection)) {
                    serverModelCollection.forEach(function (property) {
                        propertiesModelMap[property.name.toLowerCase()] = FormElementPropertyModel.build(property);
                    });
                }

                return propertiesModelMap;

            }

            function buildRootFormElementIdManager(root) {
                var _nextChildFormElementId = 1;
                root._getChildFormElementId = function () {
                    return _nextChildFormElementId++;
                };
                root._rebuildFormElementIds = function () {
                    _nextChildFormElementId = 0;
                    (function rebuildWithChildren(node) {
                        var was = node._formElementId;
                        node._formElementId = _nextChildFormElementId++;
                        node.getChildElements().forEach(rebuildWithChildren);
                    })(root);
                };
            }

            FormElementModel.prototype.getUUID = function () {
                return this._uuid;
            };

            FormElementModel.prototype.addChild = function (childModel, rebuildIds) {
                var child = FormElementModelCreator.create(childModel, this);
                if (child.hasStaticConditionValue && child.getStaticConditionValue() !== false) {
                    this._childElements.push(child);
                }
                if (rebuildIds === true) {
                    this._root._rebuildFormElementIds();
                }
                return child;
            };

            FormElementModel.prototype.insertChild = function (childModel, index) {
                var child = FormElementModelCreator.create(childModel, this);
                if (child.hasStaticConditionValue && child.getStaticConditionValue() !== false) {
                    this._childElements.splice(index, 0, child);
                }
                return child;
            };

            FormElementModel.prototype.removeChild = function (child) {
                var index = this.getChildElements().indexOf(child);
                this._childElements.splice(index, 1);
                this._root._rebuildFormElementIds();
                return this._childElements;
            };

            FormElementModel.prototype.getFirstChild = function (type, onlyVisible) {
                if (onlyVisible && !this.evaluateCondition() || this._childElements.length === 0) {
                    return null;
                }
                if (!type) {
                    return this._childElements[0];
                }

                var childIndex = 0,
                    foundElement = null;

                while ((childIndex < this._childElements.length) && !foundElement) {

                    if ((this._childElements[childIndex].getType() === type) &&
                        (!onlyVisible || this._childElements[childIndex].evaluateCondition())) {
                        foundElement = this._childElements[childIndex];
                    }
                    else {
                        foundElement = this._childElements[childIndex].getFirstChild(type, onlyVisible);
                    }

                    childIndex++;

                }

                return foundElement;

            };

            FormElementModel.prototype.getNextElement = function (type, onlyVisible, upToParent) {
                var foundElement = null;
                if (this._parent) {
                    var siblings = this._parent.getChildElements();
                    var nextIndex = siblings.indexOf(this) + 1;
                    while ((!foundElement || !checkCandidateAccepted(foundElement)) && (nextIndex < siblings.length)) {
                        foundElement = siblings[nextIndex];
                        nextIndex++;
                    }
                    if (!foundElement && (!upToParent || upToParent !== this._parent)) {
                        foundElement = this._parent.getNextElement();
                        if (foundElement && !checkCandidateAccepted(foundElement)) {
                            foundElement = foundElement.getFirstChild(type, onlyVisible) || foundElement.getNextElement(
                                    type, onlyVisible);
                        }
                    }
                }

                function checkCandidateAccepted(candidate) {
                    return (!type || (candidate.getType() === type)) && (onlyVisible || candidate.evaluateCondition());
                }

                return foundElement;
            };

            FormElementModel.prototype.getChildIndex = function () {
                return this._parent && this._parent.getChildElements().indexOf(this) || 0;
            };

            FormElementModel.prototype.getChildElements = function () {
                return this._childElements;
            };

            FormElementModel.prototype.getParent = function () {
                return this._parent;
            };

            FormElementModel.prototype.setParent = function (parent) {
                this._parent = parent;
                return this;
            };

            FormElementModel.prototype.getRoot = function () {
                return this._root;
            };

            FormElementModel.prototype.isRoot = function () {
                return this._root === this;
            };

            FormElementModel.prototype.isOptional = function () {
                return this._optional;
            };

            FormElementModel.prototype.getAttribute = function (key) {
                return this._attributes[key] !== undefined ? this._attributes[key] : null;
            };

            FormElementModel.prototype.getType = function () {
                return this.getAttribute('type');
            };

            FormElementModel.prototype.getTitle = function () {
                return this.getAttribute('title') || "";
            };

            FormElementModel.prototype.setTitle = function (value) {
                return this._attributes.title = value;
            };

            FormElementModel.prototype.hasHeader = function () {
                return !!this.getTitle() || !!this.getPreamble();
            };

            FormElementModel.prototype.hasContent = function () {

                var hasContent = false;
                var hasHeader = this.hasHeader();

                if (hasHeader) {
                    hasContent = true;
                }
                else {
                    if (angular.isArray(this._childElements)) {
                        this._childElements.some(function (child) {
                            hasContent = child.hasContent();
                            return hasContent;
                        });
                    }
                }

                return hasContent;

            };

            FormElementModel.prototype.getHelpText = function () {
                return this.getAttribute('helpText') || "";
            };

            FormElementModel.prototype.getPreamble = function () {
                return this.getAttribute('preamble') || "";
            };

            FormElementModel.prototype.getFormDefinitionId = function () {
                return this.getAttribute('sequenceKey').formDefinitionId || null;
            };

            FormElementModel.prototype.hasChildElements = function () {
                return this.getChildElements().length > 0;
            };

            FormElementModel.prototype.getFormElementProperty = function (property) {
                var propertyModel = this._formElementProperties[property.toLowerCase()] || null;
                return propertyModel ? propertyModel.getValue() : null;
            };

            /**
             * @deprecated
             * @type {Function}
             */
            FormElementModel.prototype.getProperty = FormElementModel.prototype.getFormElementProperty;

            FormElementModel.prototype.getInheritableProperty = function (property) {
                var value = this.getFormElementProperty(property);
                var curParent = this.getParent();
                while ((value === null) && angular.isObject(curParent)) {
                    value = curParent.getFormElementProperty(property);
                    curParent = curParent.getParent();
                }
                return value;
            };

            FormElementModel.prototype.getLocator = function () {
                return this._locator || null;
            };

            FormElementModel.prototype.setLocator = function (value) {
                this._locator = this._attributes.locator = value;
                return this;
            };

            FormElementModel.prototype.getCustomStyles = function () {
                return this.getFormElementProperty(FormElementProperty.CSS_STYLE);
            };

            /**
             *
             * @returns {String}
             */
            FormElementModel.prototype.getAbstractLocator = function () {
                var locator = this.getLocator();
                return FormElementLocationService.normalizeLocator(locator);
            };

            FormElementModel.prototype.getFormElementId = function () {
                return this._formElementId;
            };

            FormElementModel.prototype.getElementId = function () {
                return this.getLocator();
            };

            FormElementModel.prototype.evaluateCondition = function () {
                return true;
            };

            FormElementModel.prototype.canHaveCondition = function () {
                return false;
            };

            FormElementModel.prototype.canHaveValue = function () {
                return false;
            };

            FormElementModel.prototype.hasChanged = function () {
                var changed = false;
                var children = this.getChildElements();
                for (var i = 0, ii = children.length; i < ii; i++) {
                    var child = children[i];
                    if (child.hasChanged()) {
                        changed = true;
                        break;
                    }
                }
                return changed;
            };

            FormElementModel.prototype.persist = function () {
                this.getChildElements().forEach(function (child) {
                    child.persist();
                })
            };

            FormElementModel.prototype.validate = function (validator) {
                return validator && validator.validate(this);
            };

            FormElementModel.prototype.toJSON = function () {
                var json = angular.copy(this._attributes);
                delete json.formElementProperties;
                delete json.condition;
                delete json.title;
                delete json.preamble;
                delete json.helpText;
                delete json.preText;
                delete json.postText;

                var children = [];
                this.getChildElements().forEach(function (child) {
                    if (child.evaluateCondition()) {
                        children.push(child.toJSON());
                    }
                });
                json.childElements = children;
                return json;
            };

            FormElementModel.prototype.getSequenceKey = function () {
                return this.getAttribute('sequenceKey');
            };

            FormElementModel.prototype.clearAllValuesDown = function () {
                if (this.canHaveValue()) {
                    this.clearValue();
                }
                this.getChildElements().forEach(function (child) {
                    child.clearAllValuesDown();
                });
            };

            /**
             * @description
             * This method clears up answers that was entered by user and then "hidden" by conditions on upper nodes
             * Currently is used after Partial Submit
             * */
            FormElementModel.prototype.clearFalseConditional = function () {
                if (this.canHaveCondition() && !this.evaluateCondition()) {
                    this.clearAllValuesDown();
                    return;
                }
                if (!this.hasChildElements()) {
                    return;
                }
                this.getChildElements().forEach(function(child) {
                    child.clearFalseConditional();
                });
            };

            /**
            * @description
            * Generally this method just invoke same method on all children
            * It intended to be overridden in SectionRepeatingModel to perform actual clearance
            */
            FormElementModel.prototype.cleanUpEmptyRepeatingInstances = function () {
                if (!this.hasChildElements()) {
                    return;
                }
                this.getChildElements().forEach(function(child) {
                    child.cleanUpEmptyRepeatingInstances();
                });
            };

            /**
             * @description
             * Generally this method just invoke same method on all children
             * It intended to be overridden in SectionRepeatingModel to perform actual work
             * */
            FormElementModel.prototype.addDefaultEmptyRepeatingInstances = function () {
                if (!this.hasChildElements()) {
                    return;
                }
                this.getChildElements().forEach(function(child) {
                    child.addDefaultEmptyRepeatingInstances();
                });
            };

            /**
             *
             * @param model
             * @param parentNode
             * @deprecated
             * Please use FormElementModelCreator
             * @returns {FormElementModel|*}
             */
            FormElementModel.factory = function (model, parentNode) {
                return FormElementModelCreator.create(model, parentNode);
            };
            return FormElementModel;
        }]);

angular.module('mxg.formElement.FormElementModelCreator', [
    'mxg.formElement.question.QuestionModel',
    'mxg.formElement.sectionRepeating.SectionRepeatingModel',
    'mxg.formElement.ConditionalFormElementModel',
    'mxg.formElement.SectionModel',
    'mxg.formElement.sectionInstance.SectionInstanceModel',
    'mxg.formElement.sectionInline.SectionInlineModel',
    'mxg.formElement.form.FormModel',
    'mxg.formElement.FormElementType'
])
    .factory('mxgFormElementModelCreator', [
        '$injector', 'mxgFormElementType',
        function ($injector, FormElementType) {
            'use strict';
            var FormModel, QuestionModel, RepeatingSectionModel, SectionModel, SectionInstanceModel, SectionInlineModel;
            return {
                create: function (model, parentNode) {
                    FormModel = FormModel || $injector.get('mxgFormModel');
                    QuestionModel = QuestionModel || $injector.get('mxgQuestionModel');
                    RepeatingSectionModel = RepeatingSectionModel || $injector.get('mxgRepeatingSectionModel');
                    SectionModel = SectionModel || $injector.get('mxgSectionModel');
                    SectionInstanceModel = SectionInstanceModel || $injector.get('mxgSectionInstanceModel');
                    SectionInlineModel = SectionInlineModel || $injector.get('mxgSectionInlineModel');

                    switch (model.type) {
                        case FormElementType.FORM.toString() :
                            return new FormModel(model, parentNode);
                        case FormElementType.QUESTION.toString():
                            return new QuestionModel(model, parentNode);
                        case FormElementType.SECTION_REPEATING.toString():
                            return new RepeatingSectionModel(model, parentNode);
                        case FormElementType.SECTION_STATIC.toString():
                            return new SectionModel(model, parentNode);
                        case FormElementType.SECTION_INSTANCE.toString():
                            return new SectionInstanceModel(model, parentNode);
                        case FormElementType.SECTION_INLINE.toString():
                            return new SectionInlineModel(model, parentNode);
                        default :
                            throw new Error("cannot instantiate instance of form model for FormElementType.type = " + model.type);
                    }
                }
            }
        }]);

angular.module('mxg.formElement.FormElementModelValidator', [
        'mxg.formElement.FormElementType',
        'mxg.formElement.ConditionalFormElementModel',
        'mxg.formElement.question.QuestionModelValidator'
    ])
    .factory('mxgFormElementModelValidator', [
        'mxgFormElementType', 'mxgConditionalFormElementModel', 'mxgQuestionModelValidator',
        function (FormElementType, ConditionalFormElementModel, QuestionModelValidator) {

            function FormElementModelValidator() {

                this.modelTypeToValidatorMap = {};
                this.modelTypeToValidatorMap[FormElementType.FORM.toString()] = this.validateChildren.bind(this);
                this.modelTypeToValidatorMap[FormElementType.SECTION_STATIC.toString()] = this.validateChildren.bind(
                    this);
                this.modelTypeToValidatorMap[FormElementType.SECTION_REPEATING.toString()] = this.validateChildren.bind(
                    this);
                this.modelTypeToValidatorMap[FormElementType.SECTION_INSTANCE.toString()] = this.validateChildren.bind(
                    this);
                this.modelTypeToValidatorMap[FormElementType.SECTION_INLINE.toString()] = this.validateChildren.bind(
                    this);
                this.modelTypeToValidatorMap[FormElementType.QUESTION.toString()] = this.validateQuestion.bind(this);

            }

            /**
             * @method FormElementModelValidator#validate
             * */
            FormElementModelValidator.prototype.validate = function (formElementModel) {

                if ((formElementModel instanceof ConditionalFormElementModel) && !formElementModel.evaluateCondition()) {
                    return null;
                }

                var type = formElementModel.getType();
                var validateFunction = this.modelTypeToValidatorMap[type] || null;

                return angular.isFunction(validateFunction) ? validateFunction(formElementModel) : null;

            };

            FormElementModelValidator.prototype.validateChildren = function (formElementModel) {

                var validator = this;

                return formElementModel.getChildElements().reduce(function (reduced, currentChild) {
                    Array.prototype.push.apply(reduced, validator.validate(currentChild) || []);
                    return reduced;
                }, []);

            };

            FormElementModelValidator.prototype.validateQuestion = function (questionModel) {

                var validator = QuestionModelValidator.build(questionModel);
                return validator.validate();

            };

            return new FormElementModelValidator();

        }]);

angular.module('mxg.formElement.FormElementType', [])
    .provider('mxgFormElementType', [function () {
        "use strict";

        var FormElementType = function (name) {
            this._name = name;

        };

        FormElementType.prototype.toString = function () {
            return this._name;
        };

        FormElementType.prototype.getDirectiveName = function () {
            return 'mxg-form-element-' + this._name.toLowerCase().replace('_', '-');
        };

        var types = ["FORM",
                     "SECTION_STATIC",
                     "SECTION_REPEATING",
                     "SECTION_TEMPLATE",
                     "SECTION_INSTANCE",
                     "SECTION_INLINE",
                     "QUESTION"];
        var self = this;

        types.forEach(function (key) {
            self[key] = new FormElementType(key);
        });

        this.$get = [function () {
            return self;
        }];
    }]);

angular.module('mxg.formElement.layoutType', [])
    .constant('mxgLayoutType', {
        ONE_COLUMN: "ONE_COLUMN",
        TWO_COLUMNS: "TWO_COLUMNS",
        DATA_GRID: "DATA_GRID"
    });
angular.module('mxg.formElement.QuestionDataType', [])
    .constant('mxgQuestionDataType', {
        "INTEGER_TEXTBOX": "INTEGER_TEXTBOX",
        "STRING_TEXTBOX_SINGLE": "STRING_TEXTBOX_SINGLE",
        "DECIMAL_TEXTBOX": "DECIMAL_TEXTBOX",
        "BOOLEAN_RADIO_BUTTONS_HORIZONTAL": "BOOLEAN_RADIO_BUTTONS_HORIZONTAL",
        "MULTISELECT_CHECKBOXES_VERTICAL": "MULTISELECT_CHECKBOXES_VERTICAL",
        "DATE": "DATE",
        "DATE_PARTIAL": "DATE_PARTIAL",
        "DROPDOWN": "DROPDOWN",
        "DROPDOWN_COMBOBOX": "DROPDOWN_COMBOBOX",
        "INTEGER_SPINNER": "INTEGER_SPINNER",
        "INTEGER_SLIDER": "INTEGER_SLIDER",
        "STRING_TEXTBOX_MULTI": "STRING_TEXTBOX_MULTI",
        "STRING_DICTIONARY": "STRING_DICTIONARY",
        "DROPDOWN_LABELLED_BUTTONS": "DROPDOWN_LABELLED_BUTTONS",
        "DROPDOWN_ICONIC_BUTTONS": "DROPDOWN_ICONIC_BUTTONS",
        "DROPDOWN_RADIO_BUTTONS_HORIZONTAL": "DROPDOWN_RADIO_BUTTONS_HORIZONTAL",
        "DROPDOWN_RADIO_BUTTONS_VERTICAL": "DROPDOWN_RADIO_BUTTONS_VERTICAL",
        "MULTISELECT_LABELLED_BUTTONS": "MULTISELECT_LABELLED_BUTTONS",
        "MULTISELECT_ICONIC_BUTTONS": "MULTISELECT_ICONIC_BUTTONS",
        "MULTISELECT_DROPDOWN": "MULTISELECT_DROPDOWN"
    });
angular.module('mxg.formElement.SectionModel', [
    'mxg.formElement.ConditionalFormElementModel',
    'mxg.formElement.FormElementType',
    'mxg.formElement.FormElementLocationService'
])
    .factory('mxgSectionModel', [
        'mxgConditionalFormElementModel', 'mxgFormElementType', 'mxgFormElementLocationService',
        function (ConditionalFormElementModel, FormElementType, FormElementLocationService) {
            'use strict';

            /**
             * @class
             */
            function SectionModel(model, parentNode) {
                ConditionalFormElementModel.call(this, model, parentNode);
            }

            SectionModel.prototype = Object.create(ConditionalFormElementModel.prototype);
            SectionModel.prototype.constructor = SectionModel;

            SectionModel.prototype.checkIsTopSection = function () {

                var parent = this.getParent();
                var childIndex;

                if (!parent) {
                    return true;
                }

                if ((parent.getType() === FormElementType.FORM.toString())) {
                    return true;
                }

                childIndex = this.getChildIndex();
                if ((childIndex === 0) || !hasPrevSiblings(parent, childIndex)) {
                    return parent.checkIsTopSection();
                }

                return false;

                function hasPrevSiblings(parent, childIndex) {
                    var result = false;
                    parent.getChildElements().some(function (child, index) {
                        result = child.hasContent();
                        return (index >= childIndex) || result;
                    });
                    return result;
                }

            };

            SectionModel.prototype.hasInlineChildren = function () {

                var sectionModel = this;
                var child = sectionModel.getFirstChild(FormElementType.SECTION_INLINE.toString());

                return angular.isObject(child) && child.hasChildElements();

            };

            SectionModel.prototype.inlineTrigger = function () {

                var sectionModel = this;
                var questionModel = sectionModel.getFirstChild(FormElementType.QUESTION.toString(), true);
                var found = false;

                if (angular.isObject(questionModel)) {

                    found = questionModel.inlineTrigger();

                    if (!found) {
                        do {
                            questionModel = questionModel.getNextElement(FormElementType.QUESTION.toString(), true,
                                sectionModel);
                            found = angular.isObject(questionModel) && questionModel.inlineTrigger();
                        } while (angular.isObject(questionModel) && !found);
                    }

                }

                return found;

            };

            /**
             * @description
             * "Empty" here means that no one question was yet answered inside a section
             * */
            SectionModel.prototype.checkSectionIsEmpty = function () {
                var questionType = FormElementType.QUESTION.toString();
                var sectionModel = this;
                return (function checkEmptyWithChildren(formElementModel) {
                    if (formElementModel.getType() === questionType) {
                        return formElementModel.isEmpty();
                    }
                    if (!formElementModel.hasChildElements()) {
                        return true;
                    }
                    return formElementModel.getChildElements().every(checkEmptyWithChildren);
                })(sectionModel);
            };

            return SectionModel;

        }]);

angular.module('mxg.helpers.BrowserFeatureTest', [])
    .factory('mxgBrowserFeatureTest', ['$log', '$cacheFactory', function ($log, $cacheFactory) {
        "use strict";

        var featureCache = $cacheFactory('mxgBrowserFeatureTest');

        function inputTypeNumber() {

            var cached = featureCache.get('inputTypeNumber');

            if (angular.isUndefined(cached)) {

                var i = document.createElement('input');
                i.setAttribute('type', 'number');

                var result = i.type === 'number';
                featureCache.put('inputTypeNumber', result);

                return result;

            }
            else {
                return cached;
            }

        }

        function inputTypeRange() {

            var cached = featureCache.get('inputTypeRange');

            if (angular.isUndefined(cached)) {

                var i = document.createElement('input');
                i.setAttribute('type', 'range');

                var result = i.type === 'range';
                featureCache.put('inputTypeRange', result);

                return result;

            }
            else {
                return cached;
            }

        }

        return {
            inputTypeNumber: inputTypeNumber,
            inputTypeRange: inputTypeRange
        };

    }]);

/**
 * @ngdoc service
 * @name mxgDateHelper
 * */
angular.module('mxg.helpers.DateHelper', [])
    .service('mxgDateHelper', ['$locale', 'orderByFilter', 'dateFilter', function ($locale, orderByFilter, dateFilter) {
        'use strict';

        var service = this;

        this.parsers = {};

        var localeMonths = $locale.DATETIME_FORMATS.MONTH.map(function (item) {
            return item.toLowerCase();
        });

        var localeShortMonths = $locale.DATETIME_FORMATS.SHORTMONTH.map(function (item) {
            return item.toLowerCase();
        });

        var formatCodeToRegex = {
            'yyyy': {
                regex: '\\d{4}',
                apply: function (value) {
                    this.year = +value;
                }
            },
            'yy': {
                regex: '\\d{2}',
                apply: function (value) {
                    this.year = +value + 2000;
                }
            },
            'y': {
                regex: '\\d{1,4}',
                apply: function (value) {
                    this.year = +value;
                }
            },
            'MMMM': {
                regex: localeMonths.join('|'),
                apply: function (value) {
                    var normalizedValue = value ? value.toLowerCase() : '';
                    this.month = localeMonths.indexOf(normalizedValue);
                }
            },
            'MMM': {
                regex: localeShortMonths.join('|'),
                apply: function (value) {
                    var normalizedValue = value ? value.toLowerCase() : '';
                    this.month = localeShortMonths.indexOf(normalizedValue);
                }
            },
            'MM': {
                regex: '0[1-9]|1[0-2]',
                apply: function (value) {
                    this.month = value - 1;
                }
            },
            'M': {
                regex: '[1-9]|1[0-2]',
                apply: function (value) {
                    this.month = value - 1;
                }
            },
            'dd': {
                regex: '[0-2][0-9]{1}|3[0-1]{1}',
                apply: function (value) {
                    this.date = +value;
                }
            },
            'd': {
                regex: '[1-2]?[0-9]{1}|3[0-1]{1}',
                apply: function (value) {
                    this.date = +value;
                }
            },
            'EEEE': {
                regex: $locale.DATETIME_FORMATS.DAY.join('|')
            },
            'EEE': {
                regex: $locale.DATETIME_FORMATS.SHORTDAY.join('|')
            }
        };

        function createParser(format) {
            var map = [], regex = format.split('');

            angular.forEach(formatCodeToRegex, function (data, code) {
                var index = format.indexOf(code);

                if (index > -1) {
                    format = format.split('');

                    regex[index] = '(' + data.regex + ')';
                    format[index] = '$'; // Custom symbol to define consumed part of format
                    for (var i = index + 1, n = index + code.length; i < n; i++) {
                        regex[i] = '';
                        format[i] = '$';
                    }
                    format = format.join('');

                    map.push({index: index, apply: data.apply});
                }
            });

            return {
                regex: new RegExp('^' + regex.join('') + '$', 'i'),
                map: orderByFilter(map, 'index')
            };
        }

        // Check if date is valid for specific month (and year for February).
        // Month: 0 = Jan, 1 = Feb, etc
        function isValid(year, month, date) {
            if (month === 1 && date > 28) {
                return date === 29 && ((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0);
            }
            if (month === 3 || month === 5 || month === 8 || month === 10) {
                return date < 31;
            }
            return true;
        }

        /**
         * @ngdoc method
         * @name mxgDateHelper#canonizeDateFormat
         * @param {String} format
         * @returns {String}
         * */
        service.canonizeDateFormat = function (format) {
            var dateFormatRegEx = /(y{4}|m{3}|m{2}|d{2})/gi;
            var replacer = function (match) {
                if (match[0] === 'm') {
                    return match.toUpperCase();
                }
                return match;
            };
            return format.toLowerCase().replace(dateFormatRegEx, replacer);
        };

        /**
         * @ngdoc method
         * @name mxgDateHelper#canonizeDateFormat
         * @param {String} input
         * @param {String} format
         * @returns {Date|String|undefined}
         * */
        service.parseDate = function (input, format) {
            if (!angular.isString(input) || !format) {
                return input;
            }
            format = $locale.DATETIME_FORMATS[format] || format;

            if (!service.parsers[format]) {
                service.parsers[format] = createParser(format);
            }

            var parser = service.parsers[format],
                regex = parser.regex,
                map = parser.map,
                results = input.match(regex);

            if (results && results.length) {
                var fields = {year: 1900, month: 0, date: 1, hours: 0}, dt;

                for (var i = 1, n = results.length; i < n; i++) {
                    var mapper = map[i - 1];
                    if (mapper.apply) {
                        mapper.apply.call(fields, results[i]);
                    }
                }

                if (isValid(fields.year, fields.month, fields.date)) {
                    dt = new Date(fields.year, fields.month, fields.date, fields.hours);
                }

                return dt;
            }
        };

        /**
         * @ngdoc method
         * @method mxgDateHelper.toFullISODate
         * @static
         * @description
         *  Return full date in ISO format: absent day will be set to 15, absent month = to June 30
         * @param {String} ISODate
         * @returns String
         * */
        service.toFullISODate = function (ISODate) {
            if (!ISODate || ISODate.length >= 10) {
                return ISODate;
            }
            var parts = ISODate.split('-');
            if (parts.length === 2) {
                parts[2] = '15';
            }
            if (parts.length === 1) {
                parts[1] = '06';
                parts[2] = '30';
            }
            return parts.join('-');
        };

        /**
         * @ngdoc method
         * @method mxgDateHelper.createDateInLocalTimezone
         * @static
         * @description
         * Create new Date object from a date string in ISO format.
         * Expects input as "yyyy-mm-dd" and adds time to them (always noon)
         * Supports partial dates (see toFullISODate)
         * Needed because new Date('yy-mm-dd') treats input as UTC timezone and makes inner transformations to local timezone.
         * @param {String} ISODate
         * @returns {Date}
         * */
        service.createDateInLocalTimezone = function (ISODate) {
            if (!ISODate) {
                return service.getNowDate();
            }
            return new Date(service.toFullISODate(ISODate) + 'T12:00:00');
        };

        /**
         * @ngdoc method
         * @method mxgDateHelper.dateToISOString
         * @static
         * @param {Date} date
         * @return {String}
         * */
        service.dateToISOString = function (date) {
            if (!date) {
                return null;
            }
            return dateFilter(date, 'yyyy-MM-dd');
        };

        /**
         * @ngdoc method
         * @method mxgDateHelper.getNowDate
         * @static
         * @return {Date}
         * */
        service.getNowDate = function() {
            var date = new Date();
            date.setHours(12, 0, 0, 0);
            return date;
        };

    }]);

angular.module('mxg.helpers.TypeaheadHelper', ['mxg.magnum.Config', 'mxg.helpers.TypeaheadDefaultMapValues'])
    .factory('mxgTypeaheadHelper', [
        'MagnumConfig',
        'mxgTypeaheadDefaultMapValues',
        function (MagnumConfig, TypeaheadDefaultMapValues) {
            var accentMap = TypeaheadDefaultMapValues.getTypeaheadDefaultValues();
            var initAccentMap = MagnumConfig.getOption('accentFoldingMap');
            var values;

            if (!angular.isObject(initAccentMap)) {
                values = accentMap;
            } else {
                values = initAccentMap;
            }

            return {
                accentFold: function (name) {
                    if (!name) {
                        return '';
                    }
                    var ret = '';
                    for (var i = 0; i < name.length; i++) {
                        ret += values[name.charAt(i)] || name.charAt(i);
                    }
                    return ret;
                }
            };
        }
    ]);

angular.module('mxg.helpers.EventsHelper', ['mxg.helpers.KeyCode'])
    .factory('mxgEventsHelper', [
        'mxgKeyCode',
        function mxgEventsHelper(KEY_CODE) {

            var navigationKeys = [KEY_CODE.UP, KEY_CODE.DOWN, KEY_CODE.PAGE_UP, KEY_CODE.PAGE_DOWN, KEY_CODE.HOME, KEY_CODE.END];
            var optionSelectionKeys = [KEY_CODE.ENTER, KEY_CODE.SPACE];

            return {
                checkAdditionalKeyPressed: function (event) {
                    return event.altKey || event.ctrlKey || event.metaKey;
                },
                checkNavigationEvent: function (event) {
                    var pressed = event.keyCode;
                    return navigationKeys.indexOf(pressed) !== -1;
                },
                checkSelectOptionEvent: function (event) {
                    var pressed = event.keyCode;
                    return optionSelectionKeys.indexOf(pressed) !== -1;
                }
            };

        }
    ]);

angular.module('mxg.helpers', [
    'mxg.helpers.BrowserFeatureTest',
    'mxg.helpers.EventsHelper',
    'mxg.helpers.KeyCode',
    'mxg.helpers.DateHelper',
    'mxg.helpers.NumberHelper',
    'mxg.helpers.PositionHelper',
    'mxg.helpers.RefDataHelper',
    'mxg.helpers.WindowHelper',
    'mxg.helpers.TypeaheadHelper',
    'mxg.helpers.TypeaheadDefaultMapValues'
]);

angular.module('mxg.helpers.KeyCode', [])
    .constant('mxgKeyCode', {
        BACKSPACE: 8,
        COMMA: 188,
        DELETE: 46,
        DOWN: 40,
        END: 35,
        ENTER: 13,
        ESCAPE: 27,
        HOME: 36,
        LEFT: 37,
        NUMPAD_ADD: 107,
        NUMPAD_DECIMAL: 110,
        NUMPAD_DIVIDE: 111,
        NUMPAD_ENTER: 108,
        NUMPAD_MULTIPLY: 106,
        NUMPAD_SUBTRACT: 109,
        PAGE_DOWN: 34,
        PAGE_UP: 33,
        PERIOD: 190,
        RIGHT: 39,
        SPACE: 32,
        TAB: 9,
        UP: 38
    });

/**
 * @ngdoc service
 * @name mxgNumberHelper
 * */
angular.module('mxg.helpers.NumberHelper', [])
    .service('mxgNumberHelper', function () {

        var service = this;

        /**
         * @ngdoc method
         * @name mxgNumberHelper#roundTo
         * @param {String} value
         * @param {Number} precision
         * @returns {String}
         * */
        service.roundTo = function (value, precision) {
            var decimalDigits = value.replace(/^-?\d*\.?|$/g, '').length;
            return (decimalDigits > precision) ? parseFloat(value).toFixed(Math.min(precision, 20)).toString() : value;
        };

        /**
         * @ngdoc method
         * @name mxgNumberHelper#ensureNumber
         * @param {String} value
         * @param {Number|Null} defaultValue
         * @returns {Number|Null}
         * */
        service.ensureNumber = function (value, defaultValue) {
            var numValue = angular.isUndefined(value) ? defaultValue : parseFloat(value);
            numValue = angular.isNumber(numValue) && (numValue === numValue) ? numValue : defaultValue;
            return numValue;
        };

        /**
         * @ngdoc method
         * @name mxgNumberHelper#transformWithPrecisionCheck
         * @param {String} value
         * @param {Number} precision
         * @returns {String}
         * */
        service.transformWithPrecisionCheck = function (value, precision) {
            var numValue = service.ensureNumber(value, null);
            if (numValue !== null) {
                return service.roundTo(value, precision).toString();
            }
            else {
                return value;
            }
        };

    });

/**
 * @ngdoc service
 * @name mxgPositionHelper
 * @description
 * A set of utility methods that can be use to retrieve position of DOM elements.
 * It is meant to be used where we need to absolute-position DOM elements in
 * relation to other, existing elements (this is the case for tooltips, popovers,
 * typeahead suggestions etc.).
 * */
angular.module('mxg.helpers.PositionHelper', [])
    .service('mxgPositionHelper', ['$document', '$window', function ($document, $window) {
        'use strict';

        var service = this;

        function getStyle(el, cssprop) {
            if (el.currentStyle) { //IE
                return el.currentStyle[cssprop];
            } else if ($window.getComputedStyle) {
                return $window.getComputedStyle(el)[cssprop];
            }
            // finally try and get inline style
            return el.style[cssprop];
        }

        /**
         * Checks if a given element is statically positioned
         * @param element - raw DOM element
         */
        function isStaticPositioned(element) {
            return (getStyle(element, 'position') || 'static' ) === 'static';
        }

        /**
         * returns the closest, non-statically positioned parentOffset of a given element
         * @param element
         */
        var parentOffsetEl = function (element) {
            var docDomEl = $document[0];
            var offsetParent = element.offsetParent || docDomEl;
            while (offsetParent && offsetParent !== docDomEl && isStaticPositioned(offsetParent)) {
                offsetParent = offsetParent.offsetParent;
            }
            return offsetParent || docDomEl;
        };

        /**
         * @description
         * Provides read-only equivalent of jQuery's position function:
         * http://api.jquery.com/position/
         * */
        service.position = function (element) {
            var elBCR = this.offset(element);
            var offsetParentBCR = {top: 0, left: 0};
            var offsetParentEl = parentOffsetEl(element[0]);
            if (offsetParentEl != $document[0]) {
                offsetParentBCR = this.offset(angular.element(offsetParentEl));
                offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
                offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
            }

            var boundingClientRect = element[0].getBoundingClientRect();
            return {
                width: boundingClientRect.width || element.prop('offsetWidth'),
                height: boundingClientRect.height || element.prop('offsetHeight'),
                top: elBCR.top - offsetParentBCR.top,
                left: elBCR.left - offsetParentBCR.left
            };
        };

        /**
         * @description
         * Provides read-only equivalent of jQuery's offset function:
         * http://api.jquery.com/offset/
         * */
        service.offset = function (element) {
            var boundingClientRect = element[0].getBoundingClientRect();
            return {
                width: boundingClientRect.width || element.prop('offsetWidth'),
                height: boundingClientRect.height || element.prop('offsetHeight'),
                top: boundingClientRect.top + ($window.pageYOffset || $document[0].documentElement.scrollTop),
                left: boundingClientRect.left + ($window.pageXOffset || $document[0].documentElement.scrollLeft)
            };
        };

        /**
         * @param element
         * @returns {Boolean}
         * */
        service.visible = function (element) {
            var elem = element[0] || element;
            return !!(elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length);
        };

        /**
         *
         * */
        service.height = function (element) {
            var elem = element[0] || element;

            if (this.visible(elem)) {
                return elem.clientHeight;
            } else {
                var display = elem.style.display;
                elem.style.visibility = 'hidden';
                elem.style.display = 'block';

                var result = elem.clientHeight;

                elem.style.visibility = 'visible';
                elem.style.display = display;

                return result;
            }
        };

        /**
         * @description
         * Provides coordinates for the targetEl in relation to hostEl
         * */
        service.positionElements = function (hostEl, targetEl, positionStr, appendToBody) {

            var positionStrParts = positionStr.split('-');
            var pos0 = positionStrParts[0], pos1 = positionStrParts[1] || 'center';

            var hostElPos,
                targetElWidth,
                targetElHeight,
                targetElPos;

            hostElPos = appendToBody ? this.offset(hostEl) : this.position(hostEl);

            targetElWidth = targetEl.prop('offsetWidth');
            targetElHeight = targetEl.prop('offsetHeight');

            var shiftWidth = {
                center: function () {
                    return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
                },
                left: function () {
                    return hostElPos.left;
                },
                right: function () {
                    return hostElPos.left + hostElPos.width;
                }
            };

            var shiftHeight = {
                center: function () {
                    return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
                },
                top: function () {
                    return hostElPos.top;
                },
                bottom: function () {
                    return hostElPos.top + hostElPos.height;
                }
            };

            switch (pos0) {
                case 'right':
                    targetElPos = {
                        top: shiftHeight[pos1](),
                        left: shiftWidth[pos0]()
                    };
                    break;
                case 'left':
                    targetElPos = {
                        top: shiftHeight[pos1](),
                        left: hostElPos.left - targetElWidth
                    };
                    break;
                case 'bottom':
                    targetElPos = {
                        top: shiftHeight[pos0](),
                        left: shiftWidth[pos1]()
                    };
                    break;
                default:
                    targetElPos = {
                        top: hostElPos.top - targetElHeight,
                        left: shiftWidth[pos1]()
                    };
                    break;
            }

            return targetElPos;
        };

    }]);

angular.module('mxg.helpers.RefDataHelper', [])
    .factory('mxgRefDataHelper',
        [function mxgRefDataHelper() {
            "use strict";

            var ICON_CODE_TYPE_NAME = 'Icon Code';

            /* collection here is supposed to be an array of objects with "code" and "name" properties */
            function search(collection, keyName, keyValue, targetName) {

                var result = null;
                if (angular.isArray(collection)) {
                    collection.some(function (item) {
                        if (item[keyName] == keyValue) {
                            result = angular.isDefined(targetName) ? item[targetName] || null : item;
                            return true;
                        }
                        return false;
                    });
                }
                return result;

            }

            function testContains(substr, text) {
                return angular.isString(text) && (text.toLowerCase().indexOf(substr) !== -1 );
            }

            var service = {};

            service.getItemByCode = function (referenceValues, code) {
                return search(referenceValues, 'code', code);
            };

            service.getNameByCode = function (referenceValues, code) {
                return search(referenceValues, 'code', code, 'name');
            };

            service.getCodeByName = function (referenceValues, name) {
                return search(referenceValues, 'name', name, 'code');
            };

            service.searchByNameStarting = function (referenceValues, searchStr) {

                var result = null;
                if (angular.isArray(referenceValues) && (referenceValues.length > 0) && angular.isString(
                        searchStr) && (searchStr.length > 0)) {

                    var i = 0, ii = referenceValues.length;
                    for (; i < ii; i++) {
                        if (angular.isString(referenceValues[i].name) && ( referenceValues[i].name.substr(0,
                                searchStr.length).toUpperCase() === searchStr.toUpperCase() )) {
                            result = referenceValues[i];
                            break;
                        }
                    }

                }
                return result;
            };

            service.filterByNameContains = function (referenceValues, searchStr) {

                var result = [];
                if (angular.isArray(referenceValues) && (referenceValues.length > 0) && angular.isString(
                        searchStr) && (searchStr.length > 0)) {

                    var strNormalized = searchStr.toLowerCase();

                    referenceValues.forEach(function (item) {
                        var name = item.name;
                        if (testContains(strNormalized, name)) {
                            result.push(item);
                        }
                    });

                }
                return result;
            };

            service.filterByNameSmartContainsSmartOrder = function (referenceValues, inputValue) {

                var searchStr = angular.isString(inputValue) ? inputValue.toLowerCase() : '';

                var result = [];
                var filteredWidthPriority = [];

                if (!angular.isArray(referenceValues) || !referenceValues.length) {
                    return [];
                }

                if (!searchStr.length) {
                    return referenceValues;
                }

                //var escapedValue = searchStr.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');

                /* priority will define grouping for further sorting of results */
                function addWithPriority(item, priority) {
                    if (angular.isUndefined(filteredWidthPriority[priority])) {
                        filteredWidthPriority[priority] = [];
                    }
                    filteredWidthPriority[priority].push(item);
                }

                referenceValues.forEach(function (item) {

                    var name = item.name.toLowerCase();
                    var foundIndex = name.indexOf(searchStr);

                    var foundItem;

                    /* skip if doesn't contain input string at all */
                    if (foundIndex === -1) {
                        return;
                    }

                    foundItem = angular.copy(item);

                    var words, findSuccess;

                    if (foundIndex === 0) {
                        // at the top we need to show terms which starts with input string
                        addWithPriority(foundItem, 0);
                        findSuccess = true;
                    }
                    else {
                        words = name.replace(/\W+/g, ' ');
                        words = words.split(' ');
                        findSuccess = words.some(function (w, i) {
                            if (w.indexOf(searchStr) !== -1) {
                                addWithPriority(foundItem, i + 1);
                                return true;
                            }
                            return false;
                        });
                    }

                    if (!findSuccess && testContains(searchStr, name)) {
                        addWithPriority(foundItem, words.length);
                    }

                });

                angular.forEach(filteredWidthPriority, function (item) {
                    result = [].concat(result, item);
                });

                return result;

            };

            service.getTranslation = function(languageCode, referenceDataModel) {

                var foundText = null;

                referenceDataModel.translationModels.some(function(item) {
                    if (item.languageCode === languageCode) {
                        foundText = item.text;
                        return true;
                    }
                    else {
                        return false;
                    }
                });

                return foundText;

            };

            service.getGlobalId = function (globalIdType, globalIds) {

                var foundId = null;
                if (angular.isArray(globalIds) && globalIds.length) {
                    globalIds.some(function (item) {
                        if (item.typeName === globalIdType) {
                            foundId = item.globalId;
                            return true;
                        }
                        else {
                            return false;
                        }
                    });
                }

                return foundId;

            };

            service.getIconCode = function(globalIds) {
                return service.getGlobalId(ICON_CODE_TYPE_NAME, globalIds)
            };

            return service;

        }]
    );

angular.module('mxg.helpers.TypeaheadDefaultMapValues', [])
    .service('mxgTypeaheadDefaultMapValues', function () {
        var service = this;

        service.getTypeaheadDefaultValues = function () {
            return {
                "ẚ": "a",
                "Á": "a",
                "á": "a",
                "À": "a",
                "à": "a",
                "Ă": "a",
                "ă": "a",
                "Ắ": "a",
                "ắ": "a",
                "Ằ": "a",
                "ằ": "a",
                "Ẵ": "a",
                "ẵ": "a",
                "Ẳ": "a",
                "ẳ": "a",
                "Â": "a",
                "â": "a",
                "Ấ": "a",
                "ấ": "a",
                "Ầ": "a",
                "ầ": "a",
                "Ẫ": "a",
                "ẫ": "a",
                "Ẩ": "a",
                "ẩ": "a",
                "Ǎ": "a",
                "ǎ": "a",
                "Å": "a",
                "å": "a",
                "Ǻ": "a",
                "ǻ": "a",
                "Ä": "a",
                "ä": "a",
                "Ǟ": "a",
                "ǟ": "a",
                "Ã": "a",
                "ã": "a",
                "Ȧ": "a",
                "ȧ": "a",
                "Ǡ": "a",
                "ǡ": "a",
                "Ą": "a",
                "ą": "a",
                "Ā": "a",
                "ā": "a",
                "Ả": "a",
                "ả": "a",
                "Ȁ": "a",
                "ȁ": "a",
                "Ȃ": "a",
                "ȃ": "a",
                "Ạ": "a",
                "ạ": "a",
                "Ặ": "a",
                "ặ": "a",
                "Ậ": "a",
                "ậ": "a",
                "Ḁ": "a",
                "ḁ": "a",
                "Ⱥ": "a",
                "ⱥ": "a",
                "Ǽ": "a",
                "ǽ": "a",
                "Ǣ": "a",
                "ǣ": "a",
                "Ḃ": "b",
                "ḃ": "b",
                "Ḅ": "b",
                "ḅ": "b",
                "Ḇ": "b",
                "ḇ": "b",
                "Ƀ": "b",
                "ƀ": "b",
                "ᵬ": "b",
                "Ɓ": "b",
                "ɓ": "b",
                "Ƃ": "b",
                "ƃ": "b",
                "Ć": "c",
                "ć": "c",
                "Ĉ": "c",
                "ĉ": "c",
                "Č": "c",
                "č": "c",
                "Ċ": "c",
                "ċ": "c",
                "Ç": "c",
                "ç": "c",
                "Ḉ": "c",
                "ḉ": "c",
                "Ȼ": "c",
                "ȼ": "c",
                "Ƈ": "c",
                "ƈ": "c",
                "ɕ": "c",
                "Ď": "d",
                "ď": "d",
                "Ḋ": "d",
                "ḋ": "d",
                "Ḑ": "d",
                "ḑ": "d",
                "Ḍ": "d",
                "ḍ": "d",
                "Ḓ": "d",
                "ḓ": "d",
                "Ḏ": "d",
                "ḏ": "d",
                "Đ": "d",
                "đ": "d",
                "ᵭ": "d",
                "Ɖ": "d",
                "ɖ": "d",
                "Ɗ": "d",
                "ɗ": "d",
                "Ƌ": "d",
                "ƌ": "d",
                "ȡ": "d",
                "ð": "d",
                "É": "e",
                "Ə": "e",
                "Ǝ": "e",
                "ǝ": "e",
                "é": "e",
                "È": "e",
                "è": "e",
                "Ĕ": "e",
                "ĕ": "e",
                "Ê": "e",
                "ê": "e",
                "Ế": "e",
                "ế": "e",
                "Ề": "e",
                "ề": "e",
                "Ễ": "e",
                "ễ": "e",
                "Ể": "e",
                "ể": "e",
                "Ě": "e",
                "ě": "e",
                "Ë": "e",
                "ë": "e",
                "Ẽ": "e",
                "ẽ": "e",
                "Ė": "e",
                "ė": "e",
                "Ȩ": "e",
                "ȩ": "e",
                "Ḝ": "e",
                "ḝ": "e",
                "Ę": "e",
                "ę": "e",
                "Ē": "e",
                "ē": "e",
                "Ḗ": "e",
                "ḗ": "e",
                "Ḕ": "e",
                "ḕ": "e",
                "Ẻ": "e",
                "ẻ": "e",
                "Ȅ": "e",
                "ȅ": "e",
                "Ȇ": "e",
                "ȇ": "e",
                "Ẹ": "e",
                "ẹ": "e",
                "Ệ": "e",
                "ệ": "e",
                "Ḙ": "e",
                "ḙ": "e",
                "Ḛ": "e",
                "ḛ": "e",
                "Ɇ": "e",
                "ɇ": "e",
                "ɚ": "e",
                "ɝ": "e",
                "Ḟ": "f",
                "ḟ": "f",
                "ᵮ": "f",
                "Ƒ": "f",
                "ƒ": "f",
                "Ǵ": "g",
                "ǵ": "g",
                "Ğ": "g",
                "ğ": "g",
                "Ĝ": "g",
                "ĝ": "g",
                "Ǧ": "g",
                "ǧ": "g",
                "Ġ": "g",
                "ġ": "g",
                "Ģ": "g",
                "ģ": "g",
                "Ḡ": "g",
                "ḡ": "g",
                "Ǥ": "g",
                "ǥ": "g",
                "Ɠ": "g",
                "ɠ": "g",
                "Ĥ": "h",
                "ĥ": "h",
                "Ȟ": "h",
                "ȟ": "h",
                "Ḧ": "h",
                "ḧ": "h",
                "Ḣ": "h",
                "ḣ": "h",
                "Ḩ": "h",
                "ḩ": "h",
                "Ḥ": "h",
                "ḥ": "h",
                "Ḫ": "h",
                "ḫ": "h",
                "H": "h",
                "̱": "h",
                "ẖ": "h",
                "Ħ": "h",
                "ħ": "h",
                "Ⱨ": "h",
                "ⱨ": "h",
                "Í": "i",
                "í": "i",
                "Ì": "i",
                "ì": "i",
                "Ĭ": "i",
                "ĭ": "i",
                "Î": "i",
                "î": "i",
                "Ǐ": "i",
                "ǐ": "i",
                "Ï": "i",
                "ï": "i",
                "Ḯ": "i",
                "ḯ": "i",
                "Ĩ": "i",
                "ĩ": "i",
                "İ": "i",
                "i": "i",
                "Į": "i",
                "į": "i",
                "Ī": "i",
                "ī": "i",
                "Ỉ": "i",
                "ỉ": "i",
                "Ȉ": "i",
                "ȉ": "i",
                "Ȋ": "i",
                "ȋ": "i",
                "Ị": "i",
                "ị": "i",
                "Ḭ": "i",
                "ḭ": "i",
                "I": "i",
                "ı": "i",
                "Ɨ": "i",
                "ɨ": "i",
                "Ĵ": "j",
                "ĵ": "j",
                "J": "j",
                "̌": "j",
                "ǰ": "j",
                "ȷ": "j",
                "Ɉ": "j",
                "ɉ": "j",
                "ʝ": "j",
                "ɟ": "j",
                "ʄ": "j",
                "Ḱ": "k",
                "ḱ": "k",
                "Ǩ": "k",
                "ǩ": "k",
                "Ķ": "k",
                "ķ": "k",
                "Ḳ": "k",
                "ḳ": "k",
                "Ḵ": "k",
                "ḵ": "k",
                "Ƙ": "k",
                "ƙ": "k",
                "Ⱪ": "k",
                "ⱪ": "k",
                "Ĺ": "a",
                "ĺ": "l",
                "Ľ": "l",
                "ľ": "l",
                "Ļ": "l",
                "ļ": "l",
                "Ḷ": "l",
                "ḷ": "l",
                "Ḹ": "l",
                "ḹ": "l",
                "Ḽ": "l",
                "ḽ": "l",
                "Ḻ": "l",
                "ḻ": "l",
                "Ł": "l",
                "ł": "l",
                "Ł": "l",
                "̣": "l",
                "ł": "l",
                "̣": "l",
                "Ŀ": "l",
                "ŀ": "l",
                "Ƚ": "l",
                "ƚ": "l",
                "Ⱡ": "l",
                "ⱡ": "l",
                "Ɫ": "l",
                "ɫ": "l",
                "ɬ": "l",
                "ɭ": "l",
                "ȴ": "l",
                "Ḿ": "m",
                "ḿ": "m",
                "Ṁ": "m",
                "ṁ": "m",
                "Ṃ": "m",
                "ṃ": "m",
                "ɱ": "m",
                "Ń": "n",
                "ń": "n",
                "Ǹ": "n",
                "ǹ": "n",
                "Ň": "n",
                "ň": "n",
                "Ñ": "n",
                "ñ": "n",
                "Ṅ": "n",
                "ṅ": "n",
                "Ņ": "n",
                "ņ": "n",
                "Ṇ": "n",
                "ṇ": "n",
                "Ṋ": "n",
                "ṋ": "n",
                "Ṉ": "n",
                "ṉ": "n",
                "Ɲ": "n",
                "ɲ": "n",
                "Ƞ": "n",
                "ƞ": "n",
                "ɳ": "n",
                "ȵ": "n",
                "N": "n",
                "̈": "n",
                "n": "n",
                "̈": "n",
                "Ó": "o",
                "ó": "o",
                "Ò": "o",
                "ò": "o",
                "Ŏ": "o",
                "ŏ": "o",
                "Ô": "o",
                "ô": "o",
                "Ố": "o",
                "ố": "o",
                "Ồ": "o",
                "ồ": "o",
                "Ỗ": "o",
                "ỗ": "o",
                "Ổ": "o",
                "ổ": "o",
                "Ǒ": "o",
                "ǒ": "o",
                "Ö": "o",
                "ö": "o",
                "Ȫ": "o",
                "ȫ": "o",
                "Ő": "o",
                "ő": "o",
                "Õ": "o",
                "õ": "o",
                "Ṍ": "o",
                "ṍ": "o",
                "Ṏ": "o",
                "ṏ": "o",
                "Ȭ": "o",
                "ȭ": "o",
                "Ȯ": "o",
                "ȯ": "o",
                "Ȱ": "o",
                "ȱ": "o",
                "Ø": "o",
                "ø": "o",
                "Ǿ": "o",
                "ǿ": "o",
                "Ǫ": "o",
                "ǫ": "o",
                "Ǭ": "o",
                "ǭ": "o",
                "Ō": "o",
                "ō": "o",
                "Ṓ": "o",
                "ṓ": "o",
                "Ṑ": "o",
                "ṑ": "o",
                "Ỏ": "o",
                "ỏ": "o",
                "Ȍ": "o",
                "ȍ": "o",
                "Ȏ": "o",
                "ȏ": "o",
                "Ơ": "o",
                "ơ": "o",
                "Ớ": "o",
                "ớ": "o",
                "Ờ": "o",
                "ờ": "o",
                "Ỡ": "o",
                "ỡ": "o",
                "Ở": "o",
                "ở": "o",
                "Ợ": "o",
                "ợ": "o",
                "Ọ": "o",
                "ọ": "o",
                "Ộ": "o",
                "ộ": "o",
                "Ɵ": "o",
                "ɵ": "o",
                "Ṕ": "p",
                "ṕ": "p",
                "Ṗ": "p",
                "ṗ": "p",
                "Ᵽ": "p",
                "Ƥ": "p",
                "ƥ": "p",
                "P": "p",
                "̃": "p",
                "p": "p",
                "̃": "p",
                "ʠ": "q",
                "Ɋ": "q",
                "ɋ": "q",
                "Ŕ": "r",
                "ŕ": "r",
                "Ř": "r",
                "ř": "r",
                "Ṙ": "r",
                "ṙ": "r",
                "Ŗ": "r",
                "ŗ": "r",
                "Ȑ": "r",
                "ȑ": "r",
                "Ȓ": "r",
                "ȓ": "r",
                "Ṛ": "r",
                "ṛ": "r",
                "Ṝ": "r",
                "ṝ": "r",
                "Ṟ": "r",
                "ṟ": "r",
                "Ɍ": "r",
                "ɍ": "r",
                "ᵲ": "r",
                "ɼ": "r",
                "Ɽ": "r",
                "ɽ": "r",
                "ɾ": "r",
                "ᵳ": "r",
                "ß": "s",
                "Ś": "s",
                "ś": "s",
                "Ṥ": "s",
                "ṥ": "s",
                "Ŝ": "s",
                "ŝ": "s",
                "Š": "s",
                "š": "s",
                "Ṧ": "s",
                "ṧ": "s",
                "Ṡ": "s",
                "ṡ": "s",
                "ẛ": "s",
                "Ş": "s",
                "ş": "s",
                "Ṣ": "s",
                "ṣ": "s",
                "Ṩ": "s",
                "ṩ": "s",
                "Ș": "s",
                "ș": "s",
                "ʂ": "s",
                "S": "s",
                "̩": "s",
                "s": "s",
                "̩": "s",
                "Þ": "t",
                "þ": "t",
                "Ť": "t",
                "ť": "t",
                "T": "t",
                "̈": "t",
                "ẗ": "t",
                "Ṫ": "t",
                "ṫ": "t",
                "Ţ": "t",
                "ţ": "t",
                "Ṭ": "t",
                "ṭ": "t",
                "Ț": "t",
                "ț": "t",
                "Ṱ": "t",
                "ṱ": "t",
                "Ṯ": "t",
                "ṯ": "t",
                "Ŧ": "t",
                "ŧ": "t",
                "Ⱦ": "t",
                "ⱦ": "t",
                "ᵵ": "t",
                "ƫ": "t",
                "Ƭ": "t",
                "ƭ": "t",
                "Ʈ": "t",
                "ʈ": "t",
                "ȶ": "t",
                "Ú": "u",
                "ú": "u",
                "Ù": "u",
                "ù": "u",
                "Ŭ": "u",
                "ŭ": "u",
                "Û": "u",
                "û": "u",
                "Ǔ": "u",
                "ǔ": "u",
                "Ů": "u",
                "ů": "u",
                "Ü": "u",
                "ü": "u",
                "Ǘ": "u",
                "ǘ": "u",
                "Ǜ": "u",
                "ǜ": "u",
                "Ǚ": "u",
                "ǚ": "u",
                "Ǖ": "u",
                "ǖ": "u",
                "Ű": "u",
                "ű": "u",
                "Ũ": "u",
                "ũ": "u",
                "Ṹ": "u",
                "ṹ": "u",
                "Ų": "u",
                "ų": "u",
                "Ū": "u",
                "ū": "u",
                "Ṻ": "u",
                "ṻ": "u",
                "Ủ": "u",
                "ủ": "u",
                "Ȕ": "u",
                "ȕ": "u",
                "Ȗ": "u",
                "ȗ": "u",
                "Ư": "u",
                "ư": "u",
                "Ứ": "u",
                "ứ": "u",
                "Ừ": "u",
                "ừ": "u",
                "Ữ": "u",
                "ữ": "u",
                "Ử": "u",
                "ử": "u",
                "Ự": "u",
                "ự": "u",
                "Ụ": "u",
                "ụ": "u",
                "Ṳ": "u",
                "ṳ": "u",
                "Ṷ": "u",
                "ṷ": "u",
                "Ṵ": "u",
                "ṵ": "u",
                "Ʉ": "u",
                "ʉ": "u",
                "Ṽ": "v",
                "ṽ": "v",
                "Ṿ": "v",
                "ṿ": "v",
                "Ʋ": "v",
                "ʋ": "v",
                "Ẃ": "w",
                "ẃ": "w",
                "Ẁ": "w",
                "ẁ": "w",
                "Ŵ": "w",
                "ŵ": "w",
                "W": "w",
                "̊": "w",
                "ẘ": "w",
                "Ẅ": "w",
                "ẅ": "w",
                "Ẇ": "w",
                "ẇ": "w",
                "Ẉ": "w",
                "ẉ": "w",
                "Ẍ": "x",
                "ẍ": "x",
                "Ẋ": "x",
                "ẋ": "x",
                "Ý": "y",
                "ý": "y",
                "Ỳ": "y",
                "ỳ": "y",
                "Ŷ": "y",
                "ŷ": "y",
                "Y": "y",
                "̊": "y",
                "ẙ": "y",
                "Ÿ": "y",
                "ÿ": "y",
                "Ỹ": "y",
                "ỹ": "y",
                "Ẏ": "y",
                "ẏ": "y",
                "Ȳ": "y",
                "ȳ": "y",
                "Ỷ": "y",
                "ỷ": "y",
                "Ỵ": "y",
                "ỵ": "y",
                "ʏ": "y",
                "Ɏ": "y",
                "ɏ": "y",
                "Ƴ": "y",
                "ƴ": "y",
                "Ź": "z",
                "ź": "z",
                "Ẑ": "z",
                "ẑ": "z",
                "Ž": "z",
                "ž": "z",
                "Ż": "z",
                "ż": "z",
                "Ẓ": "z",
                "ẓ": "z",
                "Ẕ": "z",
                "ẕ": "z",
                "Ƶ": "z",
                "ƶ": "z",
                "Ȥ": "z",
                "ȥ": "z",
                "ʐ": "z",
                "ʑ": "z",
                "Ⱬ": "z",
                "ⱬ": "z",
                "Ǯ": "z",
                "ǯ": "z",
                "ƺ": "z"
            };
        }
    });

angular.module('mxg.helpers.WindowHelper', [])
    .factory('mxgWindowHelper', ['$q', function ($q) {
        'use strict';

        function scrollTo(positionY, duration, increment) {

            duration = duration || 200;
            increment = increment || 20;

            var start = getScreenTop();
            var top = positionY + start;
            var change = top - start;
            var currentTime = 0;

            if (!change) {
                return $q.when(true);
            }

            return $q(function (resolve) {
                (function scrollStep() {
                    currentTime += increment;
                    // Ease Quad function
                    var val = (function (currentTime, start, change, duration) {
                        if ((currentTime /= duration / 2) < 1) {
                            return change / 2 * currentTime * currentTime + start;
                        }
                        return -change / 2 * ((--currentTime) * (currentTime - 2) - 1) + start;
                    })(currentTime, start, change, duration);
                    window.scrollTo(0, val);
                    if (currentTime < duration) {
                        setTimeout(scrollStep, increment);
                    }
                    else {
                        resolve(true);
                    }
                })();
            });

        }

        function getScreenTop() {
            return typeof window.pageYOffset != 'undefined' ? window.pageYOffset :
                document.documentElement.scrollTop ? document.documentElement.scrollTop :
                    document.body.scrollTop ? document.body.scrollTop : 0;
        }

        function scrollToElement(element, duration, increment) {
            return scrollTo(element.getBoundingClientRect().top, duration, increment);
        }

        function centerElementVertically(element) {
            var rect = element.getBoundingClientRect();
            var top = rect.top + rect.height / 2 - window.innerHeight / 2;
            return scrollTo(top, 1, 1);
        }

        return {
            scrollToElement: scrollToElement,
            centerElementVertically: centerElementVertically
        };

    }]);

/**
 * Magnum provider/factory
 *
 * It's the main service which should act as an entry point
 * for all angular applications including the integration module of Magnum xG WEB API
 */
angular.module('mxg.magnum.Magnum',
    [
        'mxg.magnum.Config',
        'mxg.caseManager.CaseManager',
        'mxg.resources.CaseResource',
        'mxg.system.RootScope',
        'mxg.system.Events',
        'mxg.system.ErrorModel',
        'mxg.markupToHTML.converter'
    ])
    .provider('Magnum', [
        'MagnumConfigProvider',
        'mxgMarkupToHTMLConverterProvider',
        function MagnumProvider(MagnumConfig, MarkupToHTMLConverterProvider) {
            "use strict";

            var initializing = false;

            function processConfigOptions(options) {
                if (angular.isDefined(options.markupToHTMLConverter)) {
                    MarkupToHTMLConverterProvider.registerConverter(options.markupToHTMLConverter);
                }
                MagnumConfig.extend(options);
            }

            this.configure = processConfigOptions;

            this.$get = [
                '$log',
                '$q',
                'mxgRootScope',
                'mxgCaseManager',
                'mxgCaseResource',
                'mxgEvents',
                'mxgErrorModel',
                function Magnum($log, $q, mxgRootScope, CaseManager, CaseResource, mxgEvents, ErrorModel) {

                    var afterInit = function () {
                        if (initializing !== false) {
                            return initializing;
                        }
                        return $q.when(true);
                    };

                    var init = function (config) {
                        if (initializing !== false) {
                            return initializing;
                        }

                        angular.isObject(config) && processConfigOptions(config);

                        var rulebase = MagnumConfig.getOption('rulebase');
                        var language = MagnumConfig.getOption('language');

                        if (rulebase) {
                            initializing = CaseResource.ensureRulebaseSpecificDataLoaded(rulebase, language)
                                .then(function () {
                                    initializing = false;
                                    return true;
                                }, function (response) {
                                    initializing = false;
                                    initFailed(response);
                                    return false;
                                });
                            return initializing;
                        }
                        else {
                            return $q.when(true);
                        }
                    };

                    function initFailed(response) {
                        var errorModel;
                        if (response.data) {
                            errorModel = ErrorModel.create(response.data);
                        }
                        else {
                            errorModel = ErrorModel.create({message: 'Magnum initialisation failed.'});
                        }
                        mxgRootScope.$broadcast(mxgEvents.FATAL_ERROR, errorModel.toString(), errorModel);
                    }

                    /**
                     *
                     * @param {*} data
                     *
                     */
                    var startCase = function (data) {
                        return afterInit().then(function () {
                            data = data || {caseData: {}};
                            return CaseManager.startCase(data);
                        }, initFailed);
                    };

                    /**
                     *
                     * @param {*} data
                     *
                     */
                    var resumeCase = function (data) {
                        return afterInit().then(function () {
                            return CaseManager.resumeCase(data);
                        }, initFailed);
                    };

                    /**
                     *
                     * @deprecated
                     * @param {function()} callback
                     * @returns {function()}
                     */
                    var onCaseCompleted = function (callback) {
                        $log.warn("Using deprecated onCaseCompleted event");
                        return mxgRootScope.$on(mxgEvents.CASE_COMPLETE, function (event, caseData) {
                            (callback || angular.noop)(caseData);
                        });
                    };

                    /**
                     * @deprecated
                     *
                     * @param callback
                     * @returns {function()|*}
                     */
                    var onCaseCreated = function (callback) {
                        $log.warn("Using deprecated onCaseCreated event");
                        return mxgRootScope.$on(mxgEvents.CASE_CREATED, function (event, caseData) {
                            (callback || angular.noop)(caseData);
                        });
                    };

                    /**
                     * @deprecated
                     *
                     * @param callback
                     * @returns {function()|*}
                     */
                    var onCaseFormSubmit = function (callback) {
                        $log.warn("Using deprecated onCaseFormSubmit event");
                        return mxgRootScope.$on(mxgEvents.CASE_FORM_SUBMITTED, function (event, caseData, formData) {
                            (callback || angular.noop)(caseData, formData);
                        });
                    };
                    var _eventHandlers = {};

                    var attachEventHandler = function (eventName, eventHandler) {
                        detachEventHandler(eventName, eventHandler);
                        var eventHandlers = _eventHandlers[eventName] = _eventHandlers[eventName] || [];
                        var destructor = mxgRootScope.$on('mxg:' + eventName, function () {
                            var args = Array.prototype.slice.call(arguments, 0);
                            eventHandler.apply(undefined, args);
                        });
                        eventHandlers.push({
                            handler: eventHandler,
                            destroy: destructor
                        });
                        return destructor;
                    };

                    var detachEventHandler = function (eventName, eventHandler) {
                        var handlers = _eventHandlers[eventName] || [];
                        for (var i = 0, ii = handlers.length; i < ii; i++) {
                            if (handlers[i] && handlers[i].handler === eventHandler) {
                                handlers[i].destroy();
                                handlers.splice(i, 1);
                                return true;
                            }
                        }
                        return false;
                    };

                    var magnum = {
                        init: init,
                        startCase: startCase,
                        resumeCase: resumeCase,
                        onCaseCompleted: onCaseCompleted,
                        onCaseCreated: onCaseCreated,
                        onCaseFormSubmit: onCaseFormSubmit,
                        on: attachEventHandler,
                        off: detachEventHandler
                    };
                    return magnum;
                }];
        }]);

angular.module('mxg.magnum.Config', [])
    .constant('mxgApplicantNameSource', {
        HOSTAPP: 'hostapp',
        RUNTIME: 'runtime'
    })
    .provider('MagnumConfig', ['mxgApplicantNameSource', function (APPLICANT_NAME_SOURCE) {
        "use strict";

        var config = {};

        var configDefaultValues = {
            rulebase: null,
            applicantnameSource: APPLICANT_NAME_SOURCE.RUNTIME
        };

        this.extend = function (src) {
            angular.extend(config, src);
        };

        /**
         * Recursive function is required to handle the situation like this:
         *
         * config  = {
         *  foobar : {
         *      'something.deep' : "value"
         *   }
         * }
         *
         *  MagnumConfig.getOption('foobar.something.deep');
         *
         * @param key
         * @param source
         * @private
         */
        var _getOption = function (key, source) {
            if (!source.hasOwnProperty(key)) {
                if (key.indexOf('.') > 0) {

                    var keys = key.split(".")
                        , firstKey = keys.shift()
                        , restKeys = keys.join('.');

                    if (source.hasOwnProperty(firstKey)) {
                        return _getOption(restKeys, source[firstKey])
                    }
                }
            } else {
                return source[key];
            }
        };

        /**
         *
         * @param key
         * @param defaultValue
         * @returns {*} if the value is found by the key returns it, or returns null|defaultValue otherwise
         */
        var getOption = function (key, defaultValue) {
            var value = _getOption(key, config);
            if (angular.isUndefined(value)) {
                value = defaultValue !== undefined ? defaultValue : _getOption(key, configDefaultValues);
            }
            return value !== undefined ? value : null;
        };

        /**
         *
         * @type {getOption}
         */
        this.getOption = getOption;

        this.$get = [function () {
            return {
                getOption: getOption
            }
        }];
    }]);

/**
 * Note: This directive is not prefixed with mxg due to word magnum in it's name
 */
angular.module('mxg.magnum.MagnumContainer', [
    'mxg.magnum.Config',
    'mxg.activeCase.ActiveCase',
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.magnum.MagnumContainerElement',
    'mxg.helpers.WindowHelper',
    'mxg.components.CoverSheet'
])
    .constant('mxgContainerLayout', {
        menuStates: ['enabled', 'disabled'],
        menuPlaces: ['left', 'hidden']
    })
    .directive('magnumContainer', [
        '$document', 'MagnumConfig', 'mxgActiveCase', 'MagnumContainerElement', 'mxgRootScope', 'mxgEvents',
        function magnumContainer($document, MagnumConfig, ActiveCase, MagnumContainerElement, mxgRootScope, mxgEvents) {
            'use strict';
            return {
                restrict: 'AE',
                scope: true,

                templateUrl: function () {
                    return MagnumConfig.getOption('layout.template') || 'mxg-template/magnum/MagnumContainer.html';
                },

                controller: [
                    '$scope', '$element', 'MagnumConfig', 'mxgContainerLayout', 'mxgWindowHelper',
                    function magnumContainerController($scope, $element, MagnumConfig, CONTAINER_LAYOUT, WindowHelper) {

                        var magnumContainer = this;
                        var scrollReady = true;

                        /*
                         * Layout Initialization
                         * */
                        var menuState = MagnumConfig.getOption('layout.menuState',
                            CONTAINER_LAYOUT.menuStates[0]);
                        var menuPlace = MagnumConfig.getOption('layout.menuPlace',
                            CONTAINER_LAYOUT.menuPlaces[0]);

                        menuState = (CONTAINER_LAYOUT.menuStates.indexOf(
                            menuState) === -1) ? CONTAINER_LAYOUT.menuStates[0] : menuState;
                        menuPlace = (CONTAINER_LAYOUT.menuPlaces.indexOf(
                            menuPlace) === -1) ? CONTAINER_LAYOUT.menuPlaces[0] : menuPlace;

                        magnumContainer.layout = {
                            menuVisible: menuPlace !== 'hidden',
                            menuDisabled: menuState === 'disabled',
                            menuActive: false
                        };

                        $scope.layoutClasses = 'mxg-layout-menu-' + menuState + ' mxg-layout-menu-' + menuPlace;
                        MagnumContainerElement.set($element);

                        /*
                         * this is used for controlling keyboard navigation between different parts of the Magnum Application
                         * */
                        magnumContainer.kb = (function (startTabIndex) {
                            var reserved = [];
                            ['NavigationMenu',
                             'NavigationControls_top',
                             'MagnumForm',
                             'NavigationControls_bottom'
                            ].forEach(function (name, index) {
                                reserved.push({
                                    name: name,
                                    tabIndex: startTabIndex + index
                                });
                            });
                            return {
                                getReservedTabIndex: function getReservedTabIndex(name) {
                                    var foundIndex = null;
                                    if (!reserved.some(function(item) {
                                            if (item.name === name) {
                                                foundIndex = item.tabIndex;
                                                return true;
                                            }
                                            return false;
                                        })) {
                                        foundIndex = startTabIndex + reserved.length;
                                        reserved.push({
                                            name: name,
                                            tabIndex: foundIndex
                                        });
                                    }
                                    return foundIndex;
                                }
                            };
                        })(MagnumConfig.getOption('startTabIndex', 1));


                        magnumContainer.focusGoNextControl = function () {
                            var controlElement = $document[0].getElementById('nav_ctrl_continue');
                            controlElement && controlElement.focus();
                        };

                        magnumContainer.requestInlineForm = function () {
                            return ActiveCase.partialSubmit();
                        };

                        magnumContainer.scrollToContainer = function () {
                            scrollReady = true;
                            WindowHelper.scrollToElement($element[0]);
                        };

                        magnumContainer.getScrolled = function () {
                            return scrollReady;
                        };

                        magnumContainer.setScrolled = function (value) {
                            scrollReady = !!value;
                            return this;
                        };

                    }],
                controllerAs: 'magnumContainer',
                link: function link($scope, $element, $attr, magnumContainer) {
                    $element.addClass('mxg-application');
                    $scope.activeCase = ActiveCase;

                    var setTransitional = (function () {
                        var timeout = null;
                        return function () {
                            if (timeout) {
                                clearTimeout(timeout);
                            } else {
                                $element.addClass('transitional');
                            }
                            timeout = setTimeout(function () {
                                timeout = null;
                                $element.removeClass('transitional');
                            }, 500);
                        };
                    })();

                    magnumContainer.layout.setMenuActive = function (bool) {
                        setTransitional();
                        magnumContainer.layout.menuActive = bool;
                        if (magnumContainer.layout.menuActive) {
                            MagnumContainerElement.get().on("click", function (event) {
                                $scope.$apply(function () {
                                    magnumContainer.layout.setMenuActive(false);
                                });
                            });
                        } else {
                            MagnumContainerElement.get().off("click");
                        }
                    };

                    mxgRootScope.$on(mxgEvents.CASE_CHECK_INVALID, magnumContainer.scrollToContainer);
                    $scope.$on('mxg:internal-inline-trigger', function() {
                        magnumContainer.requestInlineForm();
                    });

                }
            }
        }]);

angular.module('mxg.magnum.MagnumContainerElement', [
    'mxg.helpers.WindowHelper'
])
    .factory('MagnumContainerElement', [
        '$q', 'mxgWindowHelper',
        function ($q, WindowHelper) {
            'use strict';
            var _element = null;
            return {
                get: function () {
                    return _element;
                },
                set: function (element) {
                    _element = element;
                },
                getController: function () {
                    if (!_element) {
                        return null;
                    }
                    return _element.scope().magnumContainer;
                },
                moveToCenter: function () {
                    if (!_element) {
                        return $q.when(false);
                    }
                    return WindowHelper.centerElementVertically(_element[0]);
                },
                isRendering: function() {
                    return angular.isElement(_element) && _element[0].querySelector('.mxg-rendering__global');
                }
            }
        }]);

angular.module('mxg.magnum.MagnumForm', ['mxg.magnum.MagnumFormCtrl'])
    .directive('magnumForm', [function () {
        'use strict';
        return {
            restrict: 'AE',
            templateUrl: 'mxg-template/magnum/MagnumForm.html',
            scope: true,
            controller: 'MagnumFormCtrl',
            controllerAs: 'magnumFormCtrl',
            link: function magnumFormLink($scope, $element) {
                $element.addClass('mxg-application-form');
                $scope.$watch('magnumFormCtrl.getFormModel()', function() {
                    $scope.magnumFormCtrl.updateFormConfig();
                });
            }
        };
    }]);

angular.module('mxg.magnum.MagnumFormCtrl', [
    'mxg.magnum.Config',
    'mxg.formElement.FormConfig',
    'mxg.activeCase.ActiveCase',
    'mxg.system.RuntimeConstants',
    'mxg.magnum.MagnumContainerElement'
])
    .controller('MagnumFormCtrl', [
        'MagnumConfig', 'MagnumContainerElement', 'mxgFormConfig', 'mxgActiveCase', 'mxgRuntimeConstants',
        function (MagnumConfig, MagnumContainerElement, FormConfig, ActiveCase, RuntimeConstants) {
            'use strict';
            var magnumFormCtrl = this;

            magnumFormCtrl.getFormModel = function () {
                return ActiveCase.exists() ? ActiveCase.getActiveForm() : null;
            };
            magnumFormCtrl.updateFormConfig = function () {
                FormConfig.setOption('highlightUnansweredQuestions', !ActiveCase.getMandatoryValidationsSetting(
                        RuntimeConstants.mandatoryValidations.SUBMIT) && MagnumConfig.getOption(
                        'highlightUnansweredQuestions'));
            };

            var magnumContainerCtrl = MagnumContainerElement.getController();
            FormConfig.setOption('tabIndex',
                magnumContainerCtrl ? magnumContainerCtrl.kb.getReservedTabIndex('MagnumForm') : 1);
        }]);

angular.module('mxg.markupToHTML.filter', ['mxg.markupToHTML.converter'])
    .filter('mxgMarkupToHTML', ['mxgMarkupToHTMLConverter', function (Converter) {

        return function (input) {
           return Converter.makeHtml(input);
        };

    }]);

angular.module('mxg.markupToHTML', [
    'mxg.markupToHTML.converter',
    'mxg.markupToHTML.filter'
]);

angular.module('mxg.markupToHTML.converter', [])
    .provider('mxgMarkupToHTMLConverter', function mxgMarkupToHTMLConverter() {

        var provider = this;

        var _converter = null;

        /**
         * @ngdoc MarkupToHTMLConverter
         * */
        function MarkupToHTMLConverter() {
        }

        /**
         * @method MarkupToHTMLConverter#makeHtml
         * @param {String} textValue
         * @returns {String}
         * */
        MarkupToHTMLConverter.prototype.makeHtml = function (textValue) {

            /*
            *  IMPORTANT: Front-side markup processing functionality reserved for the future.
            *             Currently receiving HTML from server is expected.
            */
            return textValue;
            
            /*
                        if (!textValue || !_converter) {
                            return textValue;
                        }

                        var htmlValue = _converter(textValue);

                        if (typeof htmlValue === 'undefined') {
                            htmlValue = textValue;
                        }

                        return htmlValue;
            */

        };

        provider.registerConverter = function (converterFn) {
            _converter = angular.isFunction(converterFn) ? converterFn : null;
        };

        provider.$get = function () {
            return new MarkupToHTMLConverter();
        };

    });

angular.module('mxg.messages', [
    'mxg.messages.MessagesMap',
    'mxg.messages.MessagesBanner'
]);


angular.module('mxg.messages.MessagesBanner', [
    'mxg.messages.MessagesMap',
    'mxg.system.MessageTypes',
    'mxg.translation'])
    .directive('mxgMessagesBanner', ['mxgMessagesMap', function (MessagesMap) {
        "use strict";
        return {
            restrict: 'AE',
            scope: {
                locator: "@mxgLocator"
            },
            templateUrl: "mxg-template/messages/MessagesBanner.html",
            link: function (scope) {

                scope.messageExist = function () {
                    return MessagesMap.exists(scope.locator);
                };

                scope.getMessages = function () {
                    return MessagesMap.find(scope.locator);
                };

            }
        }
    }]);

angular.module('mxg.messages.MessagesMap', ['mxg.system.MessageTypes'])
    .factory('mxgMessagesMap', ['mxgMessageTypes', function mxgMessagesMap(MessageTypes) {

        "use strict";
        var messages;

        var service = {};

        /**
         *
         * @param {String} locator
         * @param {{}} message
         * @returns {service}
         */
        service.addMessage = function (locator, message) {

            var cacheMessage;
            if (angular.isObject(message)) {
                cacheMessage = message;
                cacheMessage.type =  cacheMessage.type in MessageTypes ? MessageTypes[cacheMessage.type ]: MessageTypes.INFO;
            }
            else {
                cacheMessage = {
                    type: MessageTypes.INFO,
                    text: angular.isArray(message) ? message.join(' ') : message
                };
            }

            messages[locator] = messages[locator] || [];
            messages[locator].push(angular.copy(cacheMessage));

            return this;

        };

        /**
         *
         * @param locator
         * @returns {*|null}
         */
        service.find = function (locator) {
            return messages[locator] || null;
        };

        /**
         *
         * @param locator
         * @returns {Boolean}
         */
        service.exists = function (locator) {
            return !!messages[locator] || false;
        };

        /**
         * @description Resets errors per locator if passed. Resets all validation errors if locator is not passed or not truthy
         * @param locator
         */
        service.reset = function (locator) {
            if (locator) {
                messages[locator] = null;
            } else {
                messages = {};
            }
        };

        service.reset();

        return service;

    }]);

angular.module('mxg.Navigation', [
    'mxg.navigation.NavigationMenuItemType',
    'mxg.navigation.NavigationModel',
    'mxg.navigation.NavigationMenuCtrl',
    'mxg.navigation.NavigationMenu',
    'mxg.navigation.NavigationMenuItemCtrl',
    'mxg.navigation.NavigationMenuItem',
    'mxg.navigation.NavigationOverviewLinkCtrl',
    'mxg.navigation.NavigationOverviewLink',
    'mxg.navigation.NavigationControls'
]);

angular.module('mxg.navigation.NavigationControls', [
    'mxg.rulebase.RulebaseLanguages',
    'mxg.translation.TranslateService',
    'mxg.activeCase.ActiveCase',
    'mxg.components.DialogService',
    'mxg.magnum.Config',
    'mxg.rulebase.RulebaseReferenceData',
    'mxg.components.ProcessManager',
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.magnum.MagnumContainerElement'
])
    .directive('mxgNavigationControls', [
        '$q',
        '$templateCache',
        '$compile',
        'mxgRulebaseLanguages',
        'mxgTranslateService',
        'mxgActiveCase',
        'mxgDialogService',
        'MagnumConfig',
        'mxgRulebaseReferenceData',
        'mxgProcessManager',
        'mxgRootScope',
        'mxgEvents',
        'MagnumContainerElement',
        function magnumControls($q, $templateCache, $compile, RulebaseLanguages, TranslateService, ActiveCase, DialogService, MagnumConfig, RulebaseReferenceData, ProcessManager, mxgRootScope, mxgEvents, MagnumContainerElement) {
            'use strict';

            function getControlID(action) {
                return 'ActionControls.BTN_LABEL_' + action.toUpperCase();
            }

            return {
                restrict: 'AE',
                require: '?^magnumContainer',
                scope: {
                    layoutPlace: '@mxgLayoutPlace'
                },

                link: function link($scope, $element, $attrs, magnumContainer) {

                    $scope.layoutPlace = $scope.layoutPlace || 'bottom';

                    $element.addClass('mxg-navigation-controls' + ' mxg-navigation-controls__' + $scope.layoutPlace);

                    var magnumContainerCtrl = MagnumContainerElement.getController();
                    var navTabIndex = magnumContainerCtrl? magnumContainerCtrl.kb.getReservedTabIndex(
                            'NavigationControls_' + $scope.layoutPlace) : 1;
                    var formTabIndex = magnumContainerCtrl ? magnumContainerCtrl.kb.getReservedTabIndex('MagnumForm') : 2;

                    var langSelectorPlacement = MagnumConfig.getOption('layout.languageSelector', 'bottom left');

                    var template, childElement;

                    var isEmptyContainer = true;

                    var navControlsPlacement = parseOptions(MagnumConfig.getOption('layout.controls', 'bottom center'));

                    if ((langSelectorPlacement !== 'hidden') && (langSelectorPlacement.indexOf(
                            $scope.layoutPlace) !== -1)) {

                        isEmptyContainer = false;

                        $scope.languageSelector = {
                            value: null
                        };

                        $scope.languageSelector.options = [];

                        $scope.languageSelector.onChange = function () {

                            var currentLanguage = ActiveCase.getLanguageCode();
                            var newLanguageCode = $scope.languageSelector.value;

                            if ($scope.languageSelector.value === currentLanguage) {
                                return;
                            }

                            if (!$scope.languageSelector.value) {
                                $scope.languageSelector.value = currentLanguage;
                                return;
                            }

                            return performLanguageSwitch(ActiveCase.getActiveForm(), {language: newLanguageCode})
                                .then(function (result) {
                                    if (!result.success) {
                                        $scope.languageSelector.value = currentLanguage;
                                    }
                                    mxgRootScope.$broadcast(mxgEvents.NAVIGATION_LANGUAGE_SELECTOR, newLanguageCode,
                                        result.success);
                                })
                                .catch(function () {
                                    $scope.languageSelector.value = currentLanguage;
                                });

                        };

                        $scope.formTabIndex = formTabIndex;

                        template = $templateCache.get('mxg-template/magnum/FormLanguageSelector.html');
                        childElement = $compile(template)($scope);

                        if (langSelectorPlacement.indexOf('right') !== -1) {
                            childElement.addClass('mxg-form-language-selector__right');
                        }
                        else {
                            childElement.addClass('mxg-form-language-selector__left');
                        }

                        $element.append(childElement);

                        $scope.$watch(function () {
                            return ActiveCase.getRulebase();
                        }, function (newValue, prevValue) {
                            if (newValue === prevValue) {
                                return;
                            }
                            updateLanguageSelector();
                        });

                        $scope.$watch(function () {
                            return ActiveCase.getActiveForm();
                        }, function (newValue, prevValue) {
                            if (newValue === prevValue) {
                                return;
                            }
                            $scope.languageSelector.value = ActiveCase.getLanguageCode();
                        });

                        updateLanguageSelector();

                    }

                    function updateLanguageSelector() {
                        $scope.languageSelector.options = RulebaseLanguages.getLanguages(
                                ActiveCase.getRulebase()) || [];
                        if ($scope.languageSelector.options.length) {
                            $scope.languageSelector.value = ActiveCase.getLanguageCode();
                        }
                    }

                    function performLanguageSwitch(form, params) {
                        return $q(function (resolve) {
                            ensureLanguageChangeAllowed(form).then(function (confirmed) {
                                if (confirmed) {
                                    ActiveCase.reloadActiveForm(params)
                                        .then(resolve.bind(null, {success: true}))
                                        .catch(resolve.bind(null, {success: false}));
                                }
                                else {
                                    resolve({success: false, reason: 'rejected by user'});
                                }
                            });
                        });
                    }

                    function ensureLanguageChangeAllowed(form) {
                        return $q(function (resolve) {
                            if (form.checkWasSubmitted()) {
                                DialogService
                                    .confirm(TranslateService.getById('UserMessages.2001'), $scope)
                                    .then(resolve.bind(null))
                                    .catch(resolve.bind(null, false));
                            }
                            else {
                                resolve(true);
                            }
                        });
                    }

                    var navLock = (function () {

                        var locked = false;
                        return {
                            isActive: function () {
                                return locked || ProcessManager.isRunning();
                            },
                            start: function () {
                                locked = true;
                            },
                            stop: function () {
                                locked = false;
                            }
                        };

                    })();

                    function performAction(actionFn) {
                        return $q(function (resolve, reject) {
                            if (navLock.isActive()) {
                                return reject({success: false, reason: 'Navigation is locked by previous action'});
                            }
                            navLock.start();
                            magnumContainerCtrl && magnumContainerCtrl.scrollToContainer();
                            actionFn()
                                .then(function () {
                                    navLock.stop();
                                    resolve({success: true});
                                })
                                .catch(function () {
                                    navLock.stop();
                                    resolve({success: false});
                                });
                        });
                    }

                    function actionControlFactory(type, actionFn, tabIndex) {
                        var navigationId = 'nav_ctrl_' + type;
                        return {
                            type: type,
                            id: navigationId,
                            action: function () {
                                performAction(actionFn)
                                    .then(function (result) {
                                        mxgRootScope.$broadcast(mxgEvents.NAVIGATION_BUTTON, navigationId,
                                            result.success);
                                    })
                                    .catch(function () {
                                        mxgRootScope.$broadcast(mxgEvents.NAVIGATION_BUTTON, navigationId, false);
                                    });
                            },
                            customClasses: getControlClasses(type),
                            getCaption: getControlCaption(type),
                            tabIndex: tabIndex
                        };
                    }

                    if (navControlsPlacement.vertical === $scope.layoutPlace) {

                        isEmptyContainer = false;

                        $scope.controls = [
                            actionControlFactory('back', ActiveCase.getPrevForm, navTabIndex),
                            actionControlFactory('save', ActiveCase.saveForm, navTabIndex),
                            /*
                             * We need formTabIndex here to make Continue button to be the first focused when tabbing away from Magnum Form.
                             * */
                            actionControlFactory('continue', ActiveCase.getNextForm, formTabIndex)
                        ];

                        template = $templateCache.get('mxg-template/navigation/NavigationControls.html');
                        childElement = $compile(template)($scope);

                        childElement.addClass('mxg-controls-buttons__' + navControlsPlacement.horizontal);

                        $element.append(childElement);

                    }

                    if (isEmptyContainer) {
                        $element.addClass('mxg-empty-container');
                    }

                    function parseOptions(options) {
                        var placement = {
                            vertical: null,
                            horizontal: null
                        };

                        var parts = options.split(' ');

                        if (parts.length < 2) {
                            placement.vertical = 'bottom';
                            placement.horizontal = 'center';
                        }
                        else {
                            placement.vertical = parts[0] === 'top' ? 'top' : 'bottom';
                            placement.horizontal = parts[1];
                        }
                        return placement;

                    }

                    function getControlCaption(action) {

                        var optionName = 'labels.controls.' + action;
                        var translationId = getControlID(action);

                        return function () {
                            return MagnumConfig.getOption(optionName, TranslateService.getById(translationId));
                        };

                    }

                    function getControlClasses(action) {

                        var actionClass = 'mxg-action-' + action;

                        return function () {
                            var rulebase = ActiveCase.getRulebase();
                            var iconCode = RulebaseReferenceData.getIconCode(getControlID(action), rulebase);
                            var iconClass = iconCode ? 'mxg-icon-code_' + iconCode : null;
                            return [actionClass, iconClass];
                        };

                    }

                }

            };

        }]);

angular.module('mxg.navigation.NavigationMenu', [
    'mxg.magnum.Config',
    'mxg.navigation.NavigationModel',
    'mxg.navigation.NavigationMenuCtrl'
])
    .directive('mxgNavigationMenu', [
        '$compile', 'mxgNavigationModel', 'MagnumConfig',
        function mxgNavigationMenu($compile, NavigationModel, MagnumConfig) {
            'use strict';
            return {
                restrict: 'AE',
                require: '^magnumContainer',
                templateUrl: 'mxg-template/navigation/NavigationMenu.html',
                scope: true,
                controller: 'mxgNavigationMenuCtrl',
                controllerAs: 'menuCtrl',
                link: function link($scope, $element, $attrs, magnumContainerCtrl) {

                    $element.addClass('mxg-navigation-menu');
                    $element.bind('click', function (event) {
                        event.stopPropagation();
                    });
                    $scope.menuTabIndex = magnumContainerCtrl.kb.getReservedTabIndex('NavigationMenu');
                    $scope.menuSource = [];

                    if (MagnumConfig.getOption('showOverviewLink')) {
                        appendOverviewLink($element[0].querySelector('.mxg-navigation-menu-container'));
                    }

                    $scope.$watch(
                        function () {
                            return $scope.menuCtrl.getMenu();
                        },
                        function (newValue) {
                            $scope.menuCtrl.reset();
                            $scope.menuSource.length = 0;
                            angular.extend($scope.menuSource, newValue);
                        }
                    );

                    $scope.toggleNavigation = function (toggle) {
                        magnumContainerCtrl.layout.setMenuActive(toggle || !magnumContainerCtrl.layout.menuActive);
                    };

                    $scope.onMenuItemClick = function (event, menuItem) {
                        event.stopPropagation();
                        if (NavigationModel.isFormLink(menuItem)) {
                            $scope.toggleNavigation(false);
                        }
                        return false;
                    };

                    function appendOverviewLink(parentElement) {
                        var linkElement = $compile('<mxg-navigation-overview-link/>')($scope);
                        angular.element(parentElement).append(linkElement);
                    }

                }
            };
        }]);

angular.module('mxg.navigation.NavigationMenuCtrl', [
    'mxg.activeCase.ActiveCase'
])
    .controller('mxgNavigationMenuCtrl', ['mxgActiveCase', function (ActiveCase) {
        'use strict';
        var menuItemCtrls = [];
        var currentMenuItem = ActiveCase.navigation.getCurrentMenuItem();

        var menuCtrl = this;

        menuCtrl.getMenu = function () {
            return ActiveCase.navigation.getMenu() || [];
        };

        menuCtrl.registerRenderedMenuItem = function (itemCtrl) {
            menuItemCtrls.push(itemCtrl);
        };

        menuCtrl.reset = function () {
            menuItemCtrls.length = 0;
            currentMenuItem = ActiveCase.navigation.getCurrentMenuItem();
        };

        menuCtrl.expandLifeBranch = function (lifeId) {
            menuItemCtrls.forEach(function (ctrl) {
                var itemLifeId = ctrl.getLifeId();
                if (!itemLifeId) {
                    return;
                }
                if (ctrl.isLifeItem()) {
                    ctrl.setCollapsed(itemLifeId !== lifeId);
                }
                else {
                    ctrl.setIsVisible(itemLifeId === lifeId);
                }
            });
        };

        menuCtrl.getInitialCollapsedState = function (itemCtrl) {
            return (itemCtrl.isLifeItem()) && (itemCtrl.getLifeId() !== currentMenuItem.lifeId);
        };

        menuCtrl.getInitialVisibility = function (itemCtrl) {
            var lifeId = itemCtrl.getLifeId();
            if (angular.isUndefined(lifeId) || (lifeId === null)) {
                return true;
            }
            return itemCtrl.isLifeItem() || (lifeId === currentMenuItem.lifeId);
        };

    }
    ]);

angular.module('mxg.navigation.NavigationMenuItem', [
    'mxg.activeCase.ActiveCase',
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.navigation.NavigationMenuItemCtrl'])
    .directive('mxgNavigationMenuItem', [
        '$q',
        'mxgActiveCase',
        'mxgRootScope',
        'mxgEvents',
        function ($q, ActiveCase, mxgRootScope, mxgEvents) {
            'use strict';
            return {
                restrict: 'AE',
                require: '^mxgNavigationMenu',
                scope: {
                    item: '=mxgNavigationMenuItem',
                    tabIndex: '@mxgTabindex'
                },
                templateUrl: 'mxg-template/navigation/NavigationMenuItem.html',
                controller: 'mxgNavigationMenuItemCtrl',
                controllerAs: 'menuItemCtrl',
                link: function ($scope, $element, $attrs, menuCtrl) {

                    menuCtrl.registerRenderedMenuItem($scope.menuItemCtrl);

                    var itemClasses = 'mxg-menu-item  mxg-level-' + $scope.item.level;

                    if (angular.isArray($scope.item.childNodes)) {
                        itemClasses += ($scope.item.childNodes.length === 0 ? ' mxg-menu-leaf' : ' mxg-menu-brunch');
                    }

                    $scope.item.current && (itemClasses += ' mxg-menu-status-current');

                    $scope.item.complete && (itemClasses += ' mxg-menu-status-complete');

                    if (angular.isString($scope.item.type)) {
                        itemClasses += ' mxg-menu-type-' + $scope.item.type.toLocaleLowerCase();
                    }

                    $element.addClass(itemClasses);

                    $scope.getElementId = function (suffix) {
                        return $scope.item.id + '_' + suffix;
                    };

                    $scope.ui = {
                        menuAction: function (event) {
                            event.preventDefault();
                            if ($scope.menuItemCtrl.getCollapsible()) {
                                /* show/expand brunch */
                                if (!$scope.menuItemCtrl.getCollapsed()) {
                                    return;
                                }
                                menuCtrl.expandLifeBranch($scope.menuItemCtrl.getLifeId());
                            }
                            else {
                                /* navigate */
                                performAction($scope.item.sequenceKey)
                                    .then(function (result) {
                                        mxgRootScope.$broadcast(mxgEvents.NAVIGATION_MENU, result.success);
                                    });
                            }
                            return false;
                        }
                    };

                    function performAction(sequenceKey) {
                        return $q(function (resolve) {
                            ActiveCase.getFormById(sequenceKey)
                                .then(function () {
                                    resolve({success: true});
                                })
                                .catch(function () {
                                    resolve({success: false});
                                });
                        });
                    }

                    if ($scope.menuItemCtrl.getCollapsible()) {
                        $scope.hasLink = true;
                        $scope.menuItemCtrl.setCollapsed(menuCtrl.getInitialCollapsedState($scope.menuItemCtrl));
                    }
                    else {
                        $scope.hasLink =
                            ($scope.menuItemCtrl.isLifeItem()) || ActiveCase.navigation.getItemIsActiveLink(
                                $scope.item);
                        $scope.menuItemCtrl.setIsVisible(menuCtrl.getInitialVisibility($scope.menuItemCtrl));
                    }

                    $scope.getItemVisible = function () {
                        return $scope.menuItemCtrl.getIsVisible();
                    };

                }
            };

        }]);


angular.module('mxg.navigation.NavigationMenuItemCtrl', [
    'mxg.navigation.NavigationMenuItemType'
])
    .controller('mxgNavigationMenuItemCtrl', [
        '$scope', '$element', 'mxgNavigationMenuItemType',
        function ($scope, $element, NavigationMenuItemType) {
            'use strict';

            var menuItemCtrl = this;

            var visible = true;
            var collapsed = false;

            menuItemCtrl.getIsVisible = function () {
                return visible;
            };

            menuItemCtrl.setIsVisible = function (newVisibleState) {
                $scope.$evalAsync(function () {
                    visible = newVisibleState;
                });
            };

            menuItemCtrl.getCollapsible = function () {
                return menuItemCtrl.isLifeItem();
            };

            menuItemCtrl.getCollapsed = function () {
                return collapsed;
            };

            menuItemCtrl.setCollapsed = function (isCollapsed) {
                collapsed = isCollapsed;
                renderCollapsedState();
            };

            menuItemCtrl.getLifeId = function () {
                return $scope.item.lifeId || null;
            };

            menuItemCtrl.getType = function () {
                return $scope.item.type || null;
            };

            menuItemCtrl.isLifeItem = function () {
                return $scope.item.type === NavigationMenuItemType.LIFE;
            };

            function renderCollapsedState() {
                $element.toggleClass('mxg-collapsed-true', collapsed === true);
                $element.toggleClass('mxg-collapsed-false', collapsed === false);
            }

        }]);

angular.module('mxg.navigation.NavigationMenuItemType', [])
    .constant('mxgNavigationMenuItemType', {
        BOOTSTRAP: 'BOOTSTRAP_FORM',
        BASE: 'BASE_FORM',
        DRILLDOWN: 'DRILLDOWN_FORM',
        THEME: 'THEME',
        LIFE: 'LIFE' //this type type is created only on front-end side, it doesn't exist in Runtime nor Rulebase

    });

angular.module('mxg.navigation.NavigationModel', [
    'mxg.magnum.Config',
    'mxg.translation.TranslateService',
    'mxg.navigation.NavigationMenuItemType'
])
    .factory('mxgNavigationModel', [
        'MagnumConfig', 'mxgNavigationMenuItemType', 'mxgTranslateService', 'mxgApplicantNameSource',
        function mxgNavigationModel(MagnumConfig, NavigationMenuItemType, TranslateService, APPLICANT_NAME_SOURCE) {
            'use strict';

            /**
             * @class
             * */
            function NavigationModel() {

                var menu = [];

                var allFormsCompleted = false;

                /**
                 *
                 * @returns Array
                 */
                this.getMenu = function () {
                    return menu;
                };

                /**
                 *  @param menuModel
                 *  @param lifeData
                 *
                 */
                this.setMenu = function (menuModel, lifeData) {

                    menu = [];

                    if (angular.isArray(menuModel)) {
                        menu = NavigationModel.rebuildMenu(menuModel, lifeData);
                    }

                    allFormsCompleted = !menu.some(function(menuItem) {
                        return menuItem.complete === false;
                    });

                };

                this.areAllFormsCompleted = function () {
                    return allFormsCompleted;
                };

                /**
                 *
                 * @returns {Object}
                 */
                this.getCurrentMenuItem = function () {

                    var menuItem = null;

                    var i = 0, ii = menu.length;
                    for (; i < ii; i++) {
                        if (menu[i].current) {
                            menuItem = angular.copy(menu[i]);
                            break;
                        }
                    }

                    return menuItem;

                };

                /**
                 * @param formDefinitionId
                 * @returns {Object|null}
                 */
                this.getMenuItem = function (formDefinitionId) {
                    var foundItem = null;
                    menu.some(function(menuItem) {
                        if (NavigationModel.isFormLink(menuItem) && (menuItem.sequenceKey.formDefinitionId === formDefinitionId)) {
                            foundItem = angular.copy(menuItem);
                            return true;
                        }
                        return false;
                    });
                    return foundItem;
                };

                /**
                 *
                 * @returns {Object|null}
                 */
                this.getFirstMenuItem = function () {
                    var foundItem = null;
                    menu.some(function(menuItem) {
                        if (NavigationModel.isFormLink(menuItem)) {
                            foundItem = angular.copy(menuItem);
                            return true;
                        }
                        return false;
                    });
                    return foundItem;
                };

                /**
                 *
                 * @returns {Object|null}
                 */
                this.getLastMenuItem = function () {

                    var menuItem = null;

                    var i = menu.length - 1;
                    for (; i >= 0; i--) {
                        if (NavigationModel.isFormLink(menu[i])) {
                            menuItem = angular.copy(menu[i]);
                            break;
                        }
                    }

                    return menuItem;

                };

                /**
                 *
                 * @returns {Array}
                 */
                this.getIncompleteItems = function () {

                    var items = [];

                    var i = 0, ii = menu.length;
                    for (; i < ii; i++) {
                        if (NavigationModel.isFormLink(menu[i]) && !menu[i].complete) {
                            items.push(angular.copy(menu[i]));
                        }
                    }

                    return items;

                };

                /**
                 *  @param menuItem
                 * @returns {Boolean}
                 */
                this.getItemIsActiveLink = function (menuItem) {
                    return (MagnumConfig.getOption('layout.menuState') !== 'disabled')
                        && NavigationModel.isFormLink(menuItem)
                        && !menuItem.current;
                };

            }


            /**
             * @method NavigationModel.rebuildMenu
             * @static
             * @description
             * Here we perform two transformations:
             * 1) create one more level of hierarchy by grouping nodes by LifeId
             * 2) flatten tree-like to an Array but add to each menu item an additional property - level
             *
             * @param menuModel {Array}
             * @param lifeData
             *
             * @returns {Array}
             */
            NavigationModel.rebuildMenu = function (menuModel, lifeData) {

                var menuList = [],
                    foundLives = {},
                    menuItemId = 0;

                angular.forEach(menuModel, function (item) {

                    var lifeId = item.lifeId,
                        lifeNode = null,
                        addIndex, subList;

                    item.id = menuItemId++;
                    item.parent = menuList;

                    if (angular.isDefined(lifeId) && (lifeId !== null)) {
                        if (angular.isUndefined(foundLives[lifeId])) {

                            lifeNode = {
                                id: menuItemId++,
                                sequenceKey: null,
                                lifeId: lifeId,
                                name: getLifeDisplayName(lifeId, item.lifeDisplayName),
                                parent: menuList,
                                type: 'LIFE',
                                level: 0,
                                childNodes: []
                            };

                            addIndex = menuList.push(lifeNode);
                            foundLives[lifeId] = lifeNode;
                        }
                        else {
                            lifeNode = foundLives[lifeId];
                            addIndex = findTail(lifeNode) + 1;
                        }
                        item.parent = lifeNode;
                        subList = [];
                        flattenNode(item, subList, 1, lifeNode);
                        menuList.splice.apply(menuList, [addIndex, 0].concat(subList));
                    }
                    else {
                        flattenNode(item, menuList, 0);
                    }
                });

                function flattenNode(node, resultList, level, lifeNode) {

                    node.level = level || 0;
                    node.lifeId = node.lifeId || (lifeNode ? lifeNode.lifeId: null);
                    resultList.push(node);

                    if (angular.isArray(node.childNodes) && (node.childNodes.length > 0)) {
                        angular.forEach(node.childNodes, function (item) {
                            item.parent = lifeNode;
                            flattenNode(item, resultList, node.level + 1, lifeNode);
                        });
                    }

                }

                function findTail(lifeNode) {
                    var tailIndex = menuList.indexOf(lifeNode);
                    var lastIndex = menuList.length - 1;
                    while (((tailIndex + 1) <= lastIndex) && (menuList[tailIndex + 1].lifeId === lifeNode.lifeId)) {
                        tailIndex++;
                    }
                    return tailIndex;
                }

                function getLifeDisplayName(lifeId, valueFromRuntime) {

                    var applicantnameSource = MagnumConfig.getOption('applicantnameSource');
                    var defaultValue = [TranslateService.getById(
                        'FrontEndLabels.LIFE_NAME_PLACEHOLDER'), lifeId].join(' ');
                    var valueFromHostApp = (angular.isObject(
                        lifeData) && (lifeId in lifeData)) ? lifeData[lifeId].displayName : '';
                    var name;

                    switch (applicantnameSource) {
                        case APPLICANT_NAME_SOURCE.RUNTIME:
                            name = valueFromRuntime || defaultValue;
                            break;
                        case APPLICANT_NAME_SOURCE.HOSTAPP:
                            name = valueFromHostApp || defaultValue;
                            break;
                        default:
                    }

                    return name || defaultValue;

                }

                return menuList;

            };

            /**
             * @method NavigationModel.isFormLink
             * @static
             * */
            NavigationModel.isFormLink = function (menuItem) {
                return ([NavigationMenuItemType.LIFE, NavigationMenuItemType.THEME].indexOf(menuItem.type) === -1)
                    && angular.isObject(menuItem.sequenceKey);
            };

            return NavigationModel;

        }]);

angular.module('mxg.navigation.NavigationOverviewLink', [
    'mxg.navigation.NavigationOverviewLinkCtrl'
])
    .directive('mxgNavigationOverviewLink', [
        function () {
            'use strict';
            return {
                templateUrl: 'mxg-template/navigation/NavigationOverviewLink.html',
                scope: true,
                controller: 'mxgNavigationOverviewLinkCtrl',
                controllerAs: 'overviewLinkCtrl'
            };
        }]);

angular.module('mxg.navigation.NavigationOverviewLinkCtrl', [
    'mxg.translation.TranslateService',
    'mxg.activeCase.ActiveCase'
])
    .controller('mxgNavigationOverviewLinkCtrl', [
        'mxgTranslateService', 'mxgActiveCase',
        function (TranslateService, ActiveCase) {
            'use strict';

            var ctrl = this;

            var linkLabel = TranslateService.getById('FrontEndLabels.APPLICATION_COMPLETE_LABEL', null,
                    true) || 'Application Overview';

            ctrl.tabIndex = 1;
            var locked = false;

            ctrl.isLinkDisabled = function () {
                return locked || !ActiveCase.isCaseComplete();
            };

            ctrl.getLinkLabel = function () {
                return linkLabel;
            };

            ctrl.onClick = function (event) {
                event.preventDefault();
                locked = true;
                ActiveCase.completeCaseSafeExit().finally(function () {
                    locked = false;
                });
                return false;
            };

        }]);

angular.module('mxg.resources.CaseResource', [
    'mxg.system.ErrorModel',
    'mxg.resources.RestCall',
    'mxg.rulebase'
])
    .factory('mxgCaseResource', [
        '$q', 'mxgErrorModel', 'mxgRulebaseService', 'mxgRulebaseLanguages', 'mxgRulebaseReferenceData', 'mxgRestCall',
        function ($q, ErrorModel, RulebaseService, RulebaseLanguages, RulebaseReferenceData, RestCall) {
            'use strict';

            function sequenceKeyToString(sequenceKey) {
                return sequenceKey.formDefinitionId + (angular.isDefined(
                    sequenceKey.entityId) ? '-' + sequenceKey.entityId : '');
            }

            function startCase(startCaseModel) {
                var rulebaseUuid = startCaseModel.rulebaseUuid || RulebaseService.getActiveRulebase();
                var language = startCaseModel.language || RulebaseService.getDefaultLanguageCode();
                return ensureRulebaseSpecificDataLoaded(rulebaseUuid, language)
                    .then(function () {
                        return RestCall.performInBackground(
                            'post',
                            'mxg-rest/composite/cases',
                            startCaseModel,
                            {id: 'startCase'});
                    });
            }

            function getCurrentForm(caseId) {
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/composite/cases', caseId, 'forms/current'].join('/'),
                    null,
                    {id: 'getCurrentForm', params: {caseId: caseId}})
                    .then(function (response) {
                        var rulebaseUUID = response.data.rulebaseUuid;
                        var language = angular.isObject(
                            response.data.resultingForm) ? response.data.resultingForm.language : null;
                        return ensureRulebaseSpecificDataLoaded(rulebaseUUID, language)
                            .then(function () {
                                return response;
                            });
                    });
            }

            function saveAndGetFormById(caseId, sequenceKey, formData) {
                var formId = sequenceKeyToString(sequenceKey);
                return RestCall.performInBackground(
                    'post',
                    ['mxg-rest/composite/cases', caseId, 'forms', formId].join('/'),
                    formData,
                    {id: 'saveAndGetFormById', params: {caseId: caseId, formId: formId}});
            }

            function getFormById(caseId, sequenceKey, clearFormValues) {
                var formId = sequenceKeyToString(sequenceKey);
                var params = {
                    clearFormValues: clearFormValues || false,
                    language: sequenceKey.language || null
                };
                var getResponse = null;
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/composite/cases', caseId, 'forms', formId].join('/'),
                    params,
                    {id: 'getFormById', params: {caseId: caseId, formId: formId}})
                    .then(function (response) {
                        getResponse = response;
                        var rulebaseUUID = response.data.rulebaseUuid;
                        var language = angular.isObject(
                            response.data.resultingForm) ? response.data.resultingForm.language : null;
                        return ensureRulebaseSpecificDataLoaded(rulebaseUUID, language);
                    })
                    .then(function () {
                        return getResponse;
                    });
            }

            function saveAndGetPreviousForm(caseId, formData) {
                return RestCall.performInBackground(
                    'post',
                    ['mxg-rest/composite/cases', caseId, 'forms/submit-and-previous'].join('/'),
                    formData,
                    {id: 'saveAndGetPreviousForm', params: {caseId: caseId}});
            }

            function getPreviousForm(caseId) {
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/composite/cases', caseId, 'forms/previous'].join('/'),
                    null,
                    {id: 'getPreviousForm', params: {caseId: caseId}});
            }

            function saveAndGetNextForm(caseId, formData) {
                return RestCall.performInBackground(
                    'post',
                    ['mxg-rest/composite/cases', caseId, 'forms/submit-and-next'].join('/'),
                    formData,
                    {id: 'saveAndGetNextForm', params: {caseId: caseId}});
            }

            function submitBootstrapAndGetNext(caseId, bootstrapData) {
                return RestCall.performInBackground(
                    'post',
                    ['mxg-rest/composite/cases', caseId, 'forms/submit-bootstrap-and-next'].join('/'),
                    bootstrapData,
                    {id: 'submitBootstrapAndGetNext', params: {caseId: caseId}});
            }

            function saveCurrentForm(caseId, formData) {
                return saveAndGetFormById(caseId, formData.sequenceKey, formData);
            }

            function getNextForm(caseId) {
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/composite/cases', caseId, 'forms/next'].join('/'),
                    null,
                    {id: 'getNextForm', params: {caseId: caseId}}
                );
            }

            function partialSubmit(caseId, formData) {
                angular.isObject(formData) && (formData.partialSubmit = true);
                /*submit-and-inline*/
                return RestCall.performInBackground(
                    'post',
                    ['mxg-rest/composite/cases', caseId, 'forms/submit-and-inline'].join('/'),
                    formData,
                    {id: 'partialSubmit', params: {caseId: caseId}});
            }

            function ensureRulebaseSpecificDataLoaded(rulebase, languageCode) {
                if (!rulebase) {
                    return $q.reject(ErrorModel.getErrorHTTPResponse(null, 'rulebase UUID is required'));
                }

                var promisedSequence = {
                    languages: RulebaseLanguages.ensureLoaded(rulebase)
                };

                promisedSequence.referenceData = promisedSequence.languages.then(function () {
                    return RulebaseReferenceData.ensureLoaded(rulebase);
                });

                return $q.all(promisedSequence).then(function () {
                    RulebaseService.setActiveRulebase(rulebase);
                    RulebaseService.setDefaultLanguageCode(RulebaseLanguages.getDefaultLanguageCode(rulebase));
                    if (languageCode) {
                        RulebaseService.setActiveLanguageCode(languageCode);
                    }
                });
            }

            return {
                saveAndGetFormById: saveAndGetFormById,
                getFormById: getFormById,
                saveAndGetPreviousForm: saveAndGetPreviousForm,
                getPreviousForm: getPreviousForm,
                saveAndGetNextForm: saveAndGetNextForm,
                saveCurrentForm: saveCurrentForm,
                saveAndGetCurrentForm: saveCurrentForm,
                getCurrentForm: getCurrentForm,
                getNextForm: getNextForm,
                startCase: startCase,
                ensureRulebaseSpecificDataLoaded: ensureRulebaseSpecificDataLoaded,
                partialSubmit: partialSubmit,
                submitBootstrapAndGetNext: submitBootstrapAndGetNext
            };

        }]
    );


/**
 *
 */
angular.module('mxg.resources.DictionaryResource', [
    'mxg.rulebase.RulebaseService',
    'mxg.resources.RestCall'
])
    .factory('mxgDictionaryResource', [
        'mxgRulebaseService', 'mxgRestCall',
        function (RulebaseService, RestCall) {
            'use strict';

            return {

                getAllPhrases: function dictionaryPhrases(notificationContent) {
                    var rulebaseId = RulebaseService.getActiveRulebase();
                    var params = {
                        language: RulebaseService.getActiveLanguageCode()
                    };
                    notificationContent.referenceDataSubsetUuid && (params.subsetUuid = notificationContent.referenceDataSubsetUuid);

                    return RestCall.performInBackground(
                        'get',
                        ['mxg-rest/rulebases', rulebaseId, 'dictionaries', notificationContent.dictionaryName].join(
                            '/'),
                        params,
                        {
                            id: 'dictionaryGetAllPhrases',
                            params: {rulebaseId: rulebaseId, dictionaryName: notificationContent.dictionaryName}
                        })
                        .then(function (response) {
                            if (angular.isObject(response.data)) {
                                return response.data.phrases || [];
                            }
                            else {
                                return [];
                            }
                        });
                },

                quickMatch: function dictionaryQuickMatch(notificationContent) {
                    var rulebaseId = RulebaseService.getActiveRulebase();
                    return RestCall.performInBackground(
                        'post',
                        ['mxg-rest/rulebases', rulebaseId, 'dictionaries'].join('/'),
                        notificationContent,
                        {id: 'dictionaryQuickMatch', params: {rulebaseId: rulebaseId}})
                        .then(function (response) {
                            return angular.extend({
                                alternatives: [],
                                confirmationStatus: 'NO_INTERACTION',
                                dictionaryState: 'INITIALISED',
                                matchStatus: 'UNRECOGNISED',
                                matchedValue: null,
                                misspellingProposal: null
                            }, response.data);
                        });
                }

            };

        }]);



angular.module('mxg.resources', [
    'mxg.resources.RestCall',
    'mxg.resources.CaseResource',
    'mxg.resources.DictionaryResource',
    'mxg.resources.TranslationResource'
]);


angular.module('mxg.resources.RestCall', [
    'mxg.components.ProcessManager'
])
    .factory('mxgRestCall', [
        '$http', '$q', '$filter', 'mxgProcessManager',
        function ($http, $q, $filter, ProcessManager) {

            function performRestCall(method, query, data, restData) {

                var config = {
                    method: method,
                    url: query,
                    data: {},
                    restData: restData
                };

                if (data) {
                    switch (method) {
                        case 'get':
                            config.params = data;
                            break;
                        default:
                            config.data = data;
                    }
                }

                return $http(config);

            }

            return {
                performGlobally: function () {

                    var request = performRestCall.apply(this, Array.prototype.slice.call(arguments, 0));
                    ProcessManager.run(request);
                    return request;

                },
                performInBackground: function () {

                    var request = performRestCall.apply(this, Array.prototype.slice.call(arguments, 0));
                    ProcessManager.runInGroup('background', request);
                    return request;

                }
            };

        }]);

angular.module('mxg.resources.TranslationResource', ['mxg.resources.RestCall'])
    .factory('mxgTranslationResource',
        ['mxgRestCall', function (RestCall) {
            'use strict';

            var REFERENCE_DATA_TYPES = [
                'ActionControls',
                'UserMessages',
                'FullMonths',
                'ShortMonths',
                'FullWeekDays',
                'ShortWeekDays',
                'FrontEndLabels'].join(',');

            function loadLanguages(rulebaseId) {
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/rulebases', rulebaseId, 'languages'].join('/'),
                    {enabled: true},
                    {id: 'getRulebaseLanguages', params: {rulebaseId: rulebaseId}});
            }

            function loadReferenceData(rulebaseId) {
                return RestCall.performInBackground(
                    'get',
                    ['mxg-rest/rulebases', rulebaseId, 'reference-data'].join('/'),
                    {referenceDataTypes: REFERENCE_DATA_TYPES},
                    {id: 'getRulebaseReferenceData', params: {rulebaseId: rulebaseId}}
                );
            }

            return {
                loadLanguages: loadLanguages,
                loadReferenceData: loadReferenceData
            };

        }]);

angular.module('mxg.rulebase', [
    'mxg.rulebase.RulebaseLanguages',
    'mxg.rulebase.RulebaseReferenceData',
    'mxg.rulebase.RulebaseService'
]);



angular.module('mxg.rulebase.RulebaseLanguages', [
    'mxg.system.ErrorModel',
    'mxg.resources.TranslationResource'
])
    .factory('mxgRulebaseLanguages', [
        '$q', '$cacheFactory', 'mxgErrorModel', 'mxgTranslationResource',
        function ($q, $cacheFactory, ErrorModel, TranslationResource) {
            'use strict';

            var _cache = $cacheFactory('mxgLanguages');

            var service = {};

            service.ensureLoaded = function (rulebase) {

                if (_cache.get(rulebase)) {
                    return $q.when(true);
                }

                return TranslationResource.loadLanguages(rulebase).then(function (response) {
                    if (!validateLanguagesStructure(response.data)) {
                        return $q.reject(ErrorModel.getIncorrectServerResponseError('GET languages'));
                    }
                    service.setLanguages(rulebase, response.data.languageObjects);
                    return true;
                });

            };

            service.getLanguages = function (rulebase) {
                return _cache.get(rulebase) || [];
            };

            service.setLanguages = function (rulebase, languages) {
                _cache.put(rulebase, languages);
            };

            service.getDefaultLanguageCode = function (rulebase) {

                var languages = _cache.get(rulebase);

                if (!languages || !languages.length) {
                    return null;
                }

                var defaultCode = null;

                languages.some(function (item) {
                    if (item.isDefault) {
                        defaultCode = item.code;
                        return true;
                    }
                    else {
                        return false;
                    }
                });

                return defaultCode || languages[0].code;

            };

            function validateLanguagesStructure(data) {
                return angular.isObject(data) &&
                    angular.isArray(data.languageObjects);
            }

            return service;

        }]);

angular.module('mxg.rulebase.RulebaseReferenceData', [
    'mxg.system.ErrorModel',
    'mxg.resources.TranslationResource',
    'mxg.rulebase.RulebaseLanguages',
    'mxg.helpers.RefDataHelper'
])
    .factory('mxgRulebaseReferenceData', [
        '$q', '$cacheFactory', '$parse', '$interpolate', 'mxgErrorModel', 'mxgTranslationResource', 'mxgRulebaseLanguages', 'mxgRefDataHelper',
        function ($q, $cacheFactory, $parse, $interpolate, ErrorModel, TranslationResource, RulebaseLanguages, RefDataHelper) {
            'use strict';

            var _cache = $cacheFactory('mxgReferenceData');

            var service = {};

            service.ensureLoaded = function (rulebase) {
                if (_cache.get(rulebase)) {
                    return $q.when(true);
                }

                return TranslationResource.loadReferenceData(rulebase).then(function (response) {
                    if (!validateReferenceDataStructure(response.data)) {
                        return $q.reject(ErrorModel.getIncorrectServerResponseError('GET reference-data'));
                    }
                    service.setReferenceData(rulebase, response.data.referenceDataTypeObjects);
                    return true;
                });
            };

            service.setReferenceData = function (rulebase, referenceDataTypeObjects) {

                var referenceData = {};

                referenceDataTypeObjects.forEach(function (referenceDataType) {

                    var referenceDataTypeName = referenceDataType.referenceDataTypeName;
                    referenceDataType.referenceDataModels.forEach(function (referenceDataModel) {
                        var fullKey = referenceDataTypeName + '.' + referenceDataModel.code;
                        referenceData[fullKey] = referenceDataModel;
                    });

                });

                _cache.put(rulebase, {
                    referenceDataModels: referenceData,
                    translationsCache: {},
                    globalIdsCache: {}
                });

            };

            service.getTranslation = function (id, interpolateParams, rulebase, languageCode, onlyIfExists) {
                var defaultLanguage = RulebaseLanguages.getDefaultLanguageCode(rulebase);
                var cachedData = _cache.get(rulebase);
                var cachedTranslation;

                if (!cachedData || !cachedData.referenceDataModels[id]) {
                    return onlyIfExists ? '' : id;
                }

                if (!languageCode) {
                    return service.getTranslation(id, interpolateParams, rulebase, defaultLanguage);
                }

                !cachedData.translationsCache[id] && (cachedData.translationsCache[id] = {});

                var params = service.hashObject(interpolateParams);
                cachedTranslation = cachedData.translationsCache[id][languageCode] && cachedData.translationsCache[id][languageCode][params];

                if (!cachedTranslation) {
                    cachedTranslation = RefDataHelper.getTranslation(languageCode, cachedData.referenceDataModels[id]);
                    if (cachedTranslation && interpolateParams) {
                        cachedTranslation = $interpolate(cachedTranslation)(
                            angular.isObject(interpolateParams) ? interpolateParams : $parse(interpolateParams)(this));
                    }
                    !cachedTranslation && (cachedTranslation = service.getTranslation(id, interpolateParams, rulebase,
                        defaultLanguage));
                    !cachedData.translationsCache[id][languageCode] && (cachedData.translationsCache[id][languageCode] = {});
                    cachedData.translationsCache[id][languageCode][params] = cachedTranslation;
                }

                return cachedTranslation;
            };

            service.hashObject = function (object) {
                return object ? JSON.stringify(object)
                    .split("")
                    .reduce(function (prevHash, currVal) {
                        prevHash = ((prevHash << 5) - prevHash) + currVal.charCodeAt(0);
                        return prevHash & prevHash;
                    }, 0) : null;
            };

            service.getIconCode = function (id, rulebase) {
                var cachedData = _cache.get(rulebase);
                var cachedIconCode;

                if (!cachedData || !cachedData.referenceDataModels[id]) {
                    return null;
                }

                !cachedData.globalIdsCache[id] && (cachedData.globalIdsCache[id] = {});

                if ('iconCode' in cachedData.globalIdsCache[id]) {
                    cachedIconCode = cachedData.globalIdsCache[id].iconCode;
                } else {
                    cachedIconCode = RefDataHelper.getIconCode(cachedData.referenceDataModels[id].globalIdModels);
                    cachedData.globalIdsCache[id].iconCode = cachedIconCode;
                }
                return cachedIconCode;

            };

            function validateReferenceDataStructure(data) {
                return angular.isObject(data) &&
                    angular.isArray(data.referenceDataTypeObjects);
            }

            return service;

        }]);

angular.module('mxg.rulebase.RulebaseService', [
    'mxg.magnum.Config'
]).factory('mxgRulebaseService', [
    'MagnumConfig',
    function (Config) {
        "use strict";

        var _rulebase = null;
        var _defaultLanguageCode = null;
        var _languageCode = null;

        var service = {};

        service.getActiveRulebase = function () {
            return _rulebase || Config.getOption('rulebase');
        };

        service.setActiveRulebase = function (rulebase) {
            _rulebase = rulebase;
            return this;
        };

        service.getDefaultLanguageCode = function () {
            return _defaultLanguageCode;
        };

        service.setDefaultLanguageCode = function (languageCode) {
            _defaultLanguageCode = languageCode;
            return this;
        };

        service.getActiveLanguageCode = function () {
            return _languageCode || _defaultLanguageCode;
        };

        service.setActiveLanguageCode = function (languageCode) {
            _languageCode = languageCode;
            return this;
        };

        return service;

    }]);

angular.module('mxg.system.ErrorModel', [
    'mxg.system.RuntimeConstants'
])
    .factory('mxgErrorModel', ['mxgRuntimeConstants', function (RuntimeConstants) {
        'use strict';

        /**
         * @class
         * */
        function ErrorModel(model) {

            var errorData = angular.isArray(model) ? (model.length ? model[0] : null ) : model;

            this._code = null;
            this._message = 'Unknown Error';
            this._stackTrace = null;

            if (!angular.isObject(errorData)) {
                return;
            }

            if (angular.isDefined(errorData.code)) {
                this._code = errorData.code;
            }

            if (angular.isDefined(errorData.message)) {
                this._message = errorData.message;
            }

            if (angular.isDefined(errorData.stackTrace)) {
                this._stackTrace = errorData.stackTrace;
            }

        }

        ErrorModel.prototype.getCode = function () {
            return this._code;
        };

        ErrorModel.prototype.getMessage = function () {
            return this._message;
        };

        ErrorModel.prototype.getStackTrace = function () {
            return this._stackTrace;
        };

        ErrorModel.prototype.toString = function () {

            var code = this.getCode();
            var message = this.getMessage();
            var stack = this.getStackTrace();
            var str = (code === null || code === '') ? message : code + '[' + message + ']';

            if (stack) {
                str += ' [' + stack.substring(0, 100) + '...]';
            }

            return str;

        };

        var service = {};

        service.create = function (model) {
            return new ErrorModel(model);
        };

        service.isErrorHTTPResponse = function (response) {
            return (+response.status >= 400) || !angular.isObject(response.data) || hasErrorCode(response.data);
        };

        service.isFormValidationError = function (data) {
            return angular.isArray(data) && data.some(function (item) {
                    return item.ruleId == '4009';
                });
        };

        service.getErrorHTTPResponse = function (code, message, request) {
            return {
                status: 500,
                data: {
                    code: code,
                    message: message,
                    stackTrace: request || null
                }
            };
        };

        service.getIncorrectServerResponseError = function(request) {
            return service.getErrorHTTPResponse('C0001', 'Invalid Payload Received', request);
        };

        function hasErrorCode(data) {
            return angular.isObject(data) && data.code
                && Object.keys(RuntimeConstants.ErrorCode).some(
                    function (key) {
                        return RuntimeConstants.ErrorCode[key] == data.code;
                    });
        }

        return service;
    }]);

angular.module('mxg.system.Events', [])
    .constant('mxgEvents', {
        FATAL_ERROR: 'mxg:fatal-error',
        EXIT_CASE: 'mxg:case-exit',
        CASE_CREATED: 'mxg:case-created',
        CASE_RESUMED: 'mxg:case-resumed',
        CASE_CHECK_VALID: 'mxg:case-check-valid',
        CASE_CHECK_INVALID: 'mxg:case-check-invalid',
        CASE_FORM_SUBMITTED: 'mxg:case-form-submitted',
        CASE_FORM_CHANGED: 'mxg:case-form-changed',
        CASE_COMPLETE: 'mxg:case-completed',
        CASE_STATUS_CHANGED: 'mxg:case-status-changed',
        QUESTION_VALUE_CHANGED: 'mxg:question-value-changed',
        NAVIGATION_BUTTON: 'mxg:navigation-button',
        NAVIGATION_MENU: 'mxg:navigation-menu',
        NAVIGATION_LANGUAGE_SELECTOR: 'mxg:navigation-language-selector'
    });

angular.module('mxg.system.FatalErrorHandler', [
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.components.DialogService',
    'mxg.magnum.MagnumContainerElement',
    'mxg.helpers.WindowHelper'
])
    .factory('mxgFatalErrorHandler', [
        '$timeout', 'mxgRootScope', 'mxgEvents', 'mxgDialogService', 'MagnumContainerElement', 'mxgWindowHelper',
        function ($timeout, mxgRootScope, mxgEvents, DialogService, MagnumContainerElement, WindowHelper) {
            'use strict';
            var FatalErrorHandler = {};
            FatalErrorHandler.enable = function () {
                mxgRootScope.$on(mxgEvents.FATAL_ERROR, function (event, message, errorModel) {
                    /* Give a chance for any other handlers to prevent showing this error popup */
                    $timeout(function () {
                        if (event.defaultPrevented) {
                            return;
                        }
                        DialogService.alert(errorModel ? errorModel.getMessage() : message);
                        WindowHelper.scrollToElement(MagnumContainerElement.get()[0], 0);
                    }, 10);
                });
            };
            return FatalErrorHandler;
        }]);

angular.module('mxg.system.MessageTypes', [])
    .constant('mxgMessageTypes', {
        ERROR: 'error',
        WARNING: 'warning',
        INFO: 'info'
    });

angular.module('mxg.system.RootScope', [])
    .factory('mxgRootScope', ['$rootScope', function ($rootScope) {
        "use strict";
        var $scope = $rootScope.$new();
        $scope.mxgScope = true;
        return $scope;
    }]);
angular.module('mxg.system.RuntimeConstants', [])
    .constant('mxgRuntimeConstants', {
        ResponseStatus: {
            OK: "OK",
            ERROR: "ERROR",
            VALIDATION: "VALIDATION"
        },
        ErrorCode: {
            DICTIONARY_NOT_READY: '2006',
            INCORRECT_LANGUAGE: '4001',
            FORM_NOT_FOUND: '4003',
            INCOMPLETE_INTERVIEW: '4028',
            INTERNAL_SERVER_ERROR: '4031',
            CASE_NOT_FOUND: '4030',
            NO_BOOTSTRAP_FORMS_AVAILABLE: '4033',
            CURRENT_FORM_NOT_COMPLETED: '4039',
            LAST_FORM: '4040',
            FIRST_FORM: '4041',
            EMPTY_MANDATORY_VALUE: '4045',
            NO_REFERENCE_DATA_TYPE: '4047',
            MISSING_REFERENCE_DATA_TYPE: '4048',
            ALL_FORMS_NOT_COMPLETED: '4049',
            INVALID_REFERENCE_VALUE: '4021',
            VALUE_IS_LESS_THAN: '4023',
            VALUE_IS_GREATER_THAN: '4027',
            VALUE_NOT_WITHIN_RANGE: '4025',
            DECIMAL_INVALID: '4017',
            INTEGER_INVALID: '4018',
            DATE_FORMAT_INVALID: '4024',
            DATE_PARTIAL_INVALID: '4044'
        },
        DateISOFormat: 'yyyy-MM-dd',
        DecimalDefaultSeparator: '.',
        dictionaryState: {
            INITIALISED: 'INITIALISED',
            MISSPELLING: 'MISSPELLING_DETECTED',
            ALTERNATIVES: 'ALTERNATIVES_PROCESSING',
            MATCHED: 'MATCHED'
        },
        confirmationStatus: {
            NO_INTERACTION: 'NO_INTERACTION',
            CONFIRMED: 'CONFIRMED',
            DECLINED: 'DECLINED'
        },
        matchStatus: {
            RECOGNISED: 'RECOGNISED',
            UNRECOGNISED: 'UNRECOGNISED'
        },
        mandatoryValidations: {
            NEXT: 'validateOnNextForm',
            PREVIOUS: 'validateOnPreviousForm',
            SUBMIT: 'validateOnSubmit'
        }
    });

angular.module('mxg.system', [
    'mxg.system.RootScope',
    'mxg.system.FatalErrorHandler',
    'mxg.system.RuntimeConstants',
    'mxg.system.ErrorModel',
    'mxg.system.Events',
    'mxg.system.MessageTypes'
]);

angular.module('mxg.translation.TranslateFilter', [
    'mxg.translation.TranslateService'
])
    .filter('mxgTranslate', ['mxgTranslateService', function (TranslateService) {
        "use strict";

        return function (translationId, interpolateParams) {

            var translation = TranslateService.getById(translationId, interpolateParams);

            return translation || translationId;

        };

    }]);

angular.module('mxg.translation.TranslateService', [
        'mxg.rulebase.RulebaseService',
        'mxg.rulebase.RulebaseReferenceData'
    ])
    .factory('mxgTranslateService', [
        'mxgRulebaseService', 'mxgRulebaseReferenceData',
        function (RulebaseService, RulebaseReferenceData) {

            var service = {};

            service.getById = function (id, interpolateParams, clean) {
                var rulebase = RulebaseService.getActiveRulebase();
                var languageCode = RulebaseService.getActiveLanguageCode();

                return RulebaseReferenceData.getTranslation(id, interpolateParams, rulebase, languageCode, clean);
            };

            service.getByErrorCode = function (errorCode, interpolateParams) {
                return service.getById('UserMessages.' + errorCode, interpolateParams);
            };

            return service;

        }]);


angular.module('mxg.translation', [
    'mxg.translation.TranslateService',
    'mxg.translation.TranslateFilter'
]);

angular.module('mxg.validation.ValidationErrorMap', [])
    .factory('mxgValidationErrorMap', [function () {
        "use strict";
        var errors;

        var service = {};

        service.process = function (validationErrorModels) {
            validationErrorModels.forEach(function (model) {

                model.fieldIds = model.fieldIds || [];
                model.fieldIds.forEach(function (locator) {
                    service.addError(locator, {
                        message: model.message,
                        ruleId: model.ruleId,
                        type: model.type
                    });
                });
                service.addError('global_validation_banner', model);

            });

        };
        /**
         *
         * @param {String} locator
         * @param {{}} error
         * @returns {service}
         */
        service.addError = function (locator, error) {
            errors[locator] = errors[locator] || [];
            errors[locator].push(angular.copy(error));
            return this;
        };

        service.processValidationErrors = function(errors) {
            errors.forEach(function(item) {
               service.addError(item.elementId, item);
               service.addError('global_validation_banner', item);
            });
        };

        /**
         *
         * @param locator
         * @returns {*|null}
         */
        service.find = function (locator) {
            return errors[locator] || null;
        };

        service.exists = function (locator) {
            return !!errors[locator] || false;
        };

        /**
         * Resets errors per locator if passed. Resets all validation errors if locator is not passed or not truthy
         * @param locator
         */
        service.reset = function (locator) {
            if (locator) {
                errors[locator] = null;
            } else {
                errors = {};
            }
        };

        service.reset();
        return service;
    }]);

angular.module('mxg.validation.ValidationType', [])
    .constant('mxgValidationType', {
        MANDATORY: "mandatory",
        INCORRECT: "incorrect",
        ALERT: "alert"
    });

/**
 * !!! IMPORTANT ASSUMPTION / LIMITATION !!!
 * Currently only one format for each part (years, months and days) are supported (case insensitive).
 * In the future some more supporting formats can be added (i.e. "MMM" for short month names).
 * Year (priority=0) is always mandatory, Month (priority=1) is mandatory only if Day is not empty,
 * and Day (priority=2) is always optional.
 *
 * canonicalFormat property added to support case insensitive formats (we don't expect minutes here, so "mm" should always
 * be treated as MM for month value
 * */
angular.module('mxg.components.datePartial.DatePartialFormat', [])
    .constant('mxgDatePartialFormat', {
        VALID_PART_FORMATS: ['YYYY', 'MM', 'DD', 'MMM'],
        VALID_DELIMITERS: [' ', '.', '-', '/', '\\'],
        PARSING_PATTERN: /(y{4}|m{3}|m{2}|d{2}|[ -\\\/])/gi,
        DEFAULT_INPUT_FORMAT: 'yyyy-mm-dd',
        PROPERTIES: {
            YYYY: {
                canonicalFormat: 'yyyy', 
                pattern: /^((19|20)\d\d+)$/i,
                inputMask: '9999',
                priority: 0
            },
            MM: {
                canonicalFormat: 'MM',
                pattern: /^(0[1-9]|1[012]+)$/i,
                inputMask: '99',
                priority: 1
            },
            MMM: {
                canonicalFormat: 'MMM',
                inputMask: '999',
                priority: 1
            },
            DD: {
                canonicalFormat: 'dd',
                pattern: /^(0[1-9]|[12][0-9]|3[01])$/i,
                inputMask: '99',
                priority: 2
            }
        }
    });


angular.module('mxg.components.datePartial.DatePartialModel', [
    'mxg.components.datePartial.DatePartialFormat',
    'mxg.components.datePartial.DatePartModel'
])
    .factory('mxgDatePartialModel',
        ['mxgDatePartialFormat', 'mxgDatePartModel', function (DATE_PARTIAL_FORMAT, DatePartModel) {
            "use strict";

            /**
             * @class DatePartialModel
             * @constructor
             * @param {String} inputFormat
             * */
            function DatePartialModel(inputFormat) {
                /**
                 * @property {String} DatePartialModel#_inputFormat
                 * @private
                 * */
                this._inputFormat = inputFormat || DATE_PARTIAL_FORMAT.DEFAULT_INPUT_FORMAT;

                var parsedFormat = DatePartialModel.parseInputFormat(this._inputFormat);

                /**
                 * @property {Array.<String>} DatePartialModel#_parts
                 * @private
                 * */
                this._parts = parsedFormat.parts || [];
                /**
                 * @property {String} DatePartialModel#_delimiter
                 * @private
                 * */
                this._delimiter = parsedFormat.delimiter || '';

            }

            /**
             * @property {String} DatePartialModel.VALUE_DELIMITER
             * @static
             * @constant
             * */
            DatePartialModel.VALUE_DELIMITER = '-';

            /**
             * @method DatePartialModel.parseInputFormat
             * @description Used for instance initialisation, parse inputFormat and create a DatePartModel for each part
             * @static
             * @param {String} dateFormat
             * @returns {Object}
             * */
            DatePartialModel.parseInputFormat = function (dateFormat) {

                var parts = [];
                var delimiter = DATE_PARTIAL_FORMAT.VALID_DELIMITERS[0];
                var parsed = dateFormat.match(DATE_PARTIAL_FORMAT.PARSING_PATTERN);
                (parsed || []).forEach(function (item) {

                    if (DATE_PARTIAL_FORMAT.VALID_PART_FORMATS.indexOf(item.toUpperCase()) !== -1) {
                        parts.push(new DatePartModel(item));
                    }
                    else if (DATE_PARTIAL_FORMAT.VALID_DELIMITERS.indexOf(item) !== -1) {
                        delimiter = item;
                    }

                });

                /* We always expect a valid inputFormat from Server. But just in case, if we somehow fail to parse anything,
                 * add at least one mandatory part with top priority */
                if (parts.length === 0) {
                    parts[0] = new DatePartModel(getTopPriorityFormat());
                }

                return {
                    parts: parts,
                    delimiter: delimiter
                };

                function getTopPriorityFormat() {

                    var format = null;
                    DATE_PARTIAL_FORMAT.PROPERTIES.some(function (item, key) {
                        if (item.priority === 0) {
                            format = key;
                            return true;
                        }
                        return false;
                    });
                    return format;

                }

            };

            /**
             * @method DatePartialModel.canonizeFormat
             * @static
             * @param {String} dateFormat
             * @returns {String}
             * */
            DatePartialModel.canonizeFormat = function (dateFormat) {
                var parsedFormat = DatePartialModel.parseInputFormat(dateFormat);
                return parsedFormat.parts.map(function (part) {
                    return part.getCanonicalFormat();
                }).join(parsedFormat.delimiter);
            };

            /**
             * @method DatePartialModel#getClassName
             * @returns {String}
             * */
            DatePartialModel.prototype.getClassName = function () {
                return 'DatePartialModel';
            };

            /**
             * @method DatePartialModel#getInputFormat
             * @returns {String}
             * */
            DatePartialModel.prototype.getInputFormat = function () {
                return this._inputFormat;
            };

            /**
             * @method DatePartialModel#getDelimiter
             * @returns {String}
             * */
            DatePartialModel.prototype.getDelimiter = function () {
                return this._delimiter;
            };

            /**
             * @method DatePartialModel#getPart
             * @param {Number} order
             * @returns {DatePartModel}
             * */
            DatePartialModel.prototype.getPart = function (order) {
                return this._parts[order] || null;
            };

            /**
             * @method DatePartialModel#getPartsCount
             * @returns {Number}
             * */
            DatePartialModel.prototype.getPartsCount = function () {
                return this._parts.length;
            };

            /**
             * @method DatePartialModel#getMinFormatPriority
             * @returns {Number}
             * */
            DatePartialModel.prototype.getMinFormatPriority = function () {
                // Using "max" function here because top priority is 0
                return Math.max.apply(this,
                    this._parts.map(function (item) {
                        return item.getPriority();
                    }));
            };

            /**
             * @method DatePartialModel#getMinValuePriority
             * @returns {Number|Null}
             * */
            DatePartialModel.prototype.getMinValuePriority = function () {
                return DatePartialModel.calcMinValuePriority(this.getValue());
            };

            /**
             * @method DatePartialModel#getValue
             * @description Returns value in format "yyyy-MM-dd" where month and day parts are optional
             * @returns {String}
             * */
            DatePartialModel.prototype.getValue = function () {
                return this._parts.reduce(function (reduced, current) {
                    reduced[current.getPriority()] = current.getValue();
                    return reduced;
                }, [])
                    .filter(function (item, index, array) {
                        var last = index === array.length - 1;
                        return (index === 0) || item || (!last && array[index + 1]);
                    })
                    .join(DatePartialModel.VALUE_DELIMITER);
            };

            /**
             * @method DatePartialModel#setValue
             * @description Value should always go in format "yyyy-MM-dd" where Month and Day parts are optional
             * @param {String} value
             * */
            DatePartialModel.prototype.setValue = function (value) {

                var partValues = (value || '').split(DatePartialModel.VALUE_DELIMITER);
                var valuesCount = partValues.length;
                this._parts.forEach(function (item) {
                    var priority = item.getPriority();
                    item.setValue(priority < valuesCount ? partValues[priority] : '');
                });

                return this;

            };

            /**
             * @method DatePartialModel.calcMinValuePriority
             * @static
             * @param {String} value
             * @returns {Number|Null}
             * */
            DatePartialModel.calcMinValuePriority = function (value) {

                var minValuePriority = null;

                value && value.split(DatePartialModel.VALUE_DELIMITER).some(function (item, index) {
                    if (item) {
                        minValuePriority = index;
                        return false;
                    }
                    return true;
                });

                return minValuePriority;

            };

            return DatePartialModel;

        }]);

angular.module('mxg.components.datePartial.DatePartModel', [
    'mxg.components.datePartial.DatePartialFormat'
])
    .factory('mxgDatePartModel', ['mxgDatePartialFormat', function (DATE_PARTIAL_FORMAT) {
        "use strict";

        /**
         * @class DatePartModel
         * @description THe goal of this class is just hold a part's properties and provide possibility to edit parts' values apart
         * format should be one of the valid formats, defined in mxgDatePartialFormat.PROPERTIES (case insensitive)
         * @constructor
         * @param {String} format
         * */
        function DatePartModel(format) {
            this._format = format;
            this._value = '';
            this._formatProperties = DATE_PARTIAL_FORMAT.PROPERTIES[format.toUpperCase()];
        }

        /**
         * @method DatePartModel#getClassName
         * @returns {String}
         * */
        DatePartModel.prototype.getClassName = function () {
            return 'DatePartModel';
        };

        /**
         * @method DatePartModel#getFormat
         * @returns {String}
         * */
        DatePartModel.prototype.getFormat = function () {
            return this._format;
        };

        /**
         * @method DatePartModel#getCanonicalFormat
         * @returns {String}
         * */
        DatePartModel.prototype.getCanonicalFormat = function () {
            return this._formatProperties.canonicalFormat;
        };

        /**
         * @method DatePartModel#getPriority
         * @returns {String}
         * */
        DatePartModel.prototype.getPriority = function () {
            return this._formatProperties.priority;
        };

        /**
         * @method DatePartModel#getInputMask
         * @returns {String}
         * */
        DatePartModel.prototype.getInputMask = function () {
            return this._formatProperties.inputMask;
        };

        /**
         * @method DatePartModel#getValue
         * @returns {String}
         * */
        DatePartModel.prototype.getValue = function () {
            return this._value;
        };

        /**
         * @method DatePartModel#setValue
         * @param {String} value
         * */
        DatePartModel.prototype.setValue = function (value) {
            this._value = value || '';
            return this;
        };

        /**
         * @method DatePartModel#containsValidValue
         * @returns {Boolean}
         * */
        DatePartModel.prototype.containsValidValue = function () {
            return (this._value) ? this._formatProperties.pattern.test(this._value) : false;
        };

        return DatePartModel;

    }]);

angular.module('mxg.components.inputMask.DateFormatMask', [])
    .value('mxgDateFormatMask', {
        'yyyy-MMM-dd': '9999-aaa-99',
        'dd-MMM-yyyy': '99-aaa-9999',
        'dd/MM/yyyy': '99/99/9999',
        'MM/dd/yyyy': '99/99/9999',
        'dd.MM.yyyy': '99.99.9999',
        'yyyy.MM.dd': '9999.99.99',
        'yyyy-MM-dd': '9999-99-99',
        'dd-MM-yyyy': '99-99-9999'
    });

angular.module('mxg.components.inputMask.InputMask', [])
    .directive('mxgInputMask', [function () {
        var deleteButtonsCodes = [8, 46]; // backspace, delete
        return {
            scope: false,
            link: function (scope, element, attrs) {

                var inputMask;
                var match9 = /[0-9]/;
                var matchA = /[a-zA-Z]/;

                var keyupHandler = function (event) {

                    if (!event.charCode || deleteButtonsCodes.indexOf(event.which) !== -1) {
                        return;
                    }

                    var nextChar = String.fromCharCode(event.which);
                    var currentPosition = this.selectionStart;
                    if (['a', '9'].indexOf(inputMask[currentPosition]) === -1 && inputMask[currentPosition] !== undefined) {
                        this.value = this.value + inputMask[currentPosition];
                        scope.$digest();
                    }
                };

                var pasteHandler = function (event) {
                    var clipboardData = event.clipboardData || window.clipboardData;
                    if (!clipboardData) {
                        return;
                    }

                    var value = "";
                    if (event.clipboardData) {
                        value = clipboardData.getData('text/plain').trim();
                    } else {
                        if (window.clipboardData) {
                            value = clipboardData.getData('Text').trim();
                        }
                    }
                    var inputMaskMatcher = "^" + inputMask.replace(/[^a9]/g, '\\$&').replace(/a/g, '[a-zA-Z]').replace(/9/g, '[0-9]') + "$";

                    var inputMaskRegexp = new RegExp(inputMaskMatcher);

                    if (!inputMaskRegexp.test(value)) {
                        event.preventDefault();
                    }

                };
                var keypressHandler = function (event) {
                    if (!event.charCode) {
                        return;
                    }
                    var currentPosition = this.selectionStart;
                    var nextChar = String.fromCharCode(event.which);
                    if (['a', '9'].indexOf(inputMask[currentPosition]) === -1 && inputMask[currentPosition] !== undefined) {
                        if (this.value[currentPosition] !== inputMask[currentPosition]) {
                            this.value = this.value + inputMask[currentPosition];
                        } else {
                            this.selectionStart = this.selectionStart + 1;
                        }
                        currentPosition++;
                        scope.$digest();
                    }
                    if (inputMask[currentPosition] === 'a') {
                        if (!matchA.test(nextChar)) {
                            event.preventDefault();
                        }
                    } else {
                        if (inputMask[currentPosition] === '9') {
                            if (!match9.test(nextChar)) {
                                event.preventDefault();
                            }
                        }
                    }

                    if (inputMask[currentPosition] === undefined) {
                        event.preventDefault();
                    }

                };

                attrs.$observe('mxgInputMask', function (newValue) {
                    "use strict";
                    if (newValue) {
                        inputMask = newValue;
                        element.on('keyup', keyupHandler);
                        element.on('paste', pasteHandler);
                        element.on('keypress', keypressHandler);
                    } else {
                        element.off('keyup', keyupHandler);
                        element.off('paste', pasteHandler);
                        element.off('keypress', keypressHandler);
                    }
                });

                scope.$on('$destroy', function() {
                    "use strict";
                    element.off('keyup', keyupHandler);
                    element.off('paste', pasteHandler);
                    element.off('keypress', keypressHandler);
                });

            }
        }
    }]);

angular.module('mxg.components.datepicker.Datepicker', [
    'mxg.components.datepicker.UiDatepickerController',
    'mxg.components.datepicker.UiDatepicker',
    'mxg.components.datepicker.UiDaypicker',
    'mxg.components.datepicker.UiMonthpicker',
    'mxg.components.datepicker.UiYearpicker',
    'mxg.components.datepicker.UiDatepickerPopup',
    'mxg.components.datepicker.UiDatepickerPopupWrap',
    'mxg.components.datepicker.DatepickerConfig',
    'mxg.components.datepicker.DatepickerPopupConfig'
]);

angular.module('mxg.components.datepicker', [
    'mxg.components.datepicker.Datepicker',
    'mxg.components.datepicker.UiDatepickerController',
    'mxg.components.datepicker.DatepickerLabels'
]);

/**
 * @description
 * NOTE: mode's priority value is related to mxgDatePartialFormat's priority
 * */
angular.module('mxg.components.datepicker.DatepickerConfig', [])
    .constant('mxgDatepickerConfig', {
        formatDay: 'dd',
        formatMonth: 'MMM',
        formatYear: 'yyyy',
        formatDayHeader: 'EEE',
        formatDayTitle: 'MMMM yyyy',
        formatMonthTitle: 'yyyy',
        datepickerMode: 'day',
        minMode: 'day',
        maxMode: 'year',
        showWeeks: false,
        startingDay: 1,
        yearRange: 12,
        minDate: null,
        maxDate: null,
        modes: [
            {
                name: 'day',
                priority: 2
            },
            {
                name: 'month',
                priority: 1
            },
            {
                name: 'year',
                priority: 0
            }
        ]
    });

angular.module('mxg.components.datepicker.DatepickerLabels', [])
    .constant('mxgDatepickerLabels', {
            months: {
                short: {
                    jan: 'ShortMonths.SHORT_JAN',
                    feb: 'ShortMonths.SHORT_FEB',
                    mar: 'ShortMonths.SHORT_MAR',
                    apr: 'ShortMonths.SHORT_APR',
                    may: 'ShortMonths.SHORT_MAY',
                    jun: 'ShortMonths.SHORT_JUN',
                    jul: 'ShortMonths.SHORT_JUL',
                    aug: 'ShortMonths.SHORT_AUG',
                    sep: 'ShortMonths.SHORT_SEP',
                    oct: 'ShortMonths.SHORT_OCT',
                    nov: 'ShortMonths.SHORT_NOV',
                    dec: 'ShortMonths.SHORT_DEC',
                    0: 'ShortMonths.SHORT_JAN',
                    1: 'ShortMonths.SHORT_FEB',
                    2: 'ShortMonths.SHORT_MAR',
                    3: 'ShortMonths.SHORT_APR',
                    4: 'ShortMonths.SHORT_MAY',
                    5: 'ShortMonths.SHORT_JUN',
                    6: 'ShortMonths.SHORT_JUL',
                    7: 'ShortMonths.SHORT_AUG',
                    8: 'ShortMonths.SHORT_SEP',
                    9: 'ShortMonths.SHORT_OCT',
                    10: 'ShortMonths.SHORT_NOV',
                    11: 'ShortMonths.SHORT_DEC'
                },
                full: {

                    jan: 'FullMonths.FULL_JAN',
                    feb: 'FullMonths.FULL_FEB',
                    mar: 'FullMonths.FULL_MAR',
                    apr: 'FullMonths.FULL_APR',
                    may: 'FullMonths.FULL_MAY',
                    jun: 'FullMonths.FULL_JUN',
                    jul: 'FullMonths.FULL_JUL',
                    aug: 'FullMonths.FULL_AUG',
                    sep: 'FullMonths.FULL_SEP',
                    oct: 'FullMonths.FULL_OCT',
                    nov: 'FullMonths.FULL_NOV',
                    dec: 'FullMonths.FULL_DEC',
                    0: 'FullMonths.FULL_JAN',
                    1: 'FullMonths.FULL_FEB',
                    2: 'FullMonths.FULL_MAR',
                    3: 'FullMonths.FULL_APR',
                    4: 'FullMonths.FULL_MAY',
                    5: 'FullMonths.FULL_JUN',
                    6: 'FullMonths.FULL_JUL',
                    7: 'FullMonths.FULL_AUG',
                    8: 'FullMonths.FULL_SEP',
                    9: 'FullMonths.FULL_OCT',
                    10: 'FullMonths.FULL_NOV',
                    11: 'FullMonths.FULL_DEC'
                }
            },
            days: {
                short: {
                    MON: "ShortWeekDays.SHORT_MON",
                    TUE: "ShortWeekDays.SHORT_TUE",
                    WED: "ShortWeekDays.SHORT_WED",
                    THU: "ShortWeekDays.SHORT_THU",
                    FRI: "ShortWeekDays.SHORT_FRI",
                    SAT: "ShortWeekDays.SHORT_SAT",
                    SUN: "ShortWeekDays.SHORT_SUN",
                    0: "ShortWeekDays.SHORT_SUN",
                    7: "ShortWeekDays.SHORT_SUN",
                    1: "ShortWeekDays.SHORT_MON",
                    2: "ShortWeekDays.SHORT_TUE",
                    3: "ShortWeekDays.SHORT_WED",
                    4: "ShortWeekDays.SHORT_THU",
                    5: "ShortWeekDays.SHORT_FRI",
                    6: "ShortWeekDays.SHORT_SAT"
                },
                full: {
                    MON: "FullWeekDays.FULL_MON",
                    TUE: "FullWeekDays.FULL_TUE",
                    WED: "FullWeekDays.FULL_WED",
                    THU: "FullWeekDays.FULL_THU",
                    FRI: "FullWeekDays.FULL_FRI",
                    SAT: "FullWeekDays.FULL_SAT",
                    SUN: "FullWeekDays.FULL_SUN",
                    0: "FullWeekDays.FULL_SUN",
                    7: "FullWeekDays.FULL_SUN",
                    1: "FullWeekDays.FULL_MON",
                    2: "FullWeekDays.FULL_TUE",
                    3: "FullWeekDays.FULL_WED",
                    4: "FullWeekDays.FULL_THU",
                    5: "FullWeekDays.FULL_FRI",
                    6: "FullWeekDays.FULL_SAT"
                }
            }

        });

angular.module('mxg.components.datepicker.DatepickerPopupConfig', [])
    .constant('mxgDatepickerPopupConfig', {
        datepickerPopup: 'yyyy-MM-dd',
        currentText: 'Today',
        clearText: 'Clear',
        closeText: 'Done',
        closeOnDateSelection: true,
        appendToBody: false,
        showButtonBar: false
    });
angular.module('mxg.components.datepicker.UiDatepicker', ['mxg.components.datepicker.UiDatepickerController'])
    .directive('mxgUiDatepicker', [function () {
        "use strict";
        
        return {
            restrict: 'EA',
            replace: true,
            templateUrl: 'mxg-template/components/datepicker/datepicker.html',
            scope: {
                datepickerMode: '=?',
                dateDisabled: '&',
                onChange: '&'
            },
            require: ['mxgUiDatepicker', '?^ngModel', '?^mxgWidgetDatepickerPartial'],
            controller: 'mxgUiDatepickerController',
            link: function ($scope, $element, $attrs, ctrls) {
                
                
                var datepickerCtrl = ctrls[0], ngModelCtrl = ctrls[1], datepicker = ctrls[2];
                if (ngModelCtrl) {
                    datepickerCtrl.init(ngModelCtrl, datepicker || null);
                }

                /**
                 * This method is called when user clicks on a date in any mode
                 * @param date
                 */
                $scope.select = function (date) {
                    var mode = $scope.datepickerMode;
                    datepickerCtrl.select(date);
                    $scope.onChange({mode: mode, value: date});
                };

            }
        };
    }]);

angular.module('mxg.components.datepicker.UiDatepickerController', [
    'mxg.helpers.DateHelper',
    'mxg.components.datepicker.DatepickerConfig'
])
    .controller('mxgUiDatepickerController', [
        '$scope', '$attrs', '$parse', '$interpolate', '$timeout', '$log', 'dateFilter', 'mxgDateHelper', 'mxgDatepickerConfig',
        function ($scope, $attrs, $parse, $interpolate, $timeout, $log, dateFilter, DateHelper, DatepickerConfig) {
            'use strict';

            var self = this,
                ngModelCtrl = {$setViewValue: angular.noop}; // nullModelCtrl;
            var parent;

            // Modes chain
            this.modes = DatepickerConfig.modes.map(function(item) {
                return item.name;
            });

            // Configuration attributes
            angular.forEach(
                ['formatDay', 'formatMonth', 'formatYear', 'formatDayHeader', 'formatDayTitle', 'formatMonthTitle',
                 'minMode', 'maxMode', 'showWeeks', 'startingDay', 'yearRange'], function (key, index) {
                    self[key] = angular.isDefined($attrs[key]) ? (index < 8 ? $interpolate($attrs[key])(
                        $scope.$parent) : $scope.$parent.$eval($attrs[key])) : DatepickerConfig[key];
                });

            // Watchable date attributes
            angular.forEach(['minDate', 'maxDate'], function (key) {
                if ($attrs[key]) {
                    $scope.$parent.$watch($parse($attrs[key]), function (value) {
                        self[key] = createDate(value);
                        self.refreshView();
                    });
                } else {
                    self[key] = createDate(DatepickerConfig[key]);
                }
            });

            $scope.datepickerMode = $scope.lastPickedMode = $scope.datepickerMode || DatepickerConfig.datepickerMode;
            $scope.uniqueId = 'datepicker-' + $scope.$id + '-' + Math.floor(Math.random() * 10000);

            /**
             * This is where init date is initialised
             */
            $attrs.$observe('initDate', function (initDate) {
                self.activeDate = angular.isDefined(initDate) ? $scope.$parent.$eval(initDate) : new Date();
                self.activeDate = angular.isDate(self.activeDate) ? self.activeDate : new Date();
            });

            /**
             *
             * @param dateObject
             * @returns {boolean}
             */
            $scope.isActive = function (dateObject) {
                if (self.compare(dateObject.date,
                        self.activeDate) === 0 && $scope.lastPickedMode === $scope.datepickerMode) {
                    $scope.activeDateId = dateObject.uid;
                    return true;
                }
                return false;
            };

            $scope.isSelected = function (dateObject) {
                return dateObject.selected && (self.modes.indexOf($scope.lastPickedMode) <= self.modes.indexOf(
                        $scope.datepickerMode));
            };

            this.notifyParent = function (datepickerMode, date) {
                if (parent && parent.selectDate) {
                    parent.selectDate(datepickerMode, date);
                }
            };

            $scope.isDisabled = function (date) {
                return self.isDisabled(date);
            };

            self.select = function (date) {
                self.notifyParent($scope.datepickerMode, date);
                self.activeDate = date;
                $scope.lastPickedMode = $scope.datepickerMode;

                if ($scope.datepickerMode === self.minMode) {
                    var dt = ngModelCtrl.$modelValue ? createDate(ngModelCtrl.$modelValue) : new Date(0, 0, 0, 12, 0, 0, 0);
                    dt.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
                    // sets value of ng-model; pretty much equal to $scope.model = dt
                    ngModelCtrl.$setViewValue(dt);
                    ngModelCtrl.$render();
                } else {
                    $scope.toggleMode(-1);
                }
            };

            $scope.move = function (direction) {
                var year = self.activeDate.getFullYear() + direction * (self.step.years || 0),
                    month = self.activeDate.getMonth() + direction * (self.step.months || 0);
                self.activeDate.setFullYear(year, month, 1);
                self.refreshView();
            };

            $scope.toggleMode = function (direction) {
                direction = direction || 1;
                if (($scope.datepickerMode === self.maxMode && direction === 1) || ($scope.datepickerMode === self.minMode && direction === -1)) {
                    return;
                }
                $scope.datepickerMode = self.modes[self.modes.indexOf($scope.datepickerMode) + direction];
            };

            // Key event mapper
            $scope.keys = {
                13: 'enter',
                32: 'space',
                33: 'pageup',
                34: 'pagedown',
                35: 'end',
                36: 'home',
                37: 'left',
                38: 'up',
                39: 'right',
                40: 'down'
            };

            this.init = function (ngModelCtrl_, parent_) {
                ngModelCtrl = ngModelCtrl_;
                parent = parent_;
                ngModelCtrl.$render = function () {
                    self.render();
                };
            };

            this.render = function () {
                if (ngModelCtrl.$modelValue) {
                    var date = createDate(ngModelCtrl.$modelValue),
                        isValid = !isNaN(date);

                    if (isValid) {
                        this.activeDate = date;
                    } else {
                        $log.error(
                            'Datepicker directive: "ng-model" value must be a Date object, a number of milliseconds since 01.01.1970 or a string representing an RFC2822 or ISO 8601 date.');
                    }
                    ngModelCtrl.$setValidity('date', isValid);
                }
                this.refreshView();
            };

            this.refreshView = function () {
                if (this.element) {
                    this._refreshView();
                    var date = createDate(ngModelCtrl.$modelValue);
                    ngModelCtrl.$setValidity('date-disabled', !date || (this.element && !this.isDisabled(date)));
                }
            };

            this.createDateObject = function (date, format) {
                var model = createDate(ngModelCtrl.$modelValue);
                var disabled = this.isDisabled(date);
                return {
                    date: date,
                    label: dateFilter(date, format),
                    selected: model && !disabled && (this.compare(date, model) === 0),
                    disabled: disabled,
                    current: this.compare(date, new Date()) === 0
                };
            };

            this.isDisabled = function (date) {
                return ((this.minDate && this.compare(date, this.minDate) < 0) || (this.maxDate && this.compare(date,
                    this.maxDate) > 0) || ($attrs.dateDisabled && $scope.dateDisabled(
                    {date: date, mode: $scope.datepickerMode})));
            };

            // Split array into smaller arrays
            this.split = function (arr, size) {
                var arrays = [];
                while (arr.length > 0) {
                    arrays.push(arr.splice(0, size));
                }
                return arrays;
            };

            var focusElement = function () {
                $timeout(function () {
                    self.element[0].focus();
                }, 0, false);
            };

            // Listen for focus requests from popup directive
            $scope.$on('datepicker.focus', focusElement);

            $scope.keydown = function (evt) {
                var key = $scope.keys[evt.which];

                if (!key || evt.shiftKey || evt.altKey) {
                    return;
                }

                evt.preventDefault();
                evt.stopPropagation();

                if (key === 'enter' || key === 'space') {
                    if (self.isDisabled(self.activeDate)) {
                        return; // do nothing
                    }
                    $scope.select(self.activeDate);
                    focusElement();
                } else if (evt.ctrlKey && (key === 'up' || key === 'down')) {
                    $scope.toggleMode(key === 'up' ? 1 : -1);
                    focusElement();
                } else {
                    self.handleKeyDown(key, evt);
                    self.refreshView();
                }
            };

            function createDate(value) {
                if (!value) {
                    return null;
                }
                if (angular.isString(value)) {
                    return DateHelper.createDateInLocalTimezone(value);
                }
                return new Date(value);
            }

        }]);

angular.module('mxg.components.datepicker.UiDatepickerPopup', [
    'mxg.magnum.MagnumContainerElement',
    'mxg.helpers.DateHelper',
    'mxg.helpers.PositionHelper'
])
    .directive('mxgUiDatepickerPopup', [
        '$compile', '$parse', '$document', '$timeout', 'MagnumContainerElement', 'mxgPositionHelper', 'dateFilter', 'mxgDateHelper', 'mxgDatepickerPopupConfig',
        function ($compile, $parse, $document, $timeout, MagnumContainerElement, PositionHelper, dateFilter, DateHelper, datepickerPopupConfig) {
            return {
                restrict: 'EA',
                require: 'ngModel',
                scope: {
                    isOpen: '=?',
                    isPartial: '=?',
                    currentText: '@',
                    clearText: '@',
                    closeText: '@',
                    dateDisabled: '&',
                    model: '=ngModel',
                    onSelect: '&',
                    onChange: '&'
                },
                link: function (scope, element, attrs, ngModel) {
                    "use strict";

                    var dateFormat,
                        closeOnDateSelection = angular.isDefined(attrs.closeOnDateSelection) ? scope.$parent.$eval(
                            attrs.closeOnDateSelection) : datepickerPopupConfig.closeOnDateSelection,
                        appendToBody = angular.isDefined(attrs.datepickerAppendToBody) ? scope.$parent.$eval(
                            attrs.datepickerAppendToBody) : datepickerPopupConfig.appendToBody;

                    scope.showButtonBar = angular.isDefined(attrs.showButtonBar) ? scope.$parent.$eval(
                        attrs.showButtonBar) : datepickerPopupConfig.showButtonBar;

                    scope.isPartial = !!scope.isPartial || false;

                    scope.getText = function (key) {
                        return scope[key + 'Text'] || datepickerPopupConfig[key + 'Text'];
                    };

                    attrs.$observe('mxgUiDatepickerPopup', function (value) {
                        dateFormat = value || datepickerPopupConfig.datepickerPopup;
                        ngModel.$render();
                    });

                    // popup element used to display calendar
                    var popupEl = angular.element(
                        '<div mxg-ui-datepicker-popup-wrap><div mxg-ui-datepicker on-change="onValueChange(mode, value)"></div></div>');
                    popupEl.attr({
                        'ng-model': 'model',
                        'ng-change': 'dateSelection()'
                    });

                    function cameltoDash(string) {
                        return string.replace(/([A-Z])/g, function ($1) {
                            return '-' + $1.toLowerCase();
                        });
                    }

                    // datepicker element
                    var datepickerEl = angular.element(popupEl.children()[0]);
                    if (attrs.datepickerOptions) {
                        angular.forEach(scope.$parent.$eval(attrs.datepickerOptions), function (value, option) {
                            datepickerEl.attr(cameltoDash(option), value);
                        });
                    }

                    scope.watchData = {};
                    angular.forEach(['minDate', 'maxDate', 'datepickerMode', 'initDate'], function (key) {
                        if (attrs[key]) {
                            var getAttribute = $parse(attrs[key]);
                            scope.$parent.$watch(getAttribute, function (value) {
                                scope.watchData[key] = value;
                            });
                            datepickerEl.attr(cameltoDash(key), 'watchData.' + key);

                            // Propagate changes from datepicker to outside
                            if (key === 'datepickerMode') {
                                var setAttribute = getAttribute.assign;
                                scope.$watch('watchData.' + key, function (value, oldvalue) {
                                    if (value !== oldvalue) {
                                        setAttribute(scope.$parent, value);
                                    }
                                });
                            }
                        }
                    });
                    if (attrs.dateDisabled) {
                        datepickerEl.attr('date-disabled', 'dateDisabled({ date: date, mode: mode })');
                    }

                    function parseDate(viewValue) {
                        if (!viewValue) {
                            ngModel.$setValidity('date', true);
                            return null;
                        } else if (angular.isDate(viewValue) && !isNaN(viewValue)) {
                            ngModel.$setValidity('date', true);
                            return viewValue;
                        } else if (angular.isString(viewValue)) {
                            var date = DateHelper.parseDate(viewValue, dateFormat) || new Date(viewValue);
                            if (isNaN(date)) {
                                ngModel.$setValidity('date', false);
                                return undefined;
                            } else {
                                ngModel.$setValidity('date', true);
                                return date;
                            }
                        } else {
                            ngModel.$setValidity('date', false);
                            return undefined;
                        }
                    }

                    ngModel.$parsers.unshift(parseDate);

                    // Inner change
                    scope.dateSelection = function () {

                        ngModel.$setViewValue(scope.model);
                        ngModel.$render();

                        if (closeOnDateSelection) {
                            scope.isOpen = false;
                            element[0].focus();
                        }
                        scope.onSelect();
                    };

                    scope.onValueChange = function (mode, value) {
                        scope.onChange({mode: mode, value: value});
                    };

                    element.bind('input change keyup', function (event) {
                        $timeout(function () {
                            scope.date = ngModel.$modelValue;
                        });
                    });

                    // Outter change
                    ngModel.$render = function () {
                        var date = ngModel.$modelValue ? dateFilter(ngModel.$modelValue, dateFormat) : '';
                        element.val(date);
                        scope.date = parseDate(ngModel.$modelValue);
                    };

                    var documentClickBind = function (event) {
                        if (scope.isOpen && event.target !== element[0]) {
                            scope.$apply(function () {
                                scope.isOpen = false;
                            });
                        }
                    };

                    var keydown = function (evt, noApply) {
                        scope.keydown(evt);
                    };
                    element.bind('keydown', keydown);

                    scope.keydown = function (evt) {
                        if (evt.which === 27) {
                            evt.preventDefault();
                            evt.stopPropagation();
                            scope.close();
                        } else if (evt.which === 40 && !scope.isOpen) {
                            scope.isOpen = true;
                        }
                    };

                    var $popup;

                    scope.$watch('isOpen', function (value) {
                        if (value) {

                            if (!$popup) {
                                $popup = $compile(popupEl)(scope);
                                // Prevent jQuery cache memory leak (template is now redundant after linking)
                                popupEl.remove();

                                if (appendToBody) {
                                    $document.find('body').append($popup);
                                } else {
                                    element.after($popup);
                                }
                            }

                            scope.$broadcast('datepicker.focus');
                            scope.position = appendToBody ? PositionHelper.offset(
                                element) : PositionHelper.position(element);
                            scope.position.top = scope.position.top + element.prop('offsetHeight');

                            var magnumContainer = MagnumContainerElement.get();

                            if (magnumContainer && PositionHelper.visible(magnumContainer)) {
                                var parent = element.parent();

                                var magnumPosition = PositionHelper.offset(magnumContainer);
                                var elementHeight = PositionHelper.height(popupEl);

                                scope.bottom = elementHeight > magnumPosition.top + magnumPosition.height - PositionHelper.offset(
                                        parent).top - PositionHelper.height(parent);
                            } else {
                                scope.bottom = false;
                            }

                            $document.bind('click', documentClickBind);
                        } else {
                            $document.unbind('click', documentClickBind);
                        }
                    });

                    scope.select = function (date) {
                        if (date === 'today') {
                            var today = new Date();
                            if (angular.isDate(ngModel.$modelValue)) {
                                date = new Date(ngModel.$modelValue);
                                date.setFullYear(today.getFullYear(), today.getMonth(), today.getDate());
                            } else {
                                date = new Date(today.setHours(12, 0, 0, 0));
                            }
                        }
                        scope.dateSelection(date);
                    };

                    scope.close = function () {
                        scope.isOpen = false;
                        element[0].focus();
                    };

                    scope.$on('$destroy', function () {
                        $popup && $popup.remove();
                        element.unbind('keydown', keydown);
                        $document.unbind('click', documentClickBind);
                    });
                }
            };
        }]);

angular.module('mxg.components.datepicker.UiDatepickerPopupWrap', [])
    .directive('mxgUiDatepickerPopupWrap', function () {
        return {
            restrict: 'EA',
            replace: true,
            transclude: true,
            templateUrl: 'mxg-template/components/datepicker/popup.html',
            link: function (scope, element, attrs) {
                element.bind('click', function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                });
            }
        };
    });
angular.module('mxg.components.datepicker.UiDaypicker', ['mxg.components.datepicker.DatepickerLabels'])

    .directive('mxgUiDaypicker', ['dateFilter', 'mxgDatepickerLabels', function (dateFilter, DatepickerLabels) {
        return {
            restrict: 'EA',
            replace: true,
            templateUrl: 'mxg-template/components/datepicker/UiDaypicker.html',
            require: '^mxgUiDatepicker',
            link: function (scope, element, attrs, ctrl) {
                scope.showWeeks = ctrl.showWeeks;

                ctrl.step = {months: 1};
                ctrl.element = element;

                var DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

                function getDaysInMonth(year, month) {
                    return ((month === 1) && (year % 4 === 0) && ((year % 100 !== 0) || (year % 400 === 0))) ? 29 : DAYS_IN_MONTH[month];
                }

                function getDates(startDate, n) {
                    var dates = new Array(n), current = new Date(startDate), i = 0;
                    current.setHours(12); // Prevent repeated dates because of timezone bug
                    while (i < n) {
                        dates[i++] = new Date(current);
                        current.setDate(current.getDate() + 1);
                    }
                    return dates;
                }

                ctrl._refreshView = function () {
                    var year = ctrl.activeDate.getFullYear(),
                        month = ctrl.activeDate.getMonth(),
                        firstDayOfMonth = new Date(year, month, 1),
                        difference = ctrl.startingDay - firstDayOfMonth.getDay(),
                        numDisplayedFromPreviousMonth = (difference > 0) ? 7 - difference : -difference,
                        firstDate = new Date(firstDayOfMonth);

                    if (numDisplayedFromPreviousMonth > 0) {
                        firstDate.setDate(-numDisplayedFromPreviousMonth + 1);
                    }

                    // 42 is the number of days on a six-week calendar
                    var days = getDates(firstDate, 42);
                    for (var i = 0; i < 42; i++) {
                        days[i] = angular.extend(ctrl.createDateObject(days[i], ctrl.formatDay), {
                            secondary: days[i].getMonth() !== month,
                            uid: scope.uniqueId + '-' + i
                        });
                    }

                    scope.labels = new Array(7);
                    for (var j = 1; j <= 7; j++) {
                        scope.labels[j - 1] = {
                            abbr: DatepickerLabels.days.short[j],
                            full: DatepickerLabels.days.full[j]
                        };
                    }

                    //scope.title = dateFilter(ctrl.activeDate, ctrl.formatDayTitle);
                    scope.titleMonth = DatepickerLabels.months.full[ctrl.activeDate.getMonth()];
                    scope.titleYear = ctrl.activeDate.getFullYear();
                    scope.rows = ctrl.split(days, 7);

                    if (scope.showWeeks) {
                        scope.weekNumbers = [];
                        var weekNumber = getISO8601WeekNumber(scope.rows[0][0].date),
                            numWeeks = scope.rows.length;
                        while (scope.weekNumbers.push(weekNumber++) < numWeeks) {
                        }
                    }
                };

                ctrl.compare = function (date1, date2) {
                    return (new Date(date1.getFullYear(), date1.getMonth(), date1.getDate()) - new Date(date2.getFullYear(), date2.getMonth(), date2.getDate()) );
                };

                function getISO8601WeekNumber(date) {
                    var checkDate = new Date(date);
                    checkDate.setDate(checkDate.getDate() + 4 - (checkDate.getDay() || 7)); // Thursday
                    var time = checkDate.getTime();
                    checkDate.setMonth(0); // Compare with Jan 1
                    checkDate.setDate(1);
                    return Math.floor(Math.round((time - checkDate) / 86400000) / 7) + 1;
                }

                ctrl.handleKeyDown = function (key, evt) {
                    var date = ctrl.activeDate.getDate();

                    if (key === 'left') {
                        date = date - 1;   // up
                    } else if (key === 'up') {
                        date = date - 7;   // down
                    } else if (key === 'right') {
                        date = date + 1;   // down
                    } else if (key === 'down') {
                        date = date + 7;
                    } else if (key === 'pageup' || key === 'pagedown') {
                        var month = ctrl.activeDate.getMonth() + (key === 'pageup' ? -1 : 1);
                        ctrl.activeDate.setMonth(month, 1);
                        date = Math.min(getDaysInMonth(ctrl.activeDate.getFullYear(), ctrl.activeDate.getMonth()), date);
                    } else if (key === 'home') {
                        date = 1;
                    } else if (key === 'end') {
                        date = getDaysInMonth(ctrl.activeDate.getFullYear(), ctrl.activeDate.getMonth());
                    }
                    ctrl.activeDate.setDate(date);
                };

                ctrl.refreshView();
            }
        };
    }]);

angular.module('mxg.components.datepicker.UiMonthpicker', ['mxg.components.datepicker.DatepickerLabels'])
    .directive('mxgUiMonthpicker', ['dateFilter', 'mxgDatepickerLabels', function (dateFilter, DatepickerLabels) {
        return {
            restrict: 'EA',
            replace: true,
            templateUrl: 'mxg-template/components/datepicker/UiMonthpicker.html',
            require: '^mxgUiDatepicker',
            link: function (scope, element, attrs, DatepickerCtrl) {
                DatepickerCtrl.step = {
                    years: 1
                };
                DatepickerCtrl.element = element;

                DatepickerCtrl._refreshView = function () {
                    var months = new Array(12),
                        year = DatepickerCtrl.activeDate.getFullYear();

                    for (var i = 0; i < 12; i++) {
                        months[i] = angular.extend(DatepickerCtrl.createDateObject(new Date(year, i, 1), DatepickerCtrl.formatMonth), {
                            uid: scope.uniqueId + '-' + i,
                            label : DatepickerLabels.months.short[i]
                        });
                    }

                    scope.title = dateFilter(DatepickerCtrl.activeDate, DatepickerCtrl.formatMonthTitle);
                    scope.rows = DatepickerCtrl.split(months, 3);
                };

                DatepickerCtrl.compare = function (date1, date2) {
                    return new Date(date1.getFullYear(), date1.getMonth()) - new Date(date2.getFullYear(), date2.getMonth());
                };

                DatepickerCtrl.handleKeyDown = function (key, evt) {
                    var date = DatepickerCtrl.activeDate.getMonth();

                    if (key === 'left') {
                        date = date - 1;   // up
                    } else if (key === 'up') {
                        date = date - 3;   // down
                    } else if (key === 'right') {
                        date = date + 1;   // down
                    } else if (key === 'down') {
                        date = date + 3;
                    } else if (key === 'pageup' || key === 'pagedown') {
                        var year = DatepickerCtrl.activeDate.getFullYear() + (key === 'pageup' ? -1 : 1);
                        DatepickerCtrl.activeDate.setFullYear(year);
                    } else if (key === 'home') {
                        date = 0;
                    } else if (key === 'end') {
                        date = 11;
                    }
                    DatepickerCtrl.activeDate.setMonth(date);
                };

                DatepickerCtrl.refreshView();
            }
        };
    }])
angular.module('mxg.components.datepicker.UiYearpicker', [])
    .directive('mxgUiYearpicker', ['dateFilter', function (dateFilter) {
        return {
            restrict: 'EA',
            replace: true,
            templateUrl: 'mxg-template/components/datepicker/UiYearpicker.html',
            require: '^mxgUiDatepicker',
            link: function (scope, element, attrs, ctrl) {
                var range = ctrl.yearRange;

                ctrl.step = { years: range };
                ctrl.element = element;

                function getStartingYear(year) {
                    return parseInt((year - 1) / range, 10) * range + 1;
                }

                ctrl._refreshView = function () {
                    var years = new Array(range);

                    for (var i = 0, start = getStartingYear(ctrl.activeDate.getFullYear()); i < range; i++) {
                        years[i] = angular.extend(ctrl.createDateObject(new Date(start + i, 0, 1), ctrl.formatYear), {
                            uid: scope.uniqueId + '-' + i
                        });
                    }

                    scope.title = [years[0].label, years[range - 1].label].join(' - ');
                    scope.rows = ctrl.split(years, 4);
                };

                ctrl.compare = function (date1, date2) {
                    return date1.getFullYear() - date2.getFullYear();
                };

                ctrl.handleKeyDown = function (key, evt) {
                    var date = ctrl.activeDate.getFullYear();

                    if (key === 'left') {
                        date = date - 1;   // up
                    } else if (key === 'up') {
                        date = date - 5;   // down
                    } else if (key === 'right') {
                        date = date + 1;   // down
                    } else if (key === 'down') {
                        date = date + 5;
                    } else if (key === 'pageup' || key === 'pagedown') {
                        date += (key === 'pageup' ? -1 : 1) * ctrl.step.years;
                    } else if (key === 'home') {
                        date = getStartingYear(ctrl.activeDate.getFullYear());
                    } else if (key === 'end') {
                        date = getStartingYear(ctrl.activeDate.getFullYear()) + range - 1;
                    }
                    ctrl.activeDate.setFullYear(date);
                };

                ctrl.refreshView();
            }
        };
    }])
angular.module('mxg.components.noUiSlider.noUiSlider', [
    'mxg.components.noUiSlider.options',
    'mxg.components.noUiSlider.scope'
])
    .directive('noUiSlider', [
        '$timeout', 'noUiSliderOptions', 'noUiSliderScope',
        function ($timeout, SliderOptions, SliderScope) {
            "use strict";

            return {
                restrict: 'AE',
                require: 'ngModel',
                template: '<div class="nouislider_target"></div>',
                scope: {
                    orientation: '@',
                    min: '@',
                    max: '@',
                    step: '@',
                    pips: '='
                },
                link: function nouisliderLink($scope, $element, $attrs, ngModel) {

                    var targetElement = angular.element($element[0].querySelector('.nouislider_target'));

                    var options = {
                        start: 0,
                        connect: 'lower',
                        orientation: $scope.orientation || 'horizontal',
                        range: {
                            min: parseInt($scope.min) || 0,
                            max: parseInt($scope.max) || 100
                        },
                        step: parseInt($scope.step) || 1
                    };

                    if (!ngModel.$isEmpty(ngModel.$modelValue)) {
                        options.start = ngModel.$modelValue || 0;
                    }
                    else {
                        options.start = parseInt($scope.min) || 0;
                    }

                    if ($scope.orientation === 'vertical') {
                        options.direction = 'rtl';
                    }

                    var slider = SliderScope(
                        targetElement,
                        options,
                        $scope.pips || null
                    );

                    targetElement.on('slide', function () {
                        var values = slider.vGet();
                        ngModel.$setViewValue(parseInt(values[0]));
                    });

                    ngModel.$render = function () {
                        if (!ngModel.$isEmpty(ngModel.$modelValue)) {
                            slider.vSet(ngModel.$modelValue);
                        }
                    };
                }
            };

        }]);


angular.module('mxg.components.noUiSlider', [
    'mxg.components.noUiSlider.helpers',
    'mxg.components.noUiSlider.constants',
    'mxg.components.noUiSlider.spectrum',
    'mxg.components.noUiSlider.structure',
    'mxg.components.noUiSlider.options',
    'mxg.components.noUiSlider.scope',
    'mxg.components.noUiSlider.noUiSlider',
    'mxg.components.noUiSlider.pips'
]);

angular.module('mxg.components.noUiSlider.constants', [])
    .factory('noUiSliderConstants', ['$window', function ($window) {
        "use strict";

        var windowActions = $window.navigator.pointerEnabled ? {
            start: 'pointerdown',
            move: 'pointermove',
            end: 'pointerup'
        } : $window.navigator.msPointerEnabled ? {
            start: 'MSPointerDown',
            move: 'MSPointerMove',
            end: 'MSPointerUp'
        } : {
            start: 'mousedown touchstart',
            move: 'mousemove touchmove',
            end: 'mouseup touchend'
        };

        var prefix = 'mxg-noUi';

        return {
            actions: windowActions,
            prefix: prefix,
            classes: [
                /*  0 */  prefix + '-target'
                /*  1 */ , prefix + '-base'
                /*  2 */ , prefix + '-origin'
                /*  3 */ , prefix + '-handle'
                /*  4 */ , prefix + '-horizontal'
                /*  5 */ , prefix + '-vertical'
                /*  6 */ , prefix + '-background'
                /*  7 */ , prefix + '-connect'
                /*  8 */ , prefix + '-ltr'
                /*  9 */ , prefix + '-rtl'
                /* 10 */ , prefix + '-dragable'
                /* 11 */ , ''
                /* 12 */ , prefix + '-state-drag'
                /* 13 */ , ''
                /* 14 */ , prefix + '-state-tap'
                /* 15 */ , prefix + '-active'
                /* 16 */ , ''
                /* 17 */ , prefix + '-stacking'
            ]
        };

    }]);
angular.module('mxg.components.noUiSlider.helpers', [])
    .factory('noUiSliderHelpers', ['$timeout', function ($timeout) {

        // Round a value to the closest 'to'.
        function closest(value, to) {
            return Math.round(value / to) * to;
        }

        // Checks whether a value is numerical.
        function isNumeric(a) {
            return typeof a === 'number' && !isNaN(a) && isFinite(a);
        }

        // Rounds a number to 7 supported decimals.
        function accurateNumber(number) {
            var p = Math.pow(10, 7);
            return Number((Math.round(number * p) / p).toFixed(7));
        }

        // Sets a class and removes it after [duration] ms.
        function addClassFor(element, className, duration) {
            element.addClass(className);
            $timeout(function () {
                element.removeClass(className);
            }, duration);
        }

        // Limits a value to 0 - 100
        function limit(a) {
            return Math.max(Math.min(a, 100), 0);
        }

        // Wraps a variable as an array, if it isn't one yet.
        function asArray(a) {
            return angular.isArray(a) ? a : [a];
        }

        // Counts decimals
        function countDecimals(numStr) {
            var pieces = numStr.split(".");
            return pieces.length > 1 ? pieces[1].length : 0;
        }

        function getPageOffset() {

            var supportPageOffset = window.pageXOffset !== undefined;
            var x = supportPageOffset ? window.pageXOffset : document.documentElement.scrollLeft;
            var y = supportPageOffset ? window.pageYOffset : document.documentElement.scrollTop;

            return {
              x: x,
              y: y
            };

        }

        function offset(el) {

            var rect = el.getBoundingClientRect();
            var doc = el.ownerDocument;
            var docEl = doc.documentElement;
            var pageOffset = getPageOffset();

            return {
                top: rect.top + pageOffset.y - docEl.clientTop,
                left: rect.left + pageOffset.x - docEl.clientLeft
            };

        }

        return {
            closest: closest,
            isNumeric: isNumeric,
            accurateNumber: accurateNumber,
            addClassFor: addClassFor,
            limit: limit,
            asArray: asArray,
            countDecimals: countDecimals,
            offset: offset
        };

    }]);

angular.module('mxg.components.noUiSlider.options', [
    'mxg.components.noUiSlider.helpers', 'mxg.components.noUiSlider.spectrum'
])
    .factory('noUiSliderOptions', [
        'noUiSliderHelpers',
        'noUiSliderSpectrum',
        function (SliderHelpers, SliderSpectrum) {
            "use strict";

            /*	Every input option is tested and parsed. This'll prevent
             endless validation in internal methods. These tests are
             structured with an item for every option available. An
             option can be marked as required by setting the 'r' flag.
             The testing function is provided with three arguments:
             - The provided value for the option;
             - A reference to the options object;
             - The name for the option;

             The testing function returns false when an error is detected,
             or true when everything is OK. It can also modify the option
             object, to make sure all values can be correctly looped elsewhere. */

            /** @const */
            var defaultFormatter = { 'to': function (value) {
                return value.toFixed(2);
            }, 'from': Number };

            function testStep(parsed, entry) {

                if (!SliderHelpers.isNumeric(entry)) {
                    throw new Error("noUiSlider: 'step' is not numeric.");
                }

                // The step option can still be used to set stepping
                // for linear sliders. Overwritten if set in 'range'.
                parsed.singleStep = entry;
            }

            function testRange(parsed, entry) {

                // Filter incorrect input.
                if (typeof entry !== 'object' || angular.isArray(entry)) {
                    throw new Error("noUiSlider: 'range' is not an object.");
                }

                // Catch missing start or end.
                if (entry.min === undefined || entry.max === undefined) {
                    throw new Error("noUiSlider: Missing 'min' or 'max' in 'range'.");
                }

                parsed.spectrum = new SliderSpectrum(entry, parsed.snap, parsed.dir, parsed.singleStep);
            }

            function testStart(parsed, entry) {

                entry = SliderHelpers.asArray(entry);

                // Validate input. Values aren't tested, as the public .val method
                // will always provide a valid location.
                if (!angular.isArray(entry) || !entry.length || entry.length > 2) {
                    throw new Error("noUiSlider: 'start' option is incorrect.");
                }

                // Store the number of handles.
                parsed.handles = entry.length;

                // When the slider is initialized, the .val method will
                // be called with the start options.
                parsed.start = entry;
            }

            function testSnap(parsed, entry) {

                // Enforce 100% stepping within subranges.
                parsed.snap = entry;

                if (typeof entry !== 'boolean') {
                    throw new Error("noUiSlider: 'snap' option must be a boolean.");
                }
            }

            function testAnimate(parsed, entry) {

                // Enforce 100% stepping within subranges.
                parsed.animate = entry;

                if (typeof entry !== 'boolean') {
                    throw new Error("noUiSlider: 'animate' option must be a boolean.");
                }
            }

            function testConnect(parsed, entry) {

                if (entry === 'lower' && parsed.handles === 1) {
                    parsed.connect = 1;
                } else if (entry === 'upper' && parsed.handles === 1) {
                    parsed.connect = 2;
                } else if (entry === true && parsed.handles === 2) {
                    parsed.connect = 3;
                } else if (entry === false) {
                    parsed.connect = 0;
                } else {
                    throw new Error("noUiSlider: 'connect' option doesn't match handle count.");
                }
            }

            function testOrientation(parsed, entry) {

                // Set orientation to an a numerical value for easy
                // array selection.
                switch (entry) {
                    case 'horizontal':
                        parsed.ort = 0;
                        break;
                    case 'vertical':
                        parsed.ort = 1;
                        break;
                    default:
                        throw new Error("noUiSlider: 'orientation' option is invalid.");
                }
            }

            function testMargin(parsed, entry) {

                if (!SliderHelpers.isNumeric(entry)) {
                    throw new Error("noUiSlider: 'margin' option must be numeric.");
                }

                parsed.margin = parsed.spectrum.getMargin(entry);

                if (!parsed.margin) {
                    throw new Error("noUiSlider: 'margin' option is only supported on linear sliders.");
                }
            }

            function testLimit(parsed, entry) {

                if (!SliderHelpers.isNumeric(entry)) {
                    throw new Error("noUiSlider: 'limit' option must be numeric.");
                }

                parsed.limit = parsed.spectrum.getMargin(entry);

                if (!parsed.limit) {
                    throw new Error("noUiSlider: 'limit' option is only supported on linear sliders.");
                }
            }

            function testDirection(parsed, entry) {

                // Set direction as a numerical value for easy parsing.
                // Invert connection for RTL sliders, so that the proper
                // handles get the connect/background classes.
                switch (entry) {
                    case 'ltr':
                        parsed.dir = 0;
                        break;
                    case 'rtl':
                        parsed.dir = 1;
                        parsed.connect = [0, 2, 1, 3][parsed.connect];
                        break;
                    default:
                        throw new Error("noUiSlider: 'direction' option was not recognized.");
                }
            }

            function testBehaviour(parsed, entry) {

                // Make sure the input is a string.
                if (typeof entry !== 'string') {
                    throw new Error("noUiSlider: 'behaviour' must be a string containing options.");
                }

                // Check if the string contains any keywords.
                // None are required.
                var tap = entry.indexOf('tap') >= 0,
                    drag = entry.indexOf('drag') >= 0,
                    fixed = entry.indexOf('fixed') >= 0,
                    snap = entry.indexOf('snap') >= 0;

                parsed.events = {
                    tap: tap || snap,
                    drag: drag,
                    fixed: fixed,
                    snap: snap
                };
            }

            function testFormat(parsed, entry) {

                parsed.format = entry;

                // Any object with a to and from method is supported.
                if (typeof entry.to === 'function' && typeof entry.from === 'function') {
                    return true;
                }

                throw new Error("noUiSlider: 'format' requires 'to' and 'from' methods.");
            }

            // Test all developer settings and parse to assumption-safe values.
            function testOptions(options) {

                var parsed = {
                    margin: 0,
                    limit: 0,
                    animate: true,
                    format: defaultFormatter
                }, tests;

                // Tests are executed in the order they are presented here.
                tests = {
                    'step': { r: false, t: testStep },
                    'start': { r: true, t: testStart },
                    'connect': { r: true, t: testConnect },
                    'direction': { r: true, t: testDirection },
                    'snap': { r: false, t: testSnap },
                    'animate': { r: false, t: testAnimate },
                    'range': { r: true, t: testRange },
                    'orientation': { r: false, t: testOrientation },
                    'margin': { r: false, t: testMargin },
                    'limit': { r: false, t: testLimit },
                    'behaviour': { r: true, t: testBehaviour },
                    'format': { r: false, t: testFormat }
                };

                // Set defaults where applicable.
                options = angular.extend({
                    'connect': false,
                    'direction': 'ltr',
                    'behaviour': 'tap',
                    'orientation': 'horizontal'
                }, options);

                // Run all options through a testing mechanism to ensure correct
                // input. It should be noted that options might get modified to
                // be handled properly. E.g. wrapping integers in arrays.
                angular.forEach(tests, function (test, name) {

                    // If the option isn't set, but it is required, throw an error.
                    if (options[name] === undefined) {

                        if (test.r) {
                            throw new Error("noUiSlider: '" + name + "' is required.");
                        }

                        return true;
                    }

                    test.t(parsed, options[name]);
                });

                // Pre-define the styles.
                parsed.style = parsed.ort ? 'top' : 'left';

                return parsed;
            }

            return {
                test: testOptions
            };

        }]);
angular.module('mxg.components.noUiSlider.pips', ['mxg.components.noUiSlider.constants'])
    .factory('noUiSliderPips', ['noUiSliderConstants',
        function noUiSliderPipsFactory(SliderConstants) {
            "use strict";

            function getGroup($Spectrum, mode, values, stepped) {

                // Use the range.
                if (mode === 'range' || mode === 'steps') {
                    return $Spectrum.xVal;
                }

                if (mode === 'count') {

                    if (values === false) {
                        values = 0;
                    }

                    // Divide 0 - 100 in 'count' parts.
                    var spread = ( 100 / (values - 1) ), v, i = 0;
                    values = [];

                    // List these parts and have them handled as 'positions'.
                    while ((v = i++ * spread) <= 100) {
                        values.push(v);
                    }

                    mode = 'positions';
                }

                if (mode === 'positions') {

                    if (values === false) {
                        values = [];
                    }

                    // Map all percentages to on-range values.
                    return values.map(function (value) {
                        return $Spectrum.fromStepping(stepped ? $Spectrum.getStep(value) : value);
                    });
                }

                if (mode === 'values') {

                    if (values === false) {
                        values = [];
                    }

                    // If the value must be stepped, it needs to be converted to a percentage first.
                    if (stepped) {

                        return values.map(function (value) {

                            // Convert to percentage, apply step, return to value.
                            return $Spectrum.fromStepping($Spectrum.getStep($Spectrum.toStepping(value)));
                        });

                    }

                    // Otherwise, we can simply use the values.
                    return values;
                }
            }

            function generateSpread($Spectrum, density, mode, group) {

                var originalSpectrumDirection = $Spectrum.direction,
                    indexes = {},
                    firstInRange = $Spectrum.xVal[0],
                    lastInRange = $Spectrum.xVal[$Spectrum.xVal.length - 1],
                    ignoreFirst = false,
                    ignoreLast = false,
                    prevPct = 0;

                // This function loops the spectrum in an ltr linear fashion,
                // while the toStepping method is direction aware. Trick it into
                // believing it is ltr.
                $Spectrum.direction = 0;

                // Create a copy of the group, sort it and filter away all duplicates.
                group = group.slice().sort(function (a, b) {
                    return a - b;
                });

                // Make sure the range starts with the first element.
                if (group[0] !== firstInRange) {
                    group.unshift(firstInRange);
                    ignoreFirst = true;
                }

                // Likewise for the last one.
                if (group[group.length - 1] !== lastInRange) {
                    group.push(lastInRange);
                    ignoreLast = true;
                }

                group.forEach(function (item, index) {

                    // Get the current step and the lower + upper positions.
                    var step, i, q,
                        low = group[index],
                        high = group[index + 1],
                        newPct, pctDifference, pctPos, type,
                        steps, realSteps, stepsize;

                    // When using 'steps' mode, use the provided steps.
                    // Otherwise, we'll step on to the next subrange.
                    if (mode === 'steps') {
                        step = $Spectrum.xNumSteps[ index ];
                    }

                    // Default to a 'full' step.
                    if (!step) {
                        step = high - low;
                    }

                    // Low can be 0, so test for false. If high is undefined,
                    // we are at the last subrange. Index 0 is already handled.
                    if (low === false || high === undefined) {
                        return;
                    }

                    // Find all steps in the subrange.
                    for (i = low; i <= high; i += step) {

                        // Get the percentage value for the current step,
                        // calculate the size for the subrange.
                        newPct = $Spectrum.toStepping(i);
                        pctDifference = newPct - prevPct;

                        steps = pctDifference / density;
                        realSteps = Math.round(steps);

                        // This ratio represents the ammount of percentage-space a point indicates.
                        // For a density 1 the points/percentage = 1. For density 2, that percentage needs to be re-devided.
                        // Round the percentage offset to an even number, then divide by two
                        // to spread the offset on both sides of the range.
                        stepsize = pctDifference / realSteps;

                        // Divide all points evenly, adding the correct number to this subrange.
                        // Run up to <= so that 100% gets a point, event if ignoreLast is set.
                        for (q = 1; q <= realSteps; q += 1) {

                            // The ratio between the rounded value and the actual size might be ~1% off.
                            // Correct the percentage offset by the number of points
                            // per subrange. density = 1 will result in 100 points on the
                            // full range, 2 for 50, 4 for 25, etc.
                            pctPos = prevPct + ( q * stepsize );
                            indexes[pctPos.toFixed(5)] = ['x', 0];
                        }

                        // Determine the point type.
                        type = (group.indexOf(i) > -1) ? 1 : ( mode === 'steps' ? 2 : 0 );

                        // Enforce the 'ignoreFirst' option by overwriting the type for 0.
                        if (!index && ignoreFirst) {
                            type = 0;
                        }

                        if (!(i === high && ignoreLast)) {
                            // Mark the 'type' of this point. 0 = plain, 1 = real value, 2 = step value.
                            indexes[newPct.toFixed(5)] = [i, type];
                        }

                        // Update the percentage count.
                        prevPct = newPct;
                    }
                });

                // Reset the spectrum.
                $Spectrum.direction = originalSpectrumDirection;

                return indexes;
            }

            function addMarking(CSSstyle, orientation, direction, spread, filterFunc, formatter) {

                var style = ['horizontal', 'vertical'][orientation],
                    element = angular.element('<div/>');

                element.addClass(SliderConstants.prefix + '-pips '+ SliderConstants.prefix + '-pips-' + style);

                function getSize(type, value) {
                    return [ '-normal', '-large', '-sub' ][type];
                }

                function getTags(offset, source, values) {
                    return 'class="' + source + ' ' +
                        source + '-' + style + ' ' +
                        source + getSize(values[1], values[0]) +
                        '" style="' + CSSstyle + ': ' + offset + '%"';
                }

                function addSpread(values, offset) {

                    if (direction) {
                        offset = 100 - offset;
                    }

                    // Apply the filter function, if it is set.
                    values[1] = (values[1] && filterFunc) ? filterFunc(values[0], values[1]) : values[1];

                    // Add a marker for every point
                    element.append('<div ' + getTags(offset, SliderConstants.prefix + '-marker', values) + '></div>');

                    // Values are only appended for points marked '1' or '2'.
                    if (values[1]) {
                        element.append('<div ' + getTags(offset, SliderConstants.prefix + '-value', values) + '>' + formatter.to(values[0]) + '</div>');
                    }
                }

                // Append all points.
                angular.forEach(spread, addSpread);

                return element;
            }

            return function appendPipsMarkup(slider, grid) {

                var mode = grid.mode,
                    density = grid.density || 1,
                    filter = grid.filter || false,
                    values = grid.values || false,
                    format = grid.format || {
                        to: Math.round
                    },
                    stepped = grid.stepped || false;

                var info = slider.getInfo(),
                    group = getGroup(info[0], mode, values, stepped),
                    spread = generateSpread(info[0], density, mode, group);

                var pipsElement = addMarking(
                    info[1],
                    info[2],
                    info[0].direction,
                    spread,
                    filter,
                    format
                );

                return pipsElement;

            };

        }]);


angular.module('mxg.components.noUiSlider.scope', [
    'mxg.components.noUiSlider.options',
    'mxg.components.noUiSlider.helpers',
    'mxg.components.noUiSlider.constants',
    'mxg.components.noUiSlider.structure',
    'mxg.components.noUiSlider.pips'
])
    .factory('noUiSliderScope', [
        '$document',
        'noUiSliderOptions',
        'noUiSliderHelpers',
        'noUiSliderConstants',
        'noUiSliderStructure',
        'noUiSliderPips',
        function ($document, SliderOptions, SliderHelpers, SliderConstants, SliderStructure, SliderPips) {
            "use strict";

            function closure(target, options) {

                // Internal variables
                // All variables local to 'closure' are marked $.
                var $Target = target,
                    $Locations = [-1, -1],
                    $Base,
                    $Handles,
                    $Spectrum = options.spectrum,
                    $Values = [],

                    $EventHandlers = {};

                // Helpers

                // Shorthand for base dimensions.
                function baseSize() {

                    var result = 0;
                    switch (options.ort) {
                        case 0:
                            result = $Base[0].offsetWidth;
                            break;
                        case 1:
                            result = $Base[0].offsetHeight;
                            break;
                    }
                    return result;

                }

                // External event handling
                function fireEvents(events) {

                    var index, values = valueGet();

                    for (index = 0; index < events.length; index += 1) {
                        $Target.triggerHandler(events[index], values);
                    }
                }

                // Returns the input array, respecting the slider direction configuration.
                function inSliderOrder(values) {

                    if (options.dir) {
                        return values.reverse();
                    }

                    return values;
                }

                // Handler for attaching events trough a proxy.
                function attach(targetId, events, element, callback, data) {

                    // This function can be used to 'filter' events to the slider.

                    var eventHandler = function (e) {

                        if ($Target.prop('disabled')) {
                            return false;
                        }

                        // Stop if an active 'tap' transition is taking place.
                        if ($Target.hasClass(SliderConstants.classes[14])) {
                            return false;
                        }

                        e = SliderStructure.fixEvent(e);
                        e.calcPoint = e.points[options.ort];

                        // Call the event handler with the event [ and additional data ].
                        callback(e, data);

                    };

                    if (angular.isUndefined($EventHandlers[targetId])) {
                        $EventHandlers[targetId] = [];
                    }

                    $EventHandlers[targetId].push({
                        element: element,
                        events: events,
                        handler: eventHandler
                    });

                    // Bind a closure on the target.
                    return element.on(events, eventHandler);

                }

                function detach(targetId) {

                    if (targetId in $EventHandlers) {
                        $EventHandlers[targetId].forEach(function (item) {
                            item.element.off(item.events, item.handler);
                        });
                    }

                }

                // Handle movement on document for handle and range drag.
                function move(event, data) {

                    var handles = data.handles || $Handles, positions, state = false,
                        proposal = ((event.calcPoint - data.start) * 100) / baseSize(),
                        h = handles[0][0] !== $Handles[0][0] ? 1 : 0;

                    // Calculate relative positions for the handles.
                    positions = SliderStructure.getPositions(proposal, data.positions, handles.length > 1);

                    state = setHandle(handles[0], positions[h], handles.length === 1);

                    if (handles.length > 1) {
                        state = setHandle(handles[1], positions[h ? 0 : 1], false) || state;
                    }

                    // Fire the 'slide' event if any handle moved.
                    if (state) {
                        fireEvents(['slide']);
                    }
                }

                // Unbind move events on document, call callbacks.
                function end(event) {

                    // The handle is no longer active, so remove the class.

                    angular.element($document[0].querySelectorAll('.' + SliderConstants.classes[15]))
                        .removeClass(SliderConstants.classes[15]);

                    // Unbind the move and end events, which are added on 'start'.
                    detach('document');

                    // Remove dragging class.
                    $Target.removeClass(SliderConstants.classes[12]);

                    // Fire the change and set events.
                    fireEvents(['set', 'change']);
                }

                // Bind move events on document.
                function start(event, data) {

                    // Mark the handle as 'active' so it can be styled.
                    if (data.handles.length === 1) {
                        data.handles[0].children().addClass(SliderConstants.classes[15]);
                    }

                    // A drag should never propagate up to the 'tap' event.
                    event.stopPropagation();

                    // Attach the move event.
                    attach('document', SliderConstants.actions.move, $document, move, {
                        start: event.calcPoint,
                        handles: data.handles,
                        positions: [
                            $Locations[0],
                            $Locations[$Handles.length - 1]
                        ]
                    });

                    // Unbind all movement when the drag ends.
                    attach('document', SliderConstants.actions.end, $document, end, null);

                    // Text selection isn't an issue on touch devices,
                    // so adding cursor styles can be skipped.
                    if (event.cursor) {

                        // Mark the target with a dragging state.
                        if ($Handles.length > 1) {
                            $Target.addClass(SliderConstants.classes[12]);
                        }

                    }
                }

                // Move closest handle to tapped location.
                function tap(event) {

                    var location = event.calcPoint, total = 0, handleNumber, to;

                    // The tap event shouldn't propagate up and cause 'edge' to run.
                    event.stopPropagation();

                    // Add up the handle offsets.
                    $Handles.forEach(function (item) {
                        total += SliderHelpers.offset(item[0])[options.style];
                    });

                    // Find the handle closest to the tapped position.
                    handleNumber = ( location < total / 2 || $Handles.length === 1 ) ? 0 : 1;

                    if ($Handles[handleNumber][0].hasAttribute('disabled')) {
                        handleNumber = handleNumber ? 0 : 1;
                    }

                    location -= SliderHelpers.offset($Base[0])[options.style];

                    // Calculate the new position.
                    to = ( location * 100 ) / baseSize();

                    if (!options.events.snap) {
                        // Flag the slider as it is now in a transitional state.
                        // Transition takes 300 ms, so re-enable the slider afterwards.
                        SliderHelpers.addClassFor($Target, SliderConstants.classes[14], 300);
                    }

                    if ($Handles[handleNumber][0].hasAttribute('disabled')) {
                        return false;
                    }

                    // Find the closest handle and calculate the tapped point.
                    // The set handle to the new position.
                    setHandle($Handles[handleNumber], to);

                    fireEvents(['slide', 'set', 'change']);

                    if (options.events.snap) {
                        start(event, {handles: [$Handles[handleNumber]]});
                    }

                }

                // Attach events to several slider parts.
                function events(behaviour) {

                    var i, drag;

                    // Attach the standard drag event to the handles.
                    if (!behaviour.fixed) {

                        for (i = 0; i < $Handles.length; i += 1) {

                            // These events are only bound to the visual handle
                            // element, not the 'real' origin element.
                            attach('slider', SliderConstants.actions.start, $Handles[i].children(), start, {
                                handles: [$Handles[i]]
                            });
                        }
                    }

                    // Attach the tap event to the slider base.
                    if (behaviour.tap) {

                        attach('slider', SliderConstants.actions.start, $Base, tap, {
                            handles: $Handles
                        });
                    }

                    // Make the range dragable.
                    if (behaviour.drag) {

                        drag = $Base.find('.' + SliderConstants.classes[7]).addClass(SliderConstants.classes[10]);

                        // When the range is fixed, the entire range can
                        // be dragged by the handles. The handle in the first
                        // origin will propagate the start event upward,
                        // but it needs to be bound manually on the other.
                        if (behaviour.fixed) {
                            drag = drag.add($Base.children().not(drag).children());
                        }

                        attach(SliderConstants.actions.start, drag, start, {
                            handles: $Handles
                        });
                    }
                }

                // Test suggested values and apply margin, step.
                function setHandle(handle, to, noLimitOption) {

                    var trigger = handle[0] !== $Handles[0][0] ? 1 : 0,
                        lowerMargin = $Locations[0] + options.margin,
                        upperMargin = $Locations[1] - options.margin,
                        lowerLimit = $Locations[0] + options.limit,
                        upperLimit = $Locations[1] - options.limit;

                    // For sliders with multiple handles,
                    // limit movement to the other handle.
                    // Apply the margin option by adding it to the handle positions.
                    if ($Handles.length > 1) {
                        to = trigger ? Math.max(to, lowerMargin) : Math.min(to, upperMargin);
                    }

                    // The limit option has the opposite effect, limiting handles to a
                    // maximum distance from another. Limit must be > 0, as otherwise
                    // handles would be unmoveable. 'noLimitOption' is set to 'false'
                    // for the valueGet method, except for pass 4/4.
                    if (noLimitOption !== false && options.limit && $Handles.length > 1) {
                        to = trigger ? Math.min(to, lowerLimit) : Math.max(to, upperLimit);
                    }

                    // Handle the step option.
                    to = $Spectrum.getStep(to);

                    // Limit to 0/100 for .val input, trim anything beyond 7 digits, as
                    // JavaScript has some issues in its floating point implementation.
                    to = SliderHelpers.limit(parseFloat(to.toFixed(7)));

                    // Return false if handle can't move.
                    if (to === $Locations[trigger]) {
                        return false;
                    }

                    // Set the handle to the new position.
                    handle.css(options.style, to + '%');

                    // Force proper handle stacking
                    if ($Handles.indexOf(handle) === 0) {
                        handle.toggleClass(SliderConstants.classes[17], to > 50);
                    }

                    // Update locations.
                    $Locations[trigger] = to;

                    // Convert the value to the slider stepping/range.
                    $Values[trigger] = $Spectrum.fromStepping(to);

                    return true;
                }

                // Loop values from value method and apply them.
                function setValues(count, values) {

                    var i, trigger, to;

                    // With the limit option, we'll need another limiting pass.
                    if (options.limit) {
                        count += 1;
                    }

                    // If there are multiple handles to be set run the setting
                    // mechanism twice for the first handle, to make sure it
                    // can be bounced of the second one properly.
                    for (i = 0; i < count; i += 1) {

                        trigger = i % 2;

                        // Get the current argument from the array.
                        to = values[trigger];

                        // Setting with null indicates an 'ignore'.
                        // Inputting 'false' is invalid.
                        if (to !== null && to !== false) {

                            // If a formatted number was passed, attemt to decode it.
                            if (typeof to === 'number') {
                                to = String(to);
                            }

                            to = options.format.from(to);

                            if (to !== false && !isNaN(to)) {
                                setHandle($Handles[trigger], $Spectrum.toStepping(to), i === (3 - options.dir));
                            }
                        }
                    }
                }

                // Set the slider value.
                function valueSet(input) {

                    var count, values = SliderHelpers.asArray(input);

                    // The RTL settings is implemented by reversing the front-end,
                    // internal mechanisms are the same.
                    if (options.dir && options.handles > 1) {
                        values.reverse();
                    }

                    // Animation is optional.
                    // Make sure the initial values where set before using animated
                    // placement. (no report, unit testing);
                    if (options.animate && $Locations[0] !== -1) {
                        SliderHelpers.addClassFor($Target, SliderConstants.classes[14], 300);
                    }

                    // Determine how often to set the handles.
                    count = $Handles.length > 1 ? 3 : 1;

                    if (values.length === 1) {
                        count = 1;
                    }

                    setValues(count, values);

                    // Fire the 'set' event. As of noUiSlider 7,
                    // this is no longer optional.
                    fireEvents(['set']);

                    return this;
                }

                // Get the slider value.
                function valueGet() {

                    var i, retour = [];

                    // Get the value from all handles.
                    for (i = 0; i < options.handles; i += 1) {
                        retour[i] = options.format.to($Values[i]);
                    }

                    return inSliderOrder(retour);
                }

                // Get the current step size for the slider.
                function getCurrentStep() {

                    // Check all locations, map them to their stepping point.
                    // Get the step point, then find it in the input list.
                    var retour = $Locations.map(function (location, index) {

                        var step = $Spectrum.getApplicableStep(location),

                        // As per #391, the comparison for the decrement step can have some rounding issues.
                        // Round the value to the precision used in the step.
                            stepDecimals = SliderHelpers.countDecimals(String(step[2])),

                        // Get the current numeric value
                            value = $Values[index],

                        // To move the slider 'one step up', the current step value needs to be added.
                        // Use null if we are at the maximum slider value.
                            increment = location === 100 ? null : step[2],

                        // Going 'one step down' might put the slider in a different sub-range, so we
                        // need to switch between the current or the previous step.
                            prev = Number((value - step[2]).toFixed(stepDecimals)),

                        // If the value fits the step, return the current step value. Otherwise, use the
                        // previous step. Return null if the slider is at its minimum value.
                            decrement = location === 0 ? null : (prev >= step[1]) ? step[2] : (step[0] || false);

                        return [
                            [decrement, increment]
                        ];
                    });

                    // Return values in the proper order.
                    return inSliderOrder(retour);
                }

                // Get the original set of options.
                function getOriginalOptions() {
                    return originalOptions;
                }

                // Initialize slider

                // Throw an error if the slider was already initialized.
                if ($Target.hasClass(SliderConstants.classes[0])) {
                    throw new Error('Slider was already initialized.');
                }

                // Create the base element, initialise HTML and set classes.
                // Add handles and links.
                $Base = SliderStructure.addSlider(options.dir, options.ort, $Target);
                $Handles = SliderStructure.addHandles(options.handles, options.dir, $Base);

                // Set the connect classes.
                SliderStructure.addConnection(options.connect, $Target, $Handles);

                // Attach user events.
                events(options.events);

                valueSet(options.start);

                return {
                    vGet: valueGet,
                    vSet: valueSet,
                    getCurrentStep: getCurrentStep,
                    getInfo: function () {
                        return [
                            $Spectrum,
                            options.style,
                            options.ort
                        ];
                    }
                };

            }

            return function init (target, originalOptions, pipOptions) {

                var options = SliderOptions.test(originalOptions);

                var slider = closure(target, options);

                var pipsElement;

                if (pipOptions) {
                    pipsElement = SliderPips(slider, pipOptions);
                    target.append(pipsElement);
                }

                return slider;

            };

        }]);

angular.module('mxg.components.noUiSlider.spectrum', [
    'mxg.components.noUiSlider.helpers'
])
    .factory('noUiSliderSpectrum', ['noUiSliderHelpers', function (SliderHelpers) {
        "use strict";

        // Value calculation

        // Determine the size of a sub-range in relation to a full range.
        function subRangeRatio(pa, pb) {
            return (100 / (pb - pa));
        }

        // (percentage) How many percent is this value of this range?
        function fromPercentage(range, value) {
            return (value * 100) / ( range[1] - range[0] );
        }

        // (percentage) Where is this value on this range?
        function toPercentage(range, value) {
            return fromPercentage(range, range[0] < 0 ?
                value + Math.abs(range[0]) :
                value - range[0]);
        }

        // (value) How much is this percentage on this range?
        function isPercentage(range, value) {
            return ((value * ( range[1] - range[0] )) / 100) + range[0];
        }

        // Range conversion

        function getJ(value, arr) {

            var j = 1;

            while (value >= arr[j]) {
                j += 1;
            }

            return j;
        }

        // (percentage) Input a value, find where, on a scale of 0-100, it applies.
        function toStepping(xVal, xPct, value) {

            if (value >= xVal.slice(-1)[0]) {
                return 100;
            }

            var j = getJ(value, xVal), va, vb, pa, pb;

            va = xVal[j - 1];
            vb = xVal[j];
            pa = xPct[j - 1];
            pb = xPct[j];

            return pa + (toPercentage([va, vb], value) / subRangeRatio(pa, pb));
        }

        // (value) Input a percentage, find where it is on the specified range.
        function fromStepping(xVal, xPct, value) {

            // There is no range group that fits 100
            if (value >= 100) {
                return xVal.slice(-1)[0];
            }

            var j = getJ(value, xPct), va, vb, pa, pb;

            va = xVal[j - 1];
            vb = xVal[j];
            pa = xPct[j - 1];
            pb = xPct[j];

            return isPercentage([va, vb], (value - pa) * subRangeRatio(pa, pb));
        }

        // (percentage) Get the step that applies at a certain value.
        function getStep(xPct, xSteps, snap, value) {

            if (value === 100) {
                return value;
            }

            var j = getJ(value, xPct), a, b;

            // If 'snap' is set, steps are used as fixed points on the slider.
            if (snap) {

                a = xPct[j - 1];
                b = xPct[j];

                // Find the closest position, a or b.
                if ((value - a) > ((b - a) / 2)) {
                    return b;
                }

                return a;
            }

            if (!xSteps[j - 1]) {
                return value;
            }

            return xPct[j - 1] + SliderHelpers.closest(
                    value - xPct[j - 1],
                xSteps[j - 1]
            );

        }

        // Entry parsing

        function handleEntryPoint(index, value, that) {

            var percentage;

            // Wrap numerical input in an array.
            if (typeof value === "number") {
                value = [value];
            }

            // Reject any invalid input, by testing whether value is an array.
            if (Object.prototype.toString.call(value) !== '[object Array]') {
                throw new Error("noUiSlider: 'range' contains invalid value.");
            }

            // Covert min/max syntax to 0 and 100.
            if (index === 'min') {
                percentage = 0;
            } else if (index === 'max') {
                percentage = 100;
            } else {
                percentage = parseFloat(index);
            }

            // Check for correct input.
            if (!SliderHelpers.isNumeric(percentage) || !SliderHelpers.isNumeric(value[0])) {
                throw new Error("noUiSlider: 'range' value isn't numeric.");
            }

            // Store values.
            that.xPct.push(percentage);
            that.xVal.push(value[0]);

            // NaN will evaluate to false too, but to keep
            // logging clear, set step explicitly. Make sure
            // not to override the 'step' setting with false.
            if (!percentage) {
                if (!isNaN(value[1])) {
                    that.xSteps[0] = that.snap ? value[1] : false;
                }
            } else {
                that.xSteps.push(isNaN(value[1]) ? false : value[1]);
            }
        }

        function handleStepPoint(i, n, that) {

            // Ignore 'false' stepping.
            if (!n) {
                return true;
            }

            // Factor to range ratio
            that.xSteps[i] = fromPercentage([
                that.xVal[i]
                , that.xVal[i + 1]
            ], n) / subRangeRatio(
                that.xPct[i],
                that.xPct[i + 1]);
        }

        // Interface

        // The interface to Spectrum handles all direction-based
        // conversions, so the above values are unaware.

        function Spectrum(entry, snap, direction, singleStep) {

            this.xPct = [];
            this.xVal = [];
            this.xSteps = [ singleStep || false ];
            this.xNumSteps = [ false ];

            this.snap = snap;
            this.direction = direction;

            var index, ordered = [ /* [0, 'min'], [1, '50%'], [2, 'max'] */ ];

            // Map the object keys to an array.
            for (index in entry) {
                if (entry.hasOwnProperty(index)) {
                    ordered.push([entry[index], index]);
                }
            }

            // Sort all entries by value (numeric sort).
            ordered.sort(function (a, b) {
                return a[0] - b[0];
            });

            // Convert all entries to subranges.
            for (index = 0; index < ordered.length; index++) {
                handleEntryPoint(ordered[index][1], ordered[index][0], this);
            }

            // Store the actual step values.
            // xSteps is sorted in the same order as xPct and xVal.
            this.xNumSteps = this.xSteps.slice(0);

            // Convert all numeric steps to the percentage of the subrange they represent.
            for (index = 0; index < this.xNumSteps.length; index++) {
                handleStepPoint(index, this.xNumSteps[index], this);
            }
        }

        Spectrum.prototype.getMargin = function (value) {
            return this.xPct.length === 2 ? fromPercentage(this.xVal, value) : false;
        };

        Spectrum.prototype.toStepping = function (value) {

            value = toStepping(this.xVal, this.xPct, value);

            // Invert the value if this is a right-to-left slider.
            if (this.direction) {
                value = 100 - value;
            }

            return value;
        };

        Spectrum.prototype.fromStepping = function (value) {

            // Invert the value if this is a right-to-left slider.
            if (this.direction) {
                value = 100 - value;
            }

            return SliderHelpers.accurateNumber(fromStepping(this.xVal, this.xPct, value));
        };

        Spectrum.prototype.getStep = function (value) {

            // Find the proper step for rtl sliders by search in inverse direction.
            // Fixes issue #262.
            if (this.direction) {
                value = 100 - value;
            }

            value = getStep(this.xPct, this.xSteps, this.snap, value);

            if (this.direction) {
                value = 100 - value;
            }

            return value;
        };

        Spectrum.prototype.getApplicableStep = function (value) {

            // If the value is 100%, return the negative step twice.
            var j = getJ(value, this.xPct), offset = value === 100 ? 2 : 1;
            return [this.xNumSteps[j - 2], this.xVal[j - offset], this.xNumSteps[j - offset]];
        };

        // Outside testing
        Spectrum.prototype.convert = function (value) {
            return this.getStep(this.toStepping(value));
        };

        return Spectrum;

    }]);

angular.module('mxg.components.noUiSlider.structure', [
    'mxg.components.noUiSlider.helpers', 'mxg.components.noUiSlider.constants'
])
    .factory('noUiSliderStructure', [
        'noUiSliderHelpers', 'noUiSliderConstants',
        function (SliderHelpers, SliderConstants) {
            "use strict";

            // Class handling

            // Delimit proposed values for handle positions.
            function getPositions(a, b, delimit) {

                // Add movement to current position.
                var c = a + b[0], d = a + b[1];

                // Only alter the other position on drag,
                // not on standard sliding.
                if (delimit) {
                    if (c < 0) {
                        d += Math.abs(c);
                    }
                    if (d > 100) {
                        c -= ( d - 100 );
                    }

                    // Limit values to 0 and 100.
                    return [SliderHelpers.limit(c), SliderHelpers.limit(d)];
                }

                return [c, d];
            }

            // Event handling

            // Provide a clean event with standardized offset values.
            function fixEvent(e) {

                // Prevent scrolling and panning on touch events, while
                // attempting to slide. The tap event also depends on this.
                e.preventDefault();

                // Filter the event to register the type, which can be
                // touch, mouse or pointer. Offset changes need to be
                // made on an event specific basis.
                var touch = e.type.indexOf('touch') === 0
                    , mouse = e.type.indexOf('mouse') === 0
                    , pointer = e.type.indexOf('pointer') === 0
                    , x, y, event = e;

                // IE10 implemented pointer events with a prefix;
                if (e.type.indexOf('MSPointer') === 0) {
                    pointer = true;
                }

                // Get the originalEvent, if the event has been wrapped
                // by jQuery. Zepto doesn't wrap the event.
                if (e.originalEvent) {
                    e = e.originalEvent;
                }

                if (touch) {
                    // noUiSlider supports one movement at a time,
                    // so we can select the first 'changedTouch'.
                    x = e.changedTouches[0].pageX;
                    y = e.changedTouches[0].pageY;
                }

                if (mouse || pointer) {

                    // Polyfill the pageXOffset and pageYOffset
                    // variables for IE7 and IE8;
                    if (!pointer && window.pageXOffset === undefined) {
                        window.pageXOffset = document.documentElement.scrollLeft;
                        window.pageYOffset = document.documentElement.scrollTop;
                    }

                    x = e.clientX + window.pageXOffset;
                    y = e.clientY + window.pageYOffset;
                }

                event.points = [x, y];
                event.cursor = mouse;

                return event;
            }

            // DOM additions

            // Append a handle to the base.
            function addHandle(direction, index) {

                var handle = angular.element('<div><div/></div>').addClass(SliderConstants.classes[2]),
                    additions = [ '-lower', '-upper' ];

                if (direction) {
                    additions.reverse();
                }

                handle.children().addClass(
                        SliderConstants.classes[3] + " " + SliderConstants.classes[3] + additions[index]
                );

                return handle;
            }

            // Add the proper connection classes.
            function addConnection(connect, target, handles) {

                // Apply the required connection classes to the elements
                // that need them. Some classes are made up for several
                // segments listed in the class list, to allow easy
                // renaming and provide a minor compression benefit.
                switch (connect) {
                    case 1:
                        target.addClass(SliderConstants.classes[7]);
                        handles[0].addClass(SliderConstants.classes[6]);
                        break;
                    case 3:
                        handles[1].addClass(SliderConstants.classes[6]);
                    /* falls through */
                    case 2:
                        handles[0].addClass(SliderConstants.classes[7]);
                    /* falls through */
                    case 0:
                        target.addClass(SliderConstants.classes[6]);
                        break;
                }
            }

            // Add handles to the slider base.
            function addHandles(nrHandles, direction, base) {

                var index, handles = [];

                // Append handles.
                for (index = 0; index < nrHandles; index += 1) {

                    var h = addHandle(direction, index);

                    base.append(h);

                    // Keep a list of all added handles.
                    handles.push(h);
                }

                return handles;
            }

            // Initialize a single slider.
            function addSlider(direction, orientation, target) {

                // Apply classes and data to the target.
                target.addClass([
                    SliderConstants.classes[0],
                    SliderConstants.classes[8 + direction],
                    SliderConstants.classes[4 + orientation]
                ].join(' '));

                var baseElement = angular.element('<div/>').addClass(SliderConstants.classes[1]);
                target.append(baseElement);

                return baseElement;

            }

            return {
                getPositions: getPositions,
                fixEvent: fixEvent,
                addConnection: addConnection,
                addHandles: addHandles,
                addSlider: addSlider
            };

        }]);

angular.module('mxg.components.typedValue', [
    'mxg.components.typedValue.TypedValueTypes',
    'mxg.components.typedValue.TypedValueService'
]);

angular.module('mxg.components.typedValue.TypedValueService', [
    'mxg.components.typedValue.TypedValueTypes'
])
    .service('mxgTypedValueService', [
        'mxgTypedValueTypes',
        function (TypedValueTypes) {
            'use strict';

            var service = this;

            service.getTypeDefinition = function (valueObject) {
                var keys = Object.keys(valueObject);
                var typeDefinition = null;
                if (!keys.length) {
                    return null;
                }
                keys.some(function (propertyName) {
                    return TypedValueTypes.some(function (item) {
                        if (item.valueProperty === propertyName) {
                            typeDefinition = item;
                            return true;
                        }
                        return false;
                    });
                });
                return typeDefinition;
            };

            service.parseValueType = function (valueObject) {
                var validType = service.getTypeDefinition(valueObject);
                return validType ? validType.name : null;
            };

            service.getTypedValue = function (valueObject) {
                var validType = service.getTypeDefinition(valueObject);
                return validType ? valueObject[validType.valueProperty] : null;
            };

        }]);

angular.module('mxg.components.typedValue.TypedValueTypes', [])
    .constant('mxgTypedValueTypes', [
        {
            name: 'REFERENCE',
            valueProperty: 'referenceDataValues'
        },
        {
            name: 'DATE',
            valueProperty: 'dateValue'
        },
        {
            name: 'DATE_PARTIAL',
            valueProperty: 'datePartialValue'
        },
        {
            name: 'STRING',
            valueProperty: 'stringValue'
        },
        {
            name: 'DECIMAL',
            valueProperty: 'decimalValue'
        },
        {
            name: 'INTEGER',
            valueProperty: 'intValue'
        }
    ]);

angular.module('mxg.form.controls', [
    'mxg.form.controls.FormControl',
    'mxg.form.controls.SwipeControl',
    'mxg.form.controls.Switch',
    'mxg.form.controls.SwitchGroup',
    'mxg.form.controls.SwitchSvgIcon',
    'mxg.form.controls.Vlist.VlistManager',
    'mxg.form.controls.Vlist.VlistOptions'
]);

angular.module('mxg.form.controls.FormControl', [])
    .directive('mxgFormControl', ['$log', '$timeout', function mxgFormControl($log, $timeout) {
        "use strict";

        var getTabbableChildren = function (element) {
            return element.querySelectorAll('input, a, button, select, textarea, object');
        }

        /* Directive declaration */
        return {
            restrict: 'A',
            require: ['mxgFormControl', '^?ngModel', '^?form'],
            priority: 10,
            scope: false,
            controllerAs: "formControl",
            controller: ['$element', function mxgFormControlController($element) {

                var disabled = false;

                /**
                 * @todo can be improved by just returing value of $attrs.disabled
                 * @returns {boolean}
                 */
                this.isDisabled = function () {
                    return disabled;
                };

                /**
                 *
                 * @param value
                 * @returns {mxgFormControl.mxgFormControlController}
                 */
                this.setDisabled = function (value) {
                    disabled = !!value;
                    return this;
                };

                this.setFocus = function () {
                    var children = getTabbableChildren($element[0]);
                    if (children.length > 0) {
                        children[0].focus();
                    }
                };

            }],

            link: function link($scope, $element, $attrs, ctrls) {

                var formControl = ctrls[0]
                    , ngModel = ctrls[1]
                    , formCtrl = ctrls[2] || null;

                if (!ngModel) {
                    return;
                }

                if ($attrs.mxgTabindex) {
                    $timeout(function() {
                        var tabbableElements = getTabbableChildren($element[0]);
                        angular.forEach(tabbableElements, function(el) {
                            var $el = angular.element(el);
                            if ($el.attr('tabindex') != -1) {
                                $el.attr('tabindex', $attrs.mxgTabindex);
                            }
                        });
                    }, 100);
                }

                $attrs.$observe('id', function () {
                    updateControl($attrs.id);
                });

                $attrs.$observe('disabled', function (value) {
                    formControl.setDisabled(value);
                });

                function updateControl(formControlId) {

                    if (formControlId) {
                        var prevName = ngModel.$name;

                        $element.attr('name', formControlId);
                        ngModel.$name = formControlId;

                        if (formCtrl) {
                            if (angular.isDefined(formCtrl[undefined])) {
                                delete formCtrl[undefined];
                            }

                            if (prevName) {
                                delete formCtrl[formControlId];
                            }
                            formCtrl.$addControl(ngModel);
                        }

                    }

                }

            }
        };

    }]);

angular.module('mxg.form.controls.SwipeControl', [])
    .directive('mxgSwipeControl', [
        function mxgSwipeControl() {
            "use strict";

            var SwipeControl = (function () {

                function SwipeControl(element, radius) {
                    this.element = element;
                    this.radius = radius || 75;
                    this.side = null;
                    this.bindings = {};

                    for (var i = 0; i < SwipeControl.sides.length; i++) {
                        this.bindings[SwipeControl.sides[i]] = function () {};
                    }

                    this.bindElement();
                }

                SwipeControl.maxRatio = 0.3;
                SwipeControl.sides = ['right', 'left', 'up', 'down'];

                SwipeControl.prototype.getCoordinates = function (event) {
                    var originalEvent = event.originalEvent || event;
                    var touches = originalEvent.touches && originalEvent.touches.length ? originalEvent.touches : [originalEvent];
                    var e = (originalEvent.changedTouches && originalEvent.changedTouches[0]) || touches[0];

                    return {
                        x: e.clientX,
                        y: e.clientY
                    };
                };

                SwipeControl.prototype.bindElement = function () {
                    var totalX, totalY;
                    var startCoords;
                    var lastPos;
                    var active = false;
                    var _this = this;

                    this.element.on('touchstart', function (event) {
                        startCoords = _this.getCoordinates(event);
                        active = true;
                        totalX = 0;
                        totalY = 0;
                        lastPos = startCoords;
                    });

                    this.element.on('touchmove', function (event) {
                        if (!active || !startCoords) {
                            return;
                        }

                        lastPos = _this.getCoordinates(event);
                        totalX = Math.abs(lastPos.x - startCoords.x);
                        totalY = Math.abs(lastPos.y - startCoords.y);

                        if (totalX > _this.radius || totalY > _this.radius) {

                            if (totalX / totalY < SwipeControl.maxRatio) {
                                // Swipe Vertical
                                if (lastPos.y - startCoords.y > 0) {
                                    _this.side = "down";
                                } else {
                                    _this.side = "up";
                                }
                            } else if (totalY / totalX < SwipeControl.maxRatio) {
                                // Swipe Horizontal
                                if (lastPos.x - startCoords.x > 0) {
                                    _this.side = "right";
                                } else {
                                    _this.side = "left";
                                }
                            }
                        }
                    });

                    this.element.on('touchend', function (event) {
                        if (!active || !_this.side) {
                            return void 0;
                        }
                        _this.bindings[_this.side]();
                        _this.side = null;
                        active = false;
                    });

                    this.element.on('touchcancel', function (event) {
                        active = false;
                    });

                };

                return SwipeControl;
            })();

            return {
                restrict: "A",
                scope: {
                    swipe: '&mxgSwipeControl'
                },
                link: function link($scope, $element, $attrs, ctrls) {
                    var controls = $scope.swipe($scope);
                    if (controls.action && typeof controls.action == 'function') {
                        var swipeControl = new SwipeControl($element, controls.radius);
                        var func = controls.action;

                        for (var control in controls) {
                            if (SwipeControl.sides.indexOf(control) > -1) {
                                swipeControl.bindings[control] = function (param) {
                                    return function(){
                                        $scope.$apply(function () {
                                            func(param);
                                        });
                                    }
                                }(controls[control]);
                            }
                        }
                    }
                }
            }
        }
    ]);

angular.module('mxg.form.controls.Switch', [])
    .directive('mxgSwitch', ['$parse', function ($parse) {
        "use strict";

        var SwitchObject = function (type, captionSource) {

            type = (this.supportedTypes.indexOf(type) === -1) ? 'checkbox' : type;

            this.type = type;
            this.switchFunction = this.defaultSwitchFunctions[type];
            this.captionSource = captionSource || '';

        };

        SwitchObject.prototype.supportedTypes = ['checkbox', 'radio'];

        SwitchObject.prototype.defaultSwitchFunctions = {
            checkbox: function (oldValue) {
                return !oldValue;
            },
            radio: function (oldValue) {
                return oldValue || true;
            }
        };

        SwitchObject.prototype.getCaption = function (boolValue) {
            if (angular.isArray(this.captionSource)) {
                var stateIndex = boolValue * 1;
                stateIndex = angular.isDefined(this.captionSource[stateIndex]) ? stateIndex : 0;
                return this.captionSource[stateIndex];
            }
            else {
                return this.captionSource;
            }
        };

        /* Directive declaration */

        /*
         *
         * expected attributes:
         *  - id
         *  - mxg-switch ['checkbox','radio']
         *  - noicon
         *  - caption
         *  - false-caption
         *  - true-caption
         *
         * it is also possible to specify ng-change function to listen to ngModel change event
         *
         * if caption attribute is defined, false-cation and true-caption attributes will be ignored
         * */

        return {

            restrict: 'A',
            require: ['?ngModel', '?^mxgSwitchGroup'],

            link: function ($scope, $element, $attrs, ctrls) {

                var ngModel = ctrls[0] || null;
                var switchGroup = ctrls[1] || null;

                if (!ngModel) {
                    return;
                }

                var type, itemCode;

                if (angular.isObject(switchGroup) && $attrs.groupItem) {

                    type = switchGroup.type;

                    itemCode = $parse($attrs.groupItem)($scope);

                    if (angular.isDefined(itemCode)) {
                        switchGroup.addItem(itemCode);
                    }

                }
                else {
                    type = $attrs.mxgSwitch;
                }

                $scope.switchType = type;

                var captions;

                captions = $attrs.caption || '';

                if (!captions && ($attrs.falseCaption || $attrs.trueCaption)) {
                    captions = [
                            $attrs.falseCaption || '',
                            $attrs.trueCaption || ''
                    ];
                }

                var switchInstance = new SwitchObject(type, captions);

                var switchElement = $element;

                var iconElement, captionElement;

                if (angular.isUndefined($attrs.noicon)) {
                    iconElement = angular.element('<span></span>').addClass('mxg-switch-icon');
                    switchElement.append(iconElement);
                }

                if (captions) {
                    captionElement = angular.element('<span></span>').addClass('mxg-switch-caption');
                    switchElement.append(captionElement);
                }

                $attrs.$observe('id', function () {
                    updateIds($attrs.id || $element[0].id);
                });

                function updateIds(baseId) {
                    if (baseId) {
                        iconElement && (iconElement[0].id = baseId + '_icon');
                        captionElement && (captionElement[0].id = baseId + '_caption');
                    }
                }

                ngModel.$render = function () {
                    updateView(!!this.$modelValue);
                };

                switchElement
                    .addClass('mxg-switch mxg-switch' + '-' + switchInstance.type)
                    .on('click', function () {

                        var oldValue = angular.copy(ngModel.$modelValue);
                        var newValue = switchInstance.switchFunction(oldValue);

                        if (newValue !== oldValue) {
                            $scope.$apply(function () {
                                ngModel.$setViewValue(newValue);
                                ngModel.$render();
                            });
                        }

                    });

                function updateView(selected) {
                    switchElement
                        .toggleClass('mxg-switch-state-off', !selected)
                        .toggleClass('mxg-switch-state-on', selected);
                    captionElement && (captionElement.text(switchInstance.getCaption(selected)));
                }

                if (switchGroup && angular.isDefined(itemCode)) {

                    $element.addClass('mgx-group-item-' + itemCode);

                    ngModel.$viewChangeListeners.push(function () {
                        switchGroup.onItemChange(itemCode);
                    });

                    $element.on('$destroy', function () {
                        switchGroup.removeItem(itemCode);
                    });

                }

            }

        };

    }]);



angular.module('mxg.form.controls.SwitchGroup', ['mxg.form.controls.Switch'])
    .directive('mxgSwitchGroup', ['$log', function ($log) {
        "use strict";

        /* Directive declaration */

        /*
         * expected attributes:
         * - id
         * - group-type ['checkbox', 'radio]
         *
         * */
        return {

            restrict: 'A',
            require: ['^ngModel', 'mxgSwitchGroup'],

            controller: [function () {

                var switchGroup = this;

                var groupValueModel = null;

                switchGroup.initNgModel = function(ngModel) {
                    groupValueModel = ngModel;
                };

                switchGroup.type = 'checkbox';
                switchGroup.items = {};

                switchGroup.addItem = function addItem(code) {
                    if (angular.isUndefined(switchGroup.items[code])) {
                        switchGroup.items[code] = {
                            id: code,
                            selected: false
                        };
                    }

                    if (groupValueModel) {
                        var groupValue = angular.copy(groupValueModel.$modelValue);
                        groupValue = angular.isArray(groupValue) ? groupValue: [groupValue];

                        switchGroup.items[code].selected = groupValue.indexOf(code) !== -1;
                    }

                };

                switchGroup.removeItem = function removeItem(key) {
                    delete switchGroup.items[key];
                };

            }],

            controllerAs: 'switchGroup',

            link: function ($scope, $element, $attrs, ctrls) {

                var ngModel = ctrls[0];
                var switchGroup = ctrls[1];

                switchGroup.type = $attrs.mxgSwitchGroup || 'checkbox';

                switchGroup.initNgModel(ngModel);

                ngModel.$render = function switchGroupModelRender() {

                    var codes = [];

                    if (!ngModel.$isEmpty(this.$modelValue)) {
                        codes = angular.copy(this.$modelValue);
                        codes = angular.isArray(codes) ? codes : [codes];
                    }

                    if (codes.length === 0) {
                        //empty value
                        angular.forEach(switchGroup.items, function (item) {
                            item.selected = false;
                        });
                        return;
                    }

                    if (switchGroup.type === 'radio') {
                        var code = codes[0];
                        if (angular.isUndefined(switchGroup.items[code])) {
                            switchGroup.items[code] = {
                                id: code,
                                selected: true
                            };
                        }
                        angular.forEach(switchGroup.items, function (item) {
                            item.selected = item.id === code;
                        });
                    }

                    if (switchGroup.type === 'checkbox') {
                        angular.forEach(switchGroup.items, function (item) {
                            item.selected = codes.indexOf(item.id) !== -1;
                        });
                    }

                };

                switchGroup.onItemChange = function onSwitchGroupItemChange(code) {

                    var itemSelected = switchGroup.items[code].selected;

                    var groupValue;

                    if ((switchGroup.type === 'radio') && itemSelected) {
                        groupValue = code;
                    }

                    if (switchGroup.type === 'checkbox') {
                        var modelValue = angular.isArray(ngModel.$modelValue) ? angular.copy(ngModel.$modelValue) : [];
                        var itemIndex = modelValue.indexOf(code);
                        if (itemSelected && (itemIndex === -1)) {
                            modelValue.push(code);
                            groupValue = modelValue;
                        }
                        if (!itemSelected && (itemIndex !== -1)) {
                            modelValue.splice(itemIndex, 1);
                            groupValue = modelValue;
                        }
                    }

                    if (angular.isDefined(groupValue)) {
                        ngModel.$setViewValue(groupValue);
                        ngModel.$render();
                    }

                };

            }

        };

    }]);

angular.module('mxg.form.controls.SwitchSvgIcon', [])
    .directive('mxgSwitchSvgIcon', ['$templateCache', function ($templateCache) {
        "use strict";

        var iconTemplatesMap = {
            checkbox: $templateCache.get('mxg-template/form/controls/switchIconCheckbox.html'),
            radio: $templateCache.get('mxg-template/form/controls/switchIconRadio.html')
        };

        return {
            restrict: 'A',
            priority: 900,
            scope: false,
            link: function link($scope, $element, $attrs) {

                var iconElement = angular.element($element[0].querySelector('.mxg-switch-icon'));
                if (iconElement.length) {
                    iconElement.append(angular.element(iconTemplatesMap[$scope.switchType || 'checkbox']));
                }

            }
        };

    }]);

angular.module('mxg.form.controls.Vlist.VlistOptions',
    [
        'mxg.helpers.KeyCode',
        'mxg.helpers.EventsHelper',
        'mxg.helpers.RefDataHelper',
        'mxg.helpers.PositionHelper',
        'mxg.magnum.MagnumContainerElement'
    ])
    .directive('mxgVlist', [
        '$timeout', '$document', 'mxgKeyCode', 'mxgEventsHelper', 'mxgRefDataHelper', 'mxgPositionHelper', 'MagnumContainerElement',
        function mxgVlist($timeout, $document, KEY_CODE, EventsHelper, RefDataHelper, PositionHelper, MagnumContainerElement) {
            "use strict";

            return {
                restrict: 'AE',
                require: '?^mxgVlistManager',
                templateUrl: 'mxg-template/form/controls/Vlist.html',
                scope: {
                    visibleLimit: '@mxgVisibleLimit',
                    onSelect: '&mxgOnSelect',
                    onExit: '&mxgOnExit'
                },

                link: function mxgVlistLink($scope, $element, attrs, vlistManager) {

                    if (vlistManager) {
                        vlistManager.register($scope);
                    }

                    $element.addClass('mxg-vlist');

                    $element.css({
                        'display': 'block',
                        'overflow-y': 'auto'
                    });

                    var rowHeight = 0;
                    var dataSource = [];

                    var numberOfCells = 0;
                    var rowsVisible = parseInt($scope.visibleLimit, 10) || 10;

                    var _visible = false;

                    $scope.visibleProvider = [];
                    $scope.containerStyle = {};

                    $scope.getVisible = function () {
                        return _visible;
                    };

                    $scope.setVisible = function (value) {
                        if (value !== _visible) {
                            if (value) {
                                var style = {
                                    'display': 'block'
                                };

                                var magnumContainer = MagnumContainerElement.get();

                                if (magnumContainer && PositionHelper.visible(magnumContainer) && magnumContainer[0].contains($element[0])) {
                                    var element = this.$parent.getElement ? this.$parent.getElement() : $element;
                                    var parent = element.parent();

                                    var magnumPosition = PositionHelper.offset(magnumContainer);
                                    var elementHeight = PositionHelper.height(element);

                                    var bottom = PositionHelper.height($element) > magnumPosition.top + magnumPosition.height - PositionHelper.offset(parent).top - elementHeight;

                                    if (bottom) {
                                        style.top = 'auto';
                                        style.bottom = '100%';
                                    } else {
                                        style.top = '100%';
                                        style.bottom = 'auto';
                                    }
                                } else {
                                    style.top = '100%';
                                    style.bottom = 'auto';
                                }

                                $element.css(style);
                            } else {
                                $element.css({
                                    'display': 'none'
                                });
                            }
                        }
                        _visible = value;
                    };

                    $scope.setDataSource = function (data) {

                        dataSource.length = 0;
                        if (angular.isArray(data)) {
                            dataSource = angular.copy(data);
                            $scope.containerStyle.height = (dataSource.length * rowHeight + 2) + 'px';
                            $element[0].scrollTop = 0;
                            updateDisplayList(0);
                        }

                    };

                    $scope.onOptionKeydown = function (event, currentOption) {

                        var pressed = event.keyCode;

                        var currentIndex;
                        var delta;
                        var direction;
                        var nextOption;

                        if (EventsHelper.checkAdditionalKeyPressed(event)) {
                            return;
                        }

                        event.preventDefault();
                        event.stopPropagation();

                        if (pressed === KEY_CODE.ESCAPE || pressed === KEY_CODE.TAB) {
                            event.currentTarget.blur();
                            emitExit(pressed === KEY_CODE.ESCAPE);
                            return;
                        }

                        if (EventsHelper.checkSelectOptionEvent(event)) {
                            $scope.onClickOption(currentOption);
                            return;
                        }

                        currentIndex = $scope.visibleProvider.indexOf(currentOption);

                        if (EventsHelper.checkNavigationEvent(event) && (currentIndex !== -1)) {

                            switch (pressed) {
                                case KEY_CODE.UP:
                                    if (currentOption.index > 0) {
                                        delta = -1;
                                        direction = 'top';
                                    }
                                    break;
                                case KEY_CODE.DOWN:
                                    if (currentOption.index < dataSource.length - 1) {
                                        delta = 1;
                                        direction = 'bottom';
                                    }
                                    break;
                                case KEY_CODE.PAGE_UP:
                                    if (currentOption.index - rowsVisible > 0) {
                                        delta = -rowsVisible;
                                    }
                                    else {
                                        delta = -currentOption.index;
                                    }
                                    direction = 'top';
                                    break;
                                case KEY_CODE.PAGE_DOWN:
                                    if (currentOption.index + rowsVisible < dataSource.length - 1) {
                                        delta = rowsVisible;
                                    }
                                    else {
                                        delta = dataSource.length - 1 - currentOption.index;
                                    }
                                    direction = 'bottom';
                                    break;
                                case KEY_CODE.HOME:
                                    delta = -currentOption.index;
                                    direction = 'top';
                                    break;
                                case KEY_CODE.END:
                                    delta = dataSource.length - 1 - currentOption.index;
                                    direction = 'bottom';
                                    break;
                                default:
                                //
                            }

                            if (angular.isUndefined(delta)) {
                                return;
                            }

                            nextOption = dataSource[currentOption.index + delta];

                            var visibleOption;
                            visibleOption = RefDataHelper.getItemByCode($scope.visibleProvider, nextOption.code);

                            if (!visibleOption || (visibleOption.offset < 0) || (visibleOption.offset >= rowsVisible)) {
                                findAndScroll(nextOption, direction);
                            }
                            $scope.setFocusByCode(nextOption.code);
                        }

                        return false;

                    };

                    $scope.onOptionKeyup = function (event) {

                        var pressed = event.keyCode;

                        if (event.ctrlKey && (pressed === KEY_CODE.UP)) {
                            event.preventDefault();
                            event.stopPropagation();
                            emitExit(false);

                            return false;
                        }

                    };

                    $scope.onClickOption = function (option) {
                        $scope.onSelect({option: option});
                        return false;
                    };

                    $scope.onOptionBlur = function () {
                        $timeout(function () {
                            var activeElement = angular.element($document[0].activeElement);
                            if (!activeElement.length
                                || !(activeElement.attr('data-mxg-option-code') || activeElement == $element)) {
                                emitExit(false);
                            }
                        });
                    };

                    $scope.setFocusByCode = function (code) {
                        if (code === null) {
                            return;
                        }
                        $timeout(function () {
                            var optionElement = $element[0].querySelector('[data-mxg-option-code="' + code + '"]');
                            if (optionElement) {
                                optionElement.focus();
                            }
                        }, 20);
                    };

                    $scope.scrollTo = function (code) {
                        findAndScroll(code, 'top');
                    };

                    $scope.getTopVisibleOption = function () {

                        if (!$scope.visibleProvider.length) {
                            return null;
                        }

                        var option = null;

                        $scope.visibleProvider.some(function (item) {
                            if (item.offset >= 0) {
                                option = item;
                                return true;
                            }
                            return false;
                        });

                        return option ? option.code : null;
                    };

                    $element.on('mousedown', function (event) {
                        event.preventDefault();
                        return false;
                    });

                    init();

                    function init() {

                        var optionElement = $element[0].querySelector('.mxg-vlist_option');
                        if (optionElement) {
                            rowHeight = optionElement.clientHeight;
                            if (!rowHeight || rowHeight < 27) {
                                rowHeight = 27;
                            }
                            $element.css('max-height', rowHeight * rowsVisible + 2 + 'px');
                            angular.element(optionElement).remove();
                        }
                        numberOfCells = 3 * rowsVisible;
                        $element.css({
                            'display': 'none'
                        });

                    }

                    function updateDisplayList(scrollTop) {
                        $element.off('scroll', onScroll);
                        var topOffset = Math.floor(scrollTop / rowHeight);
                        var firstCell = Math.max(Math.floor(scrollTop / rowHeight) - rowsVisible, 0);
                        var cellsToCreate = Math.min(firstCell + numberOfCells, numberOfCells);
                        $scope.visibleProvider.length = 0;
                        $scope.visibleProvider = angular.copy(dataSource.slice(firstCell, firstCell + cellsToCreate));
                        for (var i = 0; i < $scope.visibleProvider.length; i++) {
                            var params = {
                                index: firstCell + i,
                                offset: firstCell + i - topOffset,
                                styles: {
                                    top: ((firstCell + i) * rowHeight) + 1 + 'px'
                                }
                            };
                            angular.extend($scope.visibleProvider[i], params);
                        }

                        $element.on('scroll', onScroll);
                    }

                    function onScroll(event) {
                        event.stopPropagation();
                        updateDisplayList($element[0].scrollTop);
                        $scope.$apply();
                    }

                    function findAndScroll(item, direction) {

                        if (!angular.isArray(dataSource) || !dataSource.length) {
                            return;
                        }

                        var code;
                        var option;
                        var scrollTopIndex;

                        if (angular.isObject(item)) {
                            option = item;
                            code = item.code;
                        }
                        else {
                            code = item;
                            option = RefDataHelper.getItemByCode(dataSource, code);
                        }

                        if (!option) {
                            return;
                        }

                        scrollTopIndex = dataSource.indexOf(option);
                        if (direction === 'bottom') {
                            scrollTopIndex = Math.max(scrollTopIndex - rowsVisible + 1, 0);
                        }

                        $element[0].scrollTop = scrollTopIndex * rowHeight;
                        updateDisplayList(scrollTopIndex * rowHeight);

                    }

                    function emitExit() {
                        var onListExit = $scope.onExit();
                        if (angular.isFunction(onListExit)) {
                            onListExit.apply(null, Array.prototype.slice.call(arguments));
                        }
                    }

                } /* link function */
            };

        }]);

angular.module('mxg.form.controls.Vlist.VlistManager', ['mxg.form.controls.Vlist.VlistOptions'])
    .directive('mxgVlistManager', ['$q', function mxgVlistManager($q) {
        "use strict";

        return {
            restrict: 'A',
            scope: false,
            controller: ['$scope', '$timeout', function mxgVlistManagerController($scope, $timeout) {

                var vlistManager = this;

                var vlistScope = null;

                vlistManager.register = function vlistManagerRegister(scope) {
                    vlistScope = scope;
                };

                vlistManager.getVisible = function () {
                    return vlistScope ? vlistScope.getVisible() : false;
                };

                vlistManager.show = function () {
                    return evalAsync(function () {
                        vlistScope.setVisible(true);
                    });
                };

                vlistManager.hide = function () {
                    return evalAsync(function () {
                        vlistScope.setVisible(false);
                    });
                };

                vlistManager.setOptionsSource = function vlistManagerSetOptionsSource(data) {
                    return evalAsync(function () {
                        vlistScope.setDataSource(data);
                    });
                };

                vlistManager.scrollTo = function vlistManagerScrollTo(code) {
                    return evalAsync(function () {
                        vlistScope.scrollTo(code);
                    });
                };

                vlistManager.setFocusByCode = function vlistManagerSetFocus(code) {
                    vlistScope.scrollTo(code);
                    vlistScope.setFocusByCode(code);
                };

                vlistManager.focus = function vlistManagerFocus() {
                    var candidate;
                    if (vlistScope.getVisible()) {
                        candidate = vlistScope.getTopVisibleOption();
                        vlistScope.setFocusByCode(candidate);
                    }
                    else {
                        vlistManager.show().then(function () {
                            candidate = vlistScope.getTopVisibleOption();
                            vlistScope.setFocusByCode(candidate);
                        });
                    }

                };

                function evalAsync(actionFn) {

                    if (!vlistScope || !angular.isFunction(actionFn)) {
                        return $q.when(false);
                    }
                    var deferred = $q.defer();
                    $timeout(function () {
                        actionFn();
                        deferred.resolve(true);
                    });
                    return deferred.promise;

                }

            }],
            controllerAs: 'vlistManager'
        };

    }]);

angular.module('mxg.form.validation.ValidationElement', ['mxg.validation.ValidationErrorMap'])
    .directive('mxgValidationElement', ['mxgValidationErrorMap', function (ValidationErrorMap) {
        "use strict";
        return {
            controller: [
                '$scope', '$element', '$attrs',
                function ($scope, $element, $attrs) {
                    var elementId = $scope.$eval($attrs.mxgValidationElement);
                    this.validationMessageExists = function () {
                        return ValidationErrorMap.exists(elementId);
                    };

                    this.getValidationMessages = function () {
                        return ValidationErrorMap.find(elementId);
                    };
                }],
            controllerAs: 'validationElement',
            link: function (scope, element, attrs) {
            }
        }
    }]);

angular.module('mxg.form.validation.ValidationTooltipTrigger', [])
    .directive('mxgValidationTooltipTrigger', ['$compile', '$rootScope', function ($compile, $rootScope) {
        "use strict";
        var template = $compile('<div class="mxg-validation-tooltip-container"><div ng-include="\'mxg-template/form/validation/validationTooltip.html\'"></div></div>');
        var tooltipScope = $rootScope.$new();
        var validationTooltip = template(tooltipScope);

        return {
            require: '^?mxgValidationElement',
            link: function (scope, element, attributes, validationElement) {
                if (!validationElement) {
                    return;
                }
                var el = element[0];
                var enabled = function () {
                    return true;
                };
                attributes.$observe('mxgValidationTooltipTrigger', function (value) {
                    if ((value !== undefined) && (value !== "")) {
                        enabled = function () {
                            return scope.$eval(value);
                        };
                    }
                });

                scope.$watch(function () {
                        return enabled();
                    },
                    function (newValue) {
                        if (!newValue) {
                            validationTooltip && validationTooltip.remove();
                        }
                    }
                );

                element.on('mouseover', function (event) {
                    if (!enabled()) {
                        return validationTooltip && validationTooltip.remove();
                    }
                    if (!validationElement.validationMessageExists()) {
                        return;
                    }

                    validationTooltip.css('top', (el.clientHeight + el.offsetTop) + "px");
                    tooltipScope.$apply(function () {
                        tooltipScope.errors = validationElement.getValidationMessages();
                    });
                    element.after(validationTooltip);
                });

                element.one('touchend', function () {
                    enabled = function () {
                        return false;
                    };
                });

                element.on('mouseout', function () {
                    validationTooltip && validationTooltip.remove();
                });
            }
        }
    }]);

angular.module('mxg.form.validationBanner.ValidationBanner', [
    'mxg.validation.ValidationErrorMap',
    'mxg.translation'
])
    .directive('mxgValidationBanner', ['mxgValidationErrorMap', function (ValidationErrorMap) {
        "use strict";
        return {
            templateUrl: "mxg-template/form/validationBanner/ValidationBanner.html",
            scope: {
                locator: "@mxgLocator"
            },
            link: function (scope, element) {
                var detailsExpanded = false;

                scope.errorsExist = function () {
                    return ValidationErrorMap.exists(scope.locator);
                };

                scope.getErrors = function () {
                    return ValidationErrorMap.find(scope.locator);
                };

                scope.getUniqueErrors = function () {
                    var uniqueMessages = [];
                    return ValidationErrorMap.find(scope.locator).filter(function (error) {
                        if (error.ruleId == '4009') {
                            return false;
                        }
                        if (uniqueMessages.indexOf(error.message) !== -1) {
                            return false;
                        }
                        uniqueMessages.push(error.message);
                        return true;
                    })
                };

                scope.detailsExist = function () {
                    return true;
                };

                scope.toggleDetails = function () {
                    detailsExpanded = !detailsExpanded;
                };

                scope.detailsAreExpanded = function () {
                    return detailsExpanded;
                };

            }
        }
    }]);

angular.module('mxg.form.widget.Statuses', [])
    .constant('mxgWidgetStatuses', {
        EMPTY: 'Empty',
        VALIDATING: 'Validating',
        AWAIT_CONFIRMATION: 'Confirmation required',
        RECOGNISED: 'Recognised',
        UNRECOGNISED: 'Unrecognised'
    });
angular.module('mxg.form.widgets.WidgetCheckbox', ['mxg.form.controls.Switch'])
    .directive('mxgWidgetCheckbox', ['$templateCache', function ($templateCache) {
        "use strict";

        var iconTemplate = $templateCache.get('mxg-template/form/controls/switchIconCheckbox.html');

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            scope: {
                checkboxLabel: '@mxgLabel'
            },
            templateUrl: 'mxg-template/form/widgets/WidgetCheckbox.html',

            link: function ($scope, $element, $attrs, ngModel) {

                $element.addClass('mxg-widget mxg-widget-checkbox');

                $scope.selected = null;

                $attrs.$observe('id', function () {
                    updateIds($attrs.id);
                });

                $scope.getIconTemplate = function() {
                    return iconTemplate;
                };

                $scope.getDisabled = function () {
                    return !!$attrs.disabled;
                };

                function updateIds(elementId) {
                    if (elementId) {
                        var switchElement = $element.find('button').eq(0);
                        if (!switchElement.length) {
                            return;
                        }
                        switchElement[0].id = elementId + '_input';
                    }
                }

                ngModel.$isEmpty = function(value) {
                    return angular.isUndefined(value) || (value === null) || (typeof value !== 'boolean');
                };

                ngModel.$render = function widgetCheckboxModelRender() {

                    var switchElement = $element.find('button').eq(0);
                    if (!switchElement.length) {
                        return;
                    }
                    if (ngModel.$isEmpty(ngModel.$modelValue)) {
                        $scope.selected = null;
                        switchElement.toggleClass('mxg-checkbox-state-empty', true);
                    }
                    else {
                        $scope.selected = this.$modelValue;
                        switchElement.toggleClass('mxg-checkbox-state-empty', false);
                    }

                };

                $scope.onSwitchChange = function() {

                    ngModel.$setViewValue($scope.selected);
                    ngModel.$render();

                };

            }

        };

    }]);

angular.module('mxg.form.widgets.WidgetCombobox',
    ['mxg.form.controls.Vlist.VlistManager',
     'mxg.form.controls.Vlist.VlistOptions',
     'mxg.form.widgets.WidgetComboboxCtrl'
    ])
    .directive('mxgWidgetCombobox', ['$timeout', function mxgWidgetCombobox($timeout) {
            "use strict";

            /* Directive declaration */
            return {
                restrict: 'AE',
                require: 'ngModel',
                templateUrl: 'mxg-template/form/widgets/WidgetCombobox.html',
                scope: {
                    elementId: '@id',
                    refSource: '=',
                    height: '@',
                    initFocus: '@',
                    onComplete: '&mxgOnComplete'
                },
                controller: 'mxgWidgetComboboxCtrl',
                controllerAs: 'widgetCtrl',
                link: function mxgWidgetComboboxLink($scope, $element, $attrs, ngModel) {
                    $element.addClass('mxg-widget mxg-widget-combobox');

                    $scope.widgetCtrl.setModelCtrl(ngModel);

                    $attrs.$observe('mxgFocus', function (value) {
                        if (value) {
                            $timeout(function () {
                                $element[0].querySelector('.mxg-widget-combobox_input').focus();
                                $attrs.$set('mxgFocus', null);
                            });
                        }
                    });
                } /* link function */
            };
        }]);

angular.module('mxg.form.widgets.WidgetComboboxCtrl', [
    'mxg.form.controls.Vlist.VlistManager',
    'mxg.form.controls.Vlist.VlistOptions',
    'mxg.helpers.KeyCode',
    'mxg.helpers.EventsHelper',
    'mxg.helpers.RefDataHelper'
])
    .controller('mxgWidgetComboboxCtrl',
        ['$scope', '$element', '$q', '$timeout', '$document', 'mxgKeyCode', 'mxgEventsHelper', 'mxgRefDataHelper',
         function ($scope, $element, $q, $timeout, $document, KeyCode, EventsHelper, RefDataHelper) {
             'use strict';
             var widgetCtrl = this;
             var modelCtrl = null;
             var valueDirty = false;
             var typeAheadActive = false;

             widgetCtrl.modelOptions = {
                 getterSetter: true,
                 allowInvalid: true,
                 updateOn: 'default blur',
                 debounce: {default: 100, blur: 0}
             };

             widgetCtrl.setModelCtrl = function (ctrl) {
                 modelCtrl = ctrl;
             };

             widgetCtrl.getElementId = function (elementName) {
                 return [$scope.elementId || '', elementName].join('_');
             };

             widgetCtrl.widgetValue = function (value) {
                 if (!modelCtrl) {
                     return null;
                 }
                 if (angular.isDefined(value)) {
                     var prevValue = modelCtrl.$viewValue;
                     var newValue;
                     if (!value) {
                         newValue = null;
                     }
                     else {
                         newValue = RefDataHelper.getCodeByName($scope.refSource, value) || value;
                     }
                     if (newValue !== prevValue) {
                         modelCtrl.$setViewValue(newValue);
                         valueDirty = true;
                     }
                 } else {
                     return modelCtrl.$isEmpty(modelCtrl.$viewValue) ? '' : RefDataHelper.getNameByCode($scope.refSource, modelCtrl.$viewValue) || modelCtrl.$viewValue;
                 }
             };

             widgetCtrl.onInputFocus = function (asClick) {
                 typeAheadActive = false;
                 if ($scope.vlistManager.getVisible()) {
                     return;
                 }
                 if (asClick) {
                     showOption(modelCtrl.$viewValue);
                 } else {
                     resetFilter();
                 }
             };

             widgetCtrl.onToggleClick = function (event) {
                 typeAheadActive = false;
                 event.preventDefault();
                 if ($scope.vlistManager.getVisible()) {
                     $scope.vlistManager.hide();
                 } else {
                     showOption(modelCtrl.$viewValue);
                 }
                 return false;
             };

             widgetCtrl.onTypeAhead = function onTypeAhead(inputValue) {
                 typeAheadActive = true;
                 if (!inputValue) {
                     resetFilter();
                     return;
                 }
                 var filteredData = RefDataHelper.filterByNameSmartContainsSmartOrder($scope.refSource,
                     inputValue);
                 if (angular.isArray(filteredData) && filteredData.length) {
                     $scope.vlistManager
                         .setOptionsSource(filteredData)
                         .then($scope.vlistManager.show);
                 } else {
                     $scope.vlistManager.hide();
                 }
             };

             widgetCtrl.onSelectOption = function (option) {
                 $timeout(function () {
                     typeAheadActive = false;
                     widgetCtrl.widgetValue(option.name);
                     $scope.vlistManager.hide().then(function () {
                         setFocusOnInput();
                     });
                     onValueReady();
                 });
             };

             widgetCtrl.onInputKeydown = function (event) {
                 var pressed = event.keyCode;
                 if (EventsHelper.checkAdditionalKeyPressed(event)) {
                     return;
                 }
                 if (pressed === KeyCode.DOWN) {
                     event.preventDefault();
                     event.stopPropagation();
                     if (!typeAheadActive) {
                         widgetCtrl.widgetValue(null);
                     }
                     if ($scope.vlistManager.getVisible()) {
                         $scope.vlistManager.focus();
                     } else {
                         showOption(modelCtrl.$viewValue);
                     }
                 }
             };

             widgetCtrl.onInputBlur = function () {
                 checkBlurEvent().then(function (realExit) {
                     realExit && onWidgetExit();
                 });
             };

             widgetCtrl.onListExit = function (needReturn) {
                 checkBlurEvent().then(function (realExit) {
                     if (realExit) {
                         if (needReturn) {
                             setFocusOnInput();
                         } else {
                             onWidgetExit();
                         }
                     }
                 });
             };

             function checkIsDescendant(parent, child) {
                 var node = child.parentNode;
                 while (node != null) {
                     if (node == parent) {
                         return true;
                     }
                     node = node.parentNode;
                 }
                 return false;
             }

             function checkBlurEvent() {
                 var deferred = $q.defer();
                 $timeout(function () {
                     var activeElement = angular.element($document[0].activeElement);
                     if (!activeElement.length
                         || (activeElement[0].tagName === 'BODY')
                         || !checkIsDescendant($element[0], activeElement[0])
                     ) {
                         deferred.resolve(true);

                     }
                     else {
                         deferred.resolve(false);
                     }
                 });
                 return deferred.promise;

             }

             function resetFilter() {
                 return $scope.vlistManager.setOptionsSource($scope.refSource);
             }

             function showOption(candidate) {
                 var code = null;
                 if (candidate) {
                     code = RefDataHelper.getNameByCode($scope.refSource,
                         candidate) ? candidate : getDefaultOption();
                 } else {
                     code = getDefaultOption();
                 }
                 if (code) {
                     return resetFilter()
                         .then($scope.vlistManager.show)
                         .then(function () {
                             return $scope.vlistManager.setFocusByCode(code);
                         });
                 } else {
                     return $scope.vlistManager.hide();
                 }
             }

             function getDefaultOption() {
                 if (!$scope.refSource.length) {
                     return null;
                 }
                 var candidate;
                 if (angular.isDefined($scope.initFocus)) {
                     candidate = $scope.initFocus;
                 }
                 return modelCtrl.$isEmpty(candidate) ? $scope.refSource[0].code : candidate;
             }

             function getInputElement() {
                 return $element[0].querySelector('.mxg-widget-combobox_input');
             }

             function setFocusOnInput() {
                 var inputElement = getInputElement();
                 inputElement && inputElement.focus();
             }

             function onWidgetExit() {
                 $scope.vlistManager.hide();
                 typeAheadActive = false;
                 onValueReady();
             }

             function onValueReady() {
                 if (valueDirty) {
                     $scope.onComplete();
                     valueDirty = false;
                 }
             }

         }]);

angular.module('mxg.form.widgets.WidgetDatePartial', [
    'mxg.components.datepicker',
    'mxg.form.widgets.WidgetDatePartialCtrl'
])
    .directive('mxgWidgetDatePartial',
        ['$timeout', '$document', function ($timeout, $document) {
            "use strict";
            return {
                restrict: 'AE',
                templateUrl: 'mxg-template/form/widgets/WidgetDatePartial.html',
                require: 'ngModel',
                scope: {
                    elementId: '@id',
                    inputFormat: '@?',
                    minDate: '@?',
                    maxDate: '@?',
                    initDate: '@?',
                    initOffset: '@initFocusOffset',
                    offsetUnits: '@initFocusUnits',
                    onComplete: '&mxgOnComplete'
                },
                controller: 'mxgWidgetDatePartialCtrl',
                controllerAs: 'widgetCtrl',
                link: function link($scope, $element, $attrs, ngModel) {

                    $scope.widgetCtrl.setModelCtrl(ngModel);

                    $element.addClass(
                        'mxg-widget mxg-widget-date-partial mxg-date-partial_parts_' + $scope.widgetCtrl.getDatePartsCount());

                    $scope.checkNextFocus = function (partInput, index, last) {
                        if (!last) {
                            $timeout(function () {
                                var partElements = getPartsElements();
                                var curElement = partElements[index];
                                var partValue = partInput.getValue();
                                if ((curElement.id === $document[0].activeElement.id) && partValue && (partValue.length === partInput.getLength())) {
                                    partElements[0] && partElements[index + 1].focus();
                                }
                            });
                        }
                    };

                    $attrs.$observe('mxgFocus', function (value) {
                        if (value) {
                            $timeout(function () {
                                var partElements = getPartsElements();
                                partElements[0] && partElements[0].focus();
                                $attrs.$set('mxgFocus', null);
                            }, 10);
                        }
                    });

                    function getPartsElements() {
                        return $element[0].querySelectorAll('.mxg-date-partial_input');
                    }

                }
            };

        }]);

angular.module('mxg.form.widgets.WidgetDatePartialCtrl', [
    'mxg.translation',
    'mxg.components.datePartial.DatePartialModel',
    'mxg.helpers.DateHelper',
    'mxg.components.datepicker.DatepickerConfig',
    'mxg.form.widgets.datePartial.DatePartInput',
    'mxg.form.widgets.datePartial.DatepickerInput'
])
    .controller('mxgWidgetDatePartialCtrl', [
        '$scope', '$timeout', 'mxgTranslateService', 'mxgDatePartialModel', 'mxgDateHelper', 'mxgDatepickerConfig', 'mxgDatePartInput', 'mxgDatepickerInput',
        function ($scope, $timeout, TranslateService, DatePartialModel, DateHelper, DatepickerConfig, DatePartInput, DatepickerInput) {
            'use strict';
            var widgetCtrl = this;
            var modelCtrl = null;
            var valueDirty = false;

            /** @type DatePartialModel */
            var widgetModel = new DatePartialModel($scope.inputFormat);
            var partsCount = widgetModel.getPartsCount();
            var delimiter = widgetModel.getDelimiter();

            var datePartPlaceholders = {
                0: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_YEAR', null, true),
                1: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_MONTH', null, true),
                2: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_DAY', null, true)
            };

            var valueTransformationMap = {
                MM: pad00,
                DD: pad00
            };

            widgetCtrl.modelOptions = {getterSetter: true, allowInvalid: true};

            widgetCtrl.partInputs = [];
            for (var i = 0; i < partsCount; i++) {
                widgetCtrl.partInputs[i] = buildPartInputModel(widgetModel.getPart(i));
            }

            widgetCtrl.datepicker = new DatepickerInput(widgetModel, {
                minDate: $scope.minDate || null,
                maxDate: $scope.maxDate || null,
                initDate: $scope.initDate || null,
                initOffset: $scope.initOffset || null,
                offsetUnits: $scope.offsetUnits || null
            });

            widgetCtrl.setModelCtrl = function (ctrl) {
                modelCtrl = ctrl;
                if (!modelCtrl.$isEmpty(modelCtrl.$viewValue)) {
                    widgetModel.setValue(modelCtrl.$viewValue);
                    widgetCtrl.datepicker.initDate = DateHelper.createDateInLocalTimezone(modelCtrl.$viewValue);
                }
            };

            widgetCtrl.getElementId = function (elementName) {
                return [$scope.elementId || '', elementName].join('_');
            };

            widgetCtrl.getDatePartsCount = function () {
                return widgetCtrl.partInputs.length;
            };

            widgetCtrl.getDelimiter = function () {
                return delimiter;
            };

            widgetCtrl.getPlaceholder = function (partInput) {
                return datePartPlaceholders[partInput.getPriority()] || partInput.getFormat();
            };

            widgetCtrl.onDatepickerChange = function (mode, value) {
                if (!modelCtrl) {
                    return null;
                }
                var prevValue = modelCtrl.$viewValue;
                var modePriority;
                DatepickerConfig.modes.some(function (item) {
                    if (item.name === mode) {
                        modePriority = item.priority;
                        return true;
                    }
                    return false;
                });
                var partValues = DateHelper.dateToISOString(value).split('-');
                widgetCtrl.partInputs.forEach(function (partInput) {
                    var partPriority = partInput.getPriority();
                    partInput.setValue((partPriority > modePriority) ? '' : partValues[partPriority]);
                });
                var newValue = widgetModel.getValue();
                if (prevValue !== newValue) {
                    modelCtrl.$setViewValue(newValue);
                    valueDirty = true;
                    $timeout(onValueReady);
                }
            };

            widgetCtrl.toggleDatepickerPopup = function (event) {
                event.stopPropagation();
                widgetCtrl.datepicker.toggle();
                return false;
            };

            widgetCtrl.onDatePartInputBlur = function (partInput) {
                if (partInput.getValue()) {
                    var transformation = valueTransformationMap[partInput.getFormat().toUpperCase()];
                    if (transformation) {
                        partInput.modelFn(transformation(partInput.getValue()));
                    }
                }
                $timeout(onValueReady);
            };

            function buildPartInputModel(datePartModel) {
                var partInput = new DatePartInput(datePartModel);
                partInput.modelFn = function (value) {
                    if (!modelCtrl) {
                        return;
                    }
                    if (angular.isDefined(value)) {
                        var prevValue = widgetModel.getValue();
                        partInput.setValue(value);
                        var newValue = widgetModel.getValue();
                        if (newValue !== prevValue) {
                            modelCtrl.$setViewValue(newValue);
                            widgetCtrl.datepicker.updateValue(widgetModel);
                            valueDirty = true;
                        }
                    }
                    else {
                        if (widgetModel.getValue() !== modelCtrl.$viewValue) {
                            widgetModel.setValue(modelCtrl.$viewValue);
                        }
                        return partInput.getValue();
                    }
                };
                return partInput;
            }

            function onValueReady() {
                if (valueDirty) {
                    $scope.onComplete();
                    valueDirty = false;
                }
            }

            function pad00(value) {
                return ('00' + value).slice(-2);
            }

        }]);

angular.module('mxg.form.widgets.WidgetDatepicker', [
    'mxg.form.widgets.WidgetDatepickerCtrl',
    'mxg.translation',
    'mxg.components.datepicker'
])
    .directive('mxgWidgetDatepicker', [
        '$timeout',
        function ($timeout) {
            "use strict";
            return {
                restrict: "AE",
                templateUrl: 'mxg-template/form/widgets/WidgetDatepicker.html',
                require: ['ngModel', '^?mxgFormControl'],
                scope: {
                    model: '=ngModel',
                    displayFormat: '@',
                    minDate: "@?",
                    maxDate: "@?",
                    initDate: "@?",
                    initOffset: "@initFocusOffset",
                    offsetUnits: "@initFocusUnits",
                    displayInputMask: "@",
                    elementId: "@id",
                    onComplete: '&mxgOnComplete'
                },
                controller: 'mxgWidgetDatepickerCtrl',
                controllerAs: 'widgetCtrl',
                link: function link($scope, $element, attributes, ctrls) {

                    $element.addClass('mxg-widget mxg-widget-datepicker');

                    var ngModel = ctrls[0];
                    var formControl = ctrls[1];

                    $scope.widgetCtrl.setModelCtrl(ngModel);

                    // @todo extract null form controller so it can be used in such situations
                    $scope.formControl = formControl || {
                            isDisabled: function () { // null controller
                                return false;
                            }
                        };

                    attributes.$observe('mxgFocus', function (value) {
                        if (value) {
                            $timeout(function () {
                                var inputElement = $element[0].querySelector('.mxg-datepicker-input');
                                inputElement && inputElement.focus();
                                attributes.$set('mxgFocus', null);
                            });
                        }
                    });

                }

            }
        }]);

angular.module('mxg.form.widgets.WidgetDatepickerCtrl', [
    'mxg.translation',
    'mxg.components.inputMask.DateFormatMask',
    'mxg.helpers.DateHelper'
])
    .controller('mxgWidgetDatepickerCtrl', [
        '$scope', '$timeout', 'mxgDateFormatMask', 'mxgDateHelper', 'mxgTranslateService', 'dateFilter',
        function ($scope, $timeout, DateFormatMask, DateHelper, TranslateService, dateFilter) {
            'use strict';

            var ISO_FORMAT = 'yyyy-MM-dd';

            var widgetCtrl = this;
            var modelCtrl = null;
            var valueDirty = false;

            widgetCtrl.minDate = $scope.minDate ? DateHelper.createDateInLocalTimezone($scope.minDate) : null;
            widgetCtrl.maxDate = $scope.maxDate ? DateHelper.createDateInLocalTimezone($scope.maxDate) : null;
            widgetCtrl.initOffset = parseInt($scope.initOffset, 10) || null;
            widgetCtrl.offsetUnits = $scope.offsetUnits ? $scope.offsetUnits.toLowerCase() : null;
            widgetCtrl.initDate = getDefaultDate();
            widgetCtrl.displayFormat = $scope.displayFormat;
            widgetCtrl.displayInputMask = $scope.displayInputMask === 'true';

            var displayDateFormat = getValidDateFormat($scope.displayFormat);

            if (DateFormatMask[displayDateFormat]) {
                widgetCtrl.inputMask = DateFormatMask[displayDateFormat] || '';
            }

            var inputPlaceholder = TranslateService.getById('FrontEndLabels.HINT_FULL_DATE', null, true);

            var elementId = $scope.elementId;
            widgetCtrl.getElementId = function () {
                return elementId;
            };

            widgetCtrl.modelOptions = {getterSetter: true, allowInvalid: true};

            widgetCtrl.setModelCtrl = function (ctrl) {
                modelCtrl = ctrl;
                if (!modelCtrl.$isEmpty(modelCtrl.$viewValue)) {
                    widgetCtrl.initDate = DateHelper.createDateInLocalTimezone(modelCtrl.$viewValue);
                    setDatepickerValue(widgetCtrl.initDate);
                }
            };

            widgetCtrl.datepickerModel = null;
            setDatepickerValue();

            widgetCtrl.widgetValue = function (value) {
                var dateValue;
                if (!modelCtrl) {
                    return null;
                }
                if (angular.isDefined(value)) {
                    var prevValue = modelCtrl.$viewValue;
                    dateValue = textToDate(value, displayDateFormat);
                    var newValue = dateToText(dateValue, ISO_FORMAT) || value;
                    if (newValue !== prevValue) {
                        modelCtrl.$setViewValue(newValue);
                        if (newValue !== dateToText(widgetCtrl.datepickerModel, ISO_FORMAT)) {
                            setDatepickerValue(dateValue);
                        }
                        valueDirty = true;
                    }
                }
                else {
                    dateValue = textToDate(modelCtrl.$viewValue, ISO_FORMAT);
                    if (dateValue && (modelCtrl.$viewValue !== dateToText(widgetCtrl.datepickerModel, ISO_FORMAT))) {
                        setDatepickerValue(dateValue);
                    }
                    return dateToText(dateValue, displayDateFormat) || modelCtrl.$viewValue;
                }
            };

            widgetCtrl.onInputBlur = onValueReady;

            widgetCtrl.getDisplayTitle = function () {
                return inputPlaceholder || widgetCtrl.displayFormat;
            };

            widgetCtrl.getDisplayPlaceholder = function () {
                return widgetCtrl.displayInputMask ? inputPlaceholder || widgetCtrl.displayFormat : '';
            };

            widgetCtrl.datepickerOpened = false;

            widgetCtrl.isDatepickerOpen = function () {
                return widgetCtrl.datepickerOpened;
            };

            widgetCtrl.openDatepicker = function ($event) {
                widgetCtrl.datepickerOpened = true;
                $event.stopPropagation();
            };

            widgetCtrl.toggleDatepicker = function ($event) {
                widgetCtrl.datepickerOpened = !widgetCtrl.datepickerOpened;
                $event.stopPropagation();
            };

            widgetCtrl.onDatepickerChange = function () {
                if (!modelCtrl) {
                    return null;
                }
                var prevValue = modelCtrl.$viewValue;
                var newValue = angular.isDate(widgetCtrl.datepickerModel) ? dateFilter(widgetCtrl.datepickerModel, ISO_FORMAT) : null;
                if (prevValue !== newValue) {
                    modelCtrl.$setViewValue(newValue);
                    valueDirty = true;
                    $timeout(onValueReady);
                }
            };

            widgetCtrl.getDefaultDatepickerDate = getDefaultDate;

            function getDefaultDate() {
                var defaultDate = widgetCtrl.initDate || null;
                if (!defaultDate) {
                    if ((widgetCtrl.initOffset != null) && widgetCtrl.offsetUnits) {
                        defaultDate = DateHelper.getNowDate();
                        if (widgetCtrl.offsetUnits === 'years') {
                            defaultDate.setFullYear(defaultDate.getFullYear() + widgetCtrl.initOffset);
                        }
                        if (widgetCtrl.offsetUnits === 'months') {
                            defaultDate.setMonth(defaultDate.getMonth() + widgetCtrl.initOffset);
                        }
                    }
                }
                return defaultDate;
            }

            function getValidDateFormat(format) {
                return format ? DateHelper.canonizeDateFormat(format) : ISO_FORMAT;
            }

            function textToDate(textValue, format) {
                var dateValue = textValue ? DateHelper.parseDate(textValue, format) : null;
                if (angular.isDate(dateValue) && (dateValue.toString() !== 'Invalid Date')) {
                    return dateValue;
                }
                return null;
            }

            function dateToText(dateValue, format) {
                var textValue = dateValue ? dateFilter(dateValue, format) : null;
                return textValue || null;
            }

            function setDatepickerValue(date) {
                widgetCtrl.datepickerModel = date || getDefaultDate();
            }

            function onValueReady() {
                if (valueDirty) {
                    $scope.onComplete();
                    valueDirty = false;
                }
            }

        }]);

/**
 * @ngdoc directive
 */
angular.module('mxg.form.widgets.WidgetDictionary', [
    'mxg.form.widgets.WidgetDictionaryCtrl',
    'mxg.form.controls.Vlist.VlistManager',
    'mxg.form.controls.Vlist.VlistOptions',
    'mxg.helpers.KeyCode',
    'mxg.translation',
    'mxg.resources.DictionaryResource',
    'mxg.form.widget.Statuses',
    'mxg.system.RuntimeConstants'
])
    .directive('mxgWidgetDictionary', [
        '$q', '$timeout', 'mxgKeyCode', 'mxgDictionaryResource', 'mxgWidgetStatuses', 'mxgRuntimeConstants',
        function ($q, $timeout, KEY_CODE, DictionaryResource, STATUSES, RuntimeConstants) {
            'use strict';

            /* Directive declaration */
            return {
                restrict: 'AE',
                require: 'ngModel',
                scope: {
                    notificationContent: '=',
                    height: '@',
                    onComplete: '&mxgOnComplete'
                },
                templateUrl: 'mxg-template/form/widgets/WidgetDictionary.html',
                controller: 'mxgWidgetDictionaryCtrl',
                controllerAs: 'widgetCtrl',
                link: function ($scope, $element, $attrs, ngModel) {

                    $element.addClass('mxg-widget mxg-widget-dictionary');

                    if (!angular.isObject($scope.notificationContent)) {
                        return;
                    }

                    $scope.widgetCtrl.maxVisibleOptions = parseInt($scope.height) || 8;
                    var inputElement = $element.find('input').eq(0);

                    var DICTIONARY_STATES = RuntimeConstants.dictionaryState;
                    var CONFIRMATION_STATUSES = RuntimeConstants.confirmationStatus;
                    var MATCH_STATUSES = RuntimeConstants.matchStatus;

                    var widgetStatus = $scope.notificationContent.originalValue ? STATUSES.RECOGNISED : STATUSES.EMPTY;

                    var valueDirty = false;

                    $scope.getElementId = function (index) {
                        return $attrs.id + '_' + index;
                    };

                    $attrs.$observe('id', function () {
                        updateIds($attrs.id);
                    });

                    function updateIds(elementId) {
                        if (elementId) {
                            inputElement[0].id = elementId + '_input';
                        }
                    }

                    /* In this object gathered common functions for both Type Ahead and Confirmation UI */
                    $scope.dialog = {

                        setFocus: function (name) {

                            var dialogElement = angular.element($element[0].querySelector('.mxg-dictionary-' + name));
                            if (dialogElement.length > 0) {
                                var optionElement = dialogElement[0].querySelector(
                                    '.mxg-dictionary-option, .mxg-vlist-option, .mxg-btn');
                                if (optionElement) {
                                    $timeout(function () {
                                        optionElement.focus();
                                    });
                                }
                            }

                        },

                        checkFocused: function () {
                            var focusedElement = angular.element(document.activeElement);
                            return (focusedElement.length > 0)
                                && (focusedElement.hasClass('mxg-dictionary-option') || focusedElement.hasClass(
                                    'mxg-vlist-option'));
                        }

                    };

                    function isInputFocused() {
                        return document.activeElement == inputElement[0];
                    }

                    $scope.typeAhead = {

                        options: [],

                        optionsVisible: function () {
                            return $scope.typeAhead.options.length > 0;
                        },

                        emptyFilterTooltipVisible: function () {
                            return isInputFocused()
                                && !ngModel.$isEmpty($scope.notificationContent.originalValue)
                                && ($scope.notificationContent.originalValue.length > 2)
                                && (widgetStatus === STATUSES.UNRECOGNISED);
                        },

                        onOptionKeydown: function (event) {
                            var pressed = event.keyCode;
                            if ((pressed === KEY_CODE.DOWN) || (pressed === KEY_CODE.UP)) {
                                event.preventDefault();
                                var link = null;
                                var parent = angular.element(event.currentTarget).parent();
                                if (parent.length > 0) {
                                    if (event.keyCode === KEY_CODE.DOWN) {
                                        link = angular.element(parent[0].nextElementSibling).find('a').eq(0);
                                    }
                                    else {
                                        link = angular.element(parent[0].previousElementSibling).find('a').eq(0);
                                    }
                                    if (link.length > 0) {
                                        link[0].focus();
                                    }
                                }
                                return false;
                            }
                        },

                        onOptionBlur: function (event) {
                            if (!isInputFocused() && !$scope.dialog.checkFocused()) {
                                $scope.onInputBlur();
                            }
                        },

                        onSelect: function (term) {
                            $timeout(function () {
                                ngModel.$setViewValue(term);
                                resetNotificationContent($scope.notificationContent,
                                    {originalValue: term, matchStatus: MATCH_STATUSES.RECOGNISED});
                                updateTypeAheadOptions();
                                setWidgetStatus(STATUSES.RECOGNISED);
                                onValueReady({moveForward: true});
                            });
                        }
                    };

                    $scope.confirmation = {

                        isActive: function () {
                            var nc = $scope.notificationContent;
                            return nc.dictionaryState === DICTIONARY_STATES.MISSPELLING || nc.dictionaryState === DICTIONARY_STATES.ALTERNATIVES;
                        },

                        misspellingVisible: function () {
                            var nc = $scope.notificationContent;
                            return nc.dictionaryState === DICTIONARY_STATES.MISSPELLING;
                        },

                        alternativesVisible: function () {
                            var nc = $scope.notificationContent;
                            return nc.dictionaryState === DICTIONARY_STATES.ALTERNATIVES && nc.alternatives && (nc.alternatives.length > 0);
                        },

                        unrecognisedVisible: function () {
                            var nc = $scope.notificationContent;
                            return nc.dictionaryState === DICTIONARY_STATES.ALTERNATIVES && (!nc.alternatives || nc.alternatives.length === 0);
                        },

                        updateAlternatives: function () {

                            var data = $scope.notificationContent.alternatives || [];

                            var alternativesSource = data.map(function (item) {
                                return {
                                    code: item,
                                    name: item
                                };
                            });
                            $scope.vlistManager.show();
                            $scope.vlistManager.setOptionsSource(alternativesSource).then(function () {
                                if (alternativesSource.length) {
                                    $scope.vlistManager.focus();
                                }
                            });
                        },
                        onListExit: function () {
                            $scope.dialog.setFocus('alternatives');
                        },
                        onConfirm: function (term) {
                            $timeout(function () {
                                ngModel.$setViewValue(term);
                                resetNotificationContent($scope.notificationContent,
                                    {
                                        originalValue: term,
                                        matchStatus: MATCH_STATUSES.RECOGNISED,
                                        confirmationStatus: CONFIRMATION_STATUSES.CONFIRMED
                                    });
                                setWidgetStatus(STATUSES.RECOGNISED);
                                onValueReady({moveForward: true});
                            });
                        },
                        onDecline: function () {

                            $timeout(function () {

                                var misspellingStage = $scope.notificationContent.dictionaryState === DICTIONARY_STATES.MISSPELLING;
                                var updatedContent = {
                                    matchStatus: MATCH_STATUSES.UNRECOGNISED,
                                    confirmationStatus: CONFIRMATION_STATUSES.DECLINED
                                };
                                if (misspellingStage) {
                                    updatedContent.dictionaryState = $scope.notificationContent.dictionaryState;
                                }
                                resetNotificationContent($scope.notificationContent, updatedContent);
                                setWidgetStatus(STATUSES.UNRECOGNISED);

                                $q.when((function () {
                                    if (misspellingStage) {
                                        return performQuickMatch();
                                    }
                                })()).finally(function () {
                                    if (widgetStatus !== STATUSES.AWAIT_CONFIRMATION) {
                                        onValueReady({moveForward: true});
                                    }
                                });

                            });

                        },

                        onCancel: function () {
                            $timeout(function () {
                                ngModel.$render();
                                resetNotificationContent($scope.notificationContent);
                                setWidgetStatus(STATUSES.EMPTY);
                                inputElement[0].focus();
                                ngModel.$setViewValue('');
                            });
                        }

                    };

                    $scope.$watch('notificationContent.alternatives', function (newValue) {
                        if ($scope.confirmation.alternativesVisible()) {
                            $scope.confirmation.updateAlternatives();
                        }
                    });

                    function setWidgetStatus(newValue) {

                        widgetStatus = newValue;

                        if (newValue === STATUSES.AWAIT_CONFIRMATION) {
                            $scope.notificationContent.AWAIT_CONFIRMATION = true;
                        } else {
                            delete $scope.notificationContent.AWAIT_CONFIRMATION;
                        }

                    }

                    $scope.onInputChange = function () {
                        valueDirty = true;
                        resetNotificationContent($scope.notificationContent);
                        setWidgetStatus(STATUSES.VALIDATING);
                        verifyInput();
                    };

                    $scope.onInputKeyup = function (event) {

                        var pressed = event.keyCode;
                        if ((pressed === KEY_CODE.DOWN) && $scope.typeAhead.optionsVisible()) {
                            event.preventDefault();
                            $scope.dialog.setFocus('typeahead');
                            return false;
                        }

                    };

                    $scope.onInputBlur = function () {

                        ngModel.$setViewValue($scope.notificationContent.originalValue);

                        $timeout(function () {

                            if ($scope.dialog.checkFocused()) {
                                return;
                            }

                            if ($scope.typeAhead.optionsVisible()) {
                                updateTypeAheadOptions();
                            }

                            switch (widgetStatus) {
                                case STATUSES.RECOGNISED:
                                    resetNotificationContent($scope.notificationContent,
                                        {matchStatus: MATCH_STATUSES.RECOGNISED});
                                    break;
                                case STATUSES.EMPTY:
                                    resetNotificationContent($scope.notificationContent);
                                    break;
                                default:
                                    setWidgetStatus(ngModel.$isEmpty(
                                        $scope.notificationContent.originalValue) ? STATUSES.EMPTY : STATUSES.UNRECOGNISED);
                            }

                            $q.when((function () {
                                if (widgetStatus === STATUSES.UNRECOGNISED) {
                                    return performQuickMatch();
                                }
                            })()).finally(function () {
                                if (widgetStatus !== STATUSES.AWAIT_CONFIRMATION) {
                                    onValueReady({moveForward: false});
                                }
                            });

                        }, 50);

                    };

                    function resetNotificationContent(nc, overrides) {

                        var defaultValues = {
                            alternatives: [],
                            confirmationStatus: CONFIRMATION_STATUSES.NO_INTERACTION,
                            dictionaryState: DICTIONARY_STATES.INITIALISED,
                            matchStatus: MATCH_STATUSES.UNRECOGNISED,
                            matchedValue: null,
                            misspellingProposal: null
                        };

                        return angular.extend(nc, defaultValues, overrides || {});

                    }

                    function verifyInput() {

                        var candidate = $scope.notificationContent.originalValue;
                        var lookupValue = angular.isString(candidate) ? candidate.trim() : '';
                        setWidgetStatus(STATUSES.VALIDATING);

                        if (lookupValue.length < 2) {
                            updateTypeAheadOptions();
                            setWidgetStatus(lookupValue.length ? STATUSES.UNRECOGNISED : STATUSES.EMPTY);
                        }
                        else {
                            $scope.widgetCtrl.dictionaryAllPhrases($scope.notificationContent)
                                .then(function (data) {
                                if (candidate === $scope.notificationContent.originalValue && widgetStatus === STATUSES.VALIDATING) {
                                    setWidgetStatus(updateTypeAheadOptions(data, lookupValue));
                                }
                            });
                        }

                    }

                    function performQuickMatch() {

                        var candidate = $scope.notificationContent.originalValue;
                        setWidgetStatus(STATUSES.VALIDATING);

                        var matchPromise = DictionaryResource.quickMatch(angular.copy($scope.notificationContent));
                        return matchPromise.then(function (response) {
                            if ((candidate === $scope.notificationContent.originalValue) && angular.isObject(
                                    response)) {
                                angular.extend($scope.notificationContent, response);
                            }
                            var updatedStatus = $scope.confirmation.isActive() ? STATUSES.AWAIT_CONFIRMATION : STATUSES.RECOGNISED;
                            setWidgetStatus(updatedStatus);
                        }, function () {
                            setWidgetStatus(STATUSES.UNRECOGNISED);
                        });

                    }

                    function updateTypeAheadOptions(data, lookupValue) {

                        var filteredTerms = [];
                        var resultStatus;

                        if (!data || !data.length || !lookupValue) {
                            /* nothing to filter - just hide options */
                            resultStatus = STATUSES.UNRECOGNISED;
                        }
                        else {

                            filteredTerms = $scope.widgetCtrl.filterForTypeAhead(data, lookupValue);

                            if (!filteredTerms.length) {
                                resultStatus = STATUSES.UNRECOGNISED;
                            }
                            else {
                                resultStatus = foundTerm(filteredTerms,
                                    lookupValue) ? STATUSES.RECOGNISED : STATUSES.AWAIT_CONFIRMATION;
                            }

                        }

                        $timeout(function () {
                            $scope.typeAhead.options.length = 0;
                            if (filteredTerms.length > 0) {
                                angular.extend($scope.typeAhead.options, filteredTerms);
                            }
                        });

                        return resultStatus;

                        //--------------------
                        function foundTerm(data, value) {
                            var normalizedValue = (angular.isString(value) ? value : value + '').toLowerCase();
                            return data.some(function (item) {
                                return item.term.toLowerCase() === normalizedValue;
                            });
                        }

                        //--------------------
                    }

                    ngModel.$render = function () {
                        $scope.notificationContent.originalValue = ngModel.$modelValue;
                    };

                    $attrs.$observe('mxgFocus', function (value) {
                        if (value) {
                            $timeout(function () {
                                inputElement[0].focus();
                                $attrs.$set('mxgFocus', null);
                            });
                        }
                    });

                    function onValueReady(params) {
                        if (valueDirty) {
                            $scope.onComplete(params);
                            valueDirty = false;
                        }
                    }

                } /* link function */

            };

        }]);

angular.module('mxg.form.widgets.WidgetDictionaryCtrl', [
    'mxg.helpers.TypeaheadHelper',
    'mxg.resources.DictionaryResource'
])
    .controller('mxgWidgetDictionaryCtrl', [
        '$q',
        '$sce',
        'mxgTypeaheadHelper',
        'mxgDictionaryResource',
        function ($q, $sce, TypeaheadHelper, DictionaryResource) {
            'use strict';

            var widgetCtrl = this;

            widgetCtrl.maxVisibleOptions = 8;

            widgetCtrl.dictionaryAllPhrases = (function () {

                var dataCache = null;

                return function (notificationContent) {
                    if (dataCache) {
                        return $q.when(dataCache);
                    }
                    return DictionaryResource.getAllPhrases(notificationContent)
                        .then(function (data) {
                            dataCache = data.map(function (term) {
                                return {
                                    term: term,
                                    normalised: TypeaheadHelper.accentFold(term).toLowerCase()
                                };
                            });
                            return dataCache;
                        });
                };

            })();

            /**
             * @ngdoc method
             * @method filterForTypeAhead
             * @static
             * @description
             *  termsCollection [{term, normalised}]
             *  returns [{term, caption}]
             * @param {Object[]} termsCollection
             * @param {String} lookupValue
             * @returns {Object[]}
             * */
            widgetCtrl.filterForTypeAhead = function (termsCollection, lookupValue) {

                var normalisedLookupValue = TypeaheadHelper.accentFold(lookupValue).toLowerCase();
                var escapedValue = lookupValue.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
                var sortingLookupValue = escapedValue.toLocaleLowerCase();

                return termsCollection
                /* Prepare for arrangement by search priority: first should go terms which starts with searched value
                 *  or have words inside that starts with it
                 * */
                    .map(function (item) {

                        var searchPosition = item.normalised.indexOf(normalisedLookupValue);
                        var highlight = searchPosition >=0 ? item.term.substr(searchPosition, normalisedLookupValue.length) : null;
                        /* priority will define grouping for further sorting of results */
                        var priority = searchPosition;
                        var words;
                        var firstInWord;

                        if (searchPosition > 0) {
                            words = item.normalised.replace(/\W+/g, ' ').split(' ');
                            firstInWord = false;
                            words.some(function (word, index) {
                                var inWordPosition = word.indexOf(lookupValue);
                                if (inWordPosition === -1) {
                                    return false;
                                }
                                firstInWord = inWordPosition === 0;
                                priority = index*10 + inWordPosition;
                                return true;
                            });
                            if (!firstInWord) {
                                priority += 100;
                            }
                        }

                        return {
                            term: item.term,
                            priority: priority,
                            highlightPattern: new RegExp('(' + highlight + ')', 'gi')
                        };

                    })
                    /*
                     * Filter: throw away terms that don't contain searched value
                     * */
                    .filter(function (item) {
                        return item.priority >= 0;
                    })
                    /*
                     * Now we a ready for sort
                     * */
                    .sort(function (item1, item2) {
                        if (item1.priority === item2.priority && sortingLookupValue !== normalisedLookupValue) {
                            if ((item1.term.toLowerCase()).indexOf(sortingLookupValue) !== -1) {
                                item1.priority = item1.priority - 1;
                            } else if ((item2.term.toLowerCase()).indexOf(sortingLookupValue) !== -1) {
                                item2.priority = item2.priority - 1;
                            }
                        }

                        if (item1.priority < item2.priority) {
                            return -1;
                        }
                        if (item1.priority > item2.priority) {
                            return 1;
                        }
                        if (item1.term < item2.term) {
                            return -1;
                        }
                        if (item1.term > item2.term) {
                            return 1;
                        }
                    })
                    /*
                     * Take no more than predefined amount of options
                     * */
                    .slice(0, widgetCtrl.maxVisibleOptions)
                    /*
                     * Highlight searched value
                     * */
                    .map(function (item) {
                        return {
                            term: item.term,
                            caption: $sce.trustAsHtml(
                                htmlEntities(item.term).replace(item.highlightPattern,
                                    '<strong>$1</strong>'))
                        }
                    });

            };


            function htmlEntities(text) {
                return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g,
                    '&gt;').replace(/"/g, '&quote;');
            }
        }]);

angular.module('mxg.form.widgets.WidgetDropdown',
    ['mxg.form.controls.Vlist.VlistManager',
     'mxg.form.controls.Vlist.VlistOptions',
     'mxg.form.widgets.WidgetDropdownCtrl'])
    .directive('mxgWidgetDropdown', ['$timeout', function mxgWidgetDropdown($timeout) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            templateUrl: 'mxg-template/form/widgets/WidgetDropdown.html',
            scope: {
                elementId: '@id',
                refSource: '=',
                height: '@',
                initFocus: '@',
                onComplete: '&mxgOnComplete'
            },
            controller: 'mxgWidgetDropdownCtrl',
            controllerAs: 'widgetCtrl',
            link: function mxgWidgetDropdownLink($scope, $element, $attrs, ngModel) {

                $element.addClass('mxg-widget mxg-widget-dropdown');

                $scope.widgetCtrl.setModelCtrl(ngModel);

                $scope.getElement = function () {
                    return $element;
                };

                $attrs.$observe('mxgFocus', function (value) {
                    if (value) {
                        $timeout(function () {
                            $element[0].querySelector('.mxg-widget-dropdown_input').focus();
                            $attrs.$set('mxgFocus', null);
                        });
                    }
                });

            } /* link function */
        };

    }]);


angular.module('mxg.form.widgets.WidgetDropdownCtrl', [
    'mxg.form.controls.Vlist.VlistManager',
    'mxg.form.controls.Vlist.VlistOptions',
    'mxg.helpers.RefDataHelper',
    'mxg.helpers.EventsHelper',
    'mxg.helpers.KeyCode'
])
    .controller('mxgWidgetDropdownCtrl',
        ['$scope', '$element', '$q', '$timeout', '$document', 'mxgKeyCode', 'mxgEventsHelper', 'mxgRefDataHelper',
         function ($scope, $element, $q, $timeout, $document, KeyCode, EventsHelper, RefDataHelper) {
             'use strict';
             var widgetCtrl = this;
             var modelCtrl = null;
             var valueDirty = false;

             widgetCtrl.modelOptions = {
                 getterSetter: true,
                 allowInvalid: true,
                 updateOn: 'default blur',
                 debounce: {'default': 200, blur: 0}
             };

             widgetCtrl.setModelCtrl = function (ctrl) {
                 modelCtrl = ctrl;
             };

             widgetCtrl.getElementId = function (elementName) {
                 return [$scope.elementId || '', elementName].join('_');
             };

             widgetCtrl.widgetValue = function (value) {
                 if (!modelCtrl) {
                     return null;
                 }
                 if (angular.isDefined(value)) {
                     var prevValue = modelCtrl.$viewValue;
                     var newValue;
                     if (!value) {
                         newValue = null;
                     }
                     else {
                         newValue = RefDataHelper.getCodeByName($scope.refSource, value) || null;
                     }
                     if (newValue !== prevValue) {
                         modelCtrl.$setViewValue(newValue);
                         valueDirty = true;
                     }
                 }
                 else {
                     return modelCtrl.$isEmpty(modelCtrl.$viewValue) ? '' : RefDataHelper.getNameByCode($scope.refSource, modelCtrl.$viewValue);
                 }
             };

             widgetCtrl.onInputFocus = function () {
                 if (!$scope.vlistManager.getVisible()) {
                     showOption(modelCtrl.$viewValue);
                 }
             };

             widgetCtrl.onToggleClick = function (event) {
                 event.preventDefault();
                 if ($scope.vlistManager.getVisible()) {
                     hideOptions(true);
                 }
                 else {
                     showOption(modelCtrl.$viewValue);
                 }
                 return false;
             };

             widgetCtrl.onSelectOption = function (option) {
                 $timeout(function () {
                     widgetCtrl.widgetValue(option.name);
                     hideOptions(true);
                     onValueReady();
                 });
             };

             widgetCtrl.onInputKeydown = function (event) {
                 var pressed = event.keyCode;
                 var action = getKnownAction();
                 event.stopPropagation();
                 if (action === false) {
                     return;
                 }
                 event.preventDefault();
                 switch (action) {
                     case 'clear' :
                         widgetCtrl.widgetValue(null);
                         hideOptions();
                         break;
                     case 'open':
                         if ($scope.vlistManager.getVisible()) {
                             $scope.vlistManager.focus();
                         }
                         else {
                             showOption(modelCtrl.$viewValue);
                         }
                         break;
                     case 'close':
                         hideOptions(true);
                         break;
                     default:
                     //
                 }

                 function getKnownAction() {
                     if (event.ctrlKey && (pressed === KeyCode.DOWN)) {
                         return 'open';
                     }
                     if (event.ctrlKey && (pressed === KeyCode.UP)) {
                         return 'close';
                     }
                     if (pressed === KeyCode.BACKSPACE || pressed === KeyCode.DELETE) {
                         return 'clear';
                     }
                     return false;
                 }

             };

             widgetCtrl.onInputBlur = function () {
                 checkBlurEvent().then(function (realExit) {
                     realExit && onWidgetExit();
                 });
             };

             widgetCtrl.onListExit = function (needReturn) {
                 checkBlurEvent().then(function (realExit) {
                     if (realExit) {
                         if (needReturn) {
                             setFocusOnInput();
                         }
                         else {
                             onWidgetExit();
                         }
                     }
                 });
             };

             function showOption(candidate) {
                 var code = candidate || getDefaultOption();
                 if (code) {
                     return $scope.vlistManager.setOptionsSource($scope.refSource)
                         .then($scope.vlistManager.show)
                         .then(function () {
                             return $scope.vlistManager.setFocusByCode(code);
                         });
                 }
                 else {
                     return hideOptions();
                 }
             }

             function getDefaultOption() {
                 if (!$scope.refSource.length) {
                     return null;
                 }
                 var candidate;
                 if (angular.isDefined($scope.initFocus)) {
                     candidate = $scope.initFocus;
                 }
                 return modelCtrl.$isEmpty(candidate) ? $scope.refSource[0].code : candidate;
             }

             function hideOptions(returnToInput) {
                 return $scope.vlistManager.hide().then(function () {
                     returnToInput && setFocusOnInput();
                 });
             }

             function getInputElement() {
                 return $element[0].querySelector('.mxg-widget-dropdown_input');
             }

             function setFocusOnInput() {
                 var inputElement = getInputElement();
                 inputElement && inputElement.focus();
             }

             function checkIsDescendant(parent, child) {
                 var node = child.parentNode;
                 while (node != null) {
                     if (node == parent) {
                         return true;
                     }
                     node = node.parentNode;
                 }
                 return false;
             }

             function checkBlurEvent() {
                 var deferred = $q.defer();
                 $timeout(function () {
                     var activeElement = angular.element($document[0].activeElement);
                     if (!activeElement.length
                         || (activeElement[0].tagName === 'BODY')
                         || !checkIsDescendant($element[0], activeElement[0])
                     ) {
                         deferred.resolve(true);
                     }
                     else {
                         deferred.resolve(false);
                     }
                 });
                 return deferred.promise;
             }

             function onWidgetExit() {
                 hideOptions();
                 onValueReady();
             }

             function onValueReady() {
                 if (valueDirty) {
                     $scope.onComplete();
                     valueDirty = false;
                 }
             }

         }]);

angular.module('mxg.form.widgets.WidgetList', ['mxg.form.controls.SwitchGroup'])
    .directive('mxgWidgetList', ['$timeout', '$templateCache', function mxgWidgetList($timeout, $templateCache) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            scope: {
                refSource: '=',
                selectType: '@',
                layout: '@', /*vertical, horizontal*/
                height: '@',
                novalueItem: '@',
                onComplete: '&mxgOnComplete'
            },

            templateUrl: 'mxg-template/form/widgets/WidgetList.html',

            link: function mxgWidgetListLink($scope, $element, $attrs, ngModel) {

                /* Vertical layout is by default*/
                var layout = ($scope.layout === 'horizontal') ? $scope.layout : 'vertical';
                var groupType = $scope.selectType === 'multiple' ? 'checkbox' : 'radio';

                $element.addClass('mxg-widget mxg-widget-list mxg-widget-list-' + layout);

                $scope.getOptionId = function (optionIndex) {
                    return ($attrs.id || $element[0].id) + '_option_' + optionIndex;
                };

                function setFocus() {

                    var value = ngModel.$modelValue;
                    var optionElements = $element[0].querySelectorAll('.mxg-switch');
                    var elementToFocus = null;

                    if (!optionElements.length) {
                        return;
                    }

                    value = angular.isArray(value) ? (value[0] || null) : value;
                    elementToFocus = optionElements[0];

                    if (!ngModel.$isEmpty(value)) {
                        [].some.call(optionElements, function (item) {
                            var found = angular.element(item).attr('data-code') === value;
                            if (found) {
                                elementToFocus = item;
                            }
                            return found;
                        });
                    }

                    if (elementToFocus !== null) {
                        elementToFocus.focus();
                    }

                }

                $scope.onItemClick = function (code) {

                    $timeout(function () {

                        if (($scope.selectType === 'multiple')
                            && !angular.isUndefined($attrs.novalueItem)
                            && $scope.novalueItem
                            && !ngModel.$isEmpty(ngModel.$modelValue)
                            && (ngModel.$modelValue.indexOf(code) !== -1)) {

                            if (code === $scope.novalueItem) {
                                ngModel.$setViewValue([$scope.novalueItem]);
                                ngModel.$render();
                            }
                            else {
                                var values = ngModel.$modelValue, novalueItemIndex = values.indexOf($scope.novalueItem);
                                if (novalueItemIndex !== -1) {
                                    values.splice(novalueItemIndex, 1);
                                    ngModel.$setViewValue(values);
                                    ngModel.$render();
                                }
                            }

                        }

                        $scope.onComplete();

                    });

                };

                $attrs.$observe('mxgFocus', function (value) {
                    if (value && !$attrs.disabled) {
                        $timeout(function () {
                            setFocus();
                            $attrs.$set('mxgFocus', null);
                        });
                    }
                });

            }

        };

    }]);


angular.module('mxg.form.widgets.WidgetNumber', [
    'mxg.form.widgets.WidgetNumberCtrl',
    'mxg.components.noUiSlider'
])
    .directive('mxgWidgetNumber',
        ['$timeout', function widgetNumber($timeout) {
            "use strict";

            /*
             * This directive is called "Number", but actually it works only with integer values
             *
             */

            /* Directive declaration */
            return {
                restrict: 'AE',
                require: 'ngModel',
                scope: {
                    min: '@',
                    max: '@',
                    step: '@',
                    initFocus: '@',
                    slider: '@',
                    preText: '@',
                    postText: '@',
                    onComplete: '&mxgOnComplete'
                },
                templateUrl: 'mxg-template/form/widgets/WidgetNumber.html',
                controller: 'mxgWidgetNumberCtrl',
                controllerAs: 'widgetCtrl',
                link: function widgetNumberLink($scope, $element, $attrs, ngModel) {

                    $element.addClass('mxg-widget mxg-widget-number');

                    if ($scope.slider) {
                        $element.addClass('mxg-widget-number__slider mxg-widget-slider__' + $scope.slider);
                    }

                    $scope.widgetCtrl.setModelCtrl(ngModel, !!$scope.slider);

                    $scope.getElementId = function () {
                        return $attrs.id ? $attrs.id + '_input' : null;
                    };

                    $attrs.$observe('mxgFocus', function (value) {
                        if (value) {
                            $timeout(function () {
                                var inputElement = $element[0].querySelector('.mxg-number_input');
                                inputElement && inputElement.focus();
                                $attrs.$set('mxgFocus', null);
                            });
                        }
                    });

                }

            };

        }]);

angular.module('mxg.form.widgets.WidgetNumberCtrl', [
    'mxg.helpers.KeyCode',
    'mxg.helpers.NumberHelper'
])
    .controller('mxgWidgetNumberCtrl', ['$scope', '$timeout', 'mxgKeyCode', 'mxgNumberHelper', function ($scope, $timeout, KEY_CODE, NumberHelper) {
        'use strict';

        var widgetCtrl = this;
        var modelCtrl = null;
        var valueDirty = false;

        widgetCtrl.min = NumberHelper.ensureNumber($scope.min, 0);
        widgetCtrl.max = NumberHelper.ensureNumber($scope.max, 9999999);
        widgetCtrl.step = NumberHelper.ensureNumber($scope.step, 1);
        widgetCtrl.initFocus = NumberHelper.ensureNumber($scope.initFocus, widgetCtrl.min);

        widgetCtrl.modelOptions = {getterSetter: true, allowInvalid: true};
        widgetCtrl.sliderModelOptions = {getterSetter: true, allowInvalid: true};

        widgetCtrl.setModelCtrl = function (ctrl, hasSlider) {
            modelCtrl = ctrl;
            hasSlider && setupSlider(modelCtrl);
        };

        widgetCtrl.widgetValue = function (value) {
            if (!modelCtrl) {
                return null;
            }
            if (angular.isDefined(value)) {
                var prevValue = NumberHelper.ensureNumber(modelCtrl.$viewValue, null);
                var newValue = value ? NumberHelper.ensureNumber(value.replace(/[^0-9]+/g, ''), null) : null;
                !modelCtrl.$isEmpty(newValue) && (newValue = parseInt(newValue, 10));
                if (newValue !== prevValue) {
                    modelCtrl.$setViewValue(modelCtrl.$isEmpty(newValue) ? null : '' + newValue);
                    modelCtrl.$render();
                    valueDirty = true;
                }
            }
            else {
                return modelCtrl.$viewValue;
            }
        };

        widgetCtrl.onInputKeydown = function (event) {
            var pressed = event.keyCode;
            if ((pressed === KEY_CODE.UP) || (pressed === KEY_CODE.DOWN)) {
                event.preventDefault();
                widgetCtrl.makeStep(pressed);
            }
        };

        widgetCtrl.makeStep = function (direction) {

            if (!modelCtrl) {
                return;
            }

            var currentValue;
            var newValue;
            var stepValue = widgetCtrl.step;
            (direction === KEY_CODE.DOWN) && (stepValue *= -1);

            if (modelCtrl.$isEmpty(widgetCtrl.widgetValue())) {
                currentValue = null;
                newValue = widgetCtrl.initFocus;
            }
            else {
                currentValue = NumberHelper.ensureNumber(widgetCtrl.widgetValue(), null);
                newValue = ensureWithinLimits(currentValue + stepValue);
            }

            if (newValue !== currentValue) {
                widgetCtrl.widgetValue(''+newValue);
            }

        };

        widgetCtrl.onStepperClick = function (direction) {
            widgetCtrl.makeStep(direction);
            /* we need this delay to make sure that Question value updated first */
            $timeout(onValueReady, 2);
        };

        widgetCtrl.onInputBlur = onValueReady;

        function onValueReady() {
            if (valueDirty) {
                $scope.onComplete();
                valueDirty = false;
            }
        }

        function setupSlider(ngModel) {
            widgetCtrl.sliderValue = function (value) {
                if (angular.isDefined(value)) {
                    widgetCtrl.widgetValue('' + value);
                    $timeout(onValueReady, 2);
                    return;
                }
                if (!ngModel.$isEmpty(modelCtrl.$viewValue)) {
                    return NumberHelper.ensureNumber(widgetCtrl.widgetValue(), null);
                }
                return widgetCtrl.initFocus;
            };
            widgetCtrl.isSliderActive = function () {
                return !ngModel.$isEmpty(ngModel.$viewValue);
            };
            widgetCtrl.sliderPips = {
                mode: 'count',
                values: Math.round((widgetCtrl.max - widgetCtrl.min) / widgetCtrl.step + 1),
                density: widgetCtrl.step
            };
        }

        function ensureWithinLimits(intValue) {
            if (intValue > widgetCtrl.max) {
                intValue = widgetCtrl.max;
            }
            if (intValue < widgetCtrl.min) {
                intValue = widgetCtrl.min;
            }
            return intValue;
        }

    }]);

angular.module('mxg.form.widgets', [
    'mxg.form.widget.Statuses',
    'mxg.form.widgets.WidgetCheckbox',
    'mxg.form.widgets.WidgetCombobox',
    'mxg.form.widgets.WidgetDictionary',
    'mxg.form.widgets.WidgetDropdown',
    'mxg.form.widgets.WidgetList',
    'mxg.form.widgets.WidgetNumber',
    'mxg.form.widgets.WidgetSelectCombined',
    'mxg.form.widgets.WidgetText',
    'mxg.form.widgets.WidgetTextMultiline',
    'mxg.form.widgets.WidgetToggleIconic',
    'mxg.form.widgets.WidgetToggleLabelled',
    'mxg.form.widgets.WidgetDatepicker',
    'mxg.form.widgets.WidgetDatePartial'
]);

angular.module('mxg.form.widgets.WidgetSelectCombined', [
    'mxg.form.widgets.WidgetSelectCombinedCtrl',
    'mxg.helpers.RefDataHelper'
])
    .directive('mxgWidgetSelectCombined', [
        '$timeout', '$q', 'mxgRefDataHelper',
        function mxgWidgetSelectCombined($timeout, $q, refDataHelper) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            scope: {
                elementId: '@id',
                refSource: '=',
                mxgFocus: '@',
                initFocus: '@',
                height: '@',
                novalueItem: '@',
                preText: '@?mxgPreText',
                postText: '@?mxgPostText',
                onComplete: '&mxgOnComplete'
            },
            templateUrl: 'mxg-template/form/widgets/WidgetSelectCombined.html',
            controller: 'mxgWidgetSelectCombinedCtrl',
            controllerAs: 'widgetCtrl',
            link: function mxgWidgetSelectCombinedLink($scope, $element, $attrs, ngModel) {

                $element.addClass('mxg-widget mxg-widget-select-combined');

                var dropdown = {
                    options: $scope.refSource,
                    selectedValue: null,
                    disabled: false,
                    initFocus: $scope.initFocus || null,
                    height: $scope.height || null,
                    onSelect: function () {
                        var code = dropdown.selectedValue;
                        if (!refDataHelper.getItemByCode($scope.refSource, code)) {
                            return;
                        }
                        dropdown.selectedValue = null;
                        checkNovalueItem(code).then(function() {
                            selectedItems.add(code);
                        });
                    }
                };

                var selectedItems = {

                    list: [],

                    getName: function (code) {

                        return refDataHelper.getNameByCode($scope.refSource, code) || '';

                    },

                    add: function (code) {

                        var values = angular.isArray(ngModel.$modelValue) ? ngModel.$modelValue : [];

                        var itemIndex = values.indexOf(code);
                        if (itemIndex === -1) {
                            values.push(code);
                            setModelValue(values);
                        }

                    },

                    remove: function (code) {

                        var values = angular.isArray(ngModel.$modelValue) ? ngModel.$modelValue : [];

                        var itemIndex = values.indexOf(code);
                        if (itemIndex !== -1) {
                            values.splice(itemIndex, 1);
                            setModelValue(values);
                        }

                    }

                };

                function setModelValue(values) {
                    ngModel.$setViewValue(values);
                    ngModel.$render();
                    $scope.onComplete();
                }

                $scope.dropdown = dropdown;
                $scope.selectedItems = selectedItems;

                ngModel.$render = function () {

                    var values = angular.isArray(ngModel.$modelValue) ? ngModel.$modelValue : [];
                    var options = [], selected = [];

                    if (angular.isArray($scope.refSource)) {
                        angular.forEach($scope.refSource, function (item) {
                            if (values.indexOf(item.code) === -1) {
                                options.push(angular.copy(item));
                            }
                            else {
                                selected.push(angular.copy(item));
                            }
                        });
                    }

                    dropdown.options = options;
                    selectedItems.list = selected;

                };

                function checkNovalueItem(code) {

                    var deferred = $q.defer();

                    if (angular.isUndefined($attrs.novalueItem) || !$scope.novalueItem || ngModel.$isEmpty(ngModel.$modelValue)) {
                        deferred.resolve(false);
                    }

                    $timeout(function () {

                        if (code === $scope.novalueItem) {
                            ngModel.$setViewValue([]);
                            ngModel.$render();
                        }
                        else {
                            var values = ngModel.$modelValue, novalueItemIndex = values.indexOf($scope.novalueItem);
                            if (novalueItemIndex !== -1) {
                                values.splice(novalueItemIndex, 1);
                                ngModel.$setViewValue(values);
                                ngModel.$render();
                            }
                        }

                        deferred.resolve(true);
                    });

                    return deferred.promise;

                }

            }

        };

    }]);

angular.module('mxg.form.widgets.WidgetSelectCombinedCtrl', [])
    .controller('mxgWidgetSelectCombinedCtrl', ['$scope', function ($scope) {
        'use strict';
        var widgetCtrl = this;

        widgetCtrl.getElementId = function (elementName) {
            return [$scope.elementId || '', elementName].join('_');
        };

    }]);

/**
 *
 */
angular.module('mxg.form.widgets.WidgetText', [
    'mxg.form.widgets.WidgetTextCtrl'
])
    .directive('mxgWidgetText', ['$timeout', function ($timeout) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            scope: {
                maxLength: '@mxgMaxLength',
                valueType: '@mxgValueType',
                precision: '@mxgPrecision',
                decimalSymbol: '@mxgDecimalSymbol',
                onComplete: '&mxgOnComplete'
            },
            controller: 'mxgWidgetTextCtrl',
            controllerAs: 'widgetCtrl',
            //bindToController: true,
            templateUrl: 'mxg-template/form/widgets/WidgetText.html',

            link: function ($scope, $element, $attrs, ngModel) {

                var textElement = $element.find('input').eq(0);

                $element.addClass('mxg-widget mxg-widget-text');

                if ($scope.valueType) {
                    $element.addClass('mxg-widget-text__' + $scope.valueType);
                }

                $scope.widgetCtrl.setModelCtrl(ngModel);

                $attrs.$observe('id', function () {
                    updateIds($attrs.id);
                });

                function updateIds(elementId) {
                    if (elementId) {
                        textElement[0].id = elementId + '_input';
                    }
                }

                $attrs.$observe('mxgFocus', function (value) {
                    if (value) {
                        $timeout(function () {
                            $element.find('input')[0].focus();
                            $attrs.$set('mxgFocus', null);
                        });
                    }
                });

            }

        };

    }]);

angular.module('mxg.form.widgets.WidgetTextCtrl', [
    'mxg.system.RuntimeConstants',
    'mxg.helpers.NumberHelper'
])
    .controller('mxgWidgetTextCtrl', [
        '$scope', 'mxgRuntimeConstants', 'mxgNumberHelper',
        function ($scope, RuntimeConstants, NumberHelper) {
            'use strict';

            var widgetCtrl = this;
            var modelCtrl = null;
            var valueDirty = false;

            widgetCtrl.maxLength = NumberHelper.ensureNumber($scope.maxLength, 255);
            widgetCtrl.modelOptions = {getterSetter: true, allowInvalid: true};

            var DEFAULT_DECIMAL_SYMBOL = '.';
            var ALLOWED_DECIMAL_SYMBOLS = ['.', ','];

            widgetCtrl.setModelCtrl = function (ctrl) {
                modelCtrl = ctrl;
            };

            switch ($scope.valueType) {
                case 'DECIMAL':
                    var REPLACE_FROM_REGEX = new RegExp('[' + ALLOWED_DECIMAL_SYMBOLS.join('') + ']', 'g');
                    var REPLACE_TO_REGEX = new RegExp('[' + DEFAULT_DECIMAL_SYMBOL + ']', 'g');

                    widgetCtrl.precision = NumberHelper.ensureNumber($scope.precision, 0);
                    widgetCtrl.decimalSymbol = $scope.decimalSymbol || DEFAULT_DECIMAL_SYMBOL;
                    widgetCtrl.widgetValue = function (value) {
                        if (!modelCtrl) {
                            return null;
                        }
                        if (angular.isDefined(value)) {
                            var prevValue = modelCtrl.$viewValue;
                            var newValue = value;
                            if (!modelCtrl.$isEmpty(value)) {
                                newValue = value.replace(REPLACE_FROM_REGEX, DEFAULT_DECIMAL_SYMBOL);
                            }
                            if (newValue.split('.')[1] && newValue.split('.')[1].length > $scope.precision) {
                                return null;
                            }
                            newValue = NumberHelper.transformWithPrecisionCheck(newValue, widgetCtrl.precision);
                            if (newValue !== prevValue) {
                                modelCtrl.$setViewValue(newValue);
                                modelCtrl.$render();
                                valueDirty = true;
                            }
                        }
                        else {
                            if (modelCtrl.$isEmpty(modelCtrl.$viewValue)) {
                                return modelCtrl.$viewValue;
                            }
                            return ('' + modelCtrl.$viewValue).replace(REPLACE_TO_REGEX, widgetCtrl.decimalSymbol);
                        }
                    };
                    break;
                default:
                    widgetCtrl.widgetValue = function (value) {
                        if (!modelCtrl) {
                            return null;
                        }
                        if (angular.isDefined(value)) {
                            var newValue = value;
                            if (newValue !== modelCtrl.$viewValue) {
                                modelCtrl.$setViewValue(newValue);
                                valueDirty = true;
                            }
                        }
                        else {
                            return modelCtrl.$viewValue;
                        }
                    };
            }

            widgetCtrl.onInputBlur = onValueReady;

            function onValueReady() {
                if (valueDirty) {
                    $scope.onComplete();
                    valueDirty = false;
                }
            }

        }]);

angular.module('mxg.form.widgets.WidgetTextMultiline', [
    'mxg.form.widgets.WidgetTextMultilineCtrl'
])
    .directive('mxgWidgetTextMultiline', ['$timeout', function mxgWidgetTextMultiline($timeout) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            templateUrl: 'mxg-template/form/widgets/WidgetTextMultiline.html',
            scope: {
                model: '=ngModel',
                maxLength: '@mxgMaxLength',
                height: '@',
                expandable: '@',
                onComplete: '&mxgOnComplete'
            },
            controller: 'mxgWidgetTextMultilineCtrl',
            controllerAs: 'widgetCtrl',
            link: function mxgWidgetTextMultilineLink($scope, $element, $attrs, ngModel) {

                $element.addClass('mxg-widget mxg-widget-text-multiline');
                $scope.widgetCtrl.setModelCtrl(ngModel);

                var textElement = $element.find('textarea').eq(0);
                var textEl = textElement[0];
                var rows = 0;

                var paddings = $scope.widgetCtrl.computePaddings(textEl);
                var lineHeight = $scope.widgetCtrl.computeLineHeight(textEl);

                $attrs.$observe('id', function () {
                    updateIds($attrs.id);
                });

                $scope.checkExpandable = function() {
                    if (!$scope.widgetCtrl.isExpandable()) {
                        return;
                    }
                    rows = adjustInputHeight(rows, computeExpandedRows($scope.widgetCtrl.height));
                };

                $attrs.$observe('mxgFocus', function (value) {
                    if (value) {
                        $timeout(function () {
                            $element.find('textarea')[0].focus();
                            $attrs.$set('mxgFocus', null);
                        });
                    }
                });

                $timeout(function() {
                    rows = $scope.widgetCtrl.isExpandable() ? adjustInputHeight(0, computeExpandedRows($scope.widgetCtrl.height)) : adjustInputHeight(0, $scope.widgetCtrl.height);
                });

                function updateIds(elementId) {
                    if (elementId) {
                        textElement[0].id = elementId + '_input';
                    }
                }

                function adjustInputHeight(currentRows, neededRows) {
                    if (neededRows === currentRows) {
                        return currentRows;
                    }
                    textElement.css('height', neededRows * lineHeight + paddings + 'px');
                    return neededRows;
                }

                function computeExpandedRows(defaultRows) {
                    var output;
                    var textHeight;
                    if ($scope.widgetCtrl.widgetValue()) {
                        textHeight = textEl.scrollHeight - paddings;
                        output = Math.max(Math.ceil(textHeight / lineHeight), defaultRows);
                    }
                    else {
                        output = $scope.widgetCtrl.height;
                    }
                    return output;
                }

            }
        };
    }]);

angular.module('mxg.form.widgets.WidgetTextMultilineCtrl', [
    'mxg.helpers.NumberHelper'
])
    .controller('mxgWidgetTextMultilineCtrl', ['$scope', 'mxgNumberHelper', function ($scope, NumberHelper) {

        var widgetCtrl = this;
        var modelCtrl = null;
        var valueDirty = false;

        widgetCtrl.height = NumberHelper.ensureNumber($scope.height, 3);
        widgetCtrl.maxLength = NumberHelper.ensureNumber($scope.maxLength, 4000);
        widgetCtrl.modelOptions = {getterSetter: true, allowInvalid: true};

        widgetCtrl.setModelCtrl = function (ctrl) {
            modelCtrl = ctrl;
        };

        widgetCtrl.widgetValue = function (value) {
            if (!modelCtrl) {
                return null;
            }
            if (angular.isDefined(value)) {
                var prevValue = modelCtrl.$viewValue;
                /* Unfortunately, maxlength attribute for textarea doesn't work in IE9 so we still need adjusting value by hand */
                var newValue = value ? value.substr(0, widgetCtrl.maxLength) : null;
                if (newValue !== prevValue) {
                    modelCtrl.$setViewValue(newValue);
                    valueDirty = true;
                }
            }
            else {
                return modelCtrl.$viewValue;
            }
        };

        widgetCtrl.onInputBlur = function () {
            if (valueDirty) {
                $scope.onComplete();
                valueDirty = false;
            }
        };

        widgetCtrl.isExpandable = function () {
            return $scope.expandable === 'true';
        };

        widgetCtrl.computePaddings = function (element) {
            var computedStyle = getComputedStyle(element);
            return NumberHelper.ensureNumber(computedStyle.getPropertyValue('padding-top'), 0) +
                NumberHelper.ensureNumber(computedStyle.getPropertyValue('padding-bottom'), 0) +
                NumberHelper.ensureNumber(computedStyle.getPropertyValue('border-top-width'), 0) +
                NumberHelper.ensureNumber(computedStyle.getPropertyValue('border-bottom-width'), 0);
        };

        widgetCtrl.computeLineHeight = function (element) {
            var computedStyle = getComputedStyle(element);
            var computedLineHeight = computedStyle.getPropertyValue('line-height');
            var fontSize;
            if ((/^[0-9., ]+$/g).test(computedLineHeight)) { // numeric - relative to font-size; might be worth checking only last symbol;
                fontSize = NumberHelper.ensureNumber(computedStyle.getPropertyValue('font-size'), 14);
                computedLineHeight = Math.floor(fontSize * NumberHelper.ensureNumber(computedLineHeight, 1));
            }
            else {
                computedLineHeight = NumberHelper.ensureNumber(computedLineHeight, 15);
            }
            return Math.ceil(computedLineHeight);
        };

    }]);

angular.module('mxg.form.widgets.WidgetToggleIconic', [
        'mxg.form.controls.SwitchGroup',
        'mxg.helpers.RefDataHelper'
    ])
    .directive('mxgWidgetToggleIconic',
        ['$parse', '$timeout', 'mxgRefDataHelper',
         function mxgWidgetToggleIconic($parse, $timeout, RefDataHelper) {
             "use strict";

             /* Directive declaration */
             return {
                 restrict: 'AE',
                 require: 'ngModel',
                 scope: {
                     refSource: '=',
                     selectType: '@',
                     novalueItem: '@',
                     onComplete: '&mxgOnComplete'
                 },

                 templateUrl: 'mxg-template/form/widgets/WidgetToggleIconic.html',

                 link: function mxgWidgetToggleIconicLink($scope, $element, $attrs, ngModel) {

                     var iconCodes = {};

                     $element.addClass('mxg-widget mxg-widget-toggle-iconic');

                     $scope.getOptionId = function (optionIndex) {
                         return ($attrs.id || $element[0].id) + '_option_' + optionIndex;
                     };

                     $scope.getOptionClass = function (option) {
                         var iconCode = getMemoizedIconCode(option);
                         return 'mxg-icon-code_' + iconCode;
                     };

                     function getMemoizedIconCode(option) {
                         var foundCode = iconCodes[option.uuid];
                         if (!foundCode) {
                             foundCode = RefDataHelper.getIconCode(option.globalIds);
                             iconCodes[option.uuid] = foundCode;
                         }
                         return foundCode;
                     }

                     $attrs.$observe('id', function () {
                         $scope.groupClass = 'iconic-group-' + $attrs.id;
                     });

                     $scope.onItemClick = function (code) {

                         $timeout(function () {

                             if (($scope.selectType === 'multiple')
                                 && !angular.isUndefined($attrs.novalueItem)
                                 && $scope.novalueItem
                                 && !ngModel.$isEmpty(ngModel.$modelValue)
                                 && (ngModel.$modelValue.indexOf(code) !== -1)) {

                                 if (code === $scope.novalueItem) {
                                     ngModel.$setViewValue([$scope.novalueItem]);
                                     ngModel.$render();
                                 }
                                 else {
                                     var values = ngModel.$modelValue, novalueItemIndex = values.indexOf(
                                         $scope.novalueItem);
                                     if (novalueItemIndex !== -1) {
                                         values.splice(novalueItemIndex, 1);
                                         ngModel.$setViewValue(values);
                                         ngModel.$render();
                                     }
                                 }

                             }
                             $scope.onComplete();

                         });

                     };

                     function setFocus() {
                         var value = ngModel.$modelValue;
                         var optionElements = $element[0].querySelectorAll('.mxg-switch');
                         var elementToFocus = null;

                         if (!optionElements.length) {
                             return;
                         }

                         value = angular.isArray(value) ? (value[0] || null) : value;
                         elementToFocus = optionElements[0];

                         if (!ngModel.$isEmpty(value)) {
                             [].some.call(optionElements, function (item) {
                                 var found = angular.element(item).attr('data-code') === value;
                                 if (found) {
                                     elementToFocus = item;
                                 }
                                 return found;
                             });
                         }

                         if (elementToFocus !== null) {
                             elementToFocus.focus();
                         }
                     }

                     $attrs.$observe('mxgFocus', function (value) {
                         if (value) {
                             $timeout(function () {
                                 setFocus();
                                 $attrs.$set('mxgFocus', null);
                             });
                         }
                     });

                 }

             };

         }]);

angular.module('mxg.form.widgets.WidgetToggleLabelled', ['mxg.form.controls.SwitchGroup'])
    .directive('mxgWidgetToggleLabelled', ['$parse', '$timeout', function mxgWidgetToggleLabelled($parse, $timeout) {
        "use strict";

        /* Directive declaration */
        return {
            restrict: 'AE',
            require: 'ngModel',
            scope: {
                refSource: '=',
                selectType: '@',
                novalueItem: '@',
                onComplete: '&mxgOnComplete'
            },

            templateUrl: 'mxg-template/form/widgets/WidgetToggleLabelled.html',

            link: function mxgWidgetToggleLabelledLink($scope, $element, $attrs, ngModel) {

                $element.addClass('mxg-widget mxg-widget-toggle-labelled');

                $scope.getOptionId = function (optionIndex) {
                    return ($attrs.id || $element[0].id) + '_option_' + optionIndex;
                };

                $scope.onItemClick = function (code) {

                    $timeout(function () {

                        if (($scope.selectType === 'multiple')
                            && !angular.isUndefined($attrs.novalueItem)
                            && $scope.novalueItem
                            && !ngModel.$isEmpty(ngModel.$modelValue)
                            && (ngModel.$modelValue.indexOf(code) !== -1)) {

                            if (code === $scope.novalueItem) {
                                ngModel.$setViewValue([$scope.novalueItem]);
                                ngModel.$render();
                            }
                            else {
                                var values = ngModel.$modelValue, novalueItemIndex = values.indexOf($scope.novalueItem);
                                if (novalueItemIndex !== -1) {
                                    values.splice(novalueItemIndex, 1);
                                    ngModel.$setViewValue(values);
                                    ngModel.$render();
                                }
                            }

                        }
                        $scope.onComplete();

                    });

                };

                function setFocus() {

                    var value = ngModel.$modelValue;
                    var optionElements = $element[0].querySelectorAll('.mxg-switch');
                    var elementToFocus = null;

                    if (!optionElements.length) {
                        return;
                    }

                    value = angular.isArray(value) ? (value[0] || null) : value;
                    elementToFocus = optionElements[0];

                    if (!ngModel.$isEmpty(value)) {
                        [].some.call(optionElements, function (item) {
                            var found = angular.element(item).attr('data-code') === value;
                            if (found) {
                                elementToFocus = item;
                            }
                            return found;
                        });
                    }

                    if (elementToFocus !== null) {
                        elementToFocus.focus();
                    }

                }

                $attrs.$observe('mxgFocus', function (value) {
                    if (value) {
                        $timeout(function () {
                            setFocus();
                            $attrs.$set('mxgFocus', null);
                        });
                    }
                });

            }

        };

    }]);


angular.module('mxg.formElement.conditions.ConditionDateAbsoluteRangeEvaluator', [
    'mxg.helpers.DateHelper',
    'mxg.formElement.conditions.ConditionRangeEvaluator'
])
    .factory('mxgConditionDateAbsoluteRangeEvaluator', [
        'mxgDateHelper', 'mxgConditionRangeEvaluator',
        function (DateHelper, ConditionRangeEvaluator) {
            'use strict';

            var _super = ConditionRangeEvaluator;

            /**
             * @class
             * @extends ConditionRangeEvaluator
             */
            function ConditionDateAbsoluteRangeEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);
                var range = this._rowModel.getRange();
                this._expectedFrom = range.from ? DateHelper.createDateInLocalTimezone(range.from) : null;
                this._expectedTo = range.to ? DateHelper.createDateInLocalTimezone(range.to) : null;
            }

            ConditionDateAbsoluteRangeEvaluator.prototype = Object.create(_super.prototype);
            ConditionDateAbsoluteRangeEvaluator.prototype.constructor = ConditionDateAbsoluteRangeEvaluator;

            /**
             * @method ConditionDateAbsoluteRangeEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionDateAbsoluteRangeEvaluator.prototype.evaluate = function (actualValues) {
                if (!this._testFunction) {
                    return false;
                }
                return this._testFunction(this._expectedFrom, this._expectedTo,
                    this._valueTransformationFunction(actualValues[this._rowModel.getLocator()]));
            };

            return ConditionDateAbsoluteRangeEvaluator;

        }]);


angular.module('mxg.formElement.conditions.ConditionDateRelativeRangeEvaluator', [
    'mxg.helpers.DateHelper',
    'mxg.formElement.conditions.ConditionRangeEvaluator'
])
    .factory('mxgConditionDateRelativeRangeEvaluator', [
        'mxgDateHelper', 'mxgConditionRangeEvaluator',
        function (DateHelper, ConditionRangeEvaluator) {
            'use strict';

            var _super = ConditionRangeEvaluator;

            /**
             * @class
             * @extends ConditionRangeEvaluator
             */
            function ConditionDateRelativeRangeEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);

            }

            ConditionDateRelativeRangeEvaluator.prototype = Object.create(_super.prototype);
            ConditionDateRelativeRangeEvaluator.prototype.constructor = ConditionDateRelativeRangeEvaluator;

            /**
             * @method ConditionDateRelativeRangeEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionDateRelativeRangeEvaluator.prototype.evaluate = function (actualValues) {
                if (!this._testFunction) {
                    return false;
                }
                var range = this._rowModel.getRange();
                var from, to;
                var offsetValue = this._valueTransformationFunction(actualValues[range.offsetAttributeLocator]);
                switch (range.unit) {
                    case 'years':
                        from = range.from == null ? null : new Date(
                            offsetValue.setFullYear(offsetValue.getFullYear() + range.from));
                        to = range.to == null ? null : new Date(
                            offsetValue.setFullYear(offsetValue.getFullYear() + range.to));
                        break;
                    case 'months':
                        from = range.from == null ? null : new Date(
                            offsetValue.setMonth(offsetValue.getMonth() + range.from));
                        to = range.to == null ? null : new Date(
                            offsetValue.setMonth(offsetValue.getMonth() + range.to));
                        break;
                    default:
                        return false;
                }
                return this._testFunction(from, to,
                    this._valueTransformationFunction(actualValues[this._rowModel.getLocator()]));
            };

            return ConditionDateRelativeRangeEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionDateValueEvaluator', [
    'mxg.formElement.conditions.ConditionOperator',
    'mxg.formElement.conditions.ConditionValueEvaluator'
])
    .factory('mxgConditionDateValueEvaluator', [
        'mxgConditionOperator',
        'mxgConditionValueEvaluator',
        function (ConditionOperator, ConditionValueEvaluator) {
            'use strict';

            var _super = ConditionValueEvaluator;

            var testFunctionsMap = {};
            testFunctionsMap[ConditionOperator.GREATER] = function testDate_GREATER(expected, actual) {
                return actual > expected;
            };
            testFunctionsMap[ConditionOperator.LESS] = function testDate_LESS(expected, actual) {
                return actual < expected;
            };
            testFunctionsMap[ConditionOperator.GREATER_EQ] = function testDate_GREATER_EQ(expected, actual) {
                return actual >= expected;
            };
            testFunctionsMap[ConditionOperator.LESS_EQ] = function testDate_LESS_EQ(expected, actual) {
                return actual <= expected;
            };

            /**
             * @class
             * @extends ConditionValueEvaluator
             */
            function ConditionDateValueEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);
                if (testFunctionsMap[rowModel.getOperator()]) {
                    this._testFunction = testFunctionsMap[rowModel.getOperator()];
                }
            }

            ConditionDateValueEvaluator.prototype = Object.create(_super.prototype);
            ConditionDateValueEvaluator.prototype.constructor = ConditionDateValueEvaluator;

            return ConditionDateValueEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionElementModel', [])
    .factory('mxgConditionElementModel', [function () {
        'use strict';

        /**
         * @ngdoc Model
         * @class
         * @abstract
         * @param {Object} model
         */
        function ConditionElementModel(model) {
            this._type = model.type;
        }

        /**
         * @method ConditionElementModel#getType
         * @returns {String}
         */
        ConditionElementModel.prototype.getType = function () {
            return this._type;
        };

        return ConditionElementModel;

    }]);

angular.module('mxg.formElement.conditions.ConditionElementModelFactory', [
    'mxg.formElement.conditions.ConditionElementType',
    'mxg.formElement.conditions.ConditionGroupModel',
    'mxg.formElement.conditions.ConditionRowModel'
])
    .service('mxgConditionElementModelFactory', [
        '$injector',
        'mxgConditionElementType',
        function ($injector, ConditionElementType) {
            'use strict';
            var ConditionGroupModel;
            var ConditionRowModel;
            this.build = function (model) {
                switch (model.type) {
                    case ConditionElementType.GROUP:
                        ConditionGroupModel = ConditionGroupModel || $injector.get('mxgConditionGroupModel');
                        return new ConditionGroupModel(model);
                    case ConditionElementType.ROW:
                        ConditionRowModel = ConditionRowModel || $injector.get('mxgConditionRowModel');
                        return new ConditionRowModel(model);
                    default:
                        return null;
                }
            };
        }]);


/**
 * @ngdoc constant
 * @name mxgConditionElementType
 */
angular.module('mxg.formElement.conditions.ConditionElementType', [])
    .constant('mxgConditionElementType', {
        GROUP: 'GROUP',
        ROW: 'ROW'
    });

angular.module('mxg.formElement.conditions.ConditionEvaluator', [
    'mxg.formElement.conditions.ConditionModel',
    'mxg.formElement.conditions.ConditionElementType',
    'mxg.formElement.conditions.ConditionGroupEvaluator'
])
    .factory('mxgConditionEvaluator', [
        'mxgConditionModel',
        'mxgConditionElementType',
        'mxgConditionGroupEvaluator',
        function (ConditionModel, ConditionElementType, ConditionGroupEvaluator) {
            'use strict';

            /**
             * @class
             * @name ConditionEvaluator
             */
            function ConditionEvaluator(condition) {
                this._conditionModel = new ConditionModel(condition);
                this._locators = collectLocators(this._conditionModel.getGroups())
                    .reduce(function (reduced, current) {
                        if (reduced.indexOf(current) === -1) {
                            reduced.push(current);
                        }
                        return reduced;
                    }, []);
                this._evaluationTree = new ConditionGroupEvaluator(this._conditionModel.getGroupOperator(), this._conditionModel.getGroups());
            }

            function collectLocators(conditionElements) {
                return conditionElements.reduce(function (reduced, current) {
                    switch (current.getType()) {
                        case ConditionElementType.GROUP:
                            return reduced.concat(collectLocators(current.getConditionElements()));
                        case ConditionElementType.ROW:
                            return reduced.concat(current.getLocator(), current.getAdditionalLocators());
                        default:
                            return reduced;
                    }
                }, []);
            }

            /**
             * @method ConditionEvaluator#getLocators
             * @description
             * Returns unique list of all locators found in condition rows (including offsetAttributeLocators from relative ranges)
             * @returns {String[]}
             */
            ConditionEvaluator.prototype.getLocators = function () {
                return this._locators;
            };

            /**
             * @method ConditionEvaluator#evaluateCondition
             * @param {Object} actualValuesMap
             * @returns {Boolean}
             */
            ConditionEvaluator.prototype.evaluateCondition = function (actualValuesMap) {
                return this._evaluationTree.evaluate(actualValuesMap);
            };

            return ConditionEvaluator;

        }]);


angular.module('mxg.formElement.conditions.ConditionGroupEvaluator', [
    'mxg.formElement.conditions.ConditionGroupOperator',
    'mxg.formElement.conditions.ConditionElementType',
    'mxg.formElement.conditions.ConditionGroupModel',
    'mxg.formElement.conditions.ConditionRowEvaluator'
])
    .factory('mxgConditionGroupEvaluator', [
        'mxgConditionGroupOperator',
        'mxgConditionElementType',
        'mxgConditionRowEvaluator',
        function (ConditionGroupOperator, ConditionElementType, ConditionRowEvaluator) {
            'use strict';

            /**
             * @class
             */
            function ConditionGroupEvaluator(groupOperator, conditionElements) {
                this._groupEvaluationFunction = (groupOperator == ConditionGroupOperator.ANY) ? Array.prototype.some : Array.prototype.every;
                this._groupItems = conditionElements.map(function(item) {
                    switch (item.getType()) {
                        case ConditionElementType.GROUP:
                            return new ConditionGroupEvaluator(item.getGroupOperator(), item.getConditionElements());
                        case ConditionElementType.ROW:
                            return new ConditionRowEvaluator(item);
                        default:
                            return null;
                    }
                });
            }

            /**
             * @method ConditionGroupEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionGroupEvaluator.prototype.evaluate = function (actualValues) {
                return this._groupEvaluationFunction.call(this._groupItems, function(item) {
                    return item.evaluate(actualValues);
                });
            };

            return ConditionGroupEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionGroupModel', [
    'mxg.formElement.conditions.ConditionElementModelFactory',
    'mxg.formElement.conditions.ConditionElementModel',
    'mxg.formElement.conditions.ConditionGroupOperator'
])
    .factory('mxgConditionGroupModel', [
        'mxgConditionElementModel',
        'mxgConditionElementModelFactory',
        function (ConditionElementModel, ConditionElementModelFactory) {
            'use strict';

            var _super = ConditionElementModel;

            /**
             * @ngdoc Model
             * @class
             * @extends ConditionElementModel
             * @param {Object} model
             */
            function ConditionGroupModel(model) {
                _super.call(this, model);
                this._groupOperator = model.groupOperator;
                if (model.conditionElements && model.conditionElements.length) {
                    this._conditionElements = model.conditionElements.map(function(elementModel) {
                        return ConditionElementModelFactory.build(elementModel);
                    });
                }
                else {
                    this._conditionElements = [];
                }
            }

            ConditionGroupModel.prototype = Object.create(_super.prototype);
            ConditionGroupModel.prototype.constructor = ConditionGroupModel;

            /**
             * @method ConditionGroupModel#getGroupOperator
             * @returns {String}
             */
            ConditionGroupModel.prototype.getGroupOperator = function () {
                return this._groupOperator;
            };

            /**
             * @method ConditionGroupModel#getConditionElements
             * @returns {Array}
             */
            ConditionGroupModel.prototype.getConditionElements = function () {
                return this._conditionElements;
            };

            return ConditionGroupModel;

        }]);

/**
 * @ngdoc constant
 * @name mxgConditionGroupOperator
 * */
angular.module('mxg.formElement.conditions.ConditionGroupOperator', [])
    .constant('mxgConditionGroupOperator',
        {
            ALL: 'ALL', /* logical AND */
            ANY: 'ANY'  /* logical OR */
        });


angular.module('mxg.formElement.conditions.ConditionModel', [
    'mxg.formElement.conditions.ConditionElementModelFactory',
    'mxg.formElement.conditions.ConditionGroupOperator'
])
    .factory('mxgConditionModel', [
        'mxgConditionGroupOperator', 'mxgConditionElementModelFactory',
        function (ConditionGroupOperator, ConditionElementModelFactory) {
            'use strict';

            /**
             * @ngdoc Model
             * @class
             * @param {Object} model
             */
            function ConditionModel(model) {
                this._groupOperator = ConditionGroupOperator.ANY;
                if (model.conditionGroups && model.conditionGroups.length) {
                    this._conditionElements = model.conditionGroups.map(function (groupModel) {
                        return ConditionElementModelFactory.build(groupModel);
                    });
                }
                else {
                    this._conditionElements = [];
                }
            }

            /**
             * @method ConditionModel#getGroupOperator
             * @returns {String}
             */
            ConditionModel.prototype.getGroupOperator = function () {
                return this._groupOperator;
            };

            /**
             * @method ConditionModel#getGroups
             * @returns {Array}
             */
            ConditionModel.prototype.getGroups = function () {
                return this._conditionElements;
            };

            return ConditionModel;

        }]);

angular.module('mxg.formElement.conditions.ConditionNumberValueEvaluator', [
    'mxg.formElement.conditions.ConditionOperator',
    'mxg.formElement.conditions.ConditionValueEvaluator'
])
    .factory('mxgConditionNumberValueEvaluator', [
        'mxgConditionOperator',
        'mxgConditionValueEvaluator',
        function (ConditionOperator, ConditionValueEvaluator) {
            'use strict';

            var _super = ConditionValueEvaluator;

            var testFunctionsMap = {};
            testFunctionsMap[ConditionOperator.GREATER] = function testNumber_GREATER(expected, actual) {
                return actual > expected;
            };
            testFunctionsMap[ConditionOperator.LESS] = function testNumber_LESS(expected, actual) {
                return actual < expected;
            };
            testFunctionsMap[ConditionOperator.GREATER_EQ] = function testNumber_GREATER_EQ(expected, actual) {
                return actual >= expected;
            };
            testFunctionsMap[ConditionOperator.LESS_EQ] = function testNumber_LESS_EQ(expected, actual) {
                return actual <= expected;
            };
            testFunctionsMap[ConditionOperator.IS] = function testNumber_IS(expected, actual) {
                return actual === expected;
            };
            testFunctionsMap[ConditionOperator.IS_NOT] = function testNumber_GREATER(expected, actual) {
                return actual !== expected;
            };

            /**
             * @class
             * @extends ConditionValueEvaluator
             */
            function ConditionNumberValueEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);
                if (testFunctionsMap[rowModel.getOperator()]) {
                    this._testFunction = testFunctionsMap[rowModel.getOperator()];
                }
            }

            ConditionNumberValueEvaluator.prototype = Object.create(_super.prototype);
            ConditionNumberValueEvaluator.prototype.constructor = ConditionNumberValueEvaluator;

            return ConditionNumberValueEvaluator;

        }]);

/**
 * @ngdoc constant
 * @name mxgConditionOperator
 * */
angular.module('mxg.formElement.conditions.ConditionOperator', [])
    .constant('mxgConditionOperator', {
        IS: 'IS',
        IS_NOT: 'IS_NOT',
        ANY_MEMBER_OF: 'ANY_MEMBER_OF',
        ALL_MEMBER_OF: 'ALL_MEMBER_OF',
        NOT_IN: 'NOT_IN',
        IN_RANGE: 'IN_RANGE',
        NOT_IN_RANGE: 'NOT_IN_RANGE',
        GREATER: 'GREATER',
        LESS: 'LESS',
        LESS_EQ: 'LESS_EQ',
        GREATER_EQ: 'GREATER_EQ'
    });

angular.module('mxg.formElement.conditions.ConditionRangeEvaluator', [
    'mxg.formElement.conditions.ConditionOperator'
])
    .factory('mxgConditionRangeEvaluator', [
        'mxgConditionOperator',
        function (ConditionOperator) {
            'use strict';

            function inRange(from, to, value) {
                if (from != null || to != null) {
                    return (from == null ? true : (value >= from)) && (to == null ? true : (value <= to));
                }
                return true;
            }

            var testFunctionsMap = {};
            testFunctionsMap[ConditionOperator.IN_RANGE] = function test_IN_RANGE(expectedFrom, expectedTo, actual) {
                return inRange(expectedFrom, expectedTo, actual);
            };
            testFunctionsMap[ConditionOperator.NOT_IN_RANGE] = function test_IN_RANGE(expectedFrom, expectedTo, actual) {
                return !inRange(expectedFrom, expectedTo, actual);
            };

            /**
             * @class
             */
            function ConditionRangeEvaluator(rowModel, valueTransformationFunction) {
                this._rowModel = rowModel;
                this._valueTransformationFunction = valueTransformationFunction;
                this._testFunction = testFunctionsMap[rowModel.getOperator()];
            }

            /**
             * @method ConditionRangeEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionRangeEvaluator.prototype.evaluate = function (actualValues) {
                if (!this._testFunction) {
                    return false;
                }
                var range = this._rowModel.getRange();
                return this._testFunction(range.from, range.to,
                    this._valueTransformationFunction(actualValues[this._rowModel.getLocator()]));
            };

            return ConditionRangeEvaluator;

        }]);

/**
 * @ngdoc constant
 * @name mxgConditionRangeType
 * */
angular.module('mxg.formElement.conditions.ConditionRangeType', [])
    .constant('mxgConditionRangeType', {
        ABSOLUTE_NUMBER: 'ABSOLUTE_NUMBER',
        RELATIVE_NUMBER: 'RELATIVE_NUMBER',
        ABSOLUTE_DATE: 'ABSOLUTE_DATE',
        RELATIVE_DATE: 'RELATIVE_DATE'
    });

angular.module('mxg.formElement.conditions.ConditionReferenceValueEvaluator', [
    'mxg.formElement.conditions.ConditionOperator',
    'mxg.formElement.conditions.ConditionValueEvaluator'
])
    .factory('mxgConditionReferenceValueEvaluator', [
        'mxgConditionOperator',
        'mxgConditionValueEvaluator',
        function (ConditionOperator, ConditionValueEvaluator) {
            'use strict';

            var _super = ConditionValueEvaluator;

            var testFunctionsMap = {};
            testFunctionsMap[ConditionOperator.IS] = function testReference_IS(expected, actual) {
                return actual.indexOf(expected[0]) !== -1;
            };
            testFunctionsMap[ConditionOperator.IS_NOT] = function testReference_IS_NOT(expected, actual) {
                return actual.indexOf(expected[0]) === -1;
            };
            testFunctionsMap[ConditionOperator.ANY_MEMBER_OF] = function testReference_ANY_MEMBER_OF(expected, actual) {
                return expected.some(function (item) {
                    return actual.indexOf(item) !== -1;
                });
            };
            testFunctionsMap[ConditionOperator.ALL_MEMBER_OF] = function testReference_ALL_MEMBER_OF(expected, actual) {
                return expected.every(function (item) {
                    return actual.indexOf(item) !== -1;
                });
            };
            testFunctionsMap[ConditionOperator.NOT_IN] = function testReference_NOT_IN(expected, actual) {
                return expected.every(function (item) {
                    return actual.indexOf(item) === -1;
                });
            };

            /**
             * @class
             * @extends ConditionValueEvaluator
             */
            function ConditionReferenceValueEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);
                if (testFunctionsMap[rowModel.getOperator()]) {
                    this._testFunction = testFunctionsMap[rowModel.getOperator()];
                }
            }

            ConditionReferenceValueEvaluator.prototype = Object.create(_super.prototype);
            ConditionReferenceValueEvaluator.prototype.constructor = ConditionReferenceValueEvaluator;

            return ConditionReferenceValueEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionRowEvaluator', [
    'mxg.formElement.conditions.ConditionRowModel',
    'mxg.formElement.conditions.ConditionValueEvaluatorFactory'
])
    .factory('mxgConditionRowEvaluator', [
        'mxgConditionValueEvaluatorFactory',
        function (ConditionValueEvaluatorFactory) {
            'use strict';

            /**
             * @class
             */
            function ConditionRowEvaluator(rowModel) {
                this._rowModel = rowModel;
                this._valueEvaluator = null;
            }

            /**
             * @method ConditionRowEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionRowEvaluator.prototype.evaluate = function (actualValues) {
                var mainLocator = this._rowModel.getLocator();
                var additionalLocators = this._rowModel.getAdditionalLocators();
                if (additionalLocators.concat(mainLocator).some(function (locator) {
                        return actualValues[locator] == null;
                    })) {
                    return false;
                }
                return actualValues[mainLocator].some((function (actualValue) {
                    var rowActualValues = {};
                    rowActualValues[mainLocator] = actualValue;
                    additionalLocators.forEach(function (locator) {
                        rowActualValues[locator] = actualValues[locator];
                    });
                    if (this._valueEvaluator == null) {
                        this._valueEvaluator = ConditionValueEvaluatorFactory.build(this._rowModel,
                            rowActualValues[mainLocator]);
                    }
                    return this._valueEvaluator ? this._valueEvaluator.evaluate(rowActualValues) : false;
                }).bind(this));
            };

            return ConditionRowEvaluator;

        }]);


angular.module('mxg.formElement.conditions.ConditionRowModel', [
    'mxg.formElement.conditions.ConditionElementModel'
])
    .factory('mxgConditionRowModel', [
        'mxgConditionElementModel',
        function (ConditionElementModel) {
            'use strict';

            var _super = ConditionElementModel;

            /**
             * @ngdoc Model
             * @class
             * @extends ConditionElementModel
             * @param {Object} model
             */
            function ConditionRowModel(model) {
                _super.call(this, model);
                this._locator = model.locator;
                this._operator = model.operator;
                this._value = model.value || null;
                this._range = model.range|| null;
            }

            ConditionRowModel.prototype = Object.create(_super.prototype);
            ConditionRowModel.prototype.constructor = ConditionRowModel;

            /**
             * @method ConditionRowModel#getLocator
             * @returns {String}
             */
            ConditionRowModel.prototype.getLocator = function () {
                return this._locator;
            };

            /**
             * @method ConditionRowModel#getOperator
             * @returns {String}
             */
            ConditionRowModel.prototype.getOperator = function () {
                return this._operator;
            };

            /**
             * @method ConditionRowModel#getValue
             * @returns {Object}
             */
            ConditionRowModel.prototype.getValue = function () {
                return this._value;
            };

            /**
             * @method ConditionRowModel#getRange
             * @returns {Object}
             */
            ConditionRowModel.prototype.getRange = function () {
                return this._range;
            };

            /**
             * @method ConditionRowModel#getAdditionalLocators
             * @returns {String[]}
             */
            ConditionRowModel.prototype.getAdditionalLocators = function () {
                if (this._range && this._range.offsetAttributeLocator) {
                    return [this._range.offsetAttributeLocator];
                }
                return [];
            };

            return ConditionRowModel;

        }]);


angular.module('mxg.formElement.conditions', [
    'mxg.formElement.conditions.ConditionOperator',
    'mxg.formElement.conditions.ConditionGroupOperator',
    'mxg.formElement.conditions.ConditionRangeType',
    'mxg.formElement.conditions.ConditionElementType',
    'mxg.formElement.conditions.ConditionElementModel',
    'mxg.formElement.conditions.ConditionGroupModel',
    'mxg.formElement.conditions.ConditionRowModel',
    'mxg.formElement.conditions.ConditionElementModelFactory',
    'mxg.formElement.conditions.ConditionModel',
    'mxg.formElement.conditions.ConditionValueEvaluator',
    'mxg.formElement.conditions.ConditionReferenceValueEvaluator',
    'mxg.formElement.conditions.ConditionNumberValueEvaluator',
    'mxg.formElement.conditions.ConditionDateValueEvaluator',
    'mxg.formElement.conditions.ConditionStringValueEvaluator',
    'mxg.formElement.conditions.ConditionRangeEvaluator',
    'mxg.formElement.conditions.ConditionDateAbsoluteRangeEvaluator',
    'mxg.formElement.conditions.ConditionDateRelativeRangeEvaluator',
    'mxg.formElement.conditions.ConditionValueEvaluatorFactory',
    'mxg.formElement.conditions.ConditionRowEvaluator',
    'mxg.formElement.conditions.ConditionGroupEvaluator',
    'mxg.formElement.conditions.ConditionEvaluator'
]);

angular.module('mxg.formElement.conditions.ConditionStringValueEvaluator', [
    'mxg.formElement.conditions.ConditionOperator',
    'mxg.formElement.conditions.ConditionValueEvaluator'
])
    .factory('mxgConditionStringValueEvaluator', [
        'mxgConditionOperator',
        'mxgConditionValueEvaluator',
        function (ConditionOperator, ConditionValueEvaluator) {
            'use strict';

            var _super = ConditionValueEvaluator;

            var testFunctionsMap = {};
            testFunctionsMap[ConditionOperator.IS] = function testString_IS(expected, actual) {
                return actual === expected;
            };
            testFunctionsMap[ConditionOperator.IS_NOT] = function testString_IS_NOT(expected, actual) {
                return actual !== expected;
            };

            /**
             * @class
             * @extends ConditionValueEvaluator
             */
            function ConditionStringValueEvaluator(rowModel, valueTransformationFunction) {
                _super.call(this, rowModel, valueTransformationFunction);
                if (testFunctionsMap[rowModel.getOperator()]) {
                    this._testFunction = testFunctionsMap[rowModel.getOperator()];
                }
            }

            ConditionStringValueEvaluator.prototype = Object.create(_super.prototype);
            ConditionStringValueEvaluator.prototype.constructor = ConditionStringValueEvaluator;

            return ConditionStringValueEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionValueEvaluator', [])
    .factory('mxgConditionValueEvaluator', [
        function () {
            'use strict';

            /**
             * @class
             * @abstract
             */
            function ConditionValueEvaluator(rowModel, valueTransformationFunction) {
                this._rowModel = rowModel;
                this._valueTransformationFunction = valueTransformationFunction;
                this._expected = valueTransformationFunction(rowModel.getValue());
            }

            /**
             * @method ConditionValueEvaluator#evaluate
             * @param {Object} actualValues
             * @returns {Boolean}
             */
            ConditionValueEvaluator.prototype.evaluate = function (actualValues) {
                return this._testFunction(this._expected,
                    this._valueTransformationFunction(actualValues[this._rowModel.getLocator()]));
            };

            ConditionValueEvaluator.prototype._testFunction = function (expected, actual) {
                return false;
            };

            return ConditionValueEvaluator;

        }]);

angular.module('mxg.formElement.conditions.ConditionValueEvaluatorFactory', [
    'mxg.helpers.DateHelper',
    'mxg.components.typedValue.TypedValueService',
    'mxg.formElement.conditions.ConditionRangeType',
    'mxg.formElement.conditions.ConditionReferenceValueEvaluator',
    'mxg.formElement.conditions.ConditionNumberValueEvaluator',
    'mxg.formElement.conditions.ConditionDateValueEvaluator',
    'mxg.formElement.conditions.ConditionStringValueEvaluator',
    'mxg.formElement.conditions.ConditionRangeEvaluator',
    'mxg.formElement.conditions.ConditionDateAbsoluteRangeEvaluator',
    'mxg.formElement.conditions.ConditionDateRelativeRangeEvaluator'
])
    .service('mxgConditionValueEvaluatorFactory', [
        'mxgDateHelper',
        'mxgTypedValueService',
        'mxgConditionRangeType',
        'mxgConditionReferenceValueEvaluator',
        'mxgConditionNumberValueEvaluator',
        'mxgConditionDateValueEvaluator',
        'mxgConditionStringValueEvaluator',
        'mxgConditionRangeEvaluator',
        'mxgConditionDateAbsoluteRangeEvaluator',
        'mxgConditionDateRelativeRangeEvaluator',
        function (DateHelper, TypedValueService, ConditionRangeType, ConditionReferenceValueEvaluator, ConditionNumberValueEvaluator, ConditionDateValueEvaluator, ConditionStringValueEvaluator, ConditionRangeEvaluator, ConditionDateAbsoluteRangeEvaluator, ConditionDateRelativeRangeEvaluator) {
            'use strict';

            var service = this;

            service.build = function (rowModel, actualValueObject) {
                var valueType = TypedValueService.parseValueType(actualValueObject);
                if (!valueType) {
                    return null;
                }
                var valueEvaluationClass = null;
                var transformValueFunction = null;
                var isRange = !!rowModel.getRange();
                switch (valueType) {
                    case 'REFERENCE':
                        transformValueFunction = parseReferenceValue;
                        valueEvaluationClass = ConditionReferenceValueEvaluator;
                        break;
                    case 'DATE':
                        transformValueFunction = parseDateValue;
                        valueEvaluationClass = !isRange ? ConditionDateValueEvaluator : (rowModel.getRange().type === ConditionRangeType.RELATIVE_DATE ? ConditionDateRelativeRangeEvaluator : ConditionDateAbsoluteRangeEvaluator);
                        break;
                    case 'DATE_PARTIAL':
                        transformValueFunction = parseDatePartialValue;
                        valueEvaluationClass = !isRange ? ConditionDateValueEvaluator : (rowModel.getRange().type === ConditionRangeType.RELATIVE_DATE ? ConditionDateRelativeRangeEvaluator : ConditionDateAbsoluteRangeEvaluator);
                        break;
                    case 'DECIMAL':
                        transformValueFunction = parseDecimalValue;
                        valueEvaluationClass = isRange ? ConditionRangeEvaluator : ConditionNumberValueEvaluator;
                        break;
                    case 'INTEGER':
                        transformValueFunction = parseIntegerValue;
                        valueEvaluationClass = isRange ? ConditionRangeEvaluator : ConditionNumberValueEvaluator;
                        break;
                    case 'STRING':
                        transformValueFunction = parseStringValue;
                        valueEvaluationClass = ConditionStringValueEvaluator;
                        break;
                }

                if (!valueEvaluationClass || !transformValueFunction) {
                    return null;
                }

                return new valueEvaluationClass(rowModel, transformValueFunction);

            };

            function parseReferenceValue(valueObject) {
                return valueObject.referenceDataValues.map(function (item) {
                    return item.uuid || item.code;
                });
            }

            function parseDateValue(valueObject) {
                return DateHelper.createDateInLocalTimezone(valueObject.dateValue);
            }

            function parseDatePartialValue(valueObject) {
                return DateHelper.createDateInLocalTimezone(valueObject.datePartialValue);
            }

            function parseDecimalValue(valueObject) {
                return valueObject.decimalValue;
            }

            function parseIntegerValue(valueObject) {
                return valueObject.intValue;
            }

            function parseStringValue(valueObject) {
                return valueObject.stringValue;
            }

        }]);

/**
 * @example
 * <div mxg-form-element:form>
 */
angular.module('mxg.formElement.form.Form', [
    'ngSanitize',
    'mxg.formElement.form.FormCtrl',
    'mxg.formElement.FormConfig',
    'mxg.markupToHTML'
])
    .directive('mxgFormElementForm', ['mxgFormConfig', function (FormConfig) {
        'use strict';
        return {
            templateUrl: 'mxg-template/formElement/FormElement.Form.html',
            controller: 'mxgFormCtrl',
            controllerAs: 'form',
            scope: false,
            link: function ($scope, $element) {
                var formElement = angular.element($element[0].querySelector('.mxg-form'));
                if (FormConfig.getOption('highlightUnansweredQuestions')) {
                    formElement.addClass('mxg-form__highlight-empty-question');
                }
            }
        };
    }]);

angular.module('mxg.formElement.form', [
    'mxg.formElement.form.Form',
    'mxg.formElement.form.FormCtrl',
    'mxg.formElement.form.FormModel'
]);

angular.module('mxg.formElement.form.FormCtrl',
    [
        'mxg.formElement.FormElementType',
        'mxg.formElement.FocusManager'
    ])
    .controller('mxgFormCtrl', [
        '$scope', 'mxgFormElementType', 'mxgFocusManager',
        function ($scope, FormElementType, FocusManager) {
            'use strict';
            var formCtrl = this;
            formCtrl.getFormClasses = function() {
                if (!$scope.formElement) {
                    return null;
                }
                var classes = [];
                if ($scope.formElement.checkWasSubmitted()) {
                    classes[0] = 'mxg-form__submitted';
                }
                var styleClasses = $scope.formElement.getCustomStyles();
                styleClasses && classes.push(styleClasses);
                return classes.join(' ');
            };

            if (angular.isObject($scope.formElement)) {
                !FocusManager.focusTaken() && focusForFirstQuestion($scope.formElement);
            }

            function focusForFirstQuestion(formElement) {
                var firstQuestion = formElement.getFirstChild(FormElementType.QUESTION.toString(), true);
                if (angular.isObject(firstQuestion)) {
                    FocusManager.requestFocus(firstQuestion.getFocusId());
                }
            }

        }]);

angular.module('mxg.formElement.form.FormModel', [
    'mxg.formElement.FormElementModel',
    'mxg.formElement.FormElementLocationService',
    'mxg.formElement.FormElementType'
])
    .factory('mxgFormModel', [
        'mxgFormElementModel', 'mxgFormElementLocationService', 'mxgFormElementType',
        function (FormElementModel, FormElementLocationService, FormElementType) {
            'use strict';

            /**
             * @class
             */
            function FormModel(model, parentNode) {
                FormElementModel.call(this, model, parentNode);
            }

            FormModel.prototype = Object.create(FormElementModel.prototype);
            FormModel.prototype.constructor = FormModel;

            FormModel.prototype.checkWasSubmitted = function () {
                return this.getAttribute('submittedBefore');
            };

            FormModel.prototype.isBootstrapForm = function () {
                return this.getAttribute('formDefinitionType') === 'BOOTSTRAP_FORM';
            };

            FormModel.prototype.getLanguage = function () {
                return this.getAttribute('language');
            };

            FormModel.prototype.toJSON = function () {
                var json = FormElementModel.prototype.toJSON.call(this);
                delete json.bootstrapType;
                delete json.completed;
                delete json.submittedBefore;
                return json;
            };

            FormModel.prototype._updateTriggerQuestions = function (triggerQuestions) {
                var root = this;
                var model = {
                    type: 'SECTION',
                    childElements: triggerQuestions
                };
                FormElementLocationService.updateQuestionsLocators(model, root);
            };

            FormModel.prototype._updateInlineForms = function (updatedInlineSections) {
                var root = this;
                var sectionType = FormElementType.SECTION_INLINE.toString();
                var processed = [];
                var updatedSectionsUUIDList = [];
                var inlineSectionModelsMap = FormElementLocationService.mapFormElementsByUUID(root, sectionType);
                updatedInlineSections.forEach(function (updatedSection) {
                    if (updatedSectionsUUIDList.indexOf(updatedSection.uuid) === -1) {
                        updatedSectionsUUIDList.push(updatedSection.uuid);
                    }
                    (inlineSectionModelsMap[updatedSection.uuid] || []).some(function (sectionModel) {
                        if (processed.indexOf(sectionModel) !== -1) {
                            return false;
                        }
                        var beforeUUIDs;
                        var afterUUIDs = {};
                        var sectionsToRemove = [];
                        if (sectionModel.hasChildElements()) {
                            /*
                             * More sophisticated algorithm for update:
                             * */
                            (updatedSection.childElements || []).forEach(function (item) {
                                return afterUUIDs[item.uuid] = item;
                            });

                            sectionModel.getChildElements()
                                .forEach(function (childSectionModel) {
                                    var childUpdatedSection = afterUUIDs[childSectionModel.getUUID()];
                                    var formElementsMap, updatedNodesList, processedFormElements;
                                    if (childUpdatedSection) {
                                        /*
                                         * Update locators and conditions (because conditions have locators in params and they can change)
                                         * on all nodes inside the section
                                         * */
                                        childSectionModel.setTitle(childUpdatedSection.title);
                                        formElementsMap = FormElementLocationService.mapFormElementsByUUID(childSectionModel);
                                        updatedNodesList = [];
                                        processedFormElements = [];
                                        (function flattenModel(node) {
                                            updatedNodesList.push(node);
                                            (node.childElements || []).forEach(flattenModel);
                                        })(childUpdatedSection);
                                        updatedNodesList.forEach(function(node) {
                                            var uuid = node.uuid || node.questionDefinitionId;
                                            if (!uuid) {
                                                return;
                                            }
                                            var foundFormElements = formElementsMap[uuid] || null;
                                            if (foundFormElements === null) {
                                                return;
                                            }
                                            foundFormElements.some(function (formElementModel) {
                                                if (processedFormElements.indexOf(formElementModel) !== -1) {
                                                    return false;
                                                }
                                                if (formElementModel.getLocator() !== node.locator) {
                                                    formElementModel.setLocator(node.locator);
                                                }
                                                formElementModel.setCondition(node.condition || null);
                                                processedFormElements.push(formElementModel);
                                                return true;
                                            });
                                        });
                                    }
                                    else {
                                        /*
                                         * Remove sections that was deleted on server
                                         * */
                                        sectionsToRemove.push(childSectionModel);
                                    }
                                });

                            sectionsToRemove.forEach(function (childSectionModel) {
                                sectionModel.removeChild(childSectionModel);
                            });
                            /*
                             * 2) Add new sections
                             * */
                            beforeUUIDs = sectionModel.getChildElements().map(function (item) {
                                return item.getUUID();
                            });
                            (updatedSection.childElements || []).forEach(function (child, index) {
                                if (beforeUUIDs.indexOf(child.uuid) === -1) {
                                    sectionModel.insertChild(child, index);
                                }
                            });
                        }
                        else {
                            /*
                             * Simple algorithm: just add what came from server
                             * */
                            (updatedSection.childElements || []).forEach(function (childSection) {
                                sectionModel.addChild(childSection);
                            });
                        }
                        processed.push(sectionModel);
                        return true;
                    });
                });
                /**
                 * some inline sections could be removed on server - we have to remove them too
                 */
                angular.forEach(inlineSectionModelsMap, function (sectionModels, uuid) {
                    if (updatedSectionsUUIDList.indexOf(uuid) === -1) {
                        sectionModels.forEach(function (sectionModel) {
                            sectionModel.getParent().removeChild(sectionModel);
                        });
                    }
                });
            };

            FormModel.prototype.processPartialSubmitResponse = function (data) {
                var updated = false;
                if (angular.isArray(data.triggerQuestions) && data.triggerQuestions.length) {
                    this._updateTriggerQuestions(data.triggerQuestions);
                    updated = true;
                }
                this.cleanUpEmptyRepeatingInstances();
                if (angular.isArray(data.sections)) {
                    this._updateInlineForms(data.sections);
                    updated = true;
                }
                if (updated) {
                    this.clearFalseConditional();
                    this.persist();
                }
                this.addDefaultEmptyRepeatingInstances();
                this._rebuildFormElementIds();
                return updated;
            };

            return FormModel;
        }]);

angular.module('mxg.formElement.formElementProperty.FormElementProperty', [])
    .constant('mxgFormElementProperty', {
        INITIAL_FOCUS: "INITIAL_FOCUS",
        INITIAL_FOCUS_REF: "INITIAL_FOCUS_REF",
        STEP: "STEP",
        HEIGHT: "HEIGHT",
        INITIAL_FOCUS_OFFSET: "INITIAL_FOCUS_OFFSET",
        INITIAL_FOCUS_UNITS: "INITIAL_FOCUS_UNITS",
        INPUT_FORMAT: "INPUT_FORMAT",
        DISPLAY_INPUT_MASK: "DISPLAY_INPUT_MASK",
        MAX_LENGTH: "MAX_LENGTH",
        PRECISION: "PRECISION",
        AUTO_EXPANDABLE: "AUTO_EXPANDABLE",
        NO_VALUE_ITEM: "NO_VALUE_ITEM",
        LAYOUT_TYPE: "LAYOUT_TYPE",
        FIRST_COLUMN_WIDTH: "FIRST_COLUMN_WIDTH",
        MIN_INSTANCES: "MIN_INSTANCES",
        MAX_INSTANCES: "MAX_INSTANCES",
        CSS_STYLE: "CSS_STYLE"
    });

angular.module('mxg.formElement.formElementProperty', [
    'mxg.formElement.formElementProperty.FormElementProperty',
    'mxg.formElement.formElementProperty.FormElementPropertyModel'
]);

angular.module('mxg.formElement.formElementProperty.FormElementPropertyModel', [])
    .factory('mxgFormElementPropertyModel', [function () {

        /**
         * @ngdoc Model
         * @param model
         * @class FormElementPropertyModel
         * */
        function FormElementPropertyModel(model) {
            this._name = model.name;
            this._value = parseValue(model.value);
        }

        /**
         * @ngdoc method
         * @method FormElementPropertyModel#getName
         * @returns {String}
         */
        FormElementPropertyModel.prototype.getName = function () {
            return this._name;
        };

        /**
         * @ngdoc method
         * @method FormElementPropertyModel#getValue
         * @returns {*}
         */
        FormElementPropertyModel.prototype.getValue = function () {
            return this._value;
        };

        /**
         * @ngdoc method
         * @method FormElementPropertyModel.build
         * @static
         * @param {Object} model
         */
        FormElementPropertyModel.build = function (model) {
            return new FormElementPropertyModel(model);
        };

        function parseValue (valueModel) {

            var keys;
            var valueProperty;

            if (!angular.isObject(valueModel)) {
                return null;
            }

            keys = Object.keys(valueModel);
            if (!keys.length) {
                return null;
            }

            valueProperty = keys[0];

            if ((valueProperty === 'referenceDataValues') && valueModel[valueProperty].length) {
                return valueModel[valueProperty][0].code;
            }

            return valueModel[valueProperty];

        }

        return FormElementPropertyModel;

    }]);

angular.module('mxg.formElement.sectionInline.SectionInline', [])
    .directive('mxgFormElementSectionInline', [function () {

        "use strict";

        return {
            templateUrl: 'mxg-template/formElement/FormElement.SectionInline.html',
            scope: false
        };

    }]);

angular.module('mxg.formElement.sectionInline', [
    'mxg.formElement.sectionInline.SectionInline',
    'mxg.formElement.sectionInline.SectionInlineModel'
]);

angular.module('mxg.formElement.sectionInline.SectionInlineModel', ['mxg.formElement.SectionModel'])
    .factory('mxgSectionInlineModel', ['mxgSectionModel', function (SectionModel) {
        'use strict';

        /**
         * @class
         */
        function SectionInlineModel(model, parentNode) {

            SectionModel.call(this, model, parentNode);

        }

        SectionInlineModel.prototype = Object.create(SectionModel.prototype);
        SectionInlineModel.prototype.constructor = SectionInlineModel;

        return SectionInlineModel;

    }]);

angular.module('mxg.formElement.question.DatePartialQuestionModelValidator', [
    'mxg.formElement.question.DateQuestionModelValidator',
    'mxg.components.datePartial.DatePartialModel',
    'mxg.validation.ValidationType',
    'mxg.system.RuntimeConstants'
])
    .factory('mxgDatePartialQuestionModelValidator',
        ['dateFilter', 'mxgDateQuestionModelValidator', 'mxgDatePartialModel', 'mxgValidationType', 'mxgRuntimeConstants',
         function (dateFilter, DateQuestionModelValidator, DatePartialModel, ValidationType, RuntimeConstants) {
             "use strict";

             var _super = DateQuestionModelValidator;

             var DATE_PARTIAL_TEST = /^\d{4}(-(0[1-9]|1[012]+)-(0[1-9]|[12][0-9]|3[01])$|-(0[1-9]|1[012]+)$|$)/i;

             function DatePartialQuestionValueValidator(questionModel) {
                 _super.call(this, questionModel);
             }

             DatePartialQuestionValueValidator.prototype = Object.create(_super.prototype);
             DatePartialQuestionValueValidator.prototype.constructor = DatePartialQuestionValueValidator;

             DatePartialQuestionValueValidator.prototype.dataTypeTest = function () {

                 return DATE_PARTIAL_TEST.test(this._questionModel.getValue()) ? null : this.createErrorModel(
                     ValidationType.INCORRECT,
                     RuntimeConstants.ErrorCode.DATE_PARTIAL_INVALID);

             };

             DatePartialQuestionValueValidator.prototype.rangeTest = function () {

                 var errorType = null;

                 var minDate = this._questionModel.getMinValue();
                 var maxDate = this._questionModel.getMaxValue();
                 var value = this._questionModel.getValue();
                 var displayFormat = this._questionModel.getQuestionProperty('input_format') || 'yyyy-MM-dd';
                 displayFormat = DatePartialModel.canonizeFormat(displayFormat);
                 var minDateDisplay = minDate ? dateFilter(minDate, displayFormat) : '';
                 var maxDateDisplay = maxDate ? dateFilter(maxDate, displayFormat) : '';

                 if ((minDate && DatePartialQuestionValueValidator.lessThan(value, minDate))
                     || (maxDate && DatePartialQuestionValueValidator.greaterThan(value, maxDate))) {
                     if (minDate && maxDate) {
                         errorType = RuntimeConstants.ErrorCode.VALUE_NOT_WITHIN_RANGE;
                     } else if (minDate) {
                         errorType = RuntimeConstants.ErrorCode.VALUE_IS_LESS_THAN;
                     } else {
                         errorType = RuntimeConstants.ErrorCode.VALUE_IS_GREATER_THAN;
                     }
                 }

                 return errorType ? this.createErrorModel(ValidationType.INCORRECT, errorType,
                     {minValue: minDateDisplay, maxValue: maxDateDisplay}) : null;

             };

             /**
              * @static
              * @description
              *  Values are expected to be a valid Dates in format "yyyy-MM-dd"
              * @param {String} value1
              * @param {String} value2
              * @returns {Number} -1|0|1
              * */
             DatePartialQuestionValueValidator.compareValues = function (value1, value2) {

                 var partValues1 = value1.split('-');
                 var partValues2 = value2.split('-');
                 var minValuePriority1 = partValues1.length - 1;
                 var minValuePriority2 = partValues2.length - 1;
                 var comparison = null;
                 var p = 0;

                 while (!comparison && p <= minValuePriority1 && p <= minValuePriority2) {
                     comparison = comparator(+partValues1[p], +partValues2[p]);
                     p++;
                 }

                 return comparison;

                 function comparator(a, b) {
                     return a > b ? 1 : (a < b ? -1 : 0);
                 }

             };

             /**
              * @static
              * @param {String} value1
              * @param {String} value2
              * @returns boolean
              * */
             DatePartialQuestionValueValidator.lessThan = function (value1, value2) {
                 return DatePartialQuestionValueValidator.compareValues(value1, value2) === -1;
             };

             /**
              * @static
              * @param {String} value1
              * @param {String} value2
              * @returns boolean
              * */
             DatePartialQuestionValueValidator.greaterThan = function (value1, value2) {
                 return DatePartialQuestionValueValidator.compareValues(value1, value2) === 1;
             };

             return DatePartialQuestionValueValidator;

         }]);

angular.module('mxg.formElement.question.DateQuestionModelValidator', [
    'mxg.translation',
    'mxg.formElement.question.QuestionModelValidator',
    'mxg.validation.ValidationType',
    'mxg.system.RuntimeConstants',
    'mxg.components.PartialDate',
    'mxg.components.iDateFilter'
])
    .factory('mxgDateQuestionModelValidator',
        ['mxgTranslateService', 'mxgQuestionModelValidator', 'mxgValidationType', 'mxgRuntimeConstants', 'mxgPartialDate', 'mxgIDateFilter',
         function (TranslateService, QuestionModelValidator, ValidationType, RuntimeConstants, mxgDate, iDateFilter) {
             "use strict";

             var _super = QuestionModelValidator;

             var DATE_TEST = /^((19|20)\d\d+)-(0[1-9]|1[012]+)-(0[1-9]|[12][0-9]|3[01])$/i;

             function DateQuestionModelValidator(questionModel) {

                 _super.call(this, questionModel);

                 this._testQueue.push(this.dataTypeTest);
                 this._testQueue.push(this.rangeTest);

             }

             DateQuestionModelValidator.prototype = Object.create(_super.prototype);
             DateQuestionModelValidator.prototype.constructor = DateQuestionModelValidator;

             DateQuestionModelValidator.prototype.dataTypeTest = function () {
                 var displayFormat = TranslateService.getById('FrontEndLabels.HINT_FULL_DATE', null, true) || this._questionModel.getQuestionProperty('input_format') || 'yyyy-MM-dd';
                 return DATE_TEST.test(this._questionModel.getValue()) ? null : this.createErrorModel(
                     ValidationType.INCORRECT,
                     RuntimeConstants.ErrorCode.DATE_FORMAT_INVALID,
                     {inputFormat: displayFormat});
             };

             DateQuestionModelValidator.prototype.rangeTest = function () {

                 var errorType = null;

                 var minDate = this._questionModel.getMinValue();
                 var maxDate = this._questionModel.getMaxValue();

                 var value = mxgDate(this._questionModel.getValue());

                 var displayFormat = this._questionModel.getQuestionProperty('input_format') || 'yyyy-MM-dd';
                 var minDateDisplay = minDate ? iDateFilter(minDate, displayFormat) : '';
                 var maxDateDisplay = maxDate ? iDateFilter(maxDate, displayFormat) : '';

                 if ((minDate && value.lessThan(minDate)) || (maxDate && value.greaterThan(maxDate))) {
                     if (minDate && maxDate) {
                         errorType = RuntimeConstants.ErrorCode.VALUE_NOT_WITHIN_RANGE;
                     } else if (minDate) {
                         errorType = RuntimeConstants.ErrorCode.VALUE_IS_LESS_THAN;
                     } else if (maxDate) {
                         errorType = RuntimeConstants.ErrorCode.VALUE_IS_GREATER_THAN;
                     }
                 }

                 return errorType ? this.createErrorModel(ValidationType.INCORRECT, errorType,
                     {minValue: minDateDisplay, maxValue: maxDateDisplay}) : null;

             };

             return DateQuestionModelValidator;

         }]);


angular.module('mxg.formElement.question.DecimalQuestionModelValidator', [
        'mxg.formElement.question.NumberQuestionModelValidator',
        'mxg.validation.ValidationType',
        'mxg.system.RuntimeConstants'
    ])
    .factory('mxgDecimalQuestionModelValidator',
        ['mxgNumberQuestionModelValidator', 'mxgValidationType', 'mxgRuntimeConstants', function (NumberQuestionModelValidator, ValidationType, RuntimeConstants) {

            var _super = NumberQuestionModelValidator;

            var DECIMAL_TEST = /^-?([0-9]+|([0-9]+|)\.[0-9]+)$/;

            function DecimalQuestionValueValidator(questionModel) {
                _super.call(this, questionModel);
            }

            DecimalQuestionValueValidator.prototype = Object.create(_super.prototype);
            DecimalQuestionValueValidator.prototype.constructor = DecimalQuestionValueValidator;

            DecimalQuestionValueValidator.prototype.dataTypeTest = function () {

                return DECIMAL_TEST.test(this._questionModel.getValue()) ? null : this.createErrorModel(
                    ValidationType.INCORRECT,
                    RuntimeConstants.ErrorCode.DECIMAL_INVALID);

            };

            DecimalQuestionValueValidator.prototype.rangeTest = function () {

                var minValue = parseFloat(this._questionModel.getMinValue());
                var maxValue = parseFloat(this._questionModel.getMaxValue());
                var value = this._questionModel.getStrictlyTypedValue();
                var errorType = this.testNumberRange(value, minValue, maxValue);
                return errorType ? this.createErrorModel(ValidationType.INCORRECT, errorType,
                    {minValue: minValue, maxValue: maxValue}) : null;

            };

            return DecimalQuestionValueValidator;

        }]);



angular.module('mxg.formElement.question.DictionaryQuestionModelValidator', [
        'mxg.formElement.question.QuestionModelValidator',
        'mxg.validation.ValidationType',
        'mxg.system.RuntimeConstants'
    ])
    .factory('mxgDictionaryQuestionModelValidator',
        ['mxgQuestionModelValidator', 'mxgValidationType', 'mxgRuntimeConstants',
         function (QuestionModelValidator, ValidationType, RuntimeConstants) {

             var _super = QuestionModelValidator;

             function DictionaryQuestionModelValidator(questionModel) {

                 _super.call(this, questionModel);

                 this._testQueue.push(this.busyTest);

             }

             DictionaryQuestionModelValidator.prototype = Object.create(_super.prototype);
             DictionaryQuestionModelValidator.prototype.constructor = DictionaryQuestionModelValidator;

             DictionaryQuestionModelValidator.prototype.busyTest = function () {

                 if (this._questionModel.dictionaryNotificationContent.AWAIT_CONFIRMATION === true) {

                     return this.createErrorModel(
                         ValidationType.ALERT,
                         RuntimeConstants.ErrorCode.DICTIONARY_NOT_READY);

                 }

                 return null;
             };

             return DictionaryQuestionModelValidator;

         }]);

angular.module('mxg.formElement.question.IntegerQuestionModelValidator', [
        'mxg.formElement.question.NumberQuestionModelValidator',
        'mxg.validation.ValidationType',
        'mxg.system.RuntimeConstants'
    ])
    .factory('mxgIntegerQuestionModelValidator',
        ['mxgNumberQuestionModelValidator', 'mxgValidationType', 'mxgRuntimeConstants', function (NumberQuestionModelValidator, ValidationType, RuntimeConstants) {

            var _super = NumberQuestionModelValidator;

            var INTEGER_TEST = /^-?[0-9]+$/;

            function IntegerQuestionValueValidator(questionModel) {
                _super.call(this, questionModel);
            }

            IntegerQuestionValueValidator.prototype = Object.create(_super.prototype);
            IntegerQuestionValueValidator.prototype.constructor = IntegerQuestionValueValidator;

            IntegerQuestionValueValidator.prototype.dataTypeTest = function () {

                return INTEGER_TEST.test(this._questionModel.getValue()) ? null : this.createErrorModel(
                    ValidationType.INCORRECT,
                    RuntimeConstants.ErrorCode.INTEGER_INVALID);

            };

            IntegerQuestionValueValidator.prototype.rangeTest = function () {

                var minValue = parseInt(this._questionModel.getMinValue());
                var maxValue = parseInt(this._questionModel.getMaxValue());
                var value = this._questionModel.getStrictlyTypedValue();
                var errorType = this.testNumberRange(value, minValue, maxValue);
                return errorType ? this.createErrorModel(ValidationType.INCORRECT, errorType,
                    {minValue: minValue, maxValue: maxValue}) : null;

            };

            return IntegerQuestionValueValidator;

        }]);


angular.module('mxg.formElement.question.NumberQuestionModelValidator', [
        'mxg.formElement.question.QuestionModelValidator',
        'mxg.system.RuntimeConstants'
    ])
    .factory('mxgNumberQuestionModelValidator',
        ['mxgQuestionModelValidator', 'mxgRuntimeConstants', function (QuestionModelValidator, RuntimeConstants) {

            var _super = QuestionModelValidator;

            function NumberQuestionValueValidator(questionModel) {

                _super.call(this, questionModel);

                this._testQueue.push(this.dataTypeTest);
                this._testQueue.push(this.rangeTest);

            }

            NumberQuestionValueValidator.prototype = Object.create(_super.prototype);
            NumberQuestionValueValidator.prototype.constructor = NumberQuestionValueValidator;

            NumberQuestionValueValidator.prototype.testNumberRange = function (value, minValue, maxValue) {

                var errorType = null;

                if ((limitExists(minValue) && value < minValue) || (limitExists(maxValue) && value > maxValue)) {
                    if (limitExists(minValue) && limitExists(maxValue)) {
                        errorType = RuntimeConstants.ErrorCode.VALUE_NOT_WITHIN_RANGE;
                    } else if (limitExists(minValue)) {
                        errorType = RuntimeConstants.ErrorCode.VALUE_IS_LESS_THAN;
                    } else if (limitExists(maxValue)) {
                        errorType = RuntimeConstants.ErrorCode.VALUE_IS_GREATER_THAN;
                    }
                }

                return errorType;

            };

            NumberQuestionValueValidator.prototype.dataTypeTest = function () {
                return null;
            };

            NumberQuestionValueValidator.prototype.rangeTest = function () {
                return null;
            };

            return NumberQuestionValueValidator;

            function limitExists(limit) {
                return angular.isNumber(limit) && !isNaN(limit);
            }

        }]);

/**
 * @ngdoc directive
 * @example
 * <div mxg-form-element:question></div>
 */
angular.module('mxg.formElement.question.Question', [
    'ngSanitize',
    'mxg.formElement.question.QuestionCtrl',
    'mxg.formElement.FormConfig',
    'mxg.formElement.FocusManager',
    'mxg.formElement.FormElementType',
    'mxg.validation.ValidationErrorMap',
    'mxg.markupToHTML',
    'mxg.helpers.WindowHelper',
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.magnum.MagnumContainerElement'
])
    .directive('mxgFormElementQuestion', [
        '$document', '$filter', '$timeout', '$q', '$compile', '$templateCache', 'mxgFormConfig', 'mxgFocusManager', 'mxgFormElementType', 'mxgValidationErrorMap', 'mxgWindowHelper', 'mxgRootScope', 'mxgEvents', 'MagnumContainerElement',
        function ($document, $filter, $timeout, $q, $compile, $templateCache, FormConfig, FocusManager, FormElementType, ValidationErrorMap, WindowHelper, mxgRootScope, mxgEvents, MagnumContainerElement) {
            'use strict';
            return {
                templateUrl: 'mxg-template/formElement/FormElement.Question.html',
                controller: 'mxgQuestionCtrl',
                controllerAs: 'question',
                scope: false,
                link: function ($scope, $element) {
                    var magnumContainerCtrl = MagnumContainerElement.getController();
                    var renderingClass = FormConfig.getRenderingClass();
                    var questionModel = $scope.formElement;
                    $element.addClass(renderingClass);

                    $scope.onAnswerReady = function (moveForward) {
                        if (questionModel.hasChanged()) {
                            var eventData = questionModel.toJSON();
                            if (questionModel.hasReferenceValues()) {
                                eventData.referenceValues = angular.copy(questionModel.getReferenceValues());
                            }
                            mxgRootScope.$broadcast(mxgEvents.QUESTION_VALUE_CHANGED, eventData);
                        }
                        if (questionModel.hasChanged() && questionModel.inlineTrigger()) {
                            $scope.$emit('mxg:internal-inline-trigger');
                            forceFocusToWidget();
                        }
                        else {
                            moveForward && goToNextQuestion();
                        }
                    };

                    $scope.questionValueModelOptions = {
                        getterSetter: true
                    };

                    $scope.questionValue = function (value) {
                        if (value === undefined) {
                            return questionModel.getValue();
                        }
                        ValidationErrorMap.reset(questionModel.getElementId());
                        questionModel.setValue(value);
                    };

                    $scope.$watch(
                        function isQuestionValueValid() {
                            return !ValidationErrorMap.exists(questionModel.getElementId());
                        },
                        function (isValid) {
                            $element.toggleClass('mxg-has-error ng-invalid', isValid === false);
                        });

                    setTimeout(function () {
                        appendWidgetDirective();
                        $element.removeClass(renderingClass);
                        if (FocusManager.attemptToTakeFocus(questionModel.getFocusId())) {
                            forceFocusToWidget();
                        }
                    });

                    function appendWidgetDirective() {
                        var $bodyElement = angular.element($element[0].querySelector('.mxg-question-body'));
                        var template = $templateCache.get($scope.question.getBodyTemplateUrl());
                        template && $bodyElement.append($compile(template)($scope));
                    }

                    function forceFocusToWidget() {
                        $scope.question.needFocus = null;
                        $timeout(function() {
                            $scope.question.needFocus = 'force';
                        });
                    }

                    function goToNextQuestion() {
                        var focusCandidate = questionModel.getNextElement(FormElementType.QUESTION.toString());
                        if (focusCandidate) {
                            forceFocusTo(focusCandidate.getElementId());
                        }
                        else {
                            magnumContainerCtrl && magnumContainerCtrl.focusGoNextControl();
                        }
                    }

                    function forceFocusTo(elementId) {
                        var widgetElement = $document[0].getElementById($filter('mxgElementId')(elementId));
                        var elementScope;
                        if (!widgetElement) {
                            return;
                        }
                        elementScope = angular.element(widgetElement).scope();
                        if (elementScope && elementScope.formControl) {
                            elementScope.formControl.setFocus();
                        }
                    }

                }
            }

        }]);

angular.module('mxg.formElement.question', [
    'mxg.formElement.question.Question',
    'mxg.formElement.question.QuestionCtrl',
    'mxg.formElement.question.QuestionModel',
    'mxg.formElement.question.QuestionModelValidator',
    'mxg.formElement.question.value',
    'mxg.formElement.question.QuestionTooltip'
]);

/**
 * @ngdoc controller
 */
angular.module('mxg.formElement.question.QuestionCtrl', [
    'mxg.components.ElementId',
    'mxg.formElement.QuestionDataType',
    'mxg.formElement.layoutType'
])
    .controller('mxgQuestionCtrl', [
        '$scope', '$filter', 'mxgQuestionDataType', 'mxgLayoutType',
        function ($scope, $filter, QuestionDataType, LayoutType) {
            'use strict';
            var questionCtrl = this;
            var questionModel = $scope.formElement;

            var blockTypes = [
                QuestionDataType.MULTISELECT_CHECKBOXES_VERTICAL,
                QuestionDataType.DROPDOWN_RADIO_BUTTONS_VERTICAL,
                QuestionDataType.DROPDOWN_RADIO_BUTTONS_HORIZONTAL,
                QuestionDataType.STRING_TEXTBOX_MULTI,
                QuestionDataType.DROPDOWN_LABELLED_BUTTONS,
                QuestionDataType.MULTISELECT_LABELLED_BUTTONS,
                QuestionDataType.MULTISELECT_DROPDOWN
            ];

            var layoutType = questionModel.getInheritableProperty('layout_type');
            var firstColumnWidth = questionModel.getInheritableProperty('first_column_width');
            var questionType = questionModel.getQuestionType();

            questionCtrl.title = questionModel.getTitle();

            questionCtrl.needFocus = null;

            questionModel.evaluateCondition();

            questionCtrl.getType = function () {
                return questionType;
            };

            questionCtrl.getPreText = function () {
                return questionModel.getPreText();
            };

            questionCtrl.getPostText = function () {
                return questionModel.getPostText();
            };

            questionCtrl.isBlockType = function () {
                return blockTypes.indexOf(questionModel.getQuestionType()) !== -1;
            };

            questionCtrl.getLayoutType = function () {
                return layoutType;
            };

            questionCtrl.isOneColumn = function () {
                return layoutType === LayoutType.ONE_COLUMN;
            };

            questionCtrl.isTwoColumn = function () {
                return layoutType === LayoutType.TWO_COLUMNS;
            };

            questionCtrl.getFirstColumnWidth = function () {
                return questionCtrl.isTwoColumn() && firstColumnWidth;
            };

            var elementId = $filter('mxgElementId')(questionModel.getElementId());
            questionCtrl.getElementId = function () {
                return elementId;
            };
            var questionId = questionModel.getElementId();
            questionCtrl.getQuestionId = function () {
                return questionId;
            };

            questionCtrl.getElementLocator = function () {
                return questionModel.getLocator();
            };

            var questionLocator = questionModel.getAbstractLocator();
            questionCtrl.getQuestionLocator = function () {
                return questionLocator;
            };

            questionCtrl.getQuestionProperty = function (property) {
                return questionModel.getFormElementProperty(property);
            };

            questionCtrl.isEmpty = function () {
                var value = questionModel.getValue();
                return angular.isArray(value) ? value.length === 0 : value === null || value === "";
            };

            var layoutClass = questionCtrl.isTwoColumn() ? 'mxg-form-element-layout-two_columns' : 'mxg-form-element-layout-one_column';

            questionCtrl.getQuestionClasses = function () {

                var classes = [layoutClass];
                questionCtrl.isEmpty() && classes.push('mxg-question__empty');

                var styleClasses = $scope.formElement.getCustomStyles();
                styleClasses && classes.push(styleClasses);

                return classes.join(' ');

            };

            questionCtrl.getBodyTemplateUrl = function () {
                return ['mxg-template/formElement/question/', questionModel.getQuestionType(), '.html'].join('');
            };

            var customHeaderStyle = {};
            var customBodyStyle = {};

            if (questionCtrl.getFirstColumnWidth()) {
                customHeaderStyle.width = questionCtrl.getFirstColumnWidth() + '%';
                customBodyStyle['margin-left'] = customHeaderStyle.width;
            }

            questionCtrl.getCustomHeaderStyle = function () {
                return customHeaderStyle;
            };

            questionCtrl.getCustomBodyStyle = function () {
                return customBodyStyle;
            };

        }]);

angular.module('mxg.formElement.question.QuestionModel', [
    'mxg.system.RootScope',
    'mxg.system.Events',
    'mxg.formElement.ConditionalFormElementModel',
    'mxg.formElement.question.value.QuestionValueModelFactory'
])
    .factory('mxgQuestionModel',
        ['mxgConditionalFormElementModel', 'mxgQuestionValueModelFactory', 'mxgQuestionValueType',
         function (ConditionalFormElementModel, QuestionValueModelFactory, QuestionValueType) {
             'use strict';
             /**
              * @class
              */
             function QuestionModel(model, parentNode) {
                 ConditionalFormElementModel.call(this, model, parentNode);

                 /**
                  * _questionID is used for generating unique elementIds for all questions without having to tinker locators
                  */
                 this._questionID = this._formElementId;
                 this._valueModel = QuestionValueModelFactory.build(this);
                 this._originalValue = angular.copy(this.getStrictlyTypedValue());
                 this.dictionaryNotificationContent = this.getAttribute('dictionaryNotificationContent');
                 this._uuid = this.getAttribute('questionDefinitionId');
             }

             QuestionModel.prototype = Object.create(ConditionalFormElementModel.prototype);
             QuestionModel.prototype.constructor = QuestionModel;

             QuestionModel.prototype.canHaveValue = function () {
                 return true;
             };

             QuestionModel.prototype.getQuestionType = function () {
                 return this.getAttribute('dataType');
             };

             QuestionModel.prototype.getQuestionDefinitionId = function () {
                 return this.getAttribute('questionDefinitionId');
             };

             QuestionModel.prototype.getReferenceValues = function () {
                 return this.getAttribute('referenceValues');
             };

             QuestionModel.prototype.hasReferenceValues = function () {
                 var refSource = this.getReferenceValues();
                 return angular.isArray(refSource) && refSource.length > 0;
             };

             QuestionModel.prototype.getElementId = function () {
                 return this.getAbstractLocator() + "_" + this._questionID;
             };

             QuestionModel.prototype.getFocusId = function () {
                 return [this.getQuestionDefinitionId(), this.getFormElementId()].join('_');
             };

             QuestionModel.prototype.toJSON = function () {
                 var json = ConditionalFormElementModel.prototype.toJSON.call(this);
                 delete json.referenceValues;
                 delete json.childElements;
                 delete json.dictionaryNotificationContent;
                 delete json.dataType;

                 var valueJSON = null;

                 if (this.isOptional() && this._valueModel.isEmpty()) {
                     valueJSON = {
                         emptyValue: true
                     };
                 }
                 else {
                     valueJSON = this._valueModel.toJSON()
                 }

                 return angular.extend(json, {
                     visible: true,
                     id: this.getElementId(),
                     value: valueJSON
                 });
             };

             QuestionModel.prototype.getPreText = function () {
                 return this.getAttribute('preText');
             };

             QuestionModel.prototype.getPostText = function () {
                 return this.getAttribute('postText');
             };

             QuestionModel.prototype.getMinValue = function () {
                 var minValue = this.getQuestionProperty('min_value');
                 return (minValue === null || angular.isUndefined(minValue)) ? this.getAttribute('minValue') : minValue;
             };
             QuestionModel.prototype.getMaxValue = function () {
                 var maxValue = this.getQuestionProperty('max_value');
                 return (maxValue === null || angular.isUndefined(maxValue)) ? this.getAttribute('maxValue') : maxValue;
             };

             QuestionModel.prototype.getStrictlyTypedValue = function () {
                 return this._valueModel.getStrictlyTypedValue();
             };

             QuestionModel.prototype.getQuestionProperty = QuestionModel.prototype.getFormElementProperty;

             QuestionModel.prototype.hasChanged = function () {
                 return !angular.equals(this.getStrictlyTypedValue(), this._originalValue);
             };

             QuestionModel.prototype.persist = function () {
                 this._originalValue = angular.copy(this.getValue());
             };

             QuestionModel.prototype.getValue = function () {
                 return this._valueModel.getValue();
             };

             QuestionModel.prototype.clearValue = function () {
                 this._valueModel.setValue(null);
                 return this;
             };

             QuestionModel.prototype.getValueObject = function () {
                 return this._valueModel;
             };

             QuestionModel.prototype.setValue = function (value) {
                 this._valueModel.setValue(value);
                 return this;
             };

             QuestionModel.prototype.isEmpty = function () {
                 return this._valueModel.isEmpty();
             };

             QuestionModel.prototype.getValueModel = function () {
                 return this._valueModel;
             };

             QuestionModel.prototype.hasContent = function () {
                 return true;
             };

             QuestionModel.prototype.inlineTrigger = function () {
                 return this.getAttribute('inlinable');
             };

             return QuestionModel;
         }]);

angular.module('mxg.formElement.question.QuestionModelValidator', [
        'mxg.formElement.QuestionDataType',
        'mxg.validation.ValidationType',
        'mxg.system.RuntimeConstants',
        'mxg.formElement.question.IntegerQuestionModelValidator',
        'mxg.formElement.question.DecimalQuestionModelValidator',
        'mxg.formElement.question.DateQuestionModelValidator',
        'mxg.formElement.question.DatePartialQuestionModelValidator',
        'mxg.formElement.question.ReferenceQuestionModelValidator',
        'mxg.formElement.question.DictionaryQuestionModelValidator'
    ])
    .factory('mxgQuestionModelValidator',
        ['$injector', 'mxgQuestionDataType', 'mxgValidationType', 'mxgRuntimeConstants',
         function ($injector, QuestionDataType, ValidationType, RuntimeConstants) {

             function QuestionValueValidator(questionModel) {

                 this._questionModel = questionModel;

                 this._testQueue = [];

             }

             QuestionValueValidator.prototype.getTestQueue = function () {
                 return this._testQueue;
             };

             QuestionValueValidator.prototype.createErrorModel = function (errorType, errorCode, errorParams) {
                 return {
                     elementId: this._questionModel.getElementId(),
                     type: errorType,
                     code: errorCode,
                     params: errorParams || null
                 };
             };

             QuestionValueValidator.prototype.validate = function () {

                 var validator = this;
                 var queue = this.getTestQueue() || [];
                 var result;

                 if (this._questionModel.isEmpty()) {

                     if (!this._questionModel.isOptional()) {
                         result = this.createErrorModel(ValidationType.MANDATORY,
                             RuntimeConstants.ErrorCode.EMPTY_MANDATORY_VALUE);
                     }

                 }
                 else {

                     queue.some(function (test) {
                         result = test.call(validator);
                         return result !== null;
                     });

                 }

                 return result ? [result] : null;

             };

             var IntegerQuestionValueValidator;
             var DecimalQuestionValueValidator;
             var DateQuestionModelValidator;
             var DatePartialQuestionModelValidator;
             var ReferenceQuestionModelValidator;
             var DictionaryQuestionModelValidator;

             QuestionValueValidator.build = function (questionModel) {

                 IntegerQuestionValueValidator = IntegerQuestionValueValidator || $injector.get(
                         'mxgIntegerQuestionModelValidator');

                 DecimalQuestionValueValidator = DecimalQuestionValueValidator || $injector.get(
                         'mxgDecimalQuestionModelValidator');

                 DateQuestionModelValidator = DateQuestionModelValidator || $injector.get(
                         'mxgDateQuestionModelValidator');

                 DatePartialQuestionModelValidator = DatePartialQuestionModelValidator || $injector.get(
                         'mxgDatePartialQuestionModelValidator');

                 ReferenceQuestionModelValidator = ReferenceQuestionModelValidator || $injector.get(
                         'mxgReferenceQuestionModelValidator');

                 DictionaryQuestionModelValidator = DictionaryQuestionModelValidator || $injector.get(
                         'mxgDictionaryQuestionModelValidator');

                 switch (questionModel.getQuestionType()) {
                     case QuestionDataType.INTEGER_TEXTBOX:
                     case QuestionDataType.INTEGER_SPINNER:
                     case QuestionDataType.INTEGER_SLIDER:
                         return new IntegerQuestionValueValidator(questionModel);
                     case QuestionDataType.STRING_TEXTBOX_SINGLE:
                     case QuestionDataType.STRING_TEXTBOX_MULTI:
                         return new QuestionValueValidator(questionModel);
                     case QuestionDataType.STRING_DICTIONARY:
                         return new DictionaryQuestionModelValidator(questionModel);
                     case QuestionDataType.DECIMAL_TEXTBOX:
                         return new DecimalQuestionValueValidator(questionModel);
                     case QuestionDataType.DATE:
                         return new DateQuestionModelValidator(questionModel);
                     case QuestionDataType.DATE_PARTIAL:
                         return new DatePartialQuestionModelValidator(questionModel);
                     case QuestionDataType.MULTISELECT_CHECKBOXES_VERTICAL:
                     case QuestionDataType.MULTISELECT_LABELLED_BUTTONS:
                     case QuestionDataType.MULTISELECT_ICONIC_BUTTONS:
                     case QuestionDataType.MULTISELECT_DROPDOWN:
                         return new QuestionValueValidator(questionModel);
                     case QuestionDataType.DROPDOWN_COMBOBOX:
                         return new ReferenceQuestionModelValidator(questionModel);
                     case QuestionDataType.DROPDOWN:
                     case QuestionDataType.DROPDOWN_LABELLED_BUTTONS:
                     case QuestionDataType.DROPDOWN_ICONIC_BUTTONS:
                     case QuestionDataType.DROPDOWN_RADIO_BUTTONS_HORIZONTAL:
                     case QuestionDataType.DROPDOWN_RADIO_BUTTONS_VERTICAL:
                         return new QuestionValueValidator(questionModel);
                     default :
                         return new QuestionValueValidator(questionModel);
                 }

             };

             return QuestionValueValidator;

         }]);

angular.module('mxg.formElement.question.QuestionTooltip', [
    'ngSanitize',
    'mxg.markupToHTML'
])
    .directive('mxgQuestionTooltip', ['$compile', '$timeout', function ($compile, $timeout) {
        'use strict';
        return {
            restrict: 'A',
            priority: 900,
            controller: ['$scope', '$element', function ($scope, $element) {
                var questionModel = $scope.formElement;
                var ctrl = this;

                ctrl.getContent = function () {
                    return questionModel.getHelpText();
                };

                ctrl.compileTooltip = function () {
                    if (!ctrl.getContent()) {
                        return;
                    }
                    var tooltipEl = $compile('<span mxg-help-text="{{tooltipCtrl.getContent()}}"></span>')($scope);
                    var internalAnchor = getInternalTooltipAnchor();
                    if (internalAnchor) {
                        internalAnchor = angular.element(internalAnchor);
                        angular.element(tooltipEl[0].querySelector('.mxg-help-text-icon'))
                            .removeClass('mxg-icon mxg-icon-help')
                            .addClass('mxg-tooltip-anchor')
                            .text(internalAnchor.text());
                        internalAnchor.replaceWith(tooltipEl);
                    }
                    else {
                        $element.append(tooltipEl);
                    }
                };

                function getInternalTooltipAnchor() {
                    return Array.prototype.slice.call($element[0].querySelectorAll('.mxg-question-label_wording a'))
                        .filter(function (item) {
                            return angular.element(item).attr('href') === '#link-tooltip';
                        })[0];
                }

            }],
            controllerAs: 'tooltipCtrl',
            link: function ($scope) {
                $timeout(function () {
                    $scope.tooltipCtrl.compileTooltip();
                });
            }
        };
    }]);

angular.module('mxg.formElement.question.ReferenceQuestionModelValidator', [
        'mxg.formElement.question.QuestionModelValidator',
        'mxg.helpers.RefDataHelper',
        'mxg.validation.ValidationType',
        'mxg.system.RuntimeConstants'
    ])
    .factory('mxgReferenceQuestionModelValidator',
        ['mxgQuestionModelValidator', 'mxgRefDataHelper', 'mxgValidationType', 'mxgRuntimeConstants',
         function (QuestionModelValidator, RefDataHelper, ValidationType, RuntimeConstants) {

             var _super = QuestionModelValidator;

             function ReferenceQuestionModelValidator(questionModel) {

                 _super.call(this, questionModel);

                 this._testQueue.push(this.dataTypeTest);

             }

             ReferenceQuestionModelValidator.prototype = Object.create(_super.prototype);
             ReferenceQuestionModelValidator.prototype.constructor = ReferenceQuestionModelValidator;

             ReferenceQuestionModelValidator.prototype.dataTypeTest = function () {

                 if (this._questionModel.hasReferenceValues() && !RefDataHelper.getItemByCode(this._questionModel.getReferenceValues(),
                         this._questionModel.getValue())) {

                     return this.createErrorModel(
                         ValidationType.INCORRECT,
                         RuntimeConstants.ErrorCode.INVALID_REFERENCE_VALUE);

                 }

                 return null;
             };

             return ReferenceQuestionModelValidator;

         }]);

/**
 * @example
 * <div mxg-form-element:section-instance></div>
 */
angular.module('mxg.formElement.sectionInstance.SectionInstance', [
    'ngSanitize',
    'mxg.formElement.sectionInstance.SectionInstanceCtrl',
    'mxg.markupToHTML',
    'mxg.formElement.FocusManager',
    'mxg.formElement.FormElementType'
])
    .directive('mxgFormElementSectionInstance',
        ['$controller', 'mxgFocusManager', 'mxgFormElementType',
         function ($controller, FocusManager, FormElementType) {
             'use strict';
             return {
                 templateUrl: 'mxg-template/formElement/FormElement.SectionRepeatingInstance.html',
                 scope: false,
                 controller: 'mxgSectionInstanceCtrl',
                 controllerAs: 'section',
                 link: function ($scope) {
                     var sectionModel = $scope.formElement;
                     $scope.section.removeSection = function () {
                         var needInlineTrigger = !sectionModel.checkSectionIsEmpty() && sectionModel.inlineTrigger();
                         sectionModel.removeSection();
                         var firstQuestion;
                         if (needInlineTrigger) {
                             firstQuestion = sectionModel.getFirstChild(FormElementType.QUESTION.toString(), true);
                             firstQuestion && FocusManager.requestFocus(firstQuestion.getFocusId());
                             $scope.$emit('mxg:internal-inline-trigger');
                         }
                     };

                 }
             }
         }]);

angular.module('mxg.formElement.sectionInstance', [
    'mxg.formElement.sectionInstance.SectionInstance',
    'mxg.formElement.sectionInstance.SectionInstanceModel'
]);

angular.module('mxg.formElement.sectionInstance.SectionInstanceCtrl', [])
    .controller('mxgSectionInstanceCtrl', ['$scope', function ($scope) {
        'use strict';
        this.removeSection = function () {
        };
    }]);

angular.module('mxg.formElement.sectionInstance.SectionInstanceModel', ['mxg.formElement.ConditionalFormElementModel'])
    .factory('mxgSectionInstanceModel', [
        'mxgSectionModel',
        function (SectionModel) {
            'use strict';

            /**
             * @class
             */
            function SectionInstanceModel(model, parentNode) {
                SectionModel.call(this, model, parentNode);
            }

            SectionInstanceModel.prototype = Object.create(SectionModel.prototype);
            SectionInstanceModel.prototype.constructor = SectionInstanceModel;

            SectionInstanceModel.prototype.hasHeader = function () {
                return (this.getChildIndex() === 0) && (!!this.getTitle() || !!this.getPreamble());
            };

            SectionInstanceModel.prototype.removeSection = function () {
                this.getParent() && this.getParent().removeRepeatingInstance(this);
            };

            SectionInstanceModel.prototype.canBeRemoved = function () {
                return this.getParent().getNumberOfInstances() > this.getParent().getMinInstances();
            };
            return SectionInstanceModel;
        }]);

/**
 * @example
 * <div mxg-form-element:section-repeating></div>
 */
angular.module('mxg.formElement.sectionRepeating.SectionRepeating', [
    'ngSanitize',
    'mxg.formElement.sectionRepeating.SectionRepeatingCtrl',
    'mxg.markupToHTML'
])
    .directive('mxgFormElementSectionRepeating', [function () {
        "use strict";
        return {
            templateUrl: 'mxg-template/formElement/FormElement.SectionRepeating.html',
            controller: 'mxgRepeatingSectionCtrl',
            scope: false,
            controllerAs: 'section'
        };
    }]);

angular.module('mxg.formElement.sectionRepeating', [
    'mxg.formElement.sectionRepeating.SectionRepeating',
    'mxg.formElement.sectionRepeating.SectionRepeatingCtrl'
]);
angular.module('mxg.formElement.sectionRepeating.SectionRepeatingCtrl', [
    'mxg.formElement.FormConfig',
    'mxg.formElement.FocusManager',
    'mxg.formElement.layoutType',
    'mxg.formElement.formElementProperty.FormElementProperty',
    'mxg.formElement.FormElementType'
])
    .controller('mxgRepeatingSectionCtrl',
        ['$scope', 'mxgFormConfig', 'mxgFocusManager', 'mxgLayoutType', 'mxgFormElementProperty', 'mxgFormElementType',
         function mxgRepeatingSectionCtrl($scope, FormConfig, FocusManager, LayoutType, FormElementProperty, FormElementType) {
             'use strict';
             var sectionCtrl = this;
             var sectionModel = $scope.formElement;
             var instanceTemplateModel = sectionModel.getAttribute('template');
             var layoutType = sectionModel.getFormElementProperty(FormElementProperty.LAYOUT_TYPE);

             sectionCtrl.addNewInstance = function () {
                 if (!sectionModel.canHaveMoreInstances()) {
                     return;
                 }
                 FormConfig.setRenderingMode('local');
                 var newChild = sectionModel.addNewRepeatingSection();
                 var firstQuestion = angular.isObject(newChild) ? newChild.getFirstChild(
                         FormElementType.QUESTION.toString(), true) : null;
                 if (angular.isObject(firstQuestion)) {
                     FocusManager.requestFocus(firstQuestion.getFocusId());
                 }
             };

             sectionCtrl.isDataGrid = function () {
                 return layoutType === LayoutType.DATA_GRID;
             };

             var headers = null;

             if (angular.isArray(instanceTemplateModel.childElements) && instanceTemplateModel.childElements.length) {
                 headers = instanceTemplateModel.childElements
                     .filter(function (item) {
                         return item.type === 'QUESTION';
                     })
                     .map(function (item) {
                         return item.title;
                     });
             }

             sectionCtrl.getQuestionHeaders = function () {
                 return headers || [];
             };

             sectionCtrl.getChildrenQuestions = function (sectionInstance) {
                 var children = sectionInstance.getChildElements();
                 if (angular.isArray(children) && children.length) {
                     return children.filter(function (item) {
                         return item.getType() === 'QUESTION';
                     });
                 }
                 else {
                     return [];
                 }
             };

             var sectionLocator = sectionModel.getAbstractLocator();
             sectionCtrl.getSectionLocator = function () {
                 return sectionLocator;
             };

             var isTopSection = sectionModel.checkIsTopSection();

             sectionCtrl.getSectionClasses = function () {

                 var classes = [];

                 if (isTopSection) {
                     classes[0] = 'mxg-form-element-section__top';
                 }

                 if (sectionCtrl.isDataGrid()) {
                     classes.push('mxg-section-grid');
                 }

                 if (sectionModel.getMaxInstances() == 1) {
                     classes.push('mxg-section-repeating__single');
                 }

                 var styleClasses = $scope.formElement.getCustomStyles();
                 styleClasses && classes.push(styleClasses);

                 return classes.join(' ');

             };

             sectionCtrl.canHaveMoreInstances = function () {
                 return sectionModel.canHaveMoreInstances();
             };

             sectionCtrl.removeInstance = function (event, instance) {
                 event.preventDefault();
                 instance.removeSection();
                 return false;
             };

         }]);

angular.module('mxg.formElement.sectionRepeating.SectionRepeatingModel', [
    'mxg.formElement.SectionModel',
    'mxg.formElement.FormElementLocationService'
])
    .factory('mxgRepeatingSectionModel', [
        'mxgSectionModel', 'mxgFormElementType', 'mxgFormElementLocationService',
        function (SectionModel, FormElementType, FormElementLocationService) {
        'use strict';

        var _super = SectionModel;

        /**
         * @class
         */
        function RepeatingSectionModel(model, parentNode) {
            _super.call(this, model, parentNode);
            this._changed = false;
            this._template = angular.copy(this.getAttribute('template'));
            this._template.type = FormElementType.SECTION_INSTANCE.toString();
            this._minInstances = this.getFormElementProperty("MIN_INSTANCES");
            this._maxInstances = this.getFormElementProperty("MAX_INSTANCES");
            this.addDefaultEmptyInstances();
        }

        RepeatingSectionModel.prototype = Object.create(_super.prototype);
        RepeatingSectionModel.prototype.constructor = RepeatingSectionModel;

        RepeatingSectionModel.prototype.getMinInstances = function () {
            return this._minInstances;
        };

        RepeatingSectionModel.prototype.getMaxInstances = function () {
            return this._maxInstances || Number.MAX_VALUE;
        };

        RepeatingSectionModel.prototype.hasChanged = function () {
            return _super.prototype.hasChanged.call(this) || this._changed;
        };

        RepeatingSectionModel.prototype._addChildInstance = function(rebuild) {
            return this.addChild(angular.copy(this._template), rebuild);
        };

        RepeatingSectionModel.prototype.addDefaultEmptyInstances = function () {
            var minInstances = this.getMinInstances();
            if (this.getNumberOfInstances() < minInstances) {
                for (var i = this.getNumberOfInstances(); i < minInstances; i++) {
                    this._addChildInstance();
                }
                this._root._rebuildFormElementIds();
            }
        };

        RepeatingSectionModel.prototype.addNewRepeatingSection = function () {
            if (this.getNumberOfInstances() >= this.getMaxInstances()) {
                return;
            }
            this._changed = true;
            return this._addChildInstance(true);
        };

        RepeatingSectionModel.prototype.canHaveMoreInstances = function () {
            return !this.hasNotReadyRepeatingInstances() && (this.getNumberOfInstances() < this.getMaxInstances());
        };

        RepeatingSectionModel.prototype.removeRepeatingInstance = function (section) {
            if (this.getNumberOfInstances() <= this.getMinInstances()) {
                return;
            }
            this.removeChild(section);
            this._changed = true;
        };

        RepeatingSectionModel.prototype.getNumberOfInstances = function () {
            return this.getChildElements().length;
        };

        /**
         * @description
         * Checks is there are at least one child Repeating Instance Section where not all mandatory questions
         * are answered
         * */
        RepeatingSectionModel.prototype.hasNotReadyRepeatingInstances = function () {
            if (!this.hasChildElements()) {
                return false;
            }
            var questionType = FormElementType.QUESTION.toString();
            var comparator = function (formElementModel) {
                return (formElementModel.getType() === questionType) && !formElementModel.isOptional() && formElementModel.isEmpty();
            };
            return this.getChildElements().some(function(sectionModel) {
                return FormElementLocationService.findByComparator(comparator, sectionModel, true);
            });
        };

        RepeatingSectionModel.prototype.cleanUpEmptyRepeatingInstances = function () {
            if (!this.hasChildElements()) {
                return;
            }
            var emptyInstances = this.getChildElements().filter(function(repeatingInstanceSection) {
                if (repeatingInstanceSection.checkSectionIsEmpty()) {
                    return true;
                }
                else {
                    /* just in case we have more nesting in repeating sections */
                    repeatingInstanceSection.cleanUpEmptyRepeatingInstances();
                    return false;
                }
            });
            emptyInstances.forEach(function (repeatingInstanceSection) {
                repeatingInstanceSection.getParent().removeChild(repeatingInstanceSection);
            });
        };

        /**
         * @description
         * This method overrides general method of FormElementModel to make it possible
         * to add default instances instantly throughout entire FormModel hierarchy
         * */
        RepeatingSectionModel.prototype.addDefaultEmptyRepeatingInstances = function () {
            this.addDefaultEmptyInstances();
        };

        RepeatingSectionModel.prototype.toJSON = function () {
            var json = _super.prototype.toJSON.call(this);

            return angular.extend(json, {
                template: {
                    type: FormElementType.SECTION_TEMPLATE.toString()
                }
            });
        };

        return RepeatingSectionModel;
    }]);

/**
 * @example
 * <div mxg-form-element:section-static></div>
 */
angular.module('mxg.formElement.sectionStatic.SectionStatic', [
    'ngSanitize',
    'mxg.formElement.sectionStatic.SectionStaticCtrl',
    'mxg.markupToHTML'
])
    .directive('mxgFormElementSectionStatic', [function () {
        "use strict";
        return {
            templateUrl: 'mxg-template/formElement/FormElement.Section.html',
            controller: 'mxgSectionStaticCtrl',
            scope: false,
            controllerAs: 'section'
        }
    }]);

angular.module('mxg.formElement.sectionStatic', [
    'mxg.formElement.sectionStatic.SectionStatic',
    'mxg.formElement.sectionStatic.SectionStaticCtrl'
]);

angular.module('mxg.formElement.sectionStatic.SectionStaticCtrl', [
    'mxg.formElement.layoutType',
    'mxg.formElement.formElementProperty.FormElementProperty'
])
    .controller('mxgSectionStaticCtrl', [
        '$scope', 'mxgLayoutType', 'mxgFormElementProperty',
        function ($scope, LayoutType, FormElementProperty) {
            'use strict';
            var sectionModel = $scope.formElement;
            var sectionCtrl = this;
            var layoutType = sectionModel.getFormElementProperty(FormElementProperty.LAYOUT_TYPE);

            sectionCtrl.isDataGrid = function () {
                return layoutType === LayoutType.DATA_GRID;
            };

            sectionCtrl.getSectionClasses = function () {

                var classes = [];
                sectionModel.checkIsTopSection() && classes.push('mxg-form-element-section__top');

                var styleClasses = $scope.formElement.getCustomStyles();
                styleClasses && classes.push(styleClasses);

                return classes.join(' ');

            };

        }]);

angular.module('mxg.form.widgets.datePartial.DatePartialCtrl', [
    'mxg.translation',
    'mxg.components.datePartial.DatePartialModel',
    'mxg.components.datepicker.DatepickerConfig',
    'mxg.form.widgets.datePartial.DatePartInput',
    'mxg.form.widgets.datePartial.DatepickerInput'
])
    .controller('mxgDatePartialCtrl', [
        '$scope', 'dateFilter', 'mxgTranslateService', 'mxgDatePartialModel', 'mxgDatepickerConfig', 'mxgDatePartInput', 'mxgDatepickerInput',
        function ($scope, dateFilter, TranslateService, DatePartialModel, DatepickerConfig, DatePartInput, DatepickerInput) {
            "use strict";

            /** @type DatePartialModel */
            var widgetModel = new DatePartialModel($scope.inputFormat);
            $scope.model && widgetModel.setValue($scope.model);

            var partsCount = widgetModel.getPartsCount();
            var delimiter = widgetModel.getDelimiter();

            var datePartPlaceholders = {
                0: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_YEAR', null, true),
                1: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_MONTH', null, true),
                2: TranslateService.getById('FrontEndLabels.HINT_PARTIAL_DATE_DAY', null, true)
            };

            var datePartialCtrl = this;

            datePartialCtrl.getElementId = function (elementName) {
                return [$scope.elementId || '', elementName].join('_');
            };

            datePartialCtrl.partInputs = [];
            for (var i = 0; i < partsCount; i++) {
                datePartialCtrl.partInputs[i] = buildPartInputModel(widgetModel.getPart(i));
            }

            datePartialCtrl.getDelimiter = function () {
                return delimiter;
            };

            datePartialCtrl.getPlaceholder = function (partInput) {
                return datePartPlaceholders[partInput.getPriority()] || partInput.getFormat();
            };

            datePartialCtrl.datepicker = new DatepickerInput(widgetModel, {
                minDate: $scope.minDate || null,
                maxDate: $scope.maxDate || null,
                initDate: $scope.initDate || null,
                initOffset: $scope.initOffset || null,
                offsetUnits: $scope.offsetUnits || null
            });

            datePartialCtrl.updateOuterModel = function () {
                $scope.model = widgetModel.getValue();
                datePartialCtrl.datepicker.updateValue(widgetModel);
            };

            datePartialCtrl.onDatepickerChange = function (mode, value) {

                var modePriority;
                DatepickerConfig.modes.some(function (item) {
                    if (item.name === mode) {
                        modePriority = item.priority;
                        return true;
                    }
                    return false;
                });

                var partValues = dateFilter(value, 'yyyy-MM-dd').split('-');
                datePartialCtrl.partInputs.forEach(function (partInput) {
                    var partPriority = partInput.getPriority();
                    partInput.setValue((partPriority > modePriority) ? '' : partValues[partPriority]);
                });
                datePartialCtrl.updateOuterModel();

            };

            function buildPartInputModel(datePartModel) {

                var partInput = new DatePartInput(datePartModel);
                partInput.modelFn = function (value) {
                    if (angular.isUndefined(value)) {
                        return partInput.getValue();
                    }
                    else {
                        partInput.setValue(value);
                        datePartialCtrl.updateOuterModel();
                    }
                };
                return partInput;

            }

        }]);

angular.module('mxg.form.widgets.datePartial.DatePartInput', [
    'mxg.components.datePartial.DatePartialModel',
    'mxg.components.datepicker.DatepickerConfig'
])
    .factory('mxgDatePartInput', ['mxgDatepickerConfig', function (DatepickerConfig) {
        "use strict";
        
        /**
         * @class DatePartInput
         * @constructor
         * @param {DatePartModel} datePartModel
         * */
        function DatePartInput(datePartModel) {

            var self = this;

            /** @type DatePartModel */
            this._partModel = datePartModel;
            this._mode = null;

            var partPriority = datePartModel.getPriority();
            DatepickerConfig.modes.some(function(item) {
                if (item.priority === partPriority) {
                    self._mode = item.name;
                    return true;
                }
                return false;
            });

        }

        /**
         * @method DatePartInput#getFormat
         * @returns {String}
         * */
        DatePartInput.prototype.getFormat = function () {
            return this._partModel.getFormat();
        };

        /**
         * @method DatePartInput#getLength
         * @returns {Number}
         * */
        DatePartInput.prototype.getLength = function () {
            return this._partModel.getFormat().length;
        };

        /**
         * @method DatePartInput#getInputMask
         * @returns {String}
         * */
        DatePartInput.prototype.getInputMask = function () {
            return this._partModel.getInputMask() || null;
        };

        /**
         * @method DatePartInput#getPriority
         * @returns {String}
         * */
        DatePartInput.prototype.getPriority = function () {
            return this._partModel.getPriority();
        };

        /**
         * @method DatePartInput#getValue
         * @returns {String}
         * */
        DatePartInput.prototype.getValue = function () {
            return this._partModel.getValue();
        };

        /**
         * @method DatePartInput#setValue
         * @param {String} value
         * */
        DatePartInput.prototype.setValue = function (value) {
            this._partModel.setValue(value);
        };

        /**
         * @method DatePartInput#getMode
         * @returns {String}
         * */
        DatePartInput.prototype.getMode = function () {
            return this._mode;
        };

        return DatePartInput;

    }]);

angular.module('mxg.form.widgets.datePartial.DatepickerInput', [
    'mxg.components.datePartial.DatePartialModel',
    'mxg.helpers.DateHelper',
    'mxg.components.datepicker.DatepickerConfig'
])
    .factory('mxgDatepickerInput', [
        'dateFilter', 'mxgDatePartialModel', 'mxgDateHelper', 'mxgDatepickerConfig',
        function (dateFilter, DatePartialModel, DateHelper, DatepickerConfig) {
            'use strict';

            /**
             * @class DatepickerInput
             * @constructor
             * @param {DatePartialModel} datePartialModel
             * @param {Array.<*>} options
             * */
            function DatepickerInput(datePartialModel, options) {

                var self = this;

                options = options || {};

                this.opened = false;

                var minPriority = datePartialModel.getMinFormatPriority();

                this._inputModes = [];

                DatepickerConfig.modes.forEach(function (item) {
                    if (item.priority <= minPriority) {
                        self._inputModes[item.priority] = item.name;
                    }
                });

                this.datepickerOptions = {
                    minMode: this._inputModes[minPriority]
                };

                // valueModel used as ng-model for mxg-ui-datepicker-popup directive
                // to change it from "inside" - call DatepickerInput#updateValue()
                this.valueModel = null;
                this.mode = null;

                this.minDate = options.minDate ? DateHelper.createDateInLocalTimezone(options.minDate) : null;
                this.maxDate = options.maxDate ? DateHelper.createDateInLocalTimezone(options.maxDate) : null;
                this.initDate = options.initDate ? DateHelper.createDateInLocalTimezone(options.initDate) : null;
                this.initOffset = options.initOffset ? parseInt(options.initOffset, 10) : 0;
                this.offsetUnits = options.offsetUnits ? options.offsetUnits.toLowerCase() : null;

                if (!this.initDate && this.initOffset && this.offsetUnits) {

                    this.initDate = DateHelper.getNowDate();
                    switch (this.offsetUnits) {
                        case 'years':
                            this.initDate.setFullYear(this.initDate.getFullYear() + this.initOffset);
                            break;
                        case 'months':
                            this.initDate.setMonth(this.initDate.getMonth() + this.initOffset);
                            break;
                    }

                }

                this.updateValue(datePartialModel);

            }

            /**
             * @method DatepickerInput#updateValue
             * @param {DatePartialModel} datePartialModel
             * */
            DatepickerInput.prototype.updateValue = function (datePartialModel) {

                var newValue = null;

                var validParts = [null, null, null];
                var i, ii = datePartialModel.getPartsCount(), datePart;

                for (i = 0; i < ii; i++) {
                    datePart = datePartialModel.getPart(i);
                    if (datePart.containsValidValue()) {
                        validParts[datePart.getPriority()] = datePart.getValue();
                    }
                }

                if (validParts[0]) {
                    newValue = validParts
                        .map(function (item, index, array) {
                            if (index > 0 && !array[index - 1]) {
                                return null;
                            }
                            return item;
                        }).filter(function (item) {
                            return !!item;
                        }).join('-');
                }

                this.valueModel = newValue || (this.initDate ? dateFilter(this.initDate, 'yyyy-MM-dd') : null);

                var minValuePriority = DatePartialModel.calcMinValuePriority(this.valueModel);

                if (minValuePriority === null) {
                    this.mode = this._inputModes[0];
                }
                else {
                    this.mode = this._inputModes[minValuePriority + 1] || this._inputModes[this._inputModes.length - 1];
                }

            };

            /**
             * @method DatepickerInput#toggle
             * */
            DatepickerInput.prototype.toggle = function () {
                this.opened = !this.opened;
            };

            /**
             * @method DatepickerInput#getVisible
             * @returns {Boolean}
             * */
            DatepickerInput.prototype.getVisible = function () {
                return this.opened;
            };

            return DatepickerInput;

        }]);

angular.module('mxg.formElement.question.value.DatePartialQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgDatePartialQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function DatePartialQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.DATE_PARTIAL;
        }

        DatePartialQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        DatePartialQuestionValueModel.prototype.constructor = DatePartialQuestionValueModel;

        DatePartialQuestionValueModel.prototype.getClassName = function () {
            return 'DatePartialQuestionValueModel';
        };

        DatePartialQuestionValueModel.prototype.initQuestionValue = function (value) {
            var datePartialValue = angular.isObject(value) && angular.isString(
                value.datePartialValue) ? value.datePartialValue : null;
            this.setValue(datePartialValue);
        };

        DatePartialQuestionValueModel.prototype.toJSON = function () {
            return this.isEmpty() ? null : {
                datePartialValue: this.getValue()
            };
        };

        return DatePartialQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.DateQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgDateQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function DateQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.DATE;
        }

        DateQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        DateQuestionValueModel.prototype.constructor = DateQuestionValueModel;

        DateQuestionValueModel.prototype.getClassName = function () {
            return 'DateQuestionValueModel';
        };

        DateQuestionValueModel.prototype.initQuestionValue = function (value) {
            var dateValue = angular.isObject(value) && angular.isString(value.dateValue) ? value.dateValue : null;
            this.setValue(dateValue);
        };

        DateQuestionValueModel.prototype.toJSON = function () {
            return this.isEmpty() ? null : {
                dateValue: this.getValue()
            };
        };

        return DateQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.DecimalQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgDecimalQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function DecimalQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.DECIMAL;
        }

        DecimalQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        DecimalQuestionValueModel.prototype.constructor = DecimalQuestionValueModel;

        DecimalQuestionValueModel.prototype.getClassName = function () {
            return 'DecimalQuestionValueModel';
        };

        DecimalQuestionValueModel.prototype.getStrictlyTypedValue = function () {
            var value = this.getValue();
            return (value == null) ? null : parseFloat(value);
        };

        DecimalQuestionValueModel.prototype.isEmpty = function () {
            var value = this.getValue();
            if (angular.isNumber(value)) {
                return false;
            }
            return !value;
        };

        DecimalQuestionValueModel.prototype.initQuestionValue = function (value) {
            var decimalValue = angular.isObject(value) && angular.isNumber(
                value.decimalValue) ? value.decimalValue : null;
            this.setValue(decimalValue);
        };

        DecimalQuestionValueModel.prototype.toJSON = function () {
            return this.isEmpty() ? null : {
                decimalValue: this.getStrictlyTypedValue()
            };
        };

        return DecimalQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.IntegerQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgIntegerQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function IntegerQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.INTEGER;
        }

        IntegerQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        IntegerQuestionValueModel.prototype.constructor = IntegerQuestionValueModel;

        IntegerQuestionValueModel.prototype.getClassName = function () {
            return 'IntegerQuestionValueModel';
        };

        IntegerQuestionValueModel.prototype.getStrictlyTypedValue = function () {
            var value = this.getValue();
            return (value == null) ? null : parseInt(value, 10);
        };

        IntegerQuestionValueModel.prototype.isEmpty = function () {
            var value = this.getValue();
            if (angular.isNumber(value)) {
                return false;
            }
            return !value;
        };

        IntegerQuestionValueModel.prototype.initQuestionValue = function (value) {
            var intValue = angular.isObject(value) && angular.isNumber(value.intValue) ? value.intValue : null;
            this.setValue(intValue);
        };

        IntegerQuestionValueModel.prototype.toJSON = function () {
            return this.isEmpty() ? null : {
                intValue: this.getStrictlyTypedValue()
            };
        };

        /**
         * @method IntegerQuestionValueModel#testValue
         * @param {IntegerQuestionValueModel} valueModel
         * @return Boolean
         * */
        IntegerQuestionValueModel.prototype.testValue = function (valueModel) {
            return /^-?[0-9]+$/.test(valueModel.getValue());
        };

        return IntegerQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.QuestionValueModel', [])
    .factory('mxgQuestionValueModel', [
        function () {
            'use strict';

            /**
             * @class
             * @abstract
             */
            function QuestionValueModel(questionModel) {
                this._type = null;
                this._questionModel = questionModel;
                this.initQuestionValue(questionModel.getAttribute('value') || null);
            }

            QuestionValueModel.prototype.getType = function () {
                return this._type;
            };

            QuestionValueModel.prototype.getQuestionModel = function () {
                return this._questionModel;
            };

            QuestionValueModel.prototype.initQuestionValue = function (value) {
                this.setValue(value);
            };

            QuestionValueModel.prototype.getValue = function () {
                return this.value;
            };

            QuestionValueModel.prototype.getStrictlyTypedValue = function () {
                return (this.value == null) ? null : this.value;
            };

            QuestionValueModel.prototype.setValue = function (value) {
                this.value = value;
                return this;
            };

            QuestionValueModel.prototype.isEmpty = function () {
                return !this.getValue();
            };

            QuestionValueModel.prototype.toJSON = function () {
                return this.value;
            };

            return QuestionValueModel;
        }
    ]);

angular.module('mxg.formElement.question.value.QuestionValueModelFactory', [
    'mxg.formElement.question.value.DecimalQuestionValueModel',
    'mxg.formElement.question.value.IntegerQuestionValueModel',
    'mxg.formElement.question.value.ReferenceDataQuestionValueModel',
    'mxg.formElement.question.value.ReferenceDataListQuestionValueModel',
    'mxg.formElement.question.value.StringQuestionValueModel',
    'mxg.formElement.question.value.DateQuestionValueModel',
    'mxg.formElement.question.value.DatePartialQuestionValueModel',
    'mxg.formElement.QuestionDataType',
    'mxg.formElement.question.value.QuestionValueType'
])
    .service('mxgQuestionValueModelFactory', [
        '$injector', 'mxgQuestionDataType', 'mxgQuestionValueType',
        function ($injector, QuestionDataType, QuestionValueType) {
            'use strict';
            var service = this;

            function getQuestionValueType(questionModel) {
                switch (questionModel.getQuestionType()) {
                    case QuestionDataType.INTEGER_TEXTBOX:
                    case QuestionDataType.INTEGER_SPINNER:
                    case QuestionDataType.INTEGER_SLIDER:
                        return QuestionValueType.INTEGER;
                    case QuestionDataType.STRING_TEXTBOX_SINGLE:
                    case QuestionDataType.STRING_TEXTBOX_MULTI:
                        return QuestionValueType.STRING;
                    case QuestionDataType.STRING_DICTIONARY:
                        return QuestionValueType.REFERENCE;
                    case QuestionDataType.DECIMAL_TEXTBOX:
                        return QuestionValueType.DECIMAL;
                    case QuestionDataType.DATE:
                        return QuestionValueType.DATE;
                    case QuestionDataType.DATE_PARTIAL:
                        return QuestionValueType.DATE_PARTIAL;
                    case QuestionDataType.MULTISELECT_CHECKBOXES_VERTICAL:
                    case QuestionDataType.MULTISELECT_LABELLED_BUTTONS:
                    case QuestionDataType.MULTISELECT_ICONIC_BUTTONS:
                    case QuestionDataType.MULTISELECT_DROPDOWN:
                        return QuestionValueType.REFERENCE_MULTI;
                    case QuestionDataType.DROPDOWN:
                    case QuestionDataType.DROPDOWN_COMBOBOX:
                    case QuestionDataType.DROPDOWN_LABELLED_BUTTONS:
                    case QuestionDataType.DROPDOWN_ICONIC_BUTTONS:
                    case QuestionDataType.DROPDOWN_RADIO_BUTTONS_HORIZONTAL:
                    case QuestionDataType.DROPDOWN_RADIO_BUTTONS_VERTICAL:
                        return QuestionValueType.REFERENCE;
                    default :
                        break;
                }
            }

            var DecimalQuestionValueModel;
            var IntegerQuestionValueModel;
            var ReferenceDataQuestionValueModel;
            var ReferenceDataListQuestionValueModel;
            var StringQuestionValueModel;
            var DateQuestionValueModel;
            var DatePartialQuestionValueModel;

            service.build = function (questionModel) {
                switch (getQuestionValueType(questionModel)) {
                    case QuestionValueType.INTEGER:
                        IntegerQuestionValueModel = IntegerQuestionValueModel || $injector.get(
                                'mxgIntegerQuestionValueModel');
                        return new IntegerQuestionValueModel(questionModel);
                    case QuestionValueType.DECIMAL:
                        DecimalQuestionValueModel = DecimalQuestionValueModel || $injector.get(
                                'mxgDecimalQuestionValueModel');
                        return new DecimalQuestionValueModel(questionModel);
                    case QuestionValueType.STRING:
                        StringQuestionValueModel = StringQuestionValueModel || $injector.get('mxgStringQuestionValueModel');
                        return new StringQuestionValueModel(questionModel);
                    case QuestionValueType.DATE:
                        DateQuestionValueModel = DateQuestionValueModel || $injector.get('mxgDateQuestionValueModel');
                        return new DateQuestionValueModel(questionModel);
                    case QuestionValueType.DATE_PARTIAL:
                        DatePartialQuestionValueModel = DatePartialQuestionValueModel || $injector.get(
                                'mxgDatePartialQuestionValueModel');
                        return new DatePartialQuestionValueModel(questionModel);
                    case QuestionValueType.REFERENCE:
                        ReferenceDataQuestionValueModel = ReferenceDataQuestionValueModel || $injector.get(
                                'mxgReferenceDataQuestionValueModel');
                        return new ReferenceDataQuestionValueModel(questionModel);
                    case QuestionValueType.REFERENCE_MULTI:
                        ReferenceDataListQuestionValueModel = ReferenceDataListQuestionValueModel || $injector.get(
                                'mxgReferenceDataListQuestionValueModel');
                        return new ReferenceDataListQuestionValueModel(questionModel);
                    default :
                        return null;
                }
            };

        }
    ]);

angular.module('mxg.formElement.question.value.QuestionValueType', [])
    .constant('mxgQuestionValueType', {
        "INTEGER": "INTEGER",
        "STRING": "STRING",
        "REFERENCE": "REFERENCE",
        "DECIMAL": "DECIMAL",
        "DATE": "DATE",
        "DATE_PARTIAL": "DATE_PARTIAL",
        "REFERENCE_MULTI": "REFERENCE_MULTI"
    });
angular.module('mxg.formElement.question.value.ReferenceDataListQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgReferenceDataListQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function ReferenceDataListQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.REFERENCE_MULTI;
        }

        ReferenceDataListQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        ReferenceDataListQuestionValueModel.prototype.constructor = ReferenceDataListQuestionValueModel;

        ReferenceDataListQuestionValueModel.prototype.getClassName = function () {
            return 'ReferenceDataListQuestionValueModel';
        };

        ReferenceDataListQuestionValueModel.prototype.initQuestionValue = function (value) {
            var refDataValues = angular.isObject(value) && angular.isArray(
                value.referenceDataValues) ? value.referenceDataValues : [];
            this.setValue(refDataValues.map(function (item) {
                return item.code;
            }));
        };

        ReferenceDataListQuestionValueModel.prototype.setValue = function (value) {
            if (angular.isArray(value)) {
                this.value = value;
            }
            else {
                this.value = value ? [value] : [];
            }
            return this;
        };

        ReferenceDataListQuestionValueModel.prototype.isEmpty = function () {
            return !this.value.length;
        };

        ReferenceDataListQuestionValueModel.prototype.toJSON = function () {

            if (this.isEmpty()) {
                return null;
            }

            var referenceValues = this._questionModel.getReferenceValues() || [];
            var selectedCodes = this.getValue();
            var selectedValues = referenceValues.filter(function (item) {
                return selectedCodes.indexOf(item.code) !== -1;
            }).map(function (item) {
                return {
                    code: item.code,
                    uuid: item.uuid
                };
            });

            return {
                referenceDataValues: selectedValues
            };

        };

        return ReferenceDataListQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.ReferenceDataQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgReferenceDataQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function ReferenceDataQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.REFERENCE;
        }

        ReferenceDataQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        ReferenceDataQuestionValueModel.prototype.constructor = ReferenceDataQuestionValueModel;

        ReferenceDataQuestionValueModel.prototype.getClassName = function () {
            return 'ReferenceDataQuestionValueModel';
        };

        ReferenceDataQuestionValueModel.prototype.setValue = function (value) {
            this.value = value || null;
            return this;
        };

        ReferenceDataQuestionValueModel.prototype.isEmpty = function () {
            return this.value === null;
        };

        ReferenceDataQuestionValueModel.prototype.initQuestionValue = function (value) {
            var refDataValues = angular.isObject(value) && angular.isArray(
                value.referenceDataValues) ? value.referenceDataValues : [];
            this.setValue(refDataValues.length ? refDataValues[0].code : null);
        };

        ReferenceDataQuestionValueModel.prototype.toJSON = function () {

            if (this.isEmpty()) {
                return null;
            }

            var referenceValues = this._questionModel.getReferenceValues() || [];
            var value = this.getValue();
            var json = {
                referenceDataValues: [{code: value}]
            };
            referenceValues.some(function (item) {
                if (value === item.code) {
                    json.referenceDataValues[0].uuid = item.uuid;
                    return true;
                }
                return false;
            });
            return json;
        };

        return ReferenceDataQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value.StringQuestionValueModel', [
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.QuestionValueType'
]).factory('mxgStringQuestionValueModel', [
    'mxgQuestionValueModel', 'mxgQuestionValueType',
    function (QuestionValueModel, QuestionValueType) {
        'use strict';

        /**
         * @class
         */
        function StringQuestionValueModel(questionModel) {
            QuestionValueModel.call(this, questionModel);
            this._type = QuestionValueType.STRING;
        }

        StringQuestionValueModel.prototype = Object.create(QuestionValueModel.prototype);
        StringQuestionValueModel.prototype.constructor = StringQuestionValueModel;

        StringQuestionValueModel.prototype.getClassName = function () {
            return 'StringQuestionValueModel';
        };

        StringQuestionValueModel.prototype.initQuestionValue = function (value) {
            var stringValue = angular.isObject(value) && angular.isString(value.stringValue) ? value.stringValue : null;
            this.setValue(stringValue);
        };

        StringQuestionValueModel.prototype.toJSON = function () {
            return this.isEmpty() ? null : {
                stringValue: this.getValue()
            };
        };

        return StringQuestionValueModel;
    }
]);

angular.module('mxg.formElement.question.value', [
    'mxg.formElement.question.value.QuestionValueType',
    'mxg.formElement.question.value.QuestionValueModel',
    'mxg.formElement.question.value.DecimalQuestionValueModel',
    'mxg.formElement.question.value.IntegerQuestionValueModel',
    'mxg.formElement.question.value.ReferenceDataQuestionValueModel',
    'mxg.formElement.question.value.ReferenceDataListQuestionValueModel',
    'mxg.formElement.question.value.StringQuestionValueModel',
    'mxg.formElement.question.value.DateQuestionValueModel',
    'mxg.formElement.question.value.DatePartialQuestionValueModel',
    'mxg.formElement.question.value.QuestionValueModelFactory'
]);

})(window, angular);
//# sourceMappingURL=magnum-app.js.map
