export class brms {
    result: object;
    jsonRequest: jsonreq;
}

export class jsonreq {
    payload: any;
    brmsmodel: brmsmodel;
}

export class brmsmodel {
    signature_flags: object;
    additional_life_assured: object;
    eligible_auto_revival_flag: any;
    documents: object;
    receive_amendment: any;
    sar_calculator: number
}