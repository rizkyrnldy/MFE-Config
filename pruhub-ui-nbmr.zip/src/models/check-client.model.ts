export class CheckClientOutPutTwo {
    clientNo: string;
    surname:string;
    givenNames: string;
    salutation:string;
    sex:string;
    married:string;
    street:string;
    line1:string;
    line2:string;
    kota:string;
    kodepos:string;
    province:string;
    country:string;
    bus:string;
    idNo:string;
    homePhone_AreaCode:string;
    homePhone_No:string;
    officePhone_AreaCode:string;
    officePhone_No:string;
    nationality:string;
    occupation:string;
    birthDate: string;
    birthPlace:string;
    mailing: string;
    payableTax: string;
    staffFlag: string;
    mobilePhone1: string;
    mobilePhone2: string;
    mobilePhone3: string;
    fax: string;
    internetAddress: string;
    taxIdNumber: string;
    usTaxFillingStatus: string;
    reasonForBuyingInsurance: string;
    sourceOfMonthlyIncome: string;
    income: string;
    // deserialize(input: any): SARCalculator {
    //     Object.assign(this, input);
    //     this.finance = new finance().deserialize(input.finance);
    //     this.medical = new medical().deserialize(input.medical);
    //     return this;
    // }
}