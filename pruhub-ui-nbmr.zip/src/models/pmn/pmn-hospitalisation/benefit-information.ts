export interface BenefitInformation {
  benefit: string;
  innerLimitBenefit: number;
  qty: number;
  roomType: string;
  claimSubmit: number;
  personalFee: number;
  claimDecline: number;
  claimPaid: number;
  toggleUncoverStatement: boolean;
}