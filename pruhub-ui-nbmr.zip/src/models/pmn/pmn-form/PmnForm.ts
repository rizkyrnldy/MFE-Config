import { Input, Output, EventEmitter } from '@angular/core';
/**
 * @export
 * @class PmnForm
 * @version 1.0.0
 * @description
 * A parent class for generate general properties PMN form input
 */
export class PmnForm {
  @Input() isLabel: string = "Custom Label Here";
  @Input() isPlaceholder: string = "YYYY/MM/DD"
  @Input() isDisabled: boolean = false;
  @Input() isValue: string = "";
  @Input() isRequired: boolean = true;
  @Input() isValidationError: boolean = false;
  @Input() isValidationMessageError: string = "*Tidak Boleh Kosong";
  @Output() inputBlur = new EventEmitter<string>();

  /**
   *
   *
   * @param {string} label
   * @return {*}  {string}
   * @memberof PmnForm
   * @description Auto format capitalizing a title. See below for options
   */
  capitalizingTitle(label: string): string {
    return label !== "" 
      ? label.trim().toLowerCase().replace(/\w\S*/g, (w) => (w.replace(/^\w/, (c) => c.toUpperCase())))
      : label
  };
};

