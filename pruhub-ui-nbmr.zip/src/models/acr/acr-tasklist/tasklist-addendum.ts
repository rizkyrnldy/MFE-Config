export enum TasklistAddendumStatus {
    Requester = 'requester_addendum',
    HOD = 'hod_addendum',
    Analyst = 'analyst_addendum',
    Finance = 'finance_addendum',
    CFO = 'cfo_addendum',
    CEO = 'ceo_addendum'
}

export interface TasklistAddendumParams {
    isDelegate: boolean;
    acrNumber: string;
    rowId: string;
    documentRowId?: string;
    tasklistStatus?: TasklistAddendumStatus;
}