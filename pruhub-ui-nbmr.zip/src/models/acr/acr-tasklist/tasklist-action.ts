export enum TasklistActionTypes {
    Approve = 'Approve',
    NeedInfo = 'NeedInfo',
    Reject = 'Reject',
}

export interface TasklistActionStatus {
    is_reject: boolean;
    is_need_info: boolean;
    is_approve: boolean;
}

export interface TasklistDelegateStatus {
    actionName: TasklistActionTypes;
    isDelegate: boolean;
}

export enum TasklistActionPayload {
    approve = 'approve',
    reject = 'reject',
    needInfo = 'need info'
}

export enum TasklistAlertStatus {
    approve = 'approve',
    reject = 'reject',
    needInfo = 'sending info'
}
