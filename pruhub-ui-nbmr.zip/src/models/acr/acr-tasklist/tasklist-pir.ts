export enum TasklistPIRStatus {
    Requester = 'requester_PIR',
    HOD = 'hod_PIR',
    Budget = 'finance_PIR',
    BudgetLeader = 'budget_leader_PIR',
}

export interface TasklistPIRParams {
    isDelegate: boolean;
    acrNumber: string;
    rowId: string;
    documentRowId: string;
    tasklistStatus?: TasklistPIRStatus;
}
