export enum TasklistPRStatus {
    Requester = 'requester_progress_report',
    HOD = 'hod_progress_report',
    Budget = 'budget_progress_report',
    BudgetLeader = 'budget_leader_progress_report',
}

export interface TasklistPRParams {
    isDelegate: boolean;
    acrNumber: string;
    rowId: string;
    documentRowId: string;
    tasklistStatus?: TasklistPRStatus;
}
