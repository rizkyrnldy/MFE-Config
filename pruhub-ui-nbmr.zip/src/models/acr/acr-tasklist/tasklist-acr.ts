export enum TasklistACRStatus {
    AcrRequester = 'requester_acr',
    AcrHOD = 'hod_acr',
    AcrAnalyst = 'analyst_acr',
    AcrFinance = 'finance_acr',
    AcrCFO = 'cfo_acr',
    AcrCEO = 'ceo_acr',
    NonAcrRequester = 'requester_non_acr',
    NonAcrHOD = 'hod_non_acr',
    NonAcrAnalyst = 'analyst_non_acr',
    NonAcrBudget = 'budget_non_acr',
    NonAcrBudgetLeader = 'budget_leader_non_acr',
    NonAcrCFO = 'cfo_non_acr',
    NonAcrCEO = 'ceo_non_acr'
}

export interface TasklistACRParams {
    isDelegate: boolean;
    acrNumber: string;
    isAcr?: boolean;
    rowId?: string;
    tasklistStatus?: TasklistACRStatus;
}
