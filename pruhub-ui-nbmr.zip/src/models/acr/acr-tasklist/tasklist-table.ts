export enum TasklistDocumentType {
    ACR = 1,
    Addendum = 2,
    ProgressReport = 3,
    PIR = 4
}

export interface TasklistDocumentParams {
    acrNum: string;
    documentType: TasklistDocumentType;
    documentRowId: number;
}
