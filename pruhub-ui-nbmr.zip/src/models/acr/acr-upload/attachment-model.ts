export interface AcrAttachment {
    acrNum: string;
    rowId: number;
    lastModified: number;
    savedFilename: string;
    originalFilename: string;
    base64EncodedFile: string;
}

export interface RecentAttachment {
    job: 'acr' | 'addendum' | 'pir' | 'progress_report',
    acrNum: string;
    username: string;
    authorization: string;
    rowId?: string;
}

export enum AcrType {
    ACR = 'ACR',
    Addendum = 'Addendum',
    PIR = 'PIR',
    PR = 'Progress Report'
}
