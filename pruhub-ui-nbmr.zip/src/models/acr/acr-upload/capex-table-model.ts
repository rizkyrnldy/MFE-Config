export interface CapexExcelTable {
    Description: string;
    Department: string;
    Category: string;
    CostYear1: string;
    CostYear2: string;
    CostYear3: string;
    CostYear4: string;
    CostYear5: string;
    CostYearAdditional: string;
    AccountDescription?: string;
    ExpenseSubGroup?: string;
    Total: string;
    CapexType: string;
    AccountCapex: string;
    SubcategoryCapex: string;
    indexOfCategory: string;
    indexOfSubCategory: string;
    ACRCapexOpexCategoryId: string;
    ACRCapexOpexSubcategoryId: string;
    StrategicProjectCostCapex: string;
}

export interface CapexParseTable {
    parseCapexJson: CapexExcelTable[];
    grandTotalCapex: number;
}
