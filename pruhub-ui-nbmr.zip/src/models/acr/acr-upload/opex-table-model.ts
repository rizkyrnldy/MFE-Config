export interface OpexExcelTable {
    Description: string;
    Department: string;
    Category: string;
    CostYear1: string;
    CostYear2: string;
    CostYear3: string;
    CostYear4: string;
    CostYear5: string;
    CostYearAdditional: string;
    AccountDescription?: string;
    ExpenseSubGroup?: string;
    Total: string;
    OpexType: string;
    AccountOpex: string;
    SubcategoryOpex: string;
    indexOfCategory: string;
    indexOfSubCategory: string;
    ACRCapexOpexCategoryId: string;
    ACRCapexOpexSubcategoryId: string;
    StrategicProjectCostOpex: string;
}

export interface OpexParseTable {
    parseOpexJson: OpexExcelTable[];
    grandTotalOpex: number;
}
