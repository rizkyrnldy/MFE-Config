export interface BenefitExcelTable {
    Description: string;
    Department?: string;
    Category: string;
    CostYear1: string;
    CostYear2: string;
    CostYear3: string;
    CostYear4: string;
    CostYear5: string;
    CostYearAdditional: string;
    AccountDescription?: string;
    ExpenseSubGroup?: string;
    Total: string;
    TypeBenefit: string;
    CapexType?: string;
    AccountCapex?: string;
    SubcategoryCapex?: string;
    indexOfCategory?: string;
    indexOfSubCategory?: string;
    ACRBenefitCategoryId?: string;
    StrategicProjectCostCapex?: string;
}

export interface BenefitParseTable {
    parseBenefitJson: BenefitExcelTable[];
    grandTotalBenefit: number;
}
