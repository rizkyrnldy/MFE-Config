export interface AcrPRForm {
    deptCode            : string;
    deptName            : string;
    requesterLoginName  : string;
    requesterFullName   : string;
    acrNum              : string;
    progressReportDate  : string;
    description         : string;
    analystRemarks      : string;
    progressReportAmount: string;
    progressReportGbpAmount: string;
    sponsorLoginName    : string;
    sponsorFullName     : string;
    completionProjectDate: string;
    expectedApprovalDate: string;
    contact             : string;
    extension           : string;
    addendumRowId       : string;
    prPeriod            : string;
    amountApproved      : string;
    amountTemplate      : string;
    actualSpend         : string;
    balanceRemaining    : string;
    estimatedRemaining  : string;
    variance            : string;
    overStatus          : string;
    isReject            : boolean;
    commentary          : string;
    completionDatePerACR: string;
    revisedDate         : string;
    reasonRevision      : string;
    completionStatus    : string;
    progressReportStatus: string;
    projectName         : string;
    projectType         : string;
    budgetType          : string;
    amount              : string;
    gbpAmount           : string;
    addendumAmount      : string;
    addendumGbpAmount   : string;
    startProjectActual  : string;
    completionProjectActual: string;
    parseBenefitJson?   : any[],
    parseCapexJson?     : any[],
    parseOpexJson?      : any[],
    grandTotalBenefit?  : string,
    grandTotalCapex?    : string,
    grandTotalOpex?     : string,
    remarks?            : string;
    headerRowId?        : number;
}
