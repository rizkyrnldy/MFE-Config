export interface Hospitalisation {
    caseId:               string;
    policyNo:             string;
    riderCode:            string;
    claimType:            string;
    claimSeq:             string;
    admissionDate:        Date;
    dischargeDate:        string;
    totalUsage:           number;
    hospitalName:         string;
    hospitalAddress:      string;
    hospitalCountry:      string;
    hospitalCountryName:  string;
    remainingAnnualLimit: number;
    fixedAmmount:         number;
    basicRoomPrice:       number;
    entitleRoom:          number;
    prorationArea:        number;
    fullRoom:             boolean;
    noClaimBonus:         number;
    deductible:           number;
    unpaidDowngradeClaim: number;
    prorationFactor:      number;
    primeLmtBoostr:       number;
    eligiblePlan:         string;
    claimPaid:            ClaimPaid;
    diagnose:             Diagnose[];
}

export interface ClaimPaid {
    claimSubmit?:      number;
    personalFee:       number;
    claimDecline:      number;
    claimPaid:         number;
    totalClaimSubmit?: number;
}

export interface Diagnose {
    icdCode:             string;
    symptonDate1:        string;
    diagnosis:           string;
    diagnosisType:       string;
    dokter:              Dokter;
    additionalDiagnosis: string;
    surgery:             Surgery[];
    benefitClaim:        BenefitClaim[];
    diagCalculation:     ClaimPaid;
}

export interface BenefitClaim {
    policyNo:                               string;
    claimType:                              string;
    benefitCode:                            string;
    benefitDescription:                     string;
    calculationCode:                        string;
    deductibleStatus:                       boolean;
    prorationFactorStatus:                  boolean;
    amountSubmitted:                        number;
    qty:                                    number;
    personalFee:                            number;
    iterationAnnualLimit:                   number;
    iterationPrimeLimitBooster:             number;
    iterationNoClaimBonus:                  number;
    iterationTotalDaysLimitRoomAndBoard:    number;
    iterationDaysLimitRoomAndBoardOverseas: number;
    iterationDaysLimitIcu:                  number;
    innerLimit:                             number;
    claimPaid:                              number;
    claimDec:                               number;
    maxDayLimit:                            number;
    annualLimit:                            number;
    remainingLimit:                         number;
    remainingDays:                          number;
    surgeryLimit:                           number;
    unit:                                   number;
    unitPrice:                              number;
    unPaidDownGradeClaim:                   number;
    prorationFactor:                        number;
    iterationDeductible:                    number;
    middlePaid:                             number;
    sequenceIterationHsAnnualLimit:         number;
    sequenceIterationHaAnnualLimit:         number;
    sequenceIterationHcAnnualLimit:         number;
    sequenceIterationHbSurgeryLimit:        number;
    sequenceIterationHbDaysLimit:           number;
    sequenceIterationHaPrimeLimitBooster:   number;
    sequenceIterationDeductible:            number;
    benefitLevel:                           string;
    inpatientFlag:                          string;
    multiInvoiceFlag:                       string;
    labCodeFlag:                            string;
    plan:                                   string;
    gradeNumber:                            number;
    basicRoomPricePlan:                     number;
    fullRoom:                               boolean;
    oneGradeHigher:                         boolean;
    lowestTwinBedRoom:                      number;
    higherTwinBedRoom:                      number;
    lowestSingleBedRoom:                    number;
    higherSingleBedRoom:                    number;
    higherBedRoom:                          number;
    daysToleranceThreshold:                 number;
    daysTolerance:                          number;
    coverageAreaPlanPercentage:             number;
    roomUnitPrice:                          number;
    entitledRoomCost:                       number;
    totalClaimSubmit:                       number;
    totalPersonalFee:                       number;
    totalClaimDecline:                      number;
    totalClaimPaid:                         number;
    invoice:                                Invoice[];
    labCode:                                LabCode[];
    currentClaimHistory:                    any[];
    uncoverStatement:                       any[];
}

export interface Invoice {
    kurs:            string;
    rate:            number;
    invoiceDate:     string;
    benefitAmount:   number;
    amountSubmitted: number;
    personalFee:     number;
    qty:             number;
    claimPaid:       number;
    claimDecline:    number;
    seqnum:          string;
    seqnumb:         string;
}

export interface LabCode {
    seqnum: number;
    dteiss: string;
    labcde: string;
}

export interface Dokter {
    dokterCode:       string;
    dokterName:       string;
    dokterLicense:    string;
    dokterSpeciality: string;
}

export interface Surgery {
    surgeryCode:   string;
    surgeryDesc:   string;
    surgeryRemark: string;
    seqnumb:       string;
    surgeryType:   string;
    detail:        Detail[];
}

export interface Detail {
    benefitCode:     string;
    benefitDesc:     string;
    amountSubmitted: number;
    personalFee:     number;
}