export class SARCalculator {
    date: Date;
    finance: finance;
    medical: medical;
    
    // deserialize(input: any): SARCalculator {
    //     Object.assign(this, input);
    //     this.finance = new finance().deserialize(input.finance);
    //     this.medical = new medical().deserialize(input.medical);
    //     return this;
    // }
}

export class finance {
    title: String;
    data: Object;

    // deserialize(input: any): this {
    //     Object.assign(this, input);
    //     return this;
    // }
}

export class medical {
    title: String;
    data: Object;

    // deserialize(input: any): this {
    //     Object.assign(this, input);
    //     return this;
    // }
}

// export interface Deserializable {
//     deserialize(input: any): this;
// }