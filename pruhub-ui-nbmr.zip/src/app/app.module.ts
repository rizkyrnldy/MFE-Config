import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule, LOCALE_ID } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { IonicStorageModule } from '@ionic/storage';
import { TransactionTypeProvider, UploadAchievementProvider, TaxSlipProvider, EmergencyContactProvider } from './../providers/providers';
import { registerLocaleData, DatePipe, CurrencyPipe } from '@angular/common';
import localeId from '@angular/common/locales/id';
import localeIdExtra from '@angular/common/locales/extra/id';

import { MyApp } from './app.component';
import { CKEditorModule } from 'ng2-ckeditor';

import { CollateralManagementProvider } from '../providers/collateral-management/collateral-management';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AobProvider } from '../providers/aob/aob';
import { ApiProvider } from '../providers/api/api';
import { MainMenuProvider, UserProvider, TaskProvider, MasterDataProvider,MasterDataPHSProvider, AdminProvider, ReportProvider, DashboardProvider, ExportCsvProvider, Pagination } from '../providers/providers';
import { HospitalProvider } from '../providers/hospital/hospital';
import { URLServices } from '../providers/url-services';
import { SmsProvider } from '../providers/sms/sms';
import { PruforceProvider } from '../providers/pruforce/pruforce';
import { SelectAgentProvider } from '../providers/select-agent/select-agent';
import { EmailProvider } from '../providers/email/email';
import { EmailTemplateProvider } from '../providers/email-template/email-template';
import { AuditTrailProvider } from '../providers/audit-trail/audit-trail';
import { Report1Provider } from '../providers/report1/report1';
import { Report2Provider } from '../providers/report2/report2';
import { ClaimProvider } from '../providers/claim/claim';
import { ClaimDigitalProvider } from '../providers/claim/claim-digital';
import { MasterClaimProvider } from '../providers/claim/master-data';
import { SearchModalPage } from '../pages/search-modal/search-modal';
import { SelectSearchableModule } from 'ionic-select-searchable';
import { SearchModalPageModule } from '../pages/search-modal/search-modal.module';
import { MagnumProvider } from '../providers/magnum/magnum';
import { MasterContactProvider } from '../providers/master-contact/master-contact';
import { MutDatatableModule } from './shared/datatable/mut-datatable.module';
import { MutDatatableComponent } from './shared/datatable/mut-datatable';
import { CalendarModule, CalendarComponent } from "ion2-calendar";
import { CPSSystemProvider } from '../providers/cps-system/cps-system-provider';
import { CPSSystemProviderQrks } from '../providers/cps-system/cps-system-provider-qrks'; 
import { PaymentOutProvider } from '../providers/payment-out/payment-out';
import { ExcelProvider } from '../providers/excel/excel';
import { ContestProvider } from '../providers/contest/contestProvider';
import { FatcaProvider } from '../providers/fatca/fatca';
import { KpmProvider } from '../providers/kpm/kpm';
import { CampaignProvider } from '../providers/campaign/campaign';
import { JobTemplateEmailProvider } from '../providers/job-template-email/job-template-email';
import { SubmissionReportProvider } from '../providers/submission-report/submission-report';
import { ProspectProvider } from '../providers/prospect/prospect';
import { SecretaryProvider } from '../providers/secretary/secretary';
import { RaddAdsManagementProvider } from '../providers/radd-ads-management/radd-ads-management';
/** PHS Modules */
import { ModalClientSearchPageModule } from '../pages/phs/modules/workbasket/pages/phs-workbasket-modal/modal-client-search/modal-client-search.module';
import { ModalComparingDocumentPageModule } from '../pages/phs/modules/workbasket/pages/phs-workbasket-document/modal-comparing-document/modal-comparing-document.module';
import { ModalViewDocumentPageModule } from '../pages/phs/modules/workbasket/pages/phs-workbasket-document/modal-view-document/modal-view-document.module';

import { PhsHelperStorageService } from '../providers/phs/phshelper/phshelperstorage';
import { PhsHelperDateTimeService } from '../providers/phs/phshelper/phshelperdatetime';
import { phsAlertService } from '../providers/phs/phshelper/phsAlert';
import { phsToastService } from '../providers/phs/phshelper/phsToast';
import { PHSTaskProvider } from '../providers/phs/workbasket/phstask';
import { DetailDocumentProvider } from '../providers/phs/workbasket/detailDocument.';
import { phsMagnumProvider } from '../providers/phs/workbasket/phsmagnum';
import { DecisionProvider } from '../providers/phs/workbasket/decision';
import { caseSheetProvider } from '../providers/phs/workbasket/caseSheet';
import { DetailProvider } from '../providers/phs/workbasket/detail';
import { CheckClientProvider } from '../providers/phs/workbasket/checkclient';
import { PayorProvider } from '../providers/phs/workbasket/payor';
import { clientDetailProvider } from '../providers/phs/workbasket/clientDetail';
import { QuotationProvider } from '../providers/phs/workbasket/quotation';
import { SpajtProvider } from '../providers/phs/workbasket/spajt';
import { alterationFollowUpProvider } from '../providers/phs/workbasket/alterationFollowUp';
import { kesehatanNonSyariahProvider } from '../providers/phs/workbasket/kesehatanNonSyariah';
import { UtilityProvider } from '../providers/phs/utility/utility';
import { ModalProvider } from '../providers/phs/modal/modal';
import { SarcalculatorProvider } from '../providers/phs/workbasket/sarcalculator';
import { SarProvider } from '../providers/phs/workbasket/sar';
import { EvidanceCodeProvider } from '../providers/phs/workbasket/evidancecode';
import { RestUtilProvider } from '../providers/phs/utility/rest-util';
import { PhsMasterDataProvider } from '../providers/phs-master-data/phs-master-data';
import { PhsSupportProvider } from '../providers/phs/phshelper/phsSupport';
import { TabelSarProvider } from '../providers/tabel-sar/tabel-sar';
import { LocalBrmsProvider } from '../providers/phs/local-brms/local-brms';
import { BrmsdetailProvider } from '../providers/phs/workbasket/brmsdetail';
import { MagnumResultProvider } from '../providers/phs/workbasket/magnumresult';
import { PolicyDetailProvider } from '../providers/phs/workbasket/policydetail';
import { DataComparisonProvider } from '../providers/phs/workbasket/dataComparison';
import { ProcessOutputProvider } from '../providers/phs/workbasket/processOutput';
import { FinancialReviewProvider } from '../providers/phs/workbasket/financialReview';
import { ManageTaskProvider } from '../providers/phs/workbasket/managetask';
import { DocumentProvider } from '../providers/phs/workbasket/document';
import { ReindexProvider } from '../providers/phs/workbasket/reindex';
import { UwMedAssProvider } from '../providers/phs/workbasket/uwmedass';
import { QaScoringProvider } from '../providers/phs/workbasket/qascoring';
import { IonicSelectableModule } from 'ionic-selectable';
import { ReportPhsProvider } from '../providers/phs/workbasket/reportphs';
import { RefundProvider } from '../providers/phs/workbasket/refund';
import { PolicyProvider } from "../providers/policy/policy";
import { MedicalLetterProvider } from '../providers/medical-letter/medical-letter';
import { ClientLetterProvider } from '../providers/correspondence/client-letter';
import { AgentTokenProvider } from '../providers/agent-token/agent-token';
import { PersistencyProvider } from '../providers/persistency/persistency';
import { PhotoProvider } from '../providers/photo/photo';
import { errorLogProvider } from '../providers/phs/workbasket/errorLog';
import { DocumentViewer } from '../pages/phs/modules/workbasket/pages/phs-workbasket-submitted-form/phs-workbasket-submitted-form';
/** End Of PHS Modules */

// AOB Provider
import { CoreApiProvider } from '../providers/coreApi';

// End of AOB Provider

// Provider
import { StatusProvider } from '../providers/status/status';
import { GaAllowanceProvider } from '../providers/ga-allowance/gaAllowanceProvider';
import { ProductionProvider } from '../providers/production/productionProvider';

// START leads-config Provider
import { EventProvider } from '../providers/event-management/event/event';
import { ConfigProvider } from '../providers/event-management/event-config/event-config';
import { ReportEventProvider } from '../providers/event-management/event-report/event-report';
import { LeadsConfigProvider } from '../providers/leads-config/leads-config';
// END leads-config Provider

// start pruventure provider
import { PruventureProvider } from "../providers/pruventure/pruventure";
import { SalesManagementProvider } from "../providers/sales-management/sales-management";
// end pruventure provider 

/*LMS MODULE*/
import { ExportExcelProvider } from "../providers/providers";

import { LmsProvider } from '../providers/providers';
import { from } from 'rxjs/observable/from';
/*END OF LMS MODULE*/

import { ComponentsModule } from '../components/components.module';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { PipesModule } from '../pipes/pipes.module';
import { PhsWorkbasketKesehatanMagnumPage } from '../pages/phs/modules/workbasket/pages/phs-workbasket-kesehatan-magnum/phs-workbasket-kesehatan-magnum';
import { PhsWorkbasketRevivalMagnumPage } from '../pages/phs/modules/workbasket/pages/phs-workbasket-revival-magnum/phs-workbasket-revival-magnum';
import { AssignCategoryManagementProvider } from '../providers/collateral-management/assign-category-management';
import { UploadDocumentManagementProvider } from '../providers/collateral-management/upload-document-mangement';

import { WhatsappAgentSettingProvider } from '../providers/whatsapp-agent/setting-provider';
import { WhatsappAgentAutoreplyTimeProvider } from '../providers/whatsapp-agent/autoreply-time-provider';
import { WhatsappAgentUserProvider } from '../providers/whatsapp-agent/user-provider';
import { WhatsappAgentLeaderProvider } from '../providers/whatsapp-agent/leader-provider';
import { WhatsappAgentSuperLeaderProvider } from '../providers/whatsapp-agent/super-leader-provider';
import { WhatsappAgentHsmTemplateProvider } from '../providers/whatsapp-agent/hsm-template-provider';
import { WhatsappAgentUserTimezoneProvider } from '../providers/whatsapp-agent/user-timezone-provider';
import { AgentAlterationProvider } from '../providers/agent-alteration/agent-alteration';

/** PMN */
import {UtilityPMNProvider} from '../providers/pmn/utilitypmn';
import { PmnHelperStorageService } from '../providers/pmn/pmnHelperStorage';
import { PmnHelperDateTimeService } from '../providers/pmn/pmnHelperDateTime';
import { pmnAlertService } from '../providers/pmn/pmnAlert';
import { PmnPayloadHelperProvider } from '../providers/pmn/pmnPayLoadHelper';
import { PmnToastService } from '../providers/pmn/pmnToast';
import {RestUtilPmnProvider} from '../providers/pmn/restUtilPmn';
import { PmnProvider } from '../providers/pmn/pmnProvider';
import { ConsistencyBonusProvider } from '../providers/consistency-bonus/consistency-bonus';
import { PmnHospitalisationService } from '../providers/pmn/pmnHospitalisation';
import { PmnHospitalInfoService } from '../providers/pmn/pmnHospitalInfo';
import { PmnHistoryProfillingService } from '../providers//pmn/pmnHistoryProfilling';
import { PmnDailyMonitoringService } from '../providers/pmn/pmnDailyMonitoring';
/** End Of PMN */

/** DUKCAPIL */
import { DukcapilProvider } from '../providers/dukcapil/dukcapil';
import { PruventureReportProvider } from '../providers/pruventure-report/pruventure-report';
import { WhatsappAgentContactProvider } from '../providers/whatsapp-agent/contact-provider';
import { WhatsappAgentUserLoginProvider } from '../providers/whatsapp-agent/user-login-provider';
import { WhatsappCampaignHsmTemplateProvider } from '../providers/whatsapp-campaign/hsm-template-campaign-provider';
import { WhatsappCampaignNurtureProvider } from '../providers/whatsapp-campaign/nurture-campaign-provider';
import { WhatsappCampaignNurtureTemplateProvider } from '../providers/whatsapp-campaign/nurture-template-campaign-provider';
import { WhatsappPMNAutoreplyTimeProvider } from '../providers/whatsapp-pmn/autoreply-time-provider';

// ACR
import { AddendumProvider } from './../providers/enablement/acr/addendum/addendum';
import { EnablementFileSaverProvider } from './../providers/enablement/enablement-file-saver/enablement-file-saver';
import { ProgressReportProvider } from './../providers/enablement/acr/progress-report/progress-report';
import { PostImplementationReviewProvider } from './../providers/enablement/acr/post-implementation-review/post-implementation-review';
import { FormatterProvider } from '../providers/enablement/formatter/formatter';
import { ExcelParserProvider } from '../providers/enablement/excel-parser/excel-parser';

// PRUAMAN
import { AcrProvider } from './../providers/enablement/acr/acr';
import { ApiServicesProvider } from './../providers/enablement/api-services/api-services';
import { MasterPruamanProvider } from '../providers/enablement/pruaman/master/master-pruaman';
import { PruamanTasklistProvider } from '../providers/enablement/pruaman/tasklist/pruaman-tasklist';
// End of PRUAMAN

// PRUMIKRO
import { MasterPrumikroProvider } from './../providers/enablement/prumikro/master/master-prumikro';
import { PrumikroTasklistProvider } from './../providers/enablement/prumikro/tasklist/prumikro-tasklist';
import { WhatsappCampaignRenurtureTemplateProvider } from '../providers/whatsapp-campaign/renurture-template-campaign-provider';
// END of PRUMIKRO

import { PerformanceManagementProvider } from './../providers/performance-management/pmProvider';
import { LongTermIncentiveProvider } from './../providers/long-term-incentive/long-term-incentive';

// PRUCAR 
import { EnablementExportExcelProvider } from './../providers/enablement/enablement-export-excel/enablement-export-excel';
import { ReservationProvider } from './../providers/enablement/prucar/reservation/reservation';
import { TakslistProvider } from './../providers/enablement/prucar/takslist/takslist';
import { MasterPrucarProvider } from './../providers/enablement/prucar/master-prucar/master-prucar';
import { CommonServiceProvider } from './../providers/enablement/common-service/common-service';
import { WhatsappPMNSettingProvider } from '../providers/whatsapp-pmn/setting-provider';
import { WhatsappPMNUserProvider } from '../providers/whatsapp-pmn/user-provider';
import { WhatsappPMNAssignedMessageProvider } from '../providers/whatsapp-pmn/assigned-message-provider';
import { WhatsappPMNHsmTemplateProvider } from '../providers/whatsapp-pmn/hsm-template-provider';
import { WhatsappPMNContactProvider } from '../providers/whatsapp-pmn/contact-provider';
import { WhatsappPMNBroadcastProvider } from '../providers/whatsapp-pmn/broadcast-provider';
import { WhatsappPMNBroadcastDtlProvider } from '../providers/whatsapp-pmn/broadcast-dtl-provider';
import { WhatsappCampaignRegisPhoneNumberProvider } from '../providers/whatsapp-campaign/regis-phone-number-campaign-provider';
// END of PRUCAR
import { PrumikroRoleProvider } from './../providers/enablement/prumikro/prumikro-role/prumikro-role';
import { PrumikroPdfProvider } from './../providers/enablement/prumikro/prumikro-pdf/prumikro-pdf';

// ACR 
import { NonAcrProvider } from '../providers/enablement/acr/non-acr/non-acr';
import { TasklistNonAcrProvider } from '../providers/enablement/acr/tasklist-non-acr/tasklist-non-acr';
import { UpploadFileProvider } from '../providers/enablement/uppload-file/uppload-file';
import { TasklistAddendumProvider } from '../providers/enablement/acr/tasklist-addendum/tasklist-addendum';
// ACR : u have 2 common services (bug)
// import { CommonServiceProvider } from '../providers/enablement/common-service/common-service';
import { TasklistPirProvider } from '../providers/enablement/acr/tasklist-pir/tasklist-pir';
import { TasklistProgressReportProvider } from '../providers/enablement/acr/tasklist-progress-report/tasklist-progress-report';
import { ExcangeRateProvider } from './../providers/enablement/acr/excange-rate/excange-rate';
import { TasklistAcrProvider } from './../providers/enablement/acr/tasklist-acr/tasklist-acr';
import { PruamanRoleProvider } from './../providers/enablement/pruaman/pruaman-role/pruaman-role';

// DIGITAL HELPDESK
import { DigitalHelpdeskProvider } from '../providers/digital-helpdesk/digital-helpdesk';

import { ComplianceProvider } from '../providers/enablement/compliance/compliance';

import { WhatsappCampaignNurtureJourneyAnswerProvider } from '../providers/whatsapp-campaign/nurture-campaign-journey-answer';
import { WhatsappCampaignNurtureJourneyFlowDetailProvider } from '../providers/whatsapp-campaign/nurture-campaign-journey-flow-detail';
import { WhatsappCampaignNurtureJourneyFlowProvider } from '../providers/whatsapp-campaign/nurture-campaign-journey-flow';
import { WhatsappCampaignNurtureJourneyQuestionProvider } from '../providers/whatsapp-campaign/nurture-campaign-journey-question';
import { WhatsappCampaignNurtureJourneyConfigProvider } from '../providers/whatsapp-campaign/nurture-campaign-journey-config';
import { WhatsappCampaignNurtureMessageTemplateIterationProvider } from '../providers/whatsapp-campaign/nurture-template-campaign-iteration-provider';
import { WhatsappCampaignHsmTemplateParameterProvider } from '../providers/whatsapp-campaign/hsm-template-campaign-parameter-provider';
import { WhatsappAgentBroadcastProvider } from '../providers/whatsapp-agent/broadcast-provider';
import { WhatsappAgentBroadcastDtlProvider } from '../providers/whatsapp-agent/broadcast-dtl-provider';
import { WhatsappAgentDigibotProvider } from '../providers/whatsapp-agent/digibot-provider';
import { WhatsappAgentCategoryProvider } from '../providers/whatsapp-agent/category-provider';
import { WhatsappAgentSubcategoryProvider } from '../providers/whatsapp-agent/subcategory-provider';
import { WhatsappAgentAssignedMessageProvider } from '../providers/whatsapp-agent/assigned-message-provider';
import { WhatsappAgentUserCallProvider } from '../providers/whatsapp-agent/user-call-provider';
import { WhatsappAgentRegionCodeProvider } from '../providers/whatsapp-agent/region-code-provider';
import { WhatsappAgentKpmRegionCodeProvider } from '../providers/whatsapp-agent/kpm-region-code-provider';
import { WhatsappAgentKpmCodeProvider } from '../providers/whatsapp-agent/kpm-code-provider';
import { WhatsappAgentMessageResponseTimeProvider } from '../providers/whatsapp-agent/message-response-time-provider';
import { WhatsappAgentMessageProvider } from '../providers/whatsapp-agent/message-provider';
import { WhatsappAgentGroupContactDetailProvider } from '../providers/whatsapp-agent/group-contact-detail-provider';
import { WhatsappAgentGroupContactProvider } from '../providers/whatsapp-agent/group-contact-provider';
import { WhatsappAgentHsmTemplateParameterProvider } from '../providers/whatsapp-agent/hsm-template-parameter-provider';
import { WhatsappAgentHsmTemplateApprovalProvider } from '../providers/whatsapp-agent/hsm-template-approval-provider';
import { WhatsappPMNGroupContactDetailProvider } from '../providers/whatsapp-pmn/group-contact-detail-provider';
import { WhatsappPMNGroupContactProvider } from '../providers/whatsapp-pmn/group-contact-provider';
import { WhatsappPMNHsmTemplateParameterProvider } from '../providers/whatsapp-pmn/hsm-template-parameter-provider';
import { WhatsappPMNUserCallProvider } from '../providers/whatsapp-pmn/user-call-provider';
import { WhatsappPMNMessageResponseTimeProvider } from '../providers/whatsapp-pmn/message-response-time-provider';
import { WhatsappPMNMessageProvider } from '../providers/whatsapp-pmn/message-provider';
import { WhatsappPMNUserTimezoneProvider } from '../providers/whatsapp-pmn/user-timezone-provider';
import { WhatsappPMNRegionCodeProvider } from '../providers/whatsapp-pmn/region-code-provider';
import {LMSPruPartnerProvider} from '../providers/lms-prupartner/lms-prupartner';
import { WhatsappHNWIAssignedMessageProvider } from '../providers/whatsapp-hnwi/assigned-message-provider';
import { WhatsappHNWIAutoreplyTimeProvider } from '../providers/whatsapp-hnwi/autoreply-time-provider';
import { WhatsappHNWIBroadcastDtlProvider } from '../providers/whatsapp-hnwi/broadcast-dtl-provider';
import { WhatsappHNWIBroadcastProvider } from '../providers/whatsapp-hnwi/broadcast-provider';
import { WhatsappHNWICategoryProvider } from '../providers/whatsapp-hnwi/category-provider';
import { WhatsappHNWIContactProvider } from '../providers/whatsapp-hnwi/contact-provider';
import { WhatsappHNWIDigibotProvider } from '../providers/whatsapp-hnwi/digibot-provider';
import { WhatsappHNWIGroupContactDetailProvider } from '../providers/whatsapp-hnwi/group-contact-detail-provider';
import { WhatsappHNWIGroupContactProvider } from '../providers/whatsapp-hnwi/group-contact-provider';
import { WhatsappHNWIHsmTemplateApprovalProvider } from '../providers/whatsapp-hnwi/hsm-template-approval-provider';
import { WhatsappHNWIHsmTemplateParameterProvider } from '../providers/whatsapp-hnwi/hsm-template-parameter-provider';
import { WhatsappHNWIHsmTemplateProvider } from '../providers/whatsapp-hnwi/hsm-template-provider';
import { WhatsappHNWIKpmCodeProvider } from '../providers/whatsapp-hnwi/kpm-code-provider';
import { WhatsappHNWIKpmRegionCodeProvider } from '../providers/whatsapp-hnwi/kpm-region-code-provider';
import { WhatsappHNWILeaderProvider } from '../providers/whatsapp-hnwi/leader-provider';
import { WhatsappHNWIMessageProvider } from '../providers/whatsapp-hnwi/message-provider';
import { WhatsappHNWIMessageResponseTimeProvider } from '../providers/whatsapp-hnwi/message-response-time-provider';
import { WhatsappHNWIRegionCodeProvider } from '../providers/whatsapp-hnwi/region-code-provider';
import { WhatsappHNWISettingProvider } from '../providers/whatsapp-hnwi/setting-provider';
import { WhatsappHNWISubcategoryProvider } from '../providers/whatsapp-hnwi/subcategory-provider';
import { WhatsappHNWISuperLeaderProvider } from '../providers/whatsapp-hnwi/super-leader-provider';
import { WhatsappHNWIUserCallProvider } from '../providers/whatsapp-hnwi/user-call-provider';
import { WhatsappHNWIUserLoginProvider } from '../providers/whatsapp-hnwi/user-login-provider';
import { WhatsappHNWIUserProvider } from '../providers/whatsapp-hnwi/user-provider';
import { WhatsappHNWIUserTimezoneProvider } from '../providers/whatsapp-hnwi/user-timezone-provider';
import { WhatsappHNWIPrestigeCustProvider } from '../providers/whatsapp-hnwi/prestige-cust-provider';
import { WhatsappAgencyCommAssignedMessageProvider } from '../providers/whatsapp-agency-comm/assigned-message-provider';
import { WhatsappAgencyCommAutoreplyTimeProvider } from '../providers/whatsapp-agency-comm/autoreply-time-provider';
import { WhatsappAgencyCommBroadcastDtlProvider } from '../providers/whatsapp-agency-comm/broadcast-dtl-provider';
import { WhatsappAgencyCommBroadcastProvider } from '../providers/whatsapp-agency-comm/broadcast-provider';
import { WhatsappAgencyCommCategoryProvider } from '../providers/whatsapp-agency-comm/category-provider';
import { WhatsappAgencyCommContactProvider } from '../providers/whatsapp-agency-comm/contact-provider';
import { WhatsappAgencyCommDigibotProvider } from '../providers/whatsapp-agency-comm/digibot-provider';
import { WhatsappAgencyCommGroupContactDetailProvider } from '../providers/whatsapp-agency-comm/group-contact-detail-provider';
import { WhatsappAgencyCommGroupContactProvider } from '../providers/whatsapp-agency-comm/group-contact-provider';
import { WhatsappAgencyCommHsmTemplateApprovalProvider } from '../providers/whatsapp-agency-comm/hsm-template-approval-provider';
import { WhatsappAgencyCommHsmTemplateParameterProvider } from '../providers/whatsapp-agency-comm/hsm-template-parameter-provider';
import { WhatsappAgencyCommHsmTemplateProvider } from '../providers/whatsapp-agency-comm/hsm-template-provider';
import { WhatsappAgencyCommKpmCodeProvider } from '../providers/whatsapp-agency-comm/kpm-code-provider';
import { WhatsappAgencyCommKpmRegionCodeProvider } from '../providers/whatsapp-agency-comm/kpm-region-code-provider';
import { WhatsappAgencyCommLeaderProvider } from '../providers/whatsapp-agency-comm/leader-provider';
import { WhatsappAgencyCommMessageProvider } from '../providers/whatsapp-agency-comm/message-provider';
import { WhatsappAgencyCommMessageResponseTimeProvider } from '../providers/whatsapp-agency-comm/message-response-time-provider';
import { WhatsappAgencyCommRegionCodeProvider } from '../providers/whatsapp-agency-comm/region-code-provider';
import { WhatsappAgencyCommSettingProvider } from '../providers/whatsapp-agency-comm/setting-provider';
import { WhatsappAgencyCommSubcategoryProvider } from '../providers/whatsapp-agency-comm/subcategory-provider';
import { WhatsappAgencyCommSuperLeaderProvider } from '../providers/whatsapp-agency-comm/super-leader-provider';
import { WhatsappAgencyCommUserCallProvider } from '../providers/whatsapp-agency-comm/user-call-provider';
import { WhatsappAgencyCommUserLoginProvider } from '../providers/whatsapp-agency-comm/user-login-provider';
import { WhatsappAgencyCommUserProvider } from '../providers/whatsapp-agency-comm/user-provider';
import { WhatsappAgencyCommUserTimezoneProvider } from '../providers/whatsapp-agency-comm/user-timezone-provider';
import { WhatsappAgencyCommPrestigeCustProvider } from '../providers/whatsapp-agency-comm/prestige-cust-provider';

import { PsaProvider } from '../providers/psa/psa';

// PRULADYS
import { MasterPruladysProvider } from '../providers/enablement/pruladys/master/master-pruladys';
import { WhatsappAgentKpmCodeUserPriorityProvider } from '../providers/whatsapp-agent/kpm-code-user-priority-provider';
import { WhatsappAgentContactValidationProvider } from '../providers/whatsapp-agent/contact-validation-provider';

/*END OF REGULATORY COMPLIENCE*/
import { WhatsappPulseAssignedMessageProvider } from '../providers/whatsapp-pulse/assigned-message-provider';
import { WhatsappPulseAutoreplyTimeProvider } from '../providers/whatsapp-pulse/autoreply-time-provider';
import { WhatsappPulseBroadcastDtlProvider } from '../providers/whatsapp-pulse/broadcast-dtl-provider';
import { WhatsappPulseBroadcastProvider } from '../providers/whatsapp-pulse/broadcast-provider';
import { WhatsappPulseCategoryProvider } from '../providers/whatsapp-pulse/category-provider';
import { WhatsappPulseContactProvider } from '../providers/whatsapp-pulse/contact-provider';
import { WhatsappPulseDigibotProvider } from '../providers/whatsapp-pulse/digibot-provider';
import { WhatsappPulseGroupContactDetailProvider } from '../providers/whatsapp-pulse/group-contact-detail-provider';
import { WhatsappPulseGroupContactProvider } from '../providers/whatsapp-pulse/group-contact-provider';
import { WhatsappPulseHsmTemplateApprovalProvider } from '../providers/whatsapp-pulse/hsm-template-approval-provider';
import { WhatsappPulseHsmTemplateParameterProvider } from '../providers/whatsapp-pulse/hsm-template-parameter-provider';
import { WhatsappPulseHsmTemplateProvider } from '../providers/whatsapp-pulse/hsm-template-provider';
import { WhatsappPulseKpmCodeProvider } from '../providers/whatsapp-pulse/kpm-code-provider';
import { WhatsappPulseKpmRegionCodeProvider } from '../providers/whatsapp-pulse/kpm-region-code-provider';
import { WhatsappPulseLeaderProvider } from '../providers/whatsapp-pulse/leader-provider';
import { WhatsappPulseMessageProvider } from '../providers/whatsapp-pulse/message-provider';
import { WhatsappPulseMessageResponseTimeProvider } from '../providers/whatsapp-pulse/message-response-time-provider';
import { WhatsappPulseRegionCodeProvider } from '../providers/whatsapp-pulse/region-code-provider';
import { WhatsappPulseSettingProvider } from '../providers/whatsapp-pulse/setting-provider';
import { WhatsappPulseSubcategoryProvider } from '../providers/whatsapp-pulse/subcategory-provider';
import { WhatsappPulseSuperLeaderProvider } from '../providers/whatsapp-pulse/super-leader-provider';
import { WhatsappPulseUserCallProvider } from '../providers/whatsapp-pulse/user-call-provider';
import { WhatsappPulseUserLoginProvider } from '../providers/whatsapp-pulse/user-login-provider';
import { WhatsappPulseUserProvider } from '../providers/whatsapp-pulse/user-provider';
import { WhatsappPulseUserTimezoneProvider } from '../providers/whatsapp-pulse/user-timezone-provider';
import { WhatsappPulsePrestigeCustProvider } from '../providers/whatsapp-pulse/prestige-cust-provider';
//end import email pdf

import { WhatsappCustomerRetentionAssignedMessageProvider } from '../providers/whatsapp-customer-retention/assigned-message-provider';
import { WhatsappCustomerRetentionAutoreplyTimeProvider } from '../providers/whatsapp-customer-retention/autoreply-time-provider';
import { WhatsappCustomerRetentionBroadcastDtlProvider } from '../providers/whatsapp-customer-retention/broadcast-dtl-provider';
import { WhatsappCustomerRetentionBroadcastProvider } from '../providers/whatsapp-customer-retention/broadcast-provider';
import { WhatsappCustomerRetentionCategoryProvider } from '../providers/whatsapp-customer-retention/category-provider';
import { WhatsappCustomerRetentionContactProvider } from '../providers/whatsapp-customer-retention/contact-provider';
import { WhatsappCustomerRetentionDigibotProvider } from '../providers/whatsapp-customer-retention/digibot-provider';
import { WhatsappCustomerRetentionGroupContactDetailProvider } from '../providers/whatsapp-customer-retention/group-contact-detail-provider';
import { WhatsappCustomerRetentionGroupContactProvider } from '../providers/whatsapp-customer-retention/group-contact-provider';
import { WhatsappCustomerRetentionHsmTemplateApprovalProvider } from '../providers/whatsapp-customer-retention/hsm-template-approval-provider';
import { WhatsappCustomerRetentionHsmTemplateParameterProvider } from '../providers/whatsapp-customer-retention/hsm-template-parameter-provider';
import { WhatsappCustomerRetentionHsmTemplateProvider } from '../providers/whatsapp-customer-retention/hsm-template-provider';
import { WhatsappCustomerRetentionKpmCodeProvider } from '../providers/whatsapp-customer-retention/kpm-code-provider';
import { WhatsappCustomerRetentionKpmRegionCodeProvider } from '../providers/whatsapp-customer-retention/kpm-region-code-provider';
import { WhatsappCustomerRetentionLeaderProvider } from '../providers/whatsapp-customer-retention/leader-provider';
import { WhatsappCustomerRetentionMessageProvider } from '../providers/whatsapp-customer-retention/message-provider';
import { WhatsappCustomerRetentionMessageResponseTimeProvider } from '../providers/whatsapp-customer-retention/message-response-time-provider';
import { WhatsappCustomerRetentionRegionCodeProvider } from '../providers/whatsapp-customer-retention/region-code-provider';
import { WhatsappCustomerRetentionSettingProvider } from '../providers/whatsapp-customer-retention/setting-provider';
import { WhatsappCustomerRetentionSubcategoryProvider } from '../providers/whatsapp-customer-retention/subcategory-provider';
import { WhatsappCustomerRetentionSuperLeaderProvider } from '../providers/whatsapp-customer-retention/super-leader-provider';
import { WhatsappCustomerRetentionUserCallProvider } from '../providers/whatsapp-customer-retention/user-call-provider';
import { WhatsappCustomerRetentionUserLoginProvider } from '../providers/whatsapp-customer-retention/user-login-provider';
import { WhatsappCustomerRetentionUserProvider } from '../providers/whatsapp-customer-retention/user-provider';
import { WhatsappCustomerRetentionUserTimezoneProvider } from '../providers/whatsapp-customer-retention/user-timezone-provider';
import { WhatsappCustomerRetentionPrestigeCustProvider } from '../providers/whatsapp-customer-retention/prestige-cust-provider';
import { WhatsappUWPECAssignedMessageProvider } from '../providers/whatsapp-uwpec/assigned-message-provider';
import { WhatsappUWPECAutoreplyTimeProvider } from '../providers/whatsapp-uwpec/autoreply-time-provider';
import { WhatsappUWPECBroadcastDtlProvider } from '../providers/whatsapp-uwpec/broadcast-dtl-provider';
import { WhatsappUWPECBroadcastProvider } from '../providers/whatsapp-uwpec/broadcast-provider';
import { WhatsappUWPECCategoryProvider } from '../providers/whatsapp-uwpec/category-provider';
import { WhatsappUWPECContactProvider } from '../providers/whatsapp-uwpec/contact-provider';
import { WhatsappUWPECDigibotProvider } from '../providers/whatsapp-uwpec/digibot-provider';
import { WhatsappUWPECGroupContactDetailProvider } from '../providers/whatsapp-uwpec/group-contact-detail-provider';
import { WhatsappUWPECGroupContactProvider } from '../providers/whatsapp-uwpec/group-contact-provider';
import { WhatsappUWPECHsmTemplateApprovalProvider } from '../providers/whatsapp-uwpec/hsm-template-approval-provider';
import { WhatsappUWPECHsmTemplateParameterProvider } from '../providers/whatsapp-uwpec/hsm-template-parameter-provider';
import { WhatsappUWPECHsmTemplateProvider } from '../providers/whatsapp-uwpec/hsm-template-provider';
import { WhatsappUWPECKpmCodeProvider } from '../providers/whatsapp-uwpec/kpm-code-provider';
import { WhatsappUWPECLeaderProvider } from '../providers/whatsapp-uwpec/leader-provider';
import { WhatsappUWPECMessageProvider } from '../providers/whatsapp-uwpec/message-provider';
import { WhatsappUWPECKpmRegionCodeProvider } from '../providers/whatsapp-uwpec/kpm-region-code-provider';
import { WhatsappUWPECMessageResponseTimeProvider } from '../providers/whatsapp-uwpec/message-response-time-provider';
import { WhatsappUWPECRegionCodeProvider } from '../providers/whatsapp-uwpec/region-code-provider';
import { WhatsappUWPECSettingProvider } from '../providers/whatsapp-uwpec/setting-provider';
import { WhatsappUWPECSubcategoryProvider } from '../providers/whatsapp-uwpec/subcategory-provider';
import { WhatsappUWPECSuperLeaderProvider } from '../providers/whatsapp-uwpec/super-leader-provider';
import { WhatsappUWPECUserCallProvider } from '../providers/whatsapp-uwpec/user-call-provider';
import { WhatsappUWPECUserLoginProvider } from '../providers/whatsapp-uwpec/user-login-provider';
import { WhatsappUWPECUserProvider } from '../providers/whatsapp-uwpec/user-provider';
import { WhatsappUWPECUserTimezoneProvider } from '../providers/whatsapp-uwpec/user-timezone-provider';
import { WhatsappUWPECPrestigeCustProvider } from '../providers/whatsapp-uwpec/prestige-cust-provider';
//end import WAB UWPEC
import { FundReportFileProvider } from '../providers/fund-report-file/fund-report-file-provider';
import { DEFAULT_TIMEOUT, TimeoutInterceptor } from '../providers/ga-allowance/timeoutInterceptor';

registerLocaleData(localeId);

@NgModule({
  declarations: [
    MyApp,
    PhsWorkbasketKesehatanMagnumPage,
    PhsWorkbasketRevivalMagnumPage,
    DocumentViewer,
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp,{
    mode: 'ios',
    backButtonText: ''
    }),
    IonicStorageModule.forRoot(),
    HttpClientModule,
    MutDatatableModule,
    HttpModule,    
    CKEditorModule,
    SelectSearchableModule,
    SearchModalPageModule,
    CalendarModule,
    /**import PHS Module */
    ModalClientSearchPageModule,
    ModalComparingDocumentPageModule,
    ModalViewDocumentPageModule,
    IonicSelectableModule,
    ComponentsModule,
    PdfViewerModule,
    PipesModule,

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    PhsWorkbasketKesehatanMagnumPage,
    PhsWorkbasketRevivalMagnumPage,
    CalendarComponent,
    DocumentViewer,
  ],
  providers: [
    CurrencyPipe,
    DatePipe,
    StatusBar,
    UserProvider,
    SplashScreen,
    MainMenuProvider,
    {provide: LOCALE_ID, useValue: 'id'}, 
    TaskProvider,
    AobProvider,
    CollateralManagementProvider,
    ApiProvider,
    CoreApiProvider,
    URLServices,
    MasterDataProvider,
    MasterDataPHSProvider,
    MainMenuProvider,
    AdminProvider,
    SmsProvider,
    PruforceProvider,
    SelectAgentProvider,
    EmailProvider,
    AuditTrailProvider,
    Report1Provider,
    Report2Provider,
    FatcaProvider,
    EmailTemplateProvider,
    ReportProvider,
    ExportCsvProvider,
    MagnumProvider,
    TransactionTypeProvider,
    UploadAchievementProvider,
    MasterContactProvider,
    DashboardProvider,
    CPSSystemProvider,
    CPSSystemProviderQrks,
    PaymentOutProvider,
    ExcelProvider,
    HospitalProvider,
    TaxSlipProvider,
    ClaimProvider,
    ClaimDigitalProvider,
    MasterClaimProvider,
    KpmProvider,
    CampaignProvider,
    ContestProvider,
    EmergencyContactProvider,
    SubmissionReportProvider,
    JobTemplateEmailProvider,
    SubmissionReportProvider,
    RaddAdsManagementProvider,
    ProspectProvider,
    SecretaryProvider,
    /** PHS Providers */
    PhsHelperStorageService,
    PhsHelperDateTimeService,
    phsAlertService,
    phsToastService,
    PayorProvider,
    clientDetailProvider,
    QuotationProvider,
    SpajtProvider,
    SarProvider,
    PolicyDetailProvider,
    EvidanceCodeProvider,
    DataComparisonProvider,
    ProcessOutputProvider,
    FinancialReviewProvider,
    DocumentProvider,
    ManageTaskProvider,
    ReindexProvider,
    UwMedAssProvider,
    QaScoringProvider,
    PHSTaskProvider,
    DetailDocumentProvider,
    kesehatanNonSyariahProvider,
    DecisionProvider,
    phsMagnumProvider,
    caseSheetProvider,
    DetailProvider,
    UtilityProvider,
    CheckClientProvider,
    alterationFollowUpProvider,
    ModalProvider,
    SarcalculatorProvider,
    RestUtilProvider,
    PhsMasterDataProvider,
    TabelSarProvider,
    LocalBrmsProvider,
    PhsSupportProvider,
    BrmsdetailProvider,
    MagnumResultProvider,
    LmsProvider,
    ExportExcelProvider,
    ReportPhsProvider,
    GaAllowanceProvider,
    StatusProvider,
    RefundProvider,
    PolicyProvider,
    MedicalLetterProvider,
    ClientLetterProvider,
    AgentTokenProvider,
    PersistencyProvider,
    Pagination,
    ProductionProvider,
    PhotoProvider,
    AssignCategoryManagementProvider,
    UploadDocumentManagementProvider,
    LeadsConfigProvider,
    EventProvider,
    ConfigProvider,
    ReportEventProvider,
    CoreApiProvider,
    WhatsappCampaignHsmTemplateProvider,
    WhatsappCampaignNurtureProvider,
    WhatsappCampaignNurtureTemplateProvider,
    WhatsappCampaignRenurtureTemplateProvider,
    WhatsappCampaignRegisPhoneNumberProvider,
    WhatsappCampaignNurtureMessageTemplateIterationProvider,
    WhatsappCampaignHsmTemplateParameterProvider,
    WhatsappCampaignNurtureJourneyAnswerProvider,
    WhatsappCampaignNurtureJourneyFlowDetailProvider,
    WhatsappCampaignNurtureJourneyFlowProvider,
    WhatsappCampaignNurtureJourneyQuestionProvider,
    WhatsappCampaignNurtureJourneyConfigProvider,
    //end wab campaign provider
    //start wab psf
    WhatsappAgentSettingProvider,
    WhatsappAgentAutoreplyTimeProvider,
    WhatsappAgentUserProvider,
    WhatsappAgentLeaderProvider,
    WhatsappAgentSuperLeaderProvider,
    WhatsappAgentHsmTemplateProvider,
    WhatsappAgentContactProvider,
    WhatsappAgentUserLoginProvider,
    WhatsappAgentUserTimezoneProvider,
    WhatsappAgentBroadcastProvider,
    WhatsappAgentBroadcastDtlProvider,
    WhatsappAgentDigibotProvider,
    WhatsappAgentCategoryProvider,
    WhatsappAgentSubcategoryProvider,
    WhatsappAgentAssignedMessageProvider,
    WhatsappAgentUserCallProvider,
    WhatsappAgentRegionCodeProvider,
    WhatsappAgentKpmRegionCodeProvider,
    WhatsappAgentKpmCodeProvider,
    WhatsappAgentMessageResponseTimeProvider,
    WhatsappAgentMessageProvider,
    WhatsappAgentGroupContactDetailProvider,
    WhatsappAgentGroupContactProvider,
    WhatsappAgentHsmTemplateParameterProvider,
    WhatsappAgentHsmTemplateApprovalProvider,
    WhatsappAgentKpmCodeUserPriorityProvider,
    WhatsappAgentContactValidationProvider,
    //end wab psf
    WhatsappPMNAutoreplyTimeProvider,
    WhatsappPMNSettingProvider,
    WhatsappPMNUserProvider,
    WhatsappPMNAssignedMessageProvider,
    WhatsappPMNHsmTemplateProvider,
    WhatsappPMNContactProvider,
    WhatsappPMNBroadcastProvider,
    WhatsappPMNBroadcastDtlProvider,
    WhatsappPMNGroupContactDetailProvider,
    WhatsappPMNGroupContactProvider,
    WhatsappPMNHsmTemplateParameterProvider,
    WhatsappPMNUserCallProvider,
    WhatsappPMNMessageResponseTimeProvider,
    WhatsappPMNMessageProvider,
    WhatsappPMNUserTimezoneProvider,
    WhatsappPMNRegionCodeProvider,
    //end wab pmn provider
    //start wab hnwi provider
    WhatsappHNWIAssignedMessageProvider,
    WhatsappHNWIAutoreplyTimeProvider,
    WhatsappHNWIBroadcastDtlProvider,
    WhatsappHNWIBroadcastProvider,
    WhatsappHNWICategoryProvider,
    WhatsappHNWIContactProvider,
    WhatsappHNWIDigibotProvider,
    WhatsappHNWIGroupContactDetailProvider,
    WhatsappHNWIGroupContactProvider,
    WhatsappHNWIHsmTemplateApprovalProvider,
    WhatsappHNWIHsmTemplateParameterProvider,
    WhatsappHNWIHsmTemplateProvider,
    WhatsappHNWIKpmCodeProvider,
    WhatsappHNWIKpmRegionCodeProvider,
    WhatsappHNWILeaderProvider,
    WhatsappHNWIMessageProvider,
    WhatsappHNWIMessageResponseTimeProvider,
    WhatsappHNWIRegionCodeProvider,
    WhatsappHNWISettingProvider,
    WhatsappHNWISubcategoryProvider,
    WhatsappHNWISuperLeaderProvider,
    WhatsappHNWIUserCallProvider,
    WhatsappHNWIUserLoginProvider,
    WhatsappHNWIUserProvider,
    WhatsappHNWIUserTimezoneProvider,
    WhatsappHNWIPrestigeCustProvider,
    // end wab hnwi provider
    //start wab AgencyComm provider
    WhatsappAgencyCommAssignedMessageProvider,
    WhatsappAgencyCommAutoreplyTimeProvider,
    WhatsappAgencyCommBroadcastDtlProvider,
    WhatsappAgencyCommBroadcastProvider,
    WhatsappAgencyCommCategoryProvider,
    WhatsappAgencyCommContactProvider,
    WhatsappAgencyCommDigibotProvider,
    WhatsappAgencyCommGroupContactDetailProvider,
    WhatsappAgencyCommGroupContactProvider,
    WhatsappAgencyCommHsmTemplateApprovalProvider,
    WhatsappAgencyCommHsmTemplateParameterProvider,
    WhatsappAgencyCommHsmTemplateProvider,
    WhatsappAgencyCommKpmCodeProvider,
    WhatsappAgencyCommKpmRegionCodeProvider,
    WhatsappAgencyCommLeaderProvider,
    WhatsappAgencyCommMessageProvider,
    WhatsappAgencyCommMessageResponseTimeProvider,
    WhatsappAgencyCommRegionCodeProvider,
    WhatsappAgencyCommSettingProvider,
    WhatsappAgencyCommSubcategoryProvider,
    WhatsappAgencyCommSuperLeaderProvider,
    WhatsappAgencyCommUserCallProvider,
    WhatsappAgencyCommUserLoginProvider,
    WhatsappAgencyCommUserProvider,
    WhatsappAgencyCommUserTimezoneProvider,
    WhatsappAgencyCommPrestigeCustProvider,
    // end wab AgencyComm provider
    //start wab Pulse provider
    WhatsappPulseAssignedMessageProvider,
    WhatsappPulseAutoreplyTimeProvider,
    WhatsappPulseBroadcastDtlProvider,
    WhatsappPulseBroadcastProvider,
    WhatsappPulseCategoryProvider,
    WhatsappPulseContactProvider,
    WhatsappPulseDigibotProvider,
    WhatsappPulseGroupContactDetailProvider,
    WhatsappPulseGroupContactProvider,
    WhatsappPulseHsmTemplateApprovalProvider,
    WhatsappPulseHsmTemplateParameterProvider,
    WhatsappPulseHsmTemplateProvider,
    WhatsappPulseKpmCodeProvider,
    WhatsappPulseKpmRegionCodeProvider,
    WhatsappPulseLeaderProvider,
    WhatsappPulseMessageProvider,
    WhatsappPulseMessageResponseTimeProvider,
    WhatsappPulseRegionCodeProvider,
    WhatsappPulseSettingProvider,
    WhatsappPulseSubcategoryProvider,
    WhatsappPulseSuperLeaderProvider,
    WhatsappPulseUserCallProvider,
    WhatsappPulseUserLoginProvider,
    WhatsappPulseUserProvider,
    WhatsappPulseUserTimezoneProvider,
    WhatsappPulsePrestigeCustProvider,
    // end wab Pulse provider
    DukcapilProvider,
    errorLogProvider,
    // Begin PMN/
    PmnProvider,
    UtilityPMNProvider,
    RestUtilPmnProvider,
    PmnHelperStorageService,
    PmnHelperDateTimeService,
    pmnAlertService,
    PmnPayloadHelperProvider,
    PmnToastService,
    CurrencyPipe,
    AgentAlterationProvider,
    PruventureReportProvider,
    ConsistencyBonusProvider,
    PmnHospitalisationService,
    PmnHospitalInfoService,
    PmnHistoryProfillingService,
    PmnDailyMonitoringService,
    /**End Of PMN */
    
    // ACR
    AcrProvider,
    EnablementFileSaverProvider,
    AddendumProvider,
    PostImplementationReviewProvider,
    ProgressReportProvider,
    NonAcrProvider,
    TasklistNonAcrProvider,
    TasklistAddendumProvider,
    TasklistPirProvider,
    TasklistProgressReportProvider,
    TasklistAcrProvider,
    ExcangeRateProvider,
    FormatterProvider,
    ExcelParserProvider,

    //PRUAMAN
    ApiServicesProvider,
    MasterPruamanProvider,
    PruamanTasklistProvider,
    //End of PRUAMAN
    // pruventure 
    PruventureProvider,
    SalesManagementProvider,
    // end of pruventure 
    //PRUMIKRO
    PrumikroTasklistProvider,
    MasterPrumikroProvider,
    // End of PRUMIKRO
    PerformanceManagementProvider,
    CommonServiceProvider,
    MasterPrucarProvider,
    TakslistProvider,
    ReservationProvider,
    EnablementExportExcelProvider,
    PrumikroPdfProvider,
    PrumikroRoleProvider,
    UpploadFileProvider,
    LongTermIncentiveProvider,
    PruamanRoleProvider,
    DigitalHelpdeskProvider,
    ComplianceProvider,
    LMSPruPartnerProvider,
    PsaProvider,

    //PRULADYS
    MasterPruladysProvider,
	
    //end email provider

    FundReportFileProvider,
    WhatsappUWPECAssignedMessageProvider,
    WhatsappUWPECAutoreplyTimeProvider,
    WhatsappUWPECBroadcastDtlProvider,
    WhatsappUWPECBroadcastProvider,
    WhatsappUWPECCategoryProvider,
    WhatsappUWPECContactProvider,
    WhatsappUWPECDigibotProvider,
    WhatsappUWPECGroupContactDetailProvider,
    WhatsappUWPECGroupContactProvider,
    WhatsappUWPECHsmTemplateApprovalProvider,
    WhatsappUWPECHsmTemplateParameterProvider,
    WhatsappUWPECHsmTemplateProvider,
    WhatsappUWPECKpmCodeProvider,
    WhatsappUWPECKpmRegionCodeProvider,
    WhatsappUWPECLeaderProvider,
    WhatsappUWPECMessageProvider,
    WhatsappUWPECMessageResponseTimeProvider,
    WhatsappUWPECRegionCodeProvider,
    WhatsappUWPECSettingProvider,
    WhatsappUWPECSubcategoryProvider,
    WhatsappUWPECSuperLeaderProvider,
    WhatsappUWPECUserCallProvider,
    WhatsappUWPECUserLoginProvider,
    WhatsappUWPECUserProvider,
    WhatsappUWPECUserTimezoneProvider,
    WhatsappUWPECPrestigeCustProvider,
    WhatsappCustomerRetentionAssignedMessageProvider,
    WhatsappCustomerRetentionAutoreplyTimeProvider,
    WhatsappCustomerRetentionBroadcastDtlProvider,
    WhatsappCustomerRetentionBroadcastProvider,
    WhatsappCustomerRetentionCategoryProvider,
    WhatsappCustomerRetentionContactProvider,
    WhatsappCustomerRetentionDigibotProvider,
    WhatsappCustomerRetentionGroupContactDetailProvider,
    WhatsappCustomerRetentionGroupContactProvider,
    WhatsappCustomerRetentionHsmTemplateApprovalProvider,
    WhatsappCustomerRetentionHsmTemplateParameterProvider,
    WhatsappCustomerRetentionHsmTemplateProvider,
    WhatsappCustomerRetentionKpmCodeProvider,
    WhatsappCustomerRetentionKpmRegionCodeProvider,
    WhatsappCustomerRetentionLeaderProvider,
    WhatsappCustomerRetentionMessageProvider,
    WhatsappCustomerRetentionMessageResponseTimeProvider,
    WhatsappCustomerRetentionRegionCodeProvider,
    WhatsappCustomerRetentionSettingProvider,
    WhatsappCustomerRetentionSubcategoryProvider,
    WhatsappCustomerRetentionSuperLeaderProvider,
    WhatsappCustomerRetentionUserCallProvider,
    WhatsappCustomerRetentionUserLoginProvider,
    WhatsappCustomerRetentionUserProvider,
    WhatsappCustomerRetentionUserTimezoneProvider,
    WhatsappCustomerRetentionPrestigeCustProvider,
    // end wab Customer Retention provider

    // timeout interceptor
    [{ provide: HTTP_INTERCEPTORS, useClass: TimeoutInterceptor, multi: true }],
    [{ provide: DEFAULT_TIMEOUT, useValue: 350000 }],
 ]
})
export class AppModule {}
