import { HttpClient } from '@angular/common/http';
import { Injectable, EventEmitter, Output } from '@angular/core';
import { ToastController, Loading, LoadingController } from 'ionic-angular';

export class AssignCategoryTableFunction {
  minIndex: number = 0;
  maxPerPage: number = 10;
  maxIndex: number = 9;
  activePage: number = 0;
  numberOfPages: any[] = [];
  sortedData: any[] = [];
  goToPageInput: number;
  data: any[] = [];
  searchActive: number;
  searchText: string = '';
  selectedItem: any[] = [];
  isAsc: boolean;
  constructor() {
    this.maxIndex = this.maxPerPage - 1;
  }

  filter(row, e) {
    let val = e.target ? e.target.value : e;
    if (val || typeof val === "boolean") {
      this.sortedData = this.data.filter((x) => {
        if (x[row]) {
          if (typeof x[row] === "boolean") {
            return (x[row]) == (val);
          } else {
            return (x[row]).toLowerCase().indexOf(val.toLowerCase()) > -1;
          }
        }
      })
    } else {
      this.sortedData = this.data;
    }
    this.openPage(0);
    this.pagesCounter(this.sortedData.length);
  }

  openPage(selected_page) {
    let page = selected_page + 1;
    this.maxIndex = (page * this.maxPerPage) - 1;
    this.minIndex = (page * this.maxPerPage) - this.maxPerPage;
    this.activePage = selected_page;
  }

  pagesCounter(item_length) {
    let m = Math.ceil(item_length / this.maxPerPage);
    if (m <= 1) {
      m = 1;
    }
    this.numberOfPages = Array(m).fill(0, 0).map((x, i) => i);
  }

  goToPage() {

    let page = this.goToPageInput - 1;
    if (typeof (page) === "number" && page <= this.numberOfPages.length - 1 && page >= 0) {
      this.openPage(page);
    }
  }

  openSearch(item) {
    if (item == this.searchActive) {
      this.searchActive = undefined;
    } else {
      this.searchActive = item;
    }
  }

  changeMaxPerPage(e) {
    let page = 1;
    this.maxPerPage = e;
    this.pagesCounter(this.data.length);
    this.maxIndex = (page * this.maxPerPage) - 1;
    this.minIndex = (page * this.maxPerPage) - this.maxPerPage;
    this.activePage = 0;
  }

  sortData(attr, e) {
    if (!e.target.classList.contains('sort-button')) {
      return false;
    }
    // let isAsc : boolean;
    let get_active = e.target.classList.contains("active");
    if (!get_active) {
      e.target.parentElement.querySelectorAll('.active').forEach(function (a) {
        a.classList.remove("active");
        a.setAttribute('is-asc', 'false');
      })
    }

    e.target.classList.add("active");
    let isAscAttr = e.target.getAttribute('is-asc');
    if (isAscAttr == 'true') {
      this.isAsc = true;
      e.target.setAttribute('is-asc', 'false');
    } else {
      this.isAsc = false;
      e.target.setAttribute('is-asc', 'true');
    }

    this.sortedData = this.data.sort((a, b) => {
      return compare(a[attr], b[attr], this.isAsc);
    });

    function compare(a: number | string, b: number | string, isAsc: boolean) {
      return (a > b ? -1 : 1) * (isAsc ? 1 : -1);
    }
  }

  now() {
    let today = new Date();
    let dd = today.getDate();
    let mm = today.getMonth() + 1;
    let dds = dd.toString();
    let mms = mm.toString();

    let yyyy = today.getFullYear();
    if (dd < 10) {
      dds = '0' + dd;
    }
    if (mm < 10) {
      mms = '0' + mm;
    }

    return dds + '-' + mms + '-' + yyyy;
  }

  checkBoxSelected(e, id) {
    if (e) {
      this.selectedItem.push(id);
    } else {
      let index = this.selectedItem.findIndex((item) => { return item == id });
      if (index > -1) {
        this.selectedItem.splice(index, 1)
      }
    }
  }

}

@Injectable()
export class AssignCategoryUtilitiesProvider {
  loading: Loading;

  constructor(public http: HttpClient, public toastCtrl: ToastController, public loadingCtrl: LoadingController) { }

  presentToast(text) {
    const toast = this.toastCtrl.create({
      message: text,
      duration: 3000
    });
    toast.present();
  }

  presentLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
  }

  dismissLoading() {
    this.loading.dismiss();
  }
}