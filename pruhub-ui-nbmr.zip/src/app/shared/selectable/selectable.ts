import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
    selector: 'selectable',
    templateUrl: 'selectable.html', 
  })

  export class SelectableComponent implements OnInit  { 

    constructor() { }

    timeout:any;
    public searchInput: String = '';
    public searchResult: Array<any> = [];
    @Input() disabled: boolean;
    @Input() itemList: Array<any> = []
    @Input() sourceModel: any;
    @Output() onClick = new EventEmitter<any>();
    public focus: Boolean = false;
    public model: any;


    fetchSeries(value: String){
        if(!this.focus) {
            this.focus = true;
        }

        this.removePlaceHolder();

        if(value === '') {
            return this.searchResult = this.itemList
        }
        this.searchResult = this.itemList.filter(function(series) {
            return series.longdesc.toLowerCase().startsWith(value.toLowerCase())
        })
    }

    ngOnInit() {
        this.removePlaceHolder();

        this.searchResult = this.itemList;
        this.onSelect(this.sourceModel);
    }

    onSelect(descitem){
        const item = this.itemList.find(x=> x.descitem == descitem);
        if(item){
            this.model = item.longdesc;
        }else{
            this.model = "";
        }
    }

    onFocus(){
        this.focus = true;
    }

    onBlur(){
        this.focus = false;
    }

    onItemClick(item){
        const event = {
            value: item.descitem
        }
        this.onSelect(item.descitem)
        this.onClick.emit(event);
    }

    onClear(){
        this.searchResult = this.itemList
        this.onBlankClick();
    }

    onBlankClick(){
        const item = {
            descitem: ''
        }
        this.onItemClick(item);
        this.onFocus();
    }
    
    removePlaceHolder(){
        this.itemList = this.itemList.filter(x=>x.shortdesc != "");
    }
  }