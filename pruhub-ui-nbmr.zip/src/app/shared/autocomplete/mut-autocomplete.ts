import { HttpClient, HttpHeaders} from '@angular/common/http';
import {Component, HostListener, Input, EventEmitter, Output, OnChanges, SimpleChanges, ElementRef, ViewChild} from '@angular/core';
import { LoadingController, Loading, AlertController} from 'ionic-angular';
import { URLServices } from '../../../providers/url-services';
import { MutAutocompleteParam } from './autocomplete-param';
import { Subscription } from '../../../../node_modules/rxjs/Subscription';
import { FieldViewedParam } from './field-showed-param';

@Component({
  selector: 'mut-autocomplete',
  templateUrl: 'mut-autocomplete.html', 
})

/**
 * For infinite scroll autocomplete (not otherwise)
 * 
 * Release Notes : 
 *  - 0.002 : 
 *    - Developed only for autocomplete in worksheet claim task
 *    - Noob version ngModel binding
 *    - Noob field viewed on autocomplete
 *    - on this patch completed what needed on claim task module
 * Author : Muhammad (Mut)tabi Hudaya
 */
export class MutAutocompleteComponent implements OnChanges { 
  constructor(
    private http: HttpClient,
    private loadingCtrl: LoadingController,
    private alertCtrl: AlertController,
    public urlServices: URLServices
  ){
    // this.loadedData = this.DUMMY_DATA;
  }

  loading: Loading;
  refreshAutocomplete: boolean = true;
  loadedData:any[] = [];

  //Load more data state
  failedLoadData:boolean = false;
  loadingData:boolean = false;

  //Searching autocomplete
  searchKeyString:any;
  timeout:any;
  requestSubsription:Subscription = new Subscription();
  isServerSideRequest:boolean = true;

  //Load server side autocomplete
  totalList:number;
  bodyPost:any = {};
  //
  currentPage:number = 1;
  maxPage:number;
  stillRequesting:boolean = true;
  emptyData:boolean = false;
  
  
  //Inputted variable
  @Input() url:string = '';
  @Input() customWidth:number;
  @Input() fieldSearched:string;
  @Input() sourceModel:any;
  @Input() keyModel:string;
  @Input() fieldViewedParam:FieldViewedParam[];
  @Input() authKey:string;

  //Noob version of additional seearch : TODO Dynamically additional objects
  @Input() additionalSearchSource:any;
  @Input() additionalSearchKey:string;
  @Input() additionalFieldSearched:string;
  @Input() additionalSearch:any;
  

  @Input() isDisable:boolean = false;
  @Input() isLoading:boolean = false;
  // @Input() autocompleteParam:MutAutocompleteParam;

  //Output
  @Output() onCancel = new EventEmitter<any>()
  @Output() onBlur = new EventEmitter<any>()
  @Output() onChange = new EventEmitter<any>();
  @Output() onClick = new EventEmitter<any>();

  initAutocomplete(autocompleteParam:MutAutocompleteParam){
    
  }

  ngOnChanges(changes:SimpleChanges){
    if(changes){
      if(changes.authKey){
        this.authKey = changes.authKey.currentValue;
      }

      if(changes.isDisable){
        this.isDisable = changes.isDisable.currentValue;
        // console.log("Disabling");
        // console.log(this.isDisable);
        // this.disableAutocompleteForm(this.isDisable);
      }
    }
  }

  disableAutocompleteForm(disable:boolean){
    const inputs: any = document.getElementsByName("mut-autocomplete-dokterName");
    console.log(inputs);
    for(let input of inputs) {
      let inputForm = input.getElementsByTagName("INPUT");
      inputForm[0].disabled = disable;
    };
  }

  onKeyUp(search:string){
    this.reset();
    if(search.length > 2){
      this.timeout = setTimeout(() =>{
        this.requestServerSideData();
      }, 500);
    }
  }

  generateRequestParam(){
    this.bodyPost[this.fieldSearched] = this.sourceModel[this.keyModel];
    if(this.additionalSearchSource){
      this.bodyPost[this.additionalFieldSearched] = this.additionalSearchSource[this.additionalSearchKey]
    }
    if(this.additionalSearch){
      this.additionalSearch.forEach((el, index) => {
        this.bodyPost[el.key] = el.value;
      })
    }
  }


  requestServerSideData(){
    this.generateRequestParam();
    this.loadingData = true;
    if(this.isServerSideRequest){
      let headers    = new HttpHeaders({
        'Content-Type': 'application/json',
        'X-Requested-Url': `${this.url}/${this.currentPage}`,
        'X-Requested-Method': 'POST',
        'Authorization': this.authKey
      });
      let options    = { headers: headers };
      this.requestSubsription = this.http.post(this.urlServices.baseProxy, this.bodyPost, options).subscribe(
        (res:any) => {
          res = res.dataMaster ? res.dataMaster : res;
          if(res){
            this.loadingData = false;
            if(res.length > 0){
              if(res.length < 10){
                this.stillRequesting = false;
              }
              this.generateViewedString(res);
            }else{
              this.stillRequesting = false;
              this.emptyData = true;
            }
          }else{
            //Error
            this.loadingData = false;
            this.failedLoadData = true;
          }
        },
        (error:any) => {
          this.loadingData = false;
          this.failedLoadData = true;

        }
      );
    }else{
      //For testing area
      this.loadingData = false;
      this.failedLoadData = true;
    }
  }

  generateViewedString(res:any[]){
    res.forEach(element => {
      //Generating viewed string
      let viewString:string = "";
      this.fieldViewedParam.forEach(fieldView => {
        if(element[fieldView.keyField]){
          viewString += element[fieldView.keyField]
          if(fieldView.separator){
            viewString += fieldView.separator;
          }
        }
      });
      element.view = viewString
    });
    this.loadedData.push(...res);
  }
  
  @HostListener("scroll", ["$event"])
  onBottomScroll(){
    let pos = (document.getElementById('list-autocomplete-result').scrollTop || document.body.scrollTop) + document.getElementById('list-autocomplete-result').offsetHeight;
    let max = document.getElementById('list-autocomplete-result').scrollHeight;
    if(pos == max ){
      console.log("on scroll event");
      if(this.stillRequesting || this.currentPage == 1){
        this.requestServerSideData();
        this.currentPage++;
      }
    }
  }

  reset(){
    clearTimeout(this.timeout);
    this.requestSubsription.unsubscribe();
    this.failedLoadData = false;
    this.emptyData = false;
    this.loadedData = [];
    this.stillRequesting = true;
    this.currentPage = 1;
  }

  //#region emitter
  onCancelType(event){
    console.log("on cancel autocomplete");
    this.reset();
    this.onCancel.emit(event);
  }

  onBlurAutocomplete(event){
    this.onBlur.emit(event);
    // this.reset();
  }

  onChangeType(event){
    this.sourceModel[this.keyModel] = event;
    if(event == "" || event == null || event == undefined){
      this.reset();
    }
    this.onChange.emit(event);
  }

  onClickItem(event){
    this.sourceModel[this.keyModel] = event.view;
    console.log("on click event", event);
    this.onClick.emit(event);
    this.reset();
  }
  //#region utilities

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }

  showAlert(text) {
    let button:any = ['OK'];
    let alert = this.alertCtrl.create({
      title: 'Error',
      subTitle: text,
      buttons: button
    });
    
    alert.present();
  }

  /**
   * Return date string format dd-MMMM-yyyy
   * @param string 
   */
  private splitDate(string:string) : string{
    if(string.length == 8){
      let _string = string.toString();
      let segment1 = _string.substr(0,4);
      let segment2 = _string.substr(4,2);
      let segment3 = _string.substr(6,2);
      return segment1+'-'+segment2+'-'+segment3;
    }else if(string.length >= 14){
      if(string.length > 14){
        string = string.slice(0,14);
      }
      let _string = string.toString();
      let segment1 = _string.substr(0,4);
      let segment2 = _string.substr(4,2);
      let segment3 = _string.substr(6,2);
      let segment4 = _string.substr(8,2);
      let segment5 = _string.substr(10,2);
      let segment6 = _string.substr(12,2);
      return segment1+'-'+segment2+'-'+segment3+' '+segment4+':'+segment5+':'+segment6;
    }else{
      return string;
    }
  }

  /**
   * Return string format after replacing all commas
   * @param value 
   */
  private removeComma(value: string) :string{
    if (value != undefined) {
      let _string = value.toString();
      let get_int = _string.split('.');
      let after_comma = '00';
      if (get_int[1]) {
        after_comma = get_int[1].replace(/\D/g, "");
      }
      let before_comma = get_int[0].replace(/\D/g, "");
      return parseFloat(before_comma+'.'+after_comma).toFixed(2);
    }else{
      return '0.00';
    }
  }
  //#endregion
}