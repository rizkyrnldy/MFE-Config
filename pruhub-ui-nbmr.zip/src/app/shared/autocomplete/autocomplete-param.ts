import { FieldViewedParam } from "./field-showed-param";

export interface MutAutocompleteParam{
    url:string,
    fieldSearched:string,
    sourceModel:any,
    keyModel:string,
    fieldViews:FieldViewedParam[],

    customWidth?:number
}