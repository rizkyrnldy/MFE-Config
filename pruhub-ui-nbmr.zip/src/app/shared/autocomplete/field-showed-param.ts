export interface FieldViewedParam{
    keyField:string,
    separator?:string
}