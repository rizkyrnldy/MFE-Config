import { IFilter } from "../../modal-filter/filter-interface";
import { IFilterCheckbox } from "../../modal-filter/checkbox-filter-interface";

export interface IFilterTable {
    onFilterFn:Function,
    filters:IFilter[],

    //operator
    queryMode?:boolean,
}

export interface IFilterRequest{
    column: string,
    value:any,
    values?:any[],
    operator?: string,
    is_like?: boolean,
    is_equals?:boolean,


    is_between?:boolean,
    start_range?:any,
    end_range?:any,
    data_type?:string,

    
    label?:string,
    type?:string,
    aliases?:string,
    checkboxes?:IFilterCheckbox[]
}