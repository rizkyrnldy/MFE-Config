export interface ISortTable{
    sorts: ISort[],
    onClick:Function, //multi parameter
    sortMode?:string //asc or desc
}

export interface ISort{
    columnName:string,
    key:string,
}