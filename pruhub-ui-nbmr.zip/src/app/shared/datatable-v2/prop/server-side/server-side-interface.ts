export interface IServerSideTable{
    url:string,
    keyCurrentPage:string,
    keyItemsPerPage:string,
    keyData:string,
    keyTotalData?:string,
    keyTotalPages:string,

    customParam?:string,
    customBody?:any,

    authHeader?:string
}