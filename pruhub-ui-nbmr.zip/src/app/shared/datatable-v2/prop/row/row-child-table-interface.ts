import { IDatatable } from "../../datatable-interface";

export interface IRowChildTable{
    detailKey:string,
    tables:IDatatable[]
}