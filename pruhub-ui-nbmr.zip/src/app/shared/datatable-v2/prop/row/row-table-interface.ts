import { IAction } from "../action/action-interface";
import { IColumn } from "./row-interface";

export interface IRowTable{
    columns : IColumn[],
    actions?:IAction[],

    hideAction?:boolean,
    isSelectable?:boolean,
    selectedCheckboxStateByFn? : Function,
    onClickSelectedRow?:Function,
    onClickSelectAllRowInTable?:Function
}