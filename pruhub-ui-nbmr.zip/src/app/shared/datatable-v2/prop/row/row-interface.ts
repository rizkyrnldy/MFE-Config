export interface IColumn{
    key: string,
    header: string,
    detailKey?:string,
    tag?:ITag,
    // isCheckbox?:boolean,
    // isDate?:boolean,
    // isMoneyFormat?:boolean,
    // isTimestamp?:boolean,
    // currency?:string,
    // isAction?: boolean,
    // isTextCenter?:boolean
    isDate?:boolean
}

export interface ITag{
    onClick?:Function,
    key:string
}