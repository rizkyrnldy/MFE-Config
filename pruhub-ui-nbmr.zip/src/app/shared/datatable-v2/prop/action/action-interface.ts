export interface IAction{
    label:string,
    icon?:string,
    onClick?:Function
}