//import { IPagination } from "./pagination/pagination-interface";
//import { IFilter } from "./modal-filter/filter-interface";
import { IAction } from "./prop/action/action-interface";
import { IRowTable } from "./prop/row/row-table-interface";
import { IServerSideTable } from "./prop/server-side/server-side-interface";
import { IFilterTable } from "./prop/filter-table/filter-table-interface";
//import { IColumn } from "./prop/row/row-interface";
import { ISortTable } from "./prop/sort/sort-by-interface";

export interface IDatatable{
    identifier:string,
    name:string,
    detailName?:string,
    loadDataOnPage?:number,
    filterTable?: IFilterTable,
    primaryButton?:IAction,
    actions?:IAction[],
    sort?:ISortTable,

    rowTable: IRowTable,
    dataset?:any[],
    serverSide:IServerSideTable
}