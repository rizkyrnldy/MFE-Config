export const DATATABLE_OPTION = {
    PAGINATION : {
        TOTAL_DATA_PER_PAGE : 10,
        LOAD_TABLE_ON_PAGE : 1,
        NUMBER_OF_PAGES_SHOWN : 5
    }
}