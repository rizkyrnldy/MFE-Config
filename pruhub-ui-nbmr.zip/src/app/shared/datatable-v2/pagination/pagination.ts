import { IPagination } from "./pagination-interface";
import { Injectable } from "@angular/core";
import { Page } from "./page";

@Injectable()
export class Pagination{

    public totalData:number;
    private totalPages:number;
    private itemsPerPage:number;
    private loadDataOnPage:number = 1;
    private numberOfPagesShown:number = 5;
    private isOnlyNextAndPrevButton:boolean = false;
    private currentPage:number;

    public listOfPages:Page[] = []; //Get this one to produce pagination number

    private firstPage:number = 1;
    private lastPage:number = 1;
    private visitedPages:boolean[] = [];


    public init(initPagination:IPagination){
        for(let paginationProp in initPagination){
            if(initPagination.hasOwnProperty(paginationProp)){
                this[paginationProp] = initPagination[paginationProp];
            }
        }

        this.currentPage = this.loadDataOnPage;
    }

    public updateProp(initPagination:IPagination){
        this.init(initPagination);
    }


    public open(pageNumber:number, totalData?:number){
        this.currentPage = pageNumber;
        
        if(totalData){
            this.lastPage = this.getLastPage();
            this.totalData = totalData;
        }else{
            this.lastPage = this.totalPages;
        }

        this.setVisitedPages();
        this.listOfPages = this.generateListOfPages();
    }

    private getLastPage():number{ 
        return Math.ceil(this.totalData / this.itemsPerPage)
    }

    private setVisitedPages(){
        if(!this.visitedPages[this.currentPage]){
            this.visitedPages[this.currentPage] = true;
        }
    }

    private generateListOfPages():Page[]{
        let listOfPages:Page[] = [];
        //Prev Btn
        listOfPages.push({
            number : this.currentPage > 0 ? this.currentPage - 1 : this.currentPage,
            isPrevBtn: true
        });

        if(!this.isOnlyNextAndPrevButton){
            //Show First Page
            if(this.isShowingFirstPage()){
                listOfPages.push({
                    number : this.firstPage,
                    isFirstPage : true
                })
            }
    
            //List of Pages (Number)
            listOfPages.push(...this.getListOfPagesNumber());
    
            //Show Last Page
            if(this.isShowingLastPage()){
                listOfPages.push({
                    number : this.lastPage,
                    isLastPage : true
                })
            }
        }

        //Next Button
        listOfPages.push({
            number : this.currentPage < this.lastPage ? this.currentPage + 1 : this.currentPage,
            isNextBtn : true
        });

        return this.setState(listOfPages);
    }

    private isShowingFirstPage():boolean{
        return this.currentPage - Math.floor(this.numberOfPagesShown / 2) > this.firstPage;
    }

    private isShowingLastPage():boolean{
        return this.currentPage + Math.floor(this.numberOfPagesShown / 2) < this.lastPage;
    }

    private getListOfPagesNumber():Page[]{
        let listOfPagesNumber:Page[] = [];
        let startShowPageNumber:number;
        let endShowPageNumber:number

        if(this.currentPage == this.firstPage){
            startShowPageNumber = this.firstPage;
            endShowPageNumber = this.firstPage + Math.floor(this.numberOfPagesShown / 2);
        }else if(this.currentPage == this.lastPage){
            startShowPageNumber = this.lastPage - Math.floor(this.numberOfPagesShown / 2);
            endShowPageNumber = this.lastPage;
        }else{
            startShowPageNumber = this.currentPage - Math.floor(this.numberOfPagesShown / 2);
            endShowPageNumber = this.currentPage + Math.floor(this.numberOfPagesShown / 2);
        }
        
        for(let i=startShowPageNumber; i<=endShowPageNumber; i++){
            if((i >= this.firstPage) && (i <= this.lastPage)){
                listOfPagesNumber.push(
                    {
                        number : i
                    }
                )
            }
        }

        return listOfPagesNumber;
    }

    private setState(listOfPages:Page[]):Page[]{
        listOfPages.forEach(pages => {
            //Set prev btn state
            if(pages.isPrevBtn){
                if(this.currentPage == this.firstPage){
                    pages.isDisable = true;
                }
                if(this.visitedPages[this.firstPage - 1]){
                    pages.isVisited = true;
                }
            }

            //Set list of pages
            if(this.visitedPages[pages.number]){
                pages.isVisited = true;
            }

            if(!pages.isPrevBtn && !pages.isNextBtn){
                if(this.currentPage == pages.number){
                    pages.isActive = true;
                    pages.isDisable = true;
                }
            }

            //Set Next btn state
            if(pages.isNextBtn){
                if(this.currentPage == this.lastPage || this.lastPage == 0){
                    pages.isDisable = true;
                }
                if(this.visitedPages[this.lastPage - 1]){
                    pages.isVisited = true;
                }
            }
        });

        return listOfPages;
    }

    public getCurrentPage():number{
        return this.currentPage;
    }

    public getItemsPerPage():number{
        return this.itemsPerPage;
    }
}