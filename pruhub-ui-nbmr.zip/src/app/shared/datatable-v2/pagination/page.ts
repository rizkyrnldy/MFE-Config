export class Page{
    constructor(
        public number?:number,
        public isPrevBtn?:boolean,
        public isNextBtn?:boolean,
        public isFirstPage?:boolean,
        public isLastPage?:boolean,
        public isDisable?:boolean,
        public isActive?:boolean,
        public isVisited?:boolean
    ){

    }
}