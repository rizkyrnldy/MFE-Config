export interface IPagination{
    totalData?:number,
    totalPages?:number,
    itemsPerPage?:number,
    loadDataOnPage?:number,
    numberOfPagesShown?:number,
    isOnlyNextAndPrevButton?:boolean
}