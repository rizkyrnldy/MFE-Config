export interface IFilterCheckbox{
    key:any,
    value:string,
    checked?:boolean
}