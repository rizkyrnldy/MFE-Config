import { IFilterCheckbox } from "./checkbox-filter-interface";

export interface IFilter{
    label:string,
    type:string, //based on filter consts file
    identifier:string, //identifier for the object
    aliases?:string,

    //Checkboxes
    checkboxes?:IFilterCheckbox[]
}