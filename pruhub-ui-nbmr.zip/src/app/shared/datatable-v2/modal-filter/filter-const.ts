export const FILTER = {
    TYPE : {
        CHECKBOXES : {
            SINGLE_SELECTION : "CHECKBOXES_SINGLE_SELECTION",
            MULTIPLE_SELECTION : "CHECKBOXES_MULTIPLE_SELECTION"
        },
        INPUT : {
            STRING: "INPUT_STRING",
            NUMBER: "INPUT_NUMBER",
            DATE : "INPUT_DATE",
            RANGE : {
                NUMBER: "INPUT_RANGE_NUMBER",
                DATE : "INPUT_RANGE_DATE",
            }
        }
    }
}