import { IDatatable } from "../datatable-interface";
//import { IPagination } from "../pagination/pagination-interface";

import { ISort } from "../prop/sort/sort-by-interface";
import { IFilterRequest } from "../prop/filter-table/filter-table-interface";
import { Pagination } from "../pagination/pagination";
//import { Pagination } from "../../../../providers/providers";

export class DatatableContainer{
    constructor(
        public datatable:IDatatable,
        public pagination?: Pagination,
        public isLoaded?:boolean,

        //Sort by
        public currentSortBy?:ISort,
        public currentSortMode?:string,

        //fILTER
        public isFiltered?:boolean,
        public currentFilter?:IFilterRequest[],

        //Selected
        public isSelectAllInRow?:boolean,
        public isSelectAllRowInTable?:boolean
    ){

    }
}