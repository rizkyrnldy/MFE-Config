import { Component, HostListener } from '@angular/core';
import { IonicPage, NavController, NavParams, ModalController, Loading, LoadingController } from 'ionic-angular';
import { Pagination } from './pagination/pagination';
import { Http } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { IDatatable } from './datatable-interface';
import { DATATABLE_OPTION } from './datatable-opts';
import { DatatableContainer } from './model/datatable.model';
import { IPagination } from './pagination/pagination-interface';
import { IColumn } from './prop/row/row-interface';
import { TOOLTIP_ACTION } from './datatable-action';
import { ISort } from './prop/sort/sort-by-interface';

@Component({
  selector: 'mut-datatable-v3',
  templateUrl: 'mut-datatable-v3.html',
})
/**
 * Auhor : Muhammad Muttabi Hudaya
 * Another easy to use yet hard to master datatable component
 * You can either live easily or die hard in this rabbit hole
 * 
 * Version 1.0
 *  - Creating datatable based on desired parameter
 *   -- Pagination
 *   -- Filter
 *   -- Desired column content
 * - Creating a really complex datatable yet no one can't understand
 *   -- Creating table inside a table (onClick Event triggering this)
 *   -- Creating a tracker in this unlimited datable (file-tracker-ish [./file/document/etc])
 */
export class MutDatatableV2Component {

  // private datatables:IDatatable[] = [];
  // private currentContainer:DatatableContainer;
  public currentDatatableIdentifier:string;
  private currentContainer:DatatableContainer;
  private currentTooltip:string;
  private datatableContainer:DatatableContainer[] = [];
  TOOLTIP_ACTION:any = TOOLTIP_ACTION;

  //Server side
  // private serverResponseObj:any;

  //Filter
  private modalFilter:any;
  private tmpFilter:any;

  private itemsPerPageArray = [10,50,100];
  private viewItemsPerPage;
  //Dataset
  private dataset:any[] = [];

  
  loading: Loading;

  constructor(
    public modalCtrl: ModalController,
    private loadingCtrl: LoadingController,
    private _http:Http,
    private http:HttpClient
    ) {
  }
  

  public init(datatables: IDatatable[]){
    this.datatableContainer = [];
    datatables.forEach(datatable => {
      this.datatableContainer.push({
        datatable : Object.assign({}, datatable),
        pagination : new Pagination()
      });
    });
    this.viewItemsPerPage = 10;
    this.loadDatatable(this.datatableContainer[0]);
  }

  public loadDatatable(currentContainer:DatatableContainer){
    this.currentDatatableIdentifier = currentContainer.datatable.identifier;
    //Set filter
    if(currentContainer.datatable.filterTable){
      currentContainer.currentFilter = [];
      this.setDatatableFilter(currentContainer.datatable);
    }
    //Set pagination
    this.initPagination(currentContainer);
    
    //Set sort mode
    if(currentContainer.datatable.sort){
      currentContainer.currentSortBy = currentContainer.datatable.sort.sorts[0];
      currentContainer.currentSortMode = "asc";
    }

    //Set dataset
    this.initDataset(currentContainer);


    if(!currentContainer.datatable.serverSide){
      currentContainer.isLoaded = true;
    }
  }
  public loadDatatable2(currentContainer:DatatableContainer){
    this.currentDatatableIdentifier = currentContainer.datatable.identifier;
    //Set filter
    if(currentContainer.datatable.filterTable){
      //currentContainer.currentFilter = [];
      this.setDatatableFilter(currentContainer.datatable);
    }
    //Set pagination
    this.initPagination(currentContainer);
    
    //Set sort mode
    if(currentContainer.datatable.sort){
      currentContainer.currentSortBy = currentContainer.datatable.sort.sorts[0];
      currentContainer.currentSortMode = "asc";
    }

    //Set dataset
    this.initDataset(currentContainer);


    if(!currentContainer.datatable.serverSide){
      currentContainer.isLoaded = true;
    }
    let sortBody:any = null;
    if(currentContainer.datatable.sort){
      sortBody = {
        sort_by : currentContainer.currentSortBy.key,
        sort_mode : currentContainer.currentSortMode
      }
    }
    this.setServerSideDataset(1,currentContainer,sortBody);
  }
  private onChangeItemsPerPage(itemsPerPage:any){
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>"+this.datatableContainer[0].currentFilter[0]);
    this.viewItemsPerPage = parseInt(itemsPerPage);
    this.initPagination(this.datatableContainer[0]);
    //this.loadDatatable2(this.datatableContainer[0]);
    let sortBody:any = null;
    if(this.datatableContainer[0].datatable.sort){
      sortBody = {
        sort_by : this.datatableContainer[0].currentSortBy.key,
        sort_mode : this.datatableContainer[0].currentSortMode
      }
    }
    console.log("this.datatableContainer[0].datatable.serverSide.customBody"+this.tmpFilter);
    this.setServerSideDataset(1, this.datatableContainer[0], this.tmpFilter);
    //this.initDataset(this.datatableContainer[0]);
    //this.setServerSideDataset(1,this.datatableContainer[0],sortBody);
    //this.loadDatatable2(this.datatableContainer[0]);
    //this.currentPage = Math.floor((this.currentPage -1) * this.itemsPerPage / parseInt(itemsPerPage)) + 1;
   // this.itemsPerPage = parseInt(itemsPerPage);
    //this.initPagination(this.dataset);
    //this.onClickPage(this.currentPage);
  }
  private onClickPage(clickedPage:number){
    // this.currentPage = clickedPage;
    // if(!this.isLazyLoad){
    //   this.viewDatatable = this.getSlicedDataFromDataset(this.dataset);
    //   this.setViewPaginationIndex(this.dataset);
    // }else{
    //   this.getLazyLoadData();
    // }
  }
  //Filter
  private setDatatableFilter(datatable:IDatatable){
    this.modalFilter = this.modalCtrl.create('ModalFilterAgentPage', {
      filterList : datatable.filterTable.filters,
      queryMode : datatable.filterTable.queryMode
    });
  }

  private onClickFilterBtn(currentContainer:DatatableContainer){
    this.modalFilter = this.modalCtrl.create('ModalFilterAgentPage', {
      filterList : currentContainer.datatable.filterTable.filters,
      queryMode : currentContainer.datatable.filterTable.queryMode,
      currentFilter : currentContainer.currentFilter
    });
    this.modalFilter.present();

    
    let sortObj:any = null;
    if(currentContainer.datatable.sort){
      sortObj = {
        sortBy : currentContainer.currentSortBy,
        sortMode: currentContainer.currentSortMode
      }
    }
    this.modalFilter.onDidDismiss((filterObj:any) => {
      if(filterObj){
        if(filterObj.isEmptyFilter){
          if(currentContainer.isFiltered){
            currentContainer.datatable.filterTable.onFilterFn(filterObj, currentContainer, sortObj);
          }
          currentContainer.currentFilter = filterObj.resultFilter;
          currentContainer.isFiltered = false;
          this.datatableContainer[0] = filterObj.resultFilter;
          this.datatableContainer[0].isFiltered = false;
          this.tmpFilter= filterObj.resultFilter;
        }else{
          currentContainer.isFiltered = true;
          currentContainer.currentFilter = filterObj.resultFilter;
          this.datatableContainer[0].isFiltered = true;
          this.datatableContainer[0].currentFilter = filterObj.resultFilter;
          this.tmpFilter= filterObj.resultFilter;
          currentContainer.datatable.filterTable.onFilterFn(filterObj, currentContainer, sortObj);
        }
      }
      console.log(currentContainer.currentFilter);
    });
  }

  private onResetFilter(currentContainer:DatatableContainer){
    currentContainer.isFiltered = false;
    currentContainer.currentFilter = [];
    this.tmpFilter="";
    let sortBody:any = null;
    if(currentContainer.datatable.sort){
      sortBody = {
        sort_by : currentContainer.currentSortBy.key,
        sort_mode : currentContainer.currentSortMode
      }
    }
    this.setServerSideDataset(1,currentContainer,sortBody);
  }


  //Dataset
  private initDataset(currentContainer:DatatableContainer){
    if(!currentContainer.datatable.serverSide){
      this.dataset = currentContainer.datatable.dataset;
      this.setDataset(currentContainer.datatable.rowTable.columns, this.dataset);
      //TODO Slicing
      
    }else{
      this.setServerSideDataset(currentContainer.pagination.getCurrentPage(), currentContainer, currentContainer.datatable.serverSide.customBody);
    }
  }

  private setDataset(columns:IColumn[], dataset:any[]){
    columns.forEach(column => {
      dataset.forEach(data => {
        Object.keys(data).forEach(key => {
          if(data.hasOwnProperty(key)){
            //TODO Set custom dataset

          }
        });
      });
    });
  }

  private onOpenPage(page:number, currentContainer:DatatableContainer){
    if(currentContainer.datatable.serverSide){
      console.log("==========---========");
      this.setServerSideDataset(page,currentContainer,this.tmpFilter);
    }else{
      //TODO Slicing

    }
  }

  public setServerSideDataset(page:number, currentContainer:DatatableContainer, bodyRequest?:any){
    console.log("==========---========");
    this.showLoading();
    if(!bodyRequest){
      bodyRequest = {};
    }
    console.log("==========---========"+currentContainer.datatable.serverSide.url + " and " + this.generateBodyRequest(page, currentContainer, bodyRequest));
    this._http.post(currentContainer.datatable.serverSide.url, this.generateBodyRequest(page, currentContainer, bodyRequest)).subscribe(
      (res:any) => {
        this.loading.dismiss();
        res = res.json();
        this.dataset = res[currentContainer.datatable.serverSide.keyData];
        currentContainer.pagination.updateProp({
          totalPages : res[currentContainer.datatable.serverSide.keyTotalPages],
          totalData : res[currentContainer.datatable.serverSide.keyTotalData]
        });
        currentContainer.pagination.open(page);
        this.setDataset(currentContainer.datatable.rowTable.columns, this.dataset);
        
        if(currentContainer.datatable.rowTable.isSelectable){
          currentContainer.datatable.rowTable.selectedCheckboxStateByFn(this.dataset);
        }

        currentContainer.isLoaded = true;
        console.log("totalPages>>>"+res[currentContainer.datatable.serverSide.keyTotalPages]);
        console.log("totalData>>>"+res[currentContainer.datatable.serverSide.keyTotalData]);
      },
      (err:any) => {
        this.loading.dismiss();
        //on error todo
      }
    )
  }

  private generateBodyRequest(page:number, currentContainer:DatatableContainer, bodyRequest:any):any{
    console.log("bodyRequest"+bodyRequest['filter_query']);
    if(bodyRequest['filter_query']==undefined){
      let reBodyRequest:any= {};
      console.log("length"+bodyRequest.length);
      if(bodyRequest.length>0){
        reBodyRequest['filter_query']=bodyRequest;
      }
      reBodyRequest[currentContainer.datatable.serverSide.keyCurrentPage] = page;
      reBodyRequest[currentContainer.datatable.serverSide.keyItemsPerPage] = currentContainer.pagination.getItemsPerPage();
      return reBodyRequest;
    }
    else{
      bodyRequest[currentContainer.datatable.serverSide.keyCurrentPage] = page;
      bodyRequest[currentContainer.datatable.serverSide.keyItemsPerPage] = currentContainer.pagination.getItemsPerPage();
      console.log("bodyRequest"+bodyRequest[currentContainer.datatable.serverSide.keyCurrentPage]);
      console.log("bodyRequest"+bodyRequest[currentContainer.datatable.serverSide.keyItemsPerPage]);
      return bodyRequest;
    }
  }

  //Pagination
  private initPagination(currentContainer:DatatableContainer){
    currentContainer.pagination.init(this.initDatatablePagination(currentContainer));
  }

  private initDatatablePagination(currentContainer:DatatableContainer):IPagination{
    let pagination:IPagination = {
      itemsPerPage : this.viewItemsPerPage,
      loadDataOnPage : DATATABLE_OPTION.PAGINATION.LOAD_TABLE_ON_PAGE,
      numberOfPagesShown: DATATABLE_OPTION.PAGINATION.NUMBER_OF_PAGES_SHOWN
    }

    if(!currentContainer.datatable.serverSide){
      pagination.totalData = currentContainer.datatable.dataset.length;
    }

    if(currentContainer.datatable.loadDataOnPage){
      pagination.loadDataOnPage = currentContainer.datatable.loadDataOnPage;
    }

    return pagination;
  }

  //misc
  private setCurrentTooltip(current:string){
    setTimeout(() => {
      if(current == this.currentTooltip){
        this.currentTooltip = null;
      }else{
        this.currentTooltip = current;
      }
    }, 10)
  }

  setCurrentSortBy(container:DatatableContainer, sort:ISort){
    container.currentSortBy = sort;
  }

  public getCurrentContainer():DatatableContainer{
    return this.datatableContainer.find((container) => container.datatable.identifier == this.currentDatatableIdentifier);
  }

  public getContainerById(id:string):DatatableContainer{
    return this.datatableContainer.find((container) => container.datatable.identifier == id);
  }

  public getCurrentContainerSort(id:string):any{
    let currentContainer:DatatableContainer = this.datatableContainer.find((container) => container.datatable.identifier == id);
    return  {
      sortBy : currentContainer.currentSortBy,
      sortMode : currentContainer.currentSortMode
    }
  }

  @HostListener('document:click', ['$event'])
  onAnywhereClick(event:MouseEvent){
    this.currentTooltip = null;
  }


  selectAllRow(currentContainer:DatatableContainer, dataset:any[]){
    console.log("triggered");
    if(currentContainer.isSelectAllInRow){
      dataset.forEach(row => {
        row.isSelected = true;
        currentContainer.datatable.rowTable.onClickSelectedRow(row, true);
      });
    }else{
      dataset.forEach(row => {
        row.isSelected = false;
        currentContainer.datatable.rowTable.onClickSelectedRow(row, false);
      });
    }
  }

  selectAllRowInTable(currentContainer:DatatableContainer){
    currentContainer.isSelectAllRowInTable = true;
    currentContainer.datatable.rowTable.onClickSelectAllRowInTable(true);
  }

  unselectAllRowInTable(currentContainer:DatatableContainer, dataset:any[]){
    currentContainer.isSelectAllRowInTable = false;
    currentContainer.isSelectAllInRow = false;
    dataset.forEach(row => {
      row.isSelected = false;
    });
    currentContainer.datatable.rowTable.onClickSelectAllRowInTable(false);
  }

  onChangeRowCheckbox(currentContainer:DatatableContainer, dataset:any[]){
    if(!currentContainer.isSelectAllInRow){
      let isAllRowChecked:boolean = true;
      for(let row of dataset){
        if(!row.isSelected){
          isAllRowChecked = false;
          break;
        }
      };
      if(isAllRowChecked){
        currentContainer.isSelectAllInRow = true;
      }
    }else{
      currentContainer.isSelectAllInRow = false;
      currentContainer.isSelectAllRowInTable = false;
    }  
  }

  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: "Please wait..."
    });
    this.loading.present();
  }

}
