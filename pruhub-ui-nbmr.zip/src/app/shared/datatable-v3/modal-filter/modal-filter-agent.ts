import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { ViewController } from 'ionic-angular/navigation/view-controller';
import { UserProvider } from '../../../../providers/providers';
import { IFilter } from './filter-interface';
import { FILTER } from './filter-const';
import { IFilterRequest } from '../prop/filter-table/filter-table-interface';
import { AlertController } from 'ionic-angular/components/alert/alert-controller';


/**
 * Generated class for the ModalFilterMessageTemplatePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal-filter-agent',
  templateUrl: 'modal-filter-agent.html',
})
export class ModalFilterAgentPage {
  nowDate: Date = new Date();
  FILTER:any = FILTER

  //Form Generator
  filterList:IFilter[] = [];
  filterModel:IFilterRequest[] = []
  filterObj:any;
  singleCheckbox:any;
  showForm:boolean = false;

  queryMode:boolean = false;
  disableMode:boolean = false;
  
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private auth: UserProvider,
    public alertCtrl: AlertController,
    public toastCtrl: ToastController,
    public viewCtrl:ViewController
    ){
      this.init();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ModalFilterMessageTemplatePage');
  }

  init(){
    this.filterList = this.navParams.data.filterList;
    if(this.navParams.data.queryMode){
      this.queryMode = this.navParams.data.queryMode;
    }
    if(this.navParams.data.disableMode){
      this.disableMode = this.navParams.data.disableMode;
    }
    console.log(this.navParams.data);
    if(this.filterList){
      if(this.navParams.data.currentFilter){
        if(this.navParams.data.currentFilter.length > 0){
          //Deep copy
          this.generateFilterObj();
          let currentFilters:IFilterRequest[] = JSON.parse(JSON.stringify(this.navParams.data.currentFilter));
          this.filterModel.forEach((filter, index) => {
            for(let currentFilter of currentFilters){
              if(filter.column == currentFilter.column){
                
                this.setFilterModel(this.filterModel[index], currentFilter);
                // this.filterModel[index] = currentFilter;
              }
            }
          });

          if(this.disableMode){
            for (let index = this.filterModel.length -1; index >= 0; index--) {
              if(!this.isFilterNotEmpty(this.filterModel[index])){
                this.filterModel.splice(index , 1);
              }
            }
          }
          console.log(this.filterModel);
        }else{
          this.generateFilterObj();
        }
      }else{
        this.generateFilterObj();
      }
      this.showForm = true;
    }
  }

  setFilterModel(filterModel:IFilterRequest, currentFilter:IFilterRequest){
    for (const key in currentFilter) {
      if (currentFilter.hasOwnProperty(key)) {
        if(currentFilter[key]!=null){
          filterModel[key] = currentFilter[key];
        }
      }
    }
  }
  
  generateFilterObj(){
    this.filterModel = [];
    this.filterList.forEach(filter => {
      let filterReq:IFilterRequest = {
        column : filter.identifier,
        operator : "and",
        value : null,
        type : filter.type,
        label: filter.label,
        aliases : filter.aliases,
        is_like : true
      };

      if(this.isRangeFormFilter(filterReq)){
        filterReq.is_between = true;
        filterReq.is_like = false;
        filterReq.start_range = null;
        filterReq.end_range = null;
      }
      if(this.isCheckboxFilter(filterReq)){
        filterReq.checkboxes = filter.checkboxes;
        filterReq.is_like = false;
        filterReq.is_equals = true;
        if(filterReq.checkboxes){
          if(filterReq.checkboxes.length <= 0){
            filterReq = null;
          }
        }
      }

      
      if(filterReq){
        filterReq.data_type = this.setDataType(filter.type);
        this.filterModel.push(filterReq);
      }
    });
  }

  setDataType(filterType:string):string{
    switch(filterType){
      case FILTER.TYPE.INPUT.DATE : return "date";
      case FILTER.TYPE.INPUT.STRING : return "string";
      case FILTER.TYPE.INPUT.NUMBER : return "number";
      case FILTER.TYPE.INPUT.RANGE.NUMBER : return "number";
      case FILTER.TYPE.INPUT.RANGE.DATE : return "date";
      default : return "string"
    }
  }

  resetFilter(){
    this.filterModel.forEach(filter => {
      filter.value = null;
      if(this.isCheckboxFilter(filter)){
        filter.checkboxes.forEach(checkbox => {
          checkbox.checked = false;
        });
      }
      if(this.isRangeFormFilter(filter)){
        filter.start_range = null;
        filter.end_range = null;
      }
    });
  }

  validFilter():boolean{
    let valid:boolean = true;
    for(let filter of this.filterModel){
      if(this.isRangeFormFilter(filter)){
        if(((!this.isNullOrEmpty(filter.start_range) && this.isNullOrEmpty(filter.end_range))) || (this.isNullOrEmpty(filter.start_range) && !this.isNullOrEmpty(filter.end_range)) ){
          valid = false;
          break;
        }
      }
    };

    return valid;
  }

  applyFilter(){
    let isValiddate:Boolean = true;
    let resultFilter:any[] = [];
    this.filterModel.forEach(filter => {
      if(this.isFilterNotEmpty(filter)){
        let filterObj:IFilterRequest =  {
          column : filter.column,
          aliases : filter.aliases,
          value : filter.value
        }
  
        if(filter.type == FILTER.TYPE.CHECKBOXES.SINGLE_SELECTION){
          filterObj.values = this.singleCheckbox;
        }
        if(filter.type == FILTER.TYPE.CHECKBOXES.MULTIPLE_SELECTION){
          filterObj.values = filter.values;
        }
        
        if(this.queryMode){
          filterObj.operator = filter.operator;
          filterObj.is_like = filter.is_like;
          filterObj.is_equals = filter.is_equals;
          if(filter.is_between){
            filterObj.is_between = filter.is_between;
            filterObj.start_range = filter.start_range;
            filterObj.end_range = filter.end_range;
            if(filterObj.start_range>filterObj.end_range){
              isValiddate=false;
            }
          }
        }

        filterObj.data_type = filter.data_type;
  
        //For temp
        filterObj.type = filter.type;
        filterObj.label = filter.label;
        filterObj.checkboxes = filter.checkboxes;
  
        resultFilter.push(filterObj);
      }
    });

    let isEmptyFilter:boolean = this.isEmptyFilter();
    if(isValiddate){
      this.viewCtrl.dismiss({
        resultFilter : JSON.parse(JSON.stringify(resultFilter)),
        isEmptyFilter : isEmptyFilter
      })
    }
    else{
      this.showAlert("Can't continue, [Start date] is greather then [End date].");
    }
  }
  showAlert(errorMessage:string){
    let alert = this.alertCtrl.create({
      title: "Information",
      subTitle: errorMessage,
      buttons: [
        {
          text: "Ok",
        }
      ] 
    });

    alert.present();
  }
  showToast(text) {
    let toast = this.toastCtrl.create({
      message: text,
      duration: 15000,
      position: 'top',
      showCloseButton: true,
    });
    toast.present();
  }
  closeModal(){
    this.viewCtrl.dismiss();
  }

  ionViewWillEnter() {
    if (this.auth.loggedIn()) {
      return true;
    } else {
      this.auth.logout();
      this.navCtrl.setRoot("LoginPage");
    }
  }

  //Utils
  isNullOrEmpty(text:any){
    if(text instanceof Array){
      if(text.length == 0){
        return true;
      }
      return false;
    }

    if(text == "" || text == null){
      return true;
    }
    return false;
  }

  isEmptyFilter(){
    let emptyFilter:boolean = true;
    for(let filter of this.filterModel){
      if(this.isFilterNotEmpty(filter)){
        return false;
      }
    };
    return emptyFilter;
  }

  isFilterNotEmpty(filter:IFilterRequest){
    if(this.isCheckboxFilter(filter)){
      if(filter.values != null){
        return true;
      }
      if(filter.values instanceof Array){
        if(filter.values.length > 0){
          return true;
        }
      }
    }else if(this.isRangeFormFilter(filter)){
      if(!this.isNullOrEmpty(filter.start_range) && !this.isNullOrEmpty(filter.end_range)){
        return true;
      }
    }else{
      if(filter.value != null){
        return true;
      }
    }
    return false;
  }

  isCheckboxFilter(filter:IFilterRequest){
    if(filter.type == FILTER.TYPE.CHECKBOXES.SINGLE_SELECTION || filter.type == FILTER.TYPE.CHECKBOXES.MULTIPLE_SELECTION){
      return true;
    }
    return false;
  }

  isRangeFormFilter(filter:IFilterRequest){
    if(filter.type == FILTER.TYPE.INPUT.RANGE.NUMBER || filter.type == FILTER.TYPE.INPUT.RANGE.DATE){
      return true;
    }
    return false;
  }

  changeOperator(filter:IFilterRequest){
    if(filter.operator == "and"){
      filter.operator = "or";
    }else{
      filter.operator = "and";
    }
  }

  changeMode(filter:IFilterRequest){
    if(filter.is_like){
      filter.is_like = false;
      filter.is_equals = true;
    }else{
      filter.is_like = true;
      filter.is_equals = false;
    }
  }
}
