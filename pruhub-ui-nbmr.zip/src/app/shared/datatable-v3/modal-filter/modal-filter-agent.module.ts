import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalFilterAgentPage } from './modal-filter-agent';

@NgModule({
  declarations: [
    ModalFilterAgentPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalFilterAgentPage),
  ],
})
export class ModalFilterAgentPageModule {}
