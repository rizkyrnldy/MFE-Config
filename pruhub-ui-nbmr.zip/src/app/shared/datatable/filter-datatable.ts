export interface DatatableFilter{
    keyFilter:string,
    filterValue:any,
}