export interface PaginationParam{
    itemsPerPage: number,
    rowOfNumberShown:number,
    loadOnPage?: number
}