export interface ReceivedResponse{
    successResponse?:boolean,
    errorResponse?:boolean,
    isEmptyData?:boolean,
    dataAttached?:any
}