import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MutDatatableComponent } from './mut-datatable';
import { MutAutocompleteComponent } from '../autocomplete/mut-autocomplete';
 
@NgModule({
  declarations: [
    MutDatatableComponent,
    MutAutocompleteComponent
  ],
  imports: [
    IonicPageModule.forChild(MutDatatableComponent),
   ],
  exports : [
    MutDatatableComponent,
    MutAutocompleteComponent
   ]
})
export class MutDatatableModule {}
