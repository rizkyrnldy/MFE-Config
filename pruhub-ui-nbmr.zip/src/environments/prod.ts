const env = {
  fcr_wrapperPaymentService: "https://viddclxpwrkap07.pru.intranet.asia/api/v1_0_0/pruhub-client",
  envMode: "master",
}

export default env;
