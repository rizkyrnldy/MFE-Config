const env = {
  fcr_wrapperPaymentService: "https://10.171.86.64/api/v1_0_0/pruhub-wrapper-payment-service",
  envMode: "master",
}

export default env;
