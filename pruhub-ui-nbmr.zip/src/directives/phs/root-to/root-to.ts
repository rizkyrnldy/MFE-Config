import { Directive, Input, HostListener } from '@angular/core';
import { NavController } from 'ionic-angular';

/**
 * Generated class for the RootToDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
@Directive({
  selector: '[root-to]', // Attribute selector
  host: {
    '(click)': '_onClick($event)',
  }
})
export class RootToDirective {

  constructor(private navCtrl: NavController) {}

  @Input('root-to') rootTo; 
  _onClick(e) {
    const rootLink = this.rootTo;
     console.log("CLICK",rootLink)
    this.navCtrl.setRoot(rootLink.target,rootLink.param)
  }

  // @Input() rootTo: any;

  // @HostListener('click')
  //   onclick() {
  //     console.log(this.rootTo)
  //   }

}
