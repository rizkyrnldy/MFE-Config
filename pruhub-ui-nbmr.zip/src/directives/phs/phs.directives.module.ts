import { NgModule } from '@angular/core';
import { RootToDirective } from './root-to/root-to';
@NgModule({
	declarations: [RootToDirective],
	imports: [],
	exports: [RootToDirective]
})
export class PhsDirectivesModule {}
