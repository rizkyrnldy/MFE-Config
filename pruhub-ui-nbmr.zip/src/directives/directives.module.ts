import { NgModule } from '@angular/core';
import { DragNDropDirective } from './enablement/drag-n-drop/drag-n-drop';
@NgModule({
	declarations: [DragNDropDirective],
	imports: [],
	exports: [DragNDropDirective] 
})
export class DirectivesModule {}
